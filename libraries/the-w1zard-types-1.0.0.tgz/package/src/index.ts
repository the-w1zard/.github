export * from './primitives'
export type MaybePromise<R = any> = R;
export function MaybePromise<R = any>(v: R): MaybePromise {// ... IF value does NOT eq undefined, return value otherwise return promise(value)
  return v !== undefined || v != null ? v as R : Promise.resolve(v) as Promise<R>
}

//                                    TYPES
// #region ══════════════════════════════════════════════════════════════════════════════════════════════════════

// #region PRIMITIVE TYPES

const IncantationsConfig: IncantationsConfigCreator = (config) => config;
export type ObjectType = Record<string, IncantationsConfig<any, any, any, any, any, any, any, any, any, any>>;
export type SelfType = { self: any;[category: string]: any };
export type Factory = (ctx: SelfType) => ObjectType


export type AnySelfType = { self: any;[key: string]: any };
export type AnyObject = Record<string, any>;
export type AnyFactory = (ctx: AnySelfType) => AnyObject;
export type AnyType = AnyObject | AnyFactory;


export type incan_vars_obj = Record<string, any>;
export type incan_vars_ctx = { self: any;[category: string]: any };
export type incan_vars_vault_factory = (ctx: incan_vars_ctx) => incan_vars_obj | incan_vars_obj;


export type ArcheTypeCtx = { self: any;[category: string]: any };

export type Boundary = 'same-app' | 'same-node' | 'cross-node'


export  type StubHit = { category: string; key: string; prop: string; location: any };
export const GRAPH_KEYS = ['types', 'enums', 'interfaces', 'generics'] as const;

export  type GraphKey = typeof GRAPH_KEYS[number];
export  type ExtractFactory<A1, A2> =
    A1 extends string
    ? Extract<A2, (...args: any[]) => any>
    : Extract<A1, (...args: any[]) => any>
export interface CloudState {
    get<T>(key: string | symbol): T | undefined;
    set<T>(key: string | symbol, value: T | ((prev: T | undefined) => T)): void;
    subscribe<T>(key: string | symbol, listener: (value: T) => void): () => void;
    clear(): void;
}
export  type ConcentrationGenericsCtx = { self: any;[category: string]: any };
export  type CGFactory = (ctx: ConcentrationGenericsCtx) => Record<string, any>
export  type types<C> = { [K in keyof ReturnType<Extract<C, (...args: any[]) => any>>]: ReturnType<Extract<C, (...args: any[]) => any>>[K] extends { types: infer T } ? T : never }
export  type __location = { file: string; line: number; column: number; functionName: string }
export  type KernelTypeParameter = {
    helpers: {
        generateTypeString: (typeDef: any, paramValues?: Record<string, string>) => string
        validateGenericUsage: (typeDef: any, providedParams: string[]) => boolean
    }
}
export  type arg1<C> = string | C
export  type arg2<C> = C | KernelTypeParameter
export  type concentrationTypeRef =
    | { kind: "Named"; name: string; args?: concentrationTypeRef[] }
    | { kind: "Union"; types: concentrationTypeRef[] }
    | { kind: "Function"; params: { name: string; type: concentrationTypeRef }[]; returnType: concentrationTypeRef }
    | { kind: "Object"; fields: Record<string, { type: concentrationTypeRef; optional?: boolean }> }
export type concentrationGeneric = {
    name: string
    typeParameters: concentrationTypeParameter[]
    signature: concentrationTypeRef // always a Function here
}
export type SubstEnv = Record<string, concentrationTypeRef>




export interface CGInterface<C> {
    arg1: arg1<C>
    arg2?: C | KernelTypeParameter
    arg3?: KernelTypeParameter
}
type concentrationTypeFlags = | "Any" | "Unknown" | "Boolean" | "Number" | "String" | "Object" | "Function" | "TypeParameter" | "Union" | "Intersection"
type concentrationTypeEnv = Record<string, concentrationTypeId>
type concentrationTypeId = string
type concentrationTypeParameter = {
    id: concentrationTypeId
    name: string
    constraint?: concentrationTypeId
    default?: concentrationTypeId
}
type concentrationSignature = {
    typeParameters?: concentrationTypeParameter[]
    parameters: { name: string; type: concentrationTypeId }[]
    returnType: concentrationTypeId
}
type concentrationType = {
    id: concentrationTypeId
    flags: concentrationTypeFlags[]
    name?: string
    signatures?: concentrationSignature[]
    aliasOf?: concentrationTypeId
}



// #endregion ============================================
// #region FUNCTION TYPES
// ============================================
export type vault_source = {
    variants?: Record<string, Record<string, any>>;
    base?: ClassInput;
    slots?: Record<string, ClassInput>;
    compoundVariants?: any[];
    defaultVariants?: Record<string, any>;
    animation?: any;
    aliases?: any;
};
export type base_props = {
    className?: string;
    class?: string;
    children?: any;
    style?: any;
    [key: string]: any;
};


export type ClassInput =
    | string
    | number
    | boolean
    | null
    | undefined
    | ClassInput[]
    | Record<string, boolean | null | undefined>;
export type AsConfig = Record<string, ClassInput>;

export type AnimationVariant = {
    enter?: ClassInput;
    exit?: ClassInput;
    hover?: ClassInput;
    focus?: ClassInput;
    active?: ClassInput;
};

export type MotionVariant = {
    v?: Record<string, any>;
    animate?: Record<string, any>;
    exit?: Record<string, any>;
    transition?: Record<string, any>;
    whileHover?: Record<string, any>;
    whileFocus?: Record<string, any>;
    whileTap?: Record<string, any>;
};


export type AsNode = Record<string, any> & { parent: string };

export type SlotRecord = Record<string, ClassInput>;

export type VariantSchema = Record<string, Record<string, ClassInput>>;



export type AnyVariantSchema =
    | VariantSchema
    | SlotVariantSchema;

export type AnimationPresetMap = Record<
    string,
    AnimationVariant | MotionVariant
>;

export type ExposedVariants = Record<string, VariantGroup>;

// #endregion ============================================
// #region BASE PROPS
// ============================================

export type BaseProps = {
    className?: string;
    class?: string;
    children?: any;
    style?: any;
    [key: string]: any;
};

// #endregion ============================================
// #region VARIANT GROUP
// ============================================

export type VariantGroup = Record<string, ClassInput> & {
    extend: (
        overrides: Record<string, ClassInput>
    ) => Record<string, ClassInput>;
};

// #endregion ============================================
// #region COMPOUND VARIANTS
// ============================================

export type CompoundVariant = {
    variants: Record<string, string>;
    className?: ClassInput;
    style?: A;
    class?: ClassInput;
};

export type SlotVariantSchema1 = Record<
    string,
    Record<string, SlotRecord>
>;

export type SlotVariantSchema = Record<string, Record<string, SlotRecord>>;

export type SlotCompoundVariant = {
    variants?: Record<string, string>;
    slots?: string[];
    class: ClassInput;
};


// #endregion ============================================
// #region STATE MACHINE
// ============================================

export interface StateMachineConfig1 {
    [ComponentVariantKey: string]: {
        v: string;
        transitions: Record<string, string[]>;
        guards?: Record<string, (props: any, prev: string, next: string) => boolean>;
        onEnter?: Record<string, (props: any, prev: string, next: string) => void>;
        onExit?: Record<string, (props: any, prev: string, next: string) => void>;
        onTransition?: (props: any, prev: string, next: string) => void;
    };
}
export interface StateMachineConfig {
    v: string;
    transitions: Record<string, string[]>;
    guards?: Record<string, (props: any, prev: string, next: string) => boolean>;
    onEnter?: Record<string, (props: any, prev: string, next: string) => void>;
    onExit?: Record<string, (props: any, prev: string, next: string) => void>;
    onTransition?: (props: any, prev: string, next: string) => void;
}

// #endregion ============================================
// #region MACHINE TYPES
// ============================================

export type MachineState = {
    currentState: Record<string, string>;
};

export type LogicMachine = {
    [logicalState: string]: {
        ON?: Record<string, string>;
        ASYNC_GUARD?: (props: any) => Promise<any> | boolean;
        actions?: string[];
    };
};

export type MachineRunner = {
    states: Record<string, string>;
    send: (
        variantKey: string,
        event: string,
        currentProps: any
    ) => Record<string, string> | undefined;
};

// #endregion ============================================
// #region VAULT TYPES
// ============================================

export type VaultSource = {
    variants?: Record<string, Record<string, any>>;
    base?: ClassInput;
    slots?: Record<string, ClassInput>;
    compoundVariants?: any[];
    defaultVariants?: Record<string, any>;
    animation?: any;
    aliases?: any;
};

export type VaultEntry = {
    source: VaultSource;
    variants?: { [variantKey: string]: { [entryKey: string]: string } };
};

export type VaultConfig = {
    vault?: VaultEntry;
    [key: string]: IncantationsConfig | VaultEntry | undefined;
};

// #endregion ============================================
// #region FREYR ENUMS
// ============================================

export type FreyrMode = "light" | "dark" | "system" | string;
export type FreyrTheme = "default" | "ocean" | "forest" | "sunset" | string;
export type FreyrVersion = "v1" | "v2" | "v3" | string;
export type FreyrFonts = "sans" | "serif" | "mono" | string;
export type FreyrPresets = "minimal" | "modern" | "vintage" | string;

export type IncantationsFreyrContext = {
    theme: FreyrTheme;
    version: FreyrVersion;
    mode: FreyrMode;
};

export type IncantationsFreyr = {
    mode?: FreyrMode;
    theme?: FreyrTheme;
    version?: FreyrVersion;
    fonts?: FreyrFonts;
    presets?: FreyrPresets;
};

// #endregion ============================================
// #region INCANTATIONS LEVEL 3
// ============================================
export type variant_group = Record<string, ClassInput> & {
    extend: (
        overrides: Record<string, ClassInput>
    ) => Record<string, ClassInput>;
};

export type IncantationsLvl3 = {
    db: any;
    bus: any;
    form: any;
    rdb: any;
    loader: any;
    session_mgmt: any;
    signals: any;
    jobs: any;
    fetch: any;
    sauron: any;
    htmx: any;
    cloud: any;
    cron: any;
    action: any;
    auth: any;
    realtime: any;
    reflect: any;
};
export type vault_entry = {
    source: vault_source;
    variants?: { [variantKey: string]: { [entryKey: string]: string } };
};

// #endregion ============================================
// #region GENERIC INCANTATIONS CONFIG

export type IncantationsConfig<
    S extends string = never,
    V extends Record<string, Record<string, any>> = Record<string, Record<string, any>>,
    T = unknown,
    I = unknown,
    E = unknown,
    C = unknown,
    SP = unknown,
    SO = unknown,
    CL = unknown,
    G = unknown
> = {
    // Identifiers
    __S__?: S;
    __V__?: V;
    __T__?: T;
    __I__?: I;
    __E__?: E;
    __C__?: C;
    __SP__?: SP;
    __SO__?: SO;
    __CL__?: CL;
    __G__?: G;
    // NEED TO WORK ON THESE
    timeMachine?: any
    useMachine?: any
    useTimeMachine?: any
    logicMachine?: any
    inlineStyles?: any
    theme?: any
    className?: any
    preset?: any
    __Incantations__?: any
    meta?: any
    staticMeta?: any
    machinesMachine?: any
    router?: any


    // Types
    enums?: E;
    types?: T;
    interfaces?: I;
    generics?: G;

    interface?: I;
    enum?: I;

    // Styles
    styles?: {
        base?: A;
        variants?: Record<string, Record<string, A>>;
        defaultVariants?: Record<string, string>;
    };
    slots?: Record<S, ClassInput>;
    // Freyr & Global
    global?: () => G;
    freyrClasses?: string;
    freyrIncantations?: A;
    __globalContent?: Record<string, any>;
    __isGlobalized__?: boolean;
    freyr?: IncantationsFreyr | ((props: any) => any);
    classNames?: any;
    customTheme?: any;
    customCSS?: any;
    // Variants
    variants?: V;
    compoundVariants?: S extends never ? CompoundVariant[] : SlotCompoundVariant[];
    defaultVariants?: { [K in keyof V]?: keyof V[K] };
    base?: ClassInput;

    // Animations
    animation?: S extends never
    ? AnimationVariant | AnimationPresetMap
    : Record<S, AnimationVariant> | undefined;
    transition?: S extends never
    ? AnimationVariant | AnimationPresetMap
    : Record<S, AnimationVariant> | undefined;

    // Extend & Sync
    extend?: string;
    cloud?: CL;
    sync?: string;
    master?: boolean;

    // Context
    context?: (props: any) => any;
    useContext?: any;
    createContext?: any;
    sauronContext?: any;
    reactContext?: any;
    useReactContext?: any;
    _compiledReactContext?: any;

    // State Machines
    stateMachine?: { [K in keyof V]?: StateMachineConfig; };
    __logicMachineRunner?: any;
    getLogicState?: () => Record<string, string>;
    __machineRunner?: MachineRunner | null;
    getMachineState?: () => Record<string, string>;
    variantMachine?: any;



    // As
    as?: AsConfig;
    asName?: string;

    // Singles
    aliases?: { [K in keyof V]?: Record<string, keyof V[K]> };

    // Constants & Specs
    constants?: C;
    specs?: SP;
    source?: SO;

    // Documentation
    docs?: {
        [K in keyof V]?: {
            description?: string;
            values?: { [J in keyof V[keyof V]]?: string };
        };
    } & { description?: string };

    // Dev Tools
    __location?: {
        file: string;
        line: number;
        column: number;
        functionName: string;
    };
    __definitionName?: string;
    __concentrationEnumGraph?: Record<string, TypeGraph>;
    __concentrationInterfaceGraph?: Record<string, TypeGraph>;
    __concentrationGenericGraph?: Record<string, TypeGraph>;
    __IncantationsTypeGraph?: Record<string, TypeGraph>;
};
// #endregion ============================================
// #region TypeGraph  - Complete Type Introspection System

export type TypeFlags =
    | "Any"
    | "Unknown"
    | "Boolean"
    | "Number"
    | "String"
    | "Object"
    | "Array"
    | "Function"
    | "TypeParameter"
    | "Union"
    | "Intersection"
    | "Literal"
    | "Enum"
    | "Interface"
    | "Class"
    | "Generic"
    | "Record"
    | "Tuple"
    | "Optional"
    | "Nullable"
    | "Readonly";

export type TypeGraph = {
    // Core identification
    id?: string;
    name?: string;
    type: TypeFlags;
    kind?: "primitive" | "composite" | "reference" | "generic";

    // Value representation
    value?: any;
    defaultValue?: any;

    // Type structure
    properties?: Record<string, TypeGraph>;
    elements?: TypeGraph[];
    indexSignature?: TypeGraph;

    // Type parameters (generics)
    typeParameters?: TypeGraph[];
    typeArguments?: TypeGraph[];
    constraint?: TypeGraph;

    // Union/Intersection members
    unionMembers?: TypeGraph[];
    intersectionMembers?: TypeGraph[];

    // Function types
    parameters?: TypeGraph[];
    returnType?: TypeGraph;
    isAsync?: boolean;

    // Class/Interface
    extends?: TypeGraph[];
    implements?: TypeGraph[];
    constructors?: TypeGraph[];
    methods?: Record<string, TypeGraph>;
    accessors?: Record<string, TypeGraph>;

    // Enum
    enumMembers?: Record<string, string | number>;
    isStringEnum?: boolean;
    isNumericEnum?: boolean;

    // Record types
    keyType?: TypeGraph;
    valueType?: TypeGraph;

    // Tuple
    tupleElements?: TypeGraph[];
    isFixedLength?: boolean;
    restElement?: TypeGraph;

    // Modifiers
    isOptional?: boolean;
    isNullable?: boolean;
    isReadonly?: boolean;
    isAbstract?: boolean;
    isStatic?: boolean;

    // Generic constraints
    extendsConstraint?: TypeGraph;
    defaultType?: TypeGraph;

    // Metadata
    description?: string;
    tags?: Record<string, any>;
    source?: {
        file: string;
        line: number;
        column: number;
    };

    // Dependencies
    imports?: Record<string, string[]>;
    exports?: string[];
    references?: TypeGraph[];

    // Runtime info
    runtimeType?: any;
    validator?: (value: any) => boolean;
    serializer?: (value: any) => any;
    deserializer?: (value: any) => any;

    // Graph relationships
    parent?: TypeGraph;
    children?: TypeGraph[];
    dependencies?: TypeGraph[];

    // Custom metadata
    metadata?: Record<string, any>;

    // Timestamps
    createdAt?: Date;
    updatedAt?: Date;
    version?: string;
};

// #endregion ============================================
// #region TYPE GRAPH UTILITIES
// ============================================

// Helper to create primitive types
export function createPrimitiveGraph(
    type: "String" | "Number" | "Boolean" | "Any" | "Unknown" | "Object",
    options?: Partial<TypeGraph>
): TypeGraph {
    return {
        type,
        kind: "primitive",
        ...options
    };
}

// Helper to create object type
export function createObjectGraph(
    properties: Record<string, TypeGraph>,
    options?: Partial<TypeGraph>
): TypeGraph {
    return {
        type: "Object",
        kind: "composite",
        properties,
        ...options
    };
}

// Helper to create array type
export function createArrayGraph(
    elementType: TypeGraph,
    options?: Partial<TypeGraph>
): TypeGraph {
    return {
        type: "Array",
        kind: "composite",
        elements: [elementType],
        ...options
    };
}

// Helper to create union type
export function createUnionGraph(
    members: TypeGraph[],
    options?: Partial<TypeGraph>
): TypeGraph {
    return {
        type: "Union",
        kind: "composite",
        unionMembers: members,
        ...options
    };
}

// Helper to create function type
export function createFunctionGraph(
    parameters: TypeGraph[],
    returnType: TypeGraph,
    options?: Partial<TypeGraph>
): TypeGraph {
    return {
        type: "Function",
        kind: "composite",
        parameters,
        returnType,
        ...options
    };
}

// Helper to create generic type
export function createGenericGraph(
    name: string,
    typeParameters: TypeGraph[],
    constraint?: TypeGraph,
    options?: Partial<TypeGraph>
): TypeGraph {
    return {
        type: "Generic",
        kind: "generic",
        name,
        typeParameters,
        constraint,
        ...options
    };
}

// #endregion ============================================
// #region TYPE GRAPH PREDICATES
// ============================================

export type TypeGraphPredicates = {
    isPrimitive: (graph: TypeGraph) => boolean;
    isComposite: (graph: TypeGraph) => boolean;
    isGeneric: (graph: TypeGraph) => boolean;
    isUnion: (graph: TypeGraph) => boolean;
    isIntersection: (graph: TypeGraph) => boolean;
    isObject: (graph: TypeGraph) => boolean;
    isArray: (graph: TypeGraph) => boolean;
    isFunction: (graph: TypeGraph) => boolean;
    isEnum: (graph: TypeGraph) => boolean;
    isOptional: (graph: TypeGraph) => boolean;
    isNullable: (graph: TypeGraph) => boolean;
};

// #endregion ============================================
// #region TYPE GRAPH TRANSFORMERS
// ============================================

export type TypeGraphTransformers = {
    // Traverse graph
    traverse: (
        graph: TypeGraph,
        visitor: (node: TypeGraph) => void
    ) => void;

    // Find nodes
    findNodes: (
        graph: TypeGraph,
        predicate: (node: TypeGraph) => boolean
    ) => TypeGraph[];

    // Transform nodes
    mapNodes: (
        graph: TypeGraph,
        mapper: (node: TypeGraph) => TypeGraph
    ) => TypeGraph;

    // Collect types
    collectTypes: (graph: TypeGraph) => Set<TypeFlags>;

    // Resolve references
    resolveReferences: (
        graph: TypeGraph,
        context: Record<string, TypeGraph>
    ) => TypeGraph;

    // Validate
    validate: (
        graph: TypeGraph,
        value: any
    ) => boolean;
};


// #endregion ============================================
// #region EXAMPLE USAGE
// ============================================

// Example: Build a type graph for a config
const stringType = createPrimitiveGraph("String");
const numberType = createPrimitiveGraph("Number");
const booleanType = createPrimitiveGraph("Boolean");

const variantSchemaGraph = createObjectGraph({
    size: createUnionGraph([
        createPrimitiveGraph("String", { value: "small" }),
        createPrimitiveGraph("String", { value: "large" })
    ]),
    color: createUnionGraph([
        createPrimitiveGraph("String", { value: "red" }),
        createPrimitiveGraph("String", { value: "blue" })
    ])
});

const configGraph: TypeGraph = {
    type: "Interface",
    kind: "composite",
    name: "IncantationsConfig",
    properties: {
        variants: variantSchemaGraph,
        defaultVariants: createObjectGraph({
            size: createPrimitiveGraph("String", { defaultValue: "small" })
        })
    },
    typeParameters: [
        {
            type: "TypeParameter",
            name: "S",
            constraint: createPrimitiveGraph("String")
        },
        {
            type: "TypeParameter",
            name: "V",
            constraint: createPrimitiveGraph("Object")
        }
    ]
};
// #endregion ============================================
// #region IncantationsConfigCreator
export type IncantationsConfigCreator = <
    S extends string = never,
    V extends Record<string, Record<string, any>> = Record<string, Record<string, any>>,
    T = unknown,
    I = unknown,
    E = unknown,
    C = unknown,
    SP = unknown,
    SO = unknown,
    CL = unknown,
    G = unknown
>(
    config: IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>
) => IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>;

// #endregion ============================================
// #region AllIncantationTypes
export type AllIncantationTypes = {
    ClassInput: ClassInput;
    AnimationVariant: AnimationVariant;
    MotionVariant: MotionVariant;
    AsConfig: AsConfig;
    AsNode: AsNode;
    SlotRecord: SlotRecord;
    VariantSchema: VariantSchema;
    SlotVariantSchema: SlotVariantSchema;
    AnyVariantSchema: AnyVariantSchema;
    AnimationPresetMap: AnimationPresetMap;
    ExposedVariants: ExposedVariants;
    BaseProps: BaseProps;
    VariantGroup: VariantGroup;
    CompoundVariant: CompoundVariant;
    SlotCompoundVariant: SlotCompoundVariant;
    StateMachineConfig: StateMachineConfig;
    MachineState: MachineState;
    LogicMachine: LogicMachine;
    MachineRunner: MachineRunner;
    VaultSource: VaultSource;
    VaultEntry: VaultEntry;
    VaultConfig: VaultConfig;
    IncantationsFreyrContext: IncantationsFreyrContext;
    IncantationsFreyr: IncantationsFreyr;
    IncantationsLvl3: IncantationsLvl3;
    TypeFlags: TypeFlags;
    IncantationsConfig: IncantationsConfig;
};

// #endregion ============================================

// #endregion ============================================
// #region INFER INCANTATIONS CONFIG
// ============================================

export type InferIncantationsConfig = <
    Cfg extends {
        __S__?: any;
        __V__?: any;
        __T__?: any;
        __I__?: any;
        __E__?: any;
        __C__?: any;
        __SP__?: any;
        __SO__?: any;
        __CL__?: any;
        __G__?: any;
    }
>(
    config: Cfg
) => {
    S: Cfg["__S__"];
    V: Cfg["__V__"];
    T: Cfg["__T__"];
    I: Cfg["__I__"];
    E: Cfg["__E__"];
    C: Cfg["__C__"];
    SP: Cfg["__SP__"];
    SO: Cfg["__SO__"];
    CL: Cfg["__CL__"];
    G: Cfg["__G__"];
    Config: Cfg;
};

// #endregion ============================================
// #region VARIANT PROPS
// ============================================

export type VariantProps = {
    [key: string]: any;
    animation?: string;
    preset?: string;
    class?: any;
    className?: any;
    __instanceId__?: string;
    freyr?: FreyrConfig | ((props: any) => any);
};

export type FreyrConfig = {
    mode?: FreyrMode;
    theme?: FreyrTheme;
    version?: FreyrVersion;
    fonts?: FreyrFonts;
    presets?: FreyrPresets;
};


// #endregion ============================================
// #region SLOTTED RESULT
// ============================================

export type SlottedResult<S extends string = string> = {
    [K in S]?: string;
} & {
    className?: string;
    class?: string;
    [key: string]: any;
};
// #endregion ============================================
// #region NAMESPACE AUGMENT
// ============================================

export type NamespaceAugment = any; // Define based on your implementation

// #endregion ============================================
// #region INCANTATIONS RESULT
// ============================================

// ============================================
// INCANTATIONS RESULT - Complete Type 
// (ALL properties from IncantationsConfig + React additions)
// ============================================

// ============================================
// INCANTATIONS RESULT - Fixed with proper constraints
// ============================================

export type IncantationsResult<
    S extends string = never,
    V extends Record<string, Record<string, any>> = Record<string, Record<string, any>>,
    T = unknown,
    I = unknown,
    E = unknown,
    C = unknown,
    SP = unknown,
    SO = unknown,
    CL = unknown,
    G = unknown
> = {
    // ── THE MAIN FUNCTION ────────────────────────────────────────────────────
    (props?: VariantProps & T & {
        animation?: keyof AnimationVariant | string;
        preset?: string;
        class?: any;
        className?: any;
        __instanceId__?: string;
        freyr?: FreyrConfig | ((props: any) => any);
    }): string;

    // ── IDENTIFIERS ──────────────────────────────────────────────────────────
    __S__?: S;
    __V__?: V;
    __T__?: T;
    __I__?: I;
    __E__?: E;
    __C__?: C;
    __SP__?: SP;
    __SO__?: SO;
    __CL__?: CL;
    __G__?: G;

    // ── TYPES ──────────────────────────────────────────────────────────────
    enums?: E;
    types?: T;
    interfaces?: I;
    generics?: G;

    // ── STYLES ──────────────────────────────────────────────────────────────
    styles?: {
        base?: A;
        variants?: Record<string, Record<string, A>>;
        defaultVariants?: Record<string, string>;
    };
    slots?: Record<S, ClassInput>;
    base?: ClassInput;

    // ── VARIANTS ──────────────────────────────────────────────────────────────
    variants?: V;
    compoundVariants?: S extends never ? CompoundVariant[] : SlotCompoundVariant[];
    defaultVariants?: { [K in keyof V]?: keyof V[K] };

    // ── ANIMATIONS ──────────────────────────────────────────────────────────
    animation?: S extends never
    ? AnimationVariant | AnimationPresetMap
    : Record<S, AnimationVariant> | undefined;
    transition?: S extends never
    ? AnimationVariant | AnimationPresetMap
    : Record<S, AnimationVariant> | undefined;

    // ── EXTEND & SYNC ──────────────────────────────────────────────────────
    extend?: string;
    cloud?: CL;
    sync?: string;
    master?: boolean;

    // ── CONTEXT ──────────────────────────────────────────────────────────────
    context?: (props: any) => any;
    useContext?: any;
    createContext?: any;
    sauronContext?: any;
    reactContext?: any;
    _compiledReactContext?: any;

    // ── STATE MACHINES ────────────────────────────────────────────────────
    stateMachine?: {
        [K in keyof V]?: StateMachineConfig;
    };
    logicMachine?: LogicMachine;
    __logicMachineRunner?: any;
    getLogicState?: () => Record<string, string>;
    __machineRunner?: MachineRunner | null;
    getMachineState?: () => Record<string, string>;
    variantMachine?: any;

    // ── FREYR & GLOBAL ──────────────────────────────────────────────────────
    global?: () => G;
    freyrClasses?: string;
    freyrIncantations?: A;
    __globalContent?: Record<string, any>;
    __isGlobalized__?: boolean;
    freyr?: IncantationsFreyr | ((props: any) => any);
    classNames?: any;
    customTheme?: any;
    customCSS?: any;

    // ── AS ──────────────────────────────────────────────────────────────────
    as?: AsConfig;
    asName?: string;

    // ── SINGLES ──────────────────────────────────────────────────────────────
    aliases?: { [K in keyof V]?: Record<string, keyof V[K]> };

    // ── CONSTANTS & SPECS ──────────────────────────────────────────────────
    constants?: C;
    specs?: SP;
    source?: SO;

    // ── DOCUMENTATION ──────────────────────────────────────────────────────
    docs?: {
        [K in keyof V]?: {
            description?: string;
            values?: { [J in keyof V[keyof V]]?: string };
        };
    } & { description?: string };

    // ── DEV TOOLS ──────────────────────────────────────────────────────────
    __location?: {
        file: string;
        line: number;
        column: number;
        functionName: string;
    };
    __definitionName?: string;
    __concentrationEnumGraph?: Record<string, TypeGraph>;
    __concentrationInterfaceGraph?: Record<string, TypeGraph>;
    __concentrationGenericGraph?: Record<string, TypeGraph>;
    __IncantationsTypeGraph?: Record<string, TypeGraph>;

    // ── REACT CONTEXT (Added by wizard template) ──────────────────────────
    ReactContext: A;
    createReactContext: (props?: any) =>A;
    useReactContext: () => any;

    // ── SUB-COMPONENT UTILITIES ─────────────────────────────────────────────
    extendResult: (
        overrides: Partial<IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>>
    ) => IncantationsResult<S, V, T, I, E, C, SP, SO, CL, G>;
};
// #endregion ============================================
// #region INCANTATIONS RESULT CREATOR
// ============================================

export type IncantationsResultCreator = <
    S extends string = never,
    V extends AnyVariantSchema = any,
    T = unknown,
    I = unknown,
    C = unknown,
    SP = unknown,
    SO = unknown,
    CL = unknown,
    E = unknown,
    G = unknown
>(
    config: ((
        props?: VariantProps & T & {
            animation?: keyof AnimationVariant | string;
            preset?: string;
            class?: any;
            className?: any;
            __instanceId__?: string;
            freyr?: FreyrConfig | ((props: any) => any);
        }
    ) => string) & {
        // ── CORE HOOKS & PROCESSING ENGINE ──────────────────────────────────────
        slots: (
            props?: VariantProps & {
                preset?: string;
                class?: Partial<Record<S, ClassInput>>;
                className?: Partial<Record<S, ClassInput>>;
                __instanceId__?: string;
                freyr?: FreyrConfig | ((props: any) => any);
            }
        ) => SlottedResult<S>;

        // ── THE INLINE STYLES SYSTEM ───────────────────────────────────────────
        styles?: Record<string, any>;
        inlineStyles?: A;
        freyrClasses?: string;
        freyrIncantations?: A;
        classNames?: any;
        customTheme?: any;
        customCSS?: any;

        // ── BLUEPRINT ECHOES (CONFIG TO RESULT COPIES) ───────────────────────────
        types: T;
        interface: I;
        enum: E;
        constants: C;
        specs: SP;
        source: SO;
        cloud: CL;
        as: AsConfig;
        variants: ExposedVariants;
        compoundVariants?: any[];
        defaultVariants?: Record<string, any>;
        aliases?: Record<string, string>;
        docs?: string;

        // ── ADVANCED NESTED ENGINES ──────────────────────────────────────────────
        variantMachine?: Record<string, any>;
        transition?: {
            show?: Record<string, any>;
            hide?: Record<string, any>;
            [key: string]: any;
        };

        // ── SYSTEM MIGRATION & REACTION THREADS ──────────────────────────────────
        sync?: string;
        master?: boolean;
        context: (props: any, __sauron_id__?: string) => I;
        createContext?: any;
        sauronContext?: any;
        global: NamespaceAugment;

        // ── STATE ENGINE ACCESSORS (EXPOSED RUNTIMES) ────────────────────────────
        stateMachine?: Record<string, any>;
        logicMachine?: Record<string, any>;
        __machineRunner?: any;
        __logicMachineRunner?: any;
        getMachineState?: () => Record<string, any>;
        getLogicState?: () => Record<string, any>;
        useMachine?: (props?: any) => {
            state: Record<string, any>;
            setState: (key: string, value: any) => void;
        } & Record<string, (value: any) => void>;

        // ── GLOBALIZATION & COMPILER PROFILES ────────────────────────────────────
        __globalContent?: any;
        __isGlobalized__?: boolean;
        __location: string;
        __definitionName: string;

        // ── SUB-COMPONENT UTILITIES ─────────────────────────────────────────────
        extend: (
            overrides: Partial<IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>>
        ) => IncantationsResult<S, V, T, I, C, SP, SO, CL, E, G>;
    }
) => IncantationsResult<S, V, T, I, C, SP, SO, CL, E, G>;


// #endregion ============================================



















export interface SyncStreamOptions665 {
    /** Max unacknowledged in-flight payloads before the sender backs off. */
    windowSize?: number;
    /** Retransmit timeout per in-flight seq (default 5s). Keeps a lost ack from wedging the window. */
    retransmitMs?: number;
}
export type SBackpressureStrategy665 = "drop" | "pause" | "error";
export interface StreamRelayOptions665 {
    maxSubscribers?: number;
    bufferSize?: number;
    backpressureStrategy?: SBackpressureStrategy665;
}
export interface PipelineStage665<T> {
    name: string;
    handler: (data: T) => T | Promise<T>;
    errorHandler?: (err: Error, data: T) => T | Promise<T>;
}
export type PipelineEvent665<T> = | { type: "stage:enter"; stage: string; data: T } | { type: "stage:exit"; stage: string; data: T } | { type: "error"; stage: string; data?: T; error: string };
export interface MeshOptions665 {
    peerId?: string;
    announceInterval?: number; // ms
    peerTimeout?: number;      // ms — peer considered stale
    maxPeers?: number;
}
export interface MeshPeer665<TMeta extends Record<string, unknown> = Record<string, unknown>> {
    id: string;
    metadata: TMeta;
    latency: number;
    lastSeen: number;
}
export interface MeshMessage665<T> {
    from: string;
    p: T;
    timestamp: number;
}
export interface MeshState665 {
    peerId: string;
    peers: Array<{ id: string; metadata: Record<string, unknown> }>;
    meshSize: number;
}
export interface PlinkoContext665<TState, TPayload> {
    state: TState;
    p: TPayload;
    path: string[];
    metadata: Map<string, any>;
    reply: (data: unknown, targetSc?: string) => Promise<unknown>;
    abort: (reason?: string) => never;
    send?(rt: string, p: unknown): void;
}
export interface PlinkoNode665<TState, TPayload> {
    matcher: (p: TPayload, ctx: PlinkoContext665<TState, TPayload>) => boolean | Promise<boolean>;
    execute?: (p: TPayload, ctx: PlinkoContext665<TState, TPayload>) => unknown | Promise<unknown>;
    branches?: Record<string, PlinkoNode665<TState, TPayload>>;
    hooks?: {
        beforeEnter?: (p: TPayload, ctx: PlinkoContext665<TState, TPayload>) => void | Promise<void>;
        afterExit?: (result: unknown, ctx: PlinkoContext665<TState, TPayload>) => void | Promise<void>;
    };
}
export type PlinkoTree665<TState, TPayload> = Record<string, PlinkoNode665<TState, TPayload>>;
export interface PlinkoOptions665<TState = any, TPayload = any> {
    autoResetOnTerminal?: boolean;
    onTransition?: (from: string[], to: string[], p: TPayload) => void;
    onError?: (err: Error, path: string[], p: TPayload) => void;
}
export interface PlinkoEvaluation665<TState, TPayload> {
    success: boolean;
    path: string[];
    result: unknown;
    terminal: boolean;
    state?: TState;
    metadata?: Map<string, any>;
}
export interface PlinkoHandle665<TState, TPayload> {
    evaluate(p: TPayload, replyFn?: (data: unknown, targetSc?: string) => Promise<unknown>): Promise<PlinkoEvaluation665<TState, TPayload>>;
    getState(): TState;
    getPath(): string[];
    reset(): void;
}
export interface SwitchboardContext665<TPayload> {
    p: TPayload;
    reply: (data: unknown) => Promise<unknown>;
    store: Map<string, any>;
}
export interface SSwitchboardResult665 {
    success: boolean;
    matchedKey: string | null;
    unmatched: boolean;
    result?: unknown;
    error?: Error;
}
export interface SwitchboardRoute665<TPayload> {
    (p: TPayload, ctx: SwitchboardContext665<TPayload>): unknown;
}
export type SwitchboardRoutes665<TPayload, TKey extends string = string> = { [K in TKey]?: SwitchboardRoute665<TPayload> | "unmatched"; } & { default?: SwitchboardRoute665<TPayload> };
export interface SwitchboardOptions665<TPayload, TKey extends string = string> {
    rt?: string;
    subrt?: string;
    selectKey: (p: TPayload) => TKey;
    onUnmatched?: (p: TPayload, key: string) => void;
    onDispatch?: (route: string, p: TPayload, result: unknown) => void;
}
export interface CRDTStateHook665<S> {
    (v: S): [S, (patch: unknown) => void];
}
export interface StreamLabOptions665 {
    /** Route all bus traffic through the flood-gate transport fabric. */
    floodGates?: boolean;
    /** Transport provider for flood gates (memory by default in the VM). */
}
export interface Outbound {
    seq: number;
    p: unknown;
    acked: boolean;
    sentAt: number;
    timer?: ReturnType<typeof setTimeout>;
}
export interface SyncStreamHandler665 {
    onOrdered: (cb: (p: unknown, seq: number) => void) => void;
    onComplete: (cb: () => void) => void;
    close: () => void;
}
export type SignalKey = any;

export type AlienSignal<T> = {
    (): T;
    (next: T): void;
    peek?: () => T;
};
export type Change<T> = {
    key: SignalKey;
    previous: T;
    current: T;
    version: number;
    timestamp: number;
    source?: string;
};
export type AtomContract<T> = {
    name: string;
    postcondition: (next: T, previous: T) => boolean;
    block: boolean;
};
export type SyncJob = () => void;
export type AsyncEffectJob = {
    id: string;
    priority: number;
    run: () => void | Promise<void>;
    retry?: number;
    timeout?: number;
};
export type Unsubscribe = () => void;
export type ConflictMeta = { at: number; node: string; userId?: string };
export type ConflictEnvelope<T = any> = { value: T; meta: ConflictMeta };
export type ConflictStrategy<T = any> = | 'lww' | 'merge' | { priority: string[] } | ((local: ConflictEnvelope<T> | undefined, remote: ConflictEnvelope<T>) => ConflictEnvelope<T>);

export interface SHADOW_FN {
    <T = any>(
        v: T | (() => T),
        key: string,
        sl?: string | undefined,
        ms?: string | undefined,
        rt?: string | undefined,
    ): {
        get: () => T;
        set: (value: T | ((prev: T) => T)) => void;
        subscribe: (fn: (value: T) => void) => () => void;
        destroy: () => void;
        exists: () => boolean;
    };

    use<T>(
        v: T | (() => T),
        key: string,
        sl?: string | undefined,
        ms?: string | undefined,
        rt?: string | undefined,
    ): readonly [T, (value: T | ((prev: T) => T)) => void];

    withTTL<T>(
        v?: T | (() => T),
        k?: string | undefined,
        sl?: string | undefined,
        ms?: string | undefined,
        rt?: string | undefined,
        ttlMs?: number,
    ): {
        get: () => T | null;
        set: (value: T | ((prev: T) => T)) => void;
        subscribe: (fn: (value: T | null) => void) => () => void;
        refresh: () => void;
        destroy: () => void;
        exists: () => boolean;
        getTimeRemaining: () => number;
    };

    batch<T extends Record<string, any>>(
        v: T,
        options?: { debounceMs?: number },
        key?: string | undefined,
        sl?: string | undefined,
        ms?: string | undefined,
        rt?: string | undefined,
    ): {
        get: () => T;
        set: (updates: Partial<T> | ((prev: T) => Partial<T>)) => void;
        subscribe: (fn: (value: T) => void) => () => void;
        flush: () => void;
    };
}
export interface PORTAL_FN {
    (k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    use(v?: any, k?: SU, sl?: string, ms?: string, rt?: string): any;
    crdt(v?: any, k?: SU, sl?: string, ms?: string, rt?: string, trigger_render?: boolean, nodeId?: any): any;
    umbrella(v: Record<string, any> | undefined, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, trigger_render?: boolean): any;
    effect(effect: () => void | (() => void), k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, deps?: any[]): void;
    context: {
        (v: Record<string, any>, k: string, sl: string, ms: string, rt: string, trigger_render: boolean): any;
    };
    state: {
        (v?: any, k?: SU, sl?: string, ms?: string, rt?: string): any;
        use(v?: any, k?: SU, sl?: string, ms?: string, rt?: string, trigger_render?: boolean): any;
    };
    store: {
        (v?: any | (() => any), key?: string | undefined, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
        use(v?: any | (() => any), key?: string | undefined, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, trigger_render?: boolean): any;
    };
}
export type StateMeshReactor<T = any, A = any> = (state: T, action: A, snapshot: T) => T;
export type StateMeshUpdater<T> = T | ((current: T) => T);
export interface StateMesh<T = any, A = any> {
    state: T;
    snapshot(): T;
    set(next: StateMeshUpdater<T>): void;
    transition: <B = A>(action: B, reactor?: StateMeshReactor<T, B>) => void;

    commit(): void;
    rollback(): void;
}
export type SamplingRate = {
    numerator: number;
    denominator: number;
};
export type ProbabilisticSampling = {
    version: 1;
    algorithm: 'fnv1a64';
    seed: string;
    rate: SamplingRate;
    namespace: string;
};
export type ProbabilisticOptions<T> = {
    // Exact probability as a fraction. { numerator: 1, denominator: 10 } means keep approximately 10%. Avoids float ambiguity across runtimes.
    rate: SamplingRate;
    // Shared deterministic seed. Same seed + namespace + key = same sampling decision.
    seed: string | number;

    // Stable identity of the logical item. Must remain unchanged across producer, consumer, retries, replay, reconnects, and process restarts. Prefer event ID / record ID / trace ID.
    key: (chunk: T, index: number) => string;
    // Separates unrelated sampled populations that happen to use the same seed. Keep this constant on both ends.

    namespace?: string;
};
export type ProbabilisticSender = (
    p: any,
    onChunk: (chunk: any) => void,
    k: string,
    sl?: SU,
    ms?: SU,
    rt?: SU,
    chain?: 'chain' | 'rechain',
    binary?: boolean,
) => Promise<void>;
export type SamplingEnvelope<T> = {
    __probabilistic: ProbabilisticSampling;
    data: T;
};
export type SamplingConfig = {
    version?: 1;
    rate: number; // 0..1
    seed: string | number;
    algorithm?: 'fnv1a64';
};

export type StreamEncoding = 'json' | 'msgpack' | 'binary';
export type StreamRetryMode = | 'none' | 'at-least-once' | 'idempotent';
export type StreamContractOffer = {
    protocol: 'stream-contract';
    version: 1;

    schemas: readonly string[];
    encodings: readonly StreamEncoding[];

    limits: {
        maxChunkBytes: number;
        maxInFlightChunks: number;
        maxInFlightBytes?: number;
    };

    retry: {
        modes: readonly StreamRetryMode[];
        maxAttempts: number;
    };

    capabilities?: Record<string, boolean>;
};
export type NegotiatedStreamContract = {
    protocol: 'stream-contract';
    version: 1;

    schema: string;
    encoding: StreamEncoding;

    limits: {
        maxChunkBytes: number;
        maxInFlightChunks: number;
        maxInFlightBytes?: number;
    };

    retry: {
        mode: StreamRetryMode;
        maxAttempts: number;
    };

    capabilities: Record<string, boolean>;
};
export type NegotiationChunk =
    | {
        type: 'negotiate.accept';
        contract: NegotiatedStreamContract;
    }
    | {
        type: 'negotiate.reject';
        code: string;
        message: string;
    };
export type ConstellationFailureMode2 = 'continue' | 'fail-fast';
export type ConstellationMember2 = {
    id: string;
    p: any;
    k: string;
    sl?: SU;
    ms?: SU;
    rt?: SU;
    binary?: boolean;

    /**
     * Relative scheduling priority.
     * 1 = one turn, 2 = two turns, etc.
     */
    weight?: number;
};
export type ConstellationChunk2 = {
    memberId: string;
    chunk: any;
    receivedAt: number;
};
export type ConstellationMemberStatus2 = | 'running' | 'done' | 'error' | 'removed';
export type ConstellationMemberSnapshot2 = {
    id: string;
    status: ConstellationMemberStatus2;
    queuedChunks: number;
    error?: Error;
};
export type ConstellationStrategy = | 'round-robin' | 'weighted' | 'least-busy' | 'first-alive';
export type ConstellationFailover = | 'next-member' | 'retry-same' | 'abort';
export type ConstellationOptions2 = {
    failure?: ConstellationFailureMode2;
    maxQueuedChunksPerMember?: number;
    onMemberStatus?: (
        member: ConstellationMember,
        status: ConstellationMemberStatus,
        error?: Error,
    ) => void;

    // ---- from constellation3 ----
    /** Selection strategy for picking the next ready member. Default: 'weighted'. */
    strategy?: ConstellationStrategy;

    /** What to do when a member's stream throws or rejects. Default: 'next-member'. */
    failover?: ConstellationFailover;

    /** Max retries before giving up (used by 'retry-same' and 'next-member'). Default: 2. */
    maxRetries?: number;

    /** How many consecutive failures before a member is marked unhealthy. Default: 3. */
    unhealthyAfterFailures?: number;

    /** Interval (ms) for the health/idle sweep. 0 disables. Default: 5_000. */
    healthCheckMs?: number;

    /** Evict idle members after this many ms of no use. 0 disables. Default: 0. */
    idleEvictMs?: number;

    /** Called when a member joins the constellation. */
    onMemberJoin?: (member: ConstellationMember) => void;

    /** Called when a member leaves (manual, idle, or error). */
    onMemberLeave?: (
        member: ConstellationMember,
        reason?: 'error' | 'manual' | 'idle',
    ) => void;

    /** Called when a failover occurs: `to` is null if no successor was available. */
    onFailover?: (
        from: ConstellationMember,
        to: ConstellationMember | null,
        error: unknown,
    ) => void;
};
export type ConstellationHandle2 = {
    readonly done: Promise<void>;

    join(member: ConstellationMember2): void;

    /**
     * Stops forwarding output from this member.
     * This does not mutate or depend on your existing fn implementation.
     */
    remove(memberId: string): boolean;

    /**
     * Stops forwarding all future output and rejects `done`.
     */
    abort(reason?: unknown): void;

    members(): readonly ConstellationMemberSnapshot2[];
    setHealth(memberId: any, healthy: any): any
    on(event: string, handler: (e: Event) => void): any
    dispose(): any
};
export type ConstellationFactory2 = (options?: ConstellationOptions2,) => (onChunk?: (event: ConstellationChunk2) => void,) => ConstellationHandle2;
export type ConstellationFactory = (options?: ConstellationOptions,) => (onChunk?: (event: ConstellationChunk) => void,) => ConstellationHandle
export type ConstellationOptions = {
    strategy?: 'round-robin' | 'weighted' | 'least-busy' | 'first-alive'
    failure?: 'continue' | 'fail-fast'
    maxQueuedChunksPerMember?: number
    maxRetries?: number
    onMemberStatus?: (
        member: ConstellationMember,
        status: ConstellationMemberStatus,
        error?: Error,
    ) => void
    onFailover?: (
        from: ConstellationMember,
        to: ConstellationMember | null,
        error: unknown,
    ) => void
}
export type ConstellationMember = {
    id: string
    p: any
    k: string
    sl?: SU
    ms?: SU
    rt?: SU
    binary?: boolean
    weight?: number
}
export type ConstellationMemberStatus = | 'running' | 'done' | 'error' | 'removed'
export type ConstellationChunk = {
    memberId: string
    chunk: any
    receivedAt: number
}
export type ConstellationHandle = {
    done: Promise<void>

    join(member: ConstellationMember): void

    remove(memberId: string): boolean

    abort(reason?: unknown): void

    members(): Array<{
        id: string
        status: ConstellationMemberStatus
        queuedChunks: number
        error?: Error
    }>
}
export type StreamAddress = {
    streamId: string;
    k: string;
    sl?: SU;
    ms?: SU;
    rt?: SU;
};
export type LiminalState = 'waiting' | 'live' | 'closed';
export type LiminalChunk<T = unknown> = {
    type: 'liminal';
    direction: 'upstream->downstream' | 'downstream->upstream';
    data: T;
    upstreamStreamId: string;
    downstreamStreamId: string;
    observedAt: number;
};
export type StreamChunk<T = unknown> = {
    type: 'chunk';
    data: T;
    streamId?: string;
    ts?: number;
};
export type StreamDone = {
    type: 'done';
    streamId?: string;
    ts?: number;
};
export type StreamError = {
    type: 'error';
    error: string | Error | unknown;
    streamId?: string;
    ts?: number;
};
export type StreamEvent<T = unknown> =
    | StreamChunk<T>
    | StreamDone
    | StreamError;
export type rts = { sl?: any; ms?: any; rt?: any }
export type SIG_BUS_Boundary = 'same-app' | 'same-node' | 'cross-node'
export type SIG_BUS_Priority = 'high' | 'normal' | 'low';
export type SIG_BUS_ExportStrategy = 'overwrite' | 'merge' | 'skip';
export type SIG_BUS_SyncDirection = 'memory->adapter' | 'adapter->memory' | 'both';
export type SIG_BUS_DeliveryStatus = 'ack' | 'nak';
export type SIG_BUS_AdapterSendPayload = | SIG_BUS_Message | Uint8Array | SIG_BUS_SecureEnvelope;
export type SIG_BUS_Handler = (p: any, ctx?: SIG_BUS_HandlerContext) => any | Promise<any>;
export type SIG_BUS_CBORValue = null | boolean | number | string | Uint8Array | SIG_BUS_CBORValue[] | { [k: string]: SIG_BUS_CBORValue }
export type SIG_BUS_QueryExpr = | { type: 'eq'; key: string; value: unknown } | { type: 'and'; exprs: SIG_BUS_QueryExpr[] } | { type: 'or'; exprs: SIG_BUS_QueryExpr[] };
export interface SIG_BUS_Adapter {
    id?: string;
    send(msg: SIG_BUS_AdapterSendPayload): void;
    onMessage(handler: (msg: SIG_BUS_AdapterSendPayload) => void): () => void;
    onConnect?(handler: () => void): void;
    onDisconnect?(handler: () => void): void;
}
export interface SIG_BUS_SecureEnvelope {
    sessionId: string;
    token: string;
    p: SIG_BUS_Message | SIG_BUS_CBORValue;
}
export interface SIG_BUS_Message {
    id: string;
    rt: string;
    ms?: string;
    sl?: string;
    k?: string;
    topic?: string;
    p: unknown;
    ttl?: number;
    ts?: number;
    _ack?: boolean;
    _adapter?: SIG_BUS_Adapter;
    priority?: any;
    tags?: string[];
    streamId?: string;
    sessionId?: any;
    token?: any;
    binary?: 'signal_save_value' | 'signal' | true | false | string;
    error?: any
    adapter_id?: any
    cross_cse_ngin_connect_adapter_id?: any
    cross_app_adapter_adapter_id?: any
    type?: string
    boundary?: SIG_BUS_Boundary
}
export interface SIG_BUS_BackpressureConfig {
    maxQueueSize?: number;
    slowConsumerThresholdMs?: number;
    throttleMs?: number;
}
export interface SIG_BUS_Schema {
    validate(p: unknown): boolean;
    coerce?(p: unknown): unknown;
}
export interface SIG_BUS_rtPermissions {
    allow?: string[];
    deny?: string[];
    read?: string[];
    write?: string[];
}
export interface SIG_BUS_rtInfo {
    rt: string;
    handlers: number;
    adapters: string[];
    middleware: number;
    messageCount: number;
    tags: string[];
}
export interface SIG_BUS_AdapterMetrics {
    id: string;
    latencyMs: number;
    failureRate: number;
    throughputPerSec: number;
    healthy: boolean;
    disabled: boolean;
}
export interface SIG_BUS_RouteRule {
    name: string;
    match: (msg: SIG_BUS_Message | SIG_BUS_CBORValue) => boolean;
    targetAdapters?: string[];
    targetrts?: string[];
}
export interface SIG_BUS_Transform {
    outgoing?(msg: SIG_BUS_Message | SIG_BUS_CBORValue): SIG_BUS_Message | Promise<SIG_BUS_Message>;
    incoming?(msg: SIG_BUS_Message | SIG_BUS_CBORValue): SIG_BUS_Message | Promise<SIG_BUS_Message>;
}
export interface SIG_BUS_EncryptionConfig {
    rt?: string;
    adapterId?: string;
    secret?: string;
    publicKey?: string;
    algorithm?: string;
}
export interface SIG_BUS_DurableOptions {
    subscriberId: string;
    fromOffset?: number;
    fromTimestamp?: number;
    tags?: string[];
}
export interface SIG_BUS_ReplayOptions {
    rt: string;
    fromOffset?: number;
    toOffset?: number;
    fromTimestamp?: number;
    toTimestamp?: number;
    tags?: string[];
}
export interface SIG_BUS_GroupOptions {
    enabled?: boolean;
    middleware?: (msg: SIG_BUS_Message | SIG_BUS_CBORValue) => boolean | void;
}
export interface SIG_BUS_SendOptions {
    ttl?: number;
    priority?: SIG_BUS_Priority;
    tags?: string[];
    metadata?: Record<string, unknown>;
    expectReply?: boolean;
}
export interface SIG_BUS_BatchItem {
    rt: string;
    p: Record<string, unknown>;
}
export interface SIG_BUS_HandlerContext {
    rt: string;
    adapter?: SIG_BUS_Adapter;
    meta: SIG_BUS_MessageMeta;
}
export interface SIG_BUS_ClusterConfig {
    nodeId: string;
    peers: string[];
}
export interface SIG_BUS_WebRTCAdapterOptions {
    signalingAdapter: SIG_BUS_Adapter;
    peerId: string;
    iceServers?: RTCIceServer[];
}
export interface SIG_BUS_MessageMeta {
    id?: string;
    ttl?: number;
    priority?: SIG_BUS_Priority;
    tags?: string[];
    timestamp?: number;
    streamId?: string;
    [key: string]: unknown;
}
export interface SIG_BUS_CompressionConfig {
    rt?: string;
    adapterId?: string;
    algorithm: string;
}
export interface SIG_BUS_SEND_FN {
    (ppayload: unknown, k: string, sl?: string, ms?: string, rt?: string, ttl?: number, chain?: 'chain' | 'rechain', binary?: boolean): Promise<unknown>
    broadcast(p: unknown, k: string, sl?: string, ms?: string, rt?: string, ttl?: number, binary?: boolean): Promise<unknown>
    broadcastState(state: any, k: string, sl: string, ms: string, rt: string, chain?: 'chain' | 'rechain'): any
    bare_metal(p: unknown, k: string, sl?: string, ms?: string, rt?: string, boundary?: "same-app" | "same-node" | "cross-node"): Promise<unknown>
    emit(event: string, p: any, sl?: string, ms?: string, rt?: string): void
}
export interface SIG_BUS_SUB_FN {
    (handler: any, k: string, sl?: string, ms?: string, rt?: string, boundary?: Boundary): any
    subscribe(handler: (d: unknown) => MaybePromise<void>, quad: string, trip: string, sub: string, ch: string,): any
}
export interface SIG_BUS_BOUNDARY_FN {
    register(k: string, sl?: string, ms?: string, rt?: string, boundary?: Boundary): any
    probe<T = any>(p: unknown, k: string, sl?: string, ms?: string, rt?: string, boundary?: "same-app" | "same-node" | "cross-node"): any

}
export interface SIG_BUS_CELL_FN {
    <T = any>(k: string, sl?: string, ms?: string, rt?: string, chain?: 'chain' | 'rechain', v?: T): any
    send<T = any>(p: unknown, k: string, sl?: string, ms?: string, rt?: string, chain?: 'chain' | 'rechain'): any
    cell<T = any>(k: string, sl?: string, ms?: string, rt?: string, type?: 'waitFor' | 'sub' | 'cell', chain?: 'chain' | 'rechain', v?: T): any
    crdt<T = any>(k: string, sl?: string, ms?: string, rt?: string, chain?: 'chain' | 'rechain', v?: T): any
}

export type CELL_TYPE = 'waitFor' | 'sub' | 'cell' | 'none'
export type CHAIN_TYPE = 'chain' | 'rechain'
export type STORE_TYPE = 'tc' | 'rr' | 'auto'
export type INI_QD<T = any> = [v?: T, k?: string, sl?: string, ms?: string, rt?: string]
// ...args: [...INI_QD<T>,]
//  mailbox<T = any>(...args: [...INI_QD<T>, ]): any
export type QD_INI = [k: string, v?: any, sl?: string, ms?: string, rt?: string,]
// ...args: [...QD_INI,]
//  mailbox(...args: [...QD_INI, ]): any
export type QD = [k: string, sl?: string, ms?: string, rt?: string]
// ...args: [...QD,]
//  mailbox(...args: [...QD, ]): any


export interface SIG_BUS_DEPLUX_FN {
    (k: string, sl?: string, ms?: string, rt?: string, opts?: { windowSize?: number; livenessId?: string; }, type?: string): any;
    async<TUp = any, TDown = any>(...args: [...QD, opts?: { windowSize?: number }]): any;
    solo(readConfig: { k: string; sl?: string; ms?: string; rt?: string },
        writeConfig: { k?: string; sl?: string; ms?: string; rt?: string }
    ): { sub: ReadableStream; send: WritableStream }
    open(...args: [opts: any, ...QD,]): any
    sx(...args: [...QD, opts: any]): any
}
export interface DUPLEX_HANDLER_FN {
    <TUp = any, TDown = any>(handlerFn: (data: TUp, stream: any) => void | Promise<void>, k: string, sl?: string, ms?: string, rt?: string, opts?: { windowSize?: number; }, type?: 'default' | 'sync' | 'stream-relay' | 'rate-limited' | 'fan-out' | 'priority' | 'transactional' | 'presence' | 'authority' | 'multicast' | 'partitioned' | 'batch' | 'filtered' | 'idempotent' | 'checkpoint' | 'transform'): any;

    async<TUp = any, TDown = any>(handlerFn: (data: TUp, stream: DuplexStream<TDown, TUp>) => void | Promise<void>, k: string, sl?: string, ms?: string, rt?: string, opts?: { windowSize?: number }): any;
}
export interface DuplexStream<TSend = any, TRecv = any> {
    send: (p: TSend) => void;
    onData: (handler: (chunk: TRecv, seq: number) => void) => () => boolean;
    onError: (handler: (err: DuplexError) => void) => () => boolean;
    onRemoteClose: (handler: () => void) => () => boolean;
    closeUp?: () => void;
    closeDown?: () => void;
    close: () => void;
    isFullyClosed: () => boolean;
    isFatallyErrored: () => boolean;
}
export interface DuplexError {
    dir: 'up' | 'down';
    message: string;
    fatal: boolean;
    retryable?: boolean;
    code?: string;
}
export type LateArrivalStrategy = 'discard' | 'delay' | 'reorder';
export type CompressFormat = 'gzip' | 'deflate' | 'deflate-raw' | 'brotli' | 'zstd';
export interface HANDLER_FN {
    (handler: (d: any) => any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): any;
    syncGuard(handler: (chunk: any, seq: number, streamId: string) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, options?: SyncSubGuardOptions): void;
    sync(k: string, sl?: string, ms?: string, rt?: string): any;
    sync_2(handler: (chunk: any, seq: number) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): void;
    openSync(handler: (chunk: any, seq: number) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
    priority(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
    transactional(apply: (chunks: any[]) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
    delta<T>(applyPatch: (current: T, diff: any) => T, v: T, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    presence(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, onUpdate?: (all: Record<string, any>) => void): any;
    authority<T>(resolve: (guess: T) => Promise<T> | T, k: string, sl: string, ms: string, rt: string): () => void;
    heartbeat(onDead: () => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { deadThresholdMs?: number }): any;
    backpressure(handler: (p: any) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
    stateful(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { key?: string }): any;
    multicast(receiverId: string, handler: (p: any, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { key?: string; startFrom?: 'beginning' | 'now' }): Promise<any>;
    partitioned(handler: (key: string, p: any, partition: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { partitions?: number[]; partitionCount?: number }): any;
    batch(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
    filtered(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, predicate?: (p: any) => boolean): () => void;
    deadLetter(handler: (entry: SIG_BUS_Message) => Promise<boolean> | boolean): any;
    idempotent(handler: (p: any) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { keyPrefix?: string; ttlMs?: number }): any;
    lateArrival(handler: (p: any, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { strategy?: LateArrivalStrategy; toleranceMs?: number }): () => void;
    checkpoint(streamKey: string, handler: (p: any, seq: number) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { every?: number }): Promise<any>;
    rateLimited(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
    combo(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    transform<T = any, R = any>(fn: (p: T) => Promise<R> | R, onResult: (result: R, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { concurrency?: number }): () => void;
    map<T = any, R = any>(fn: (item: T) => R, onResult: (r: R, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { concurrency?: number }): () => void;
    filter<T = any>(predicate: (item: T) => boolean, onResult: (item: T, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
    reduce<T = any, R = any>(fn: (acc: R, item: T) => R, v: R, onUpdate: (acc: R) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
    fanout(receiverId: string, handler: (p: any, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { key?: string; startFrom?: 'beginning' | 'now' }): Promise<any>;
    useDRSS<T extends Record<string, unknown>>(v: any, handler: (chunk: any, state: any) => any | Promise<T>, k: string, sl?: string, ms?: string, rt?: string, binary?: boolean): any;
    useDRSSSync(v: any, handler: (chunk: any, seq: number, state: any) => any | Promise<any>, k: string, sl?: string, ms?: string, rt?: string, binary?: boolean): any;
}
export interface SyncSubGuardOptions {
    sl?: string;
    ms?: string;
    rt?: string;
    maxBufferSize?: number;
    streamTTLMs?: number;
    maxStreams?: number;
    binary?: boolean;
    onStreamComplete?: (streamId: string, totalChunks: number) => void;
    onStreamError?: (streamId: string, error: string) => void;
}
export interface FieldTouch {
    field: string;
    action: 'viewing' | 'editing';
    userId?: string;
    timestamp?: number;
    [key: string]: any;
}
export interface DRSConflictOptions {
    k?: string;
    sl?: string;
    ms?: string;
    rt?: string;
    conflictStrategy?: 'lww' | 'version-vector' | 'custom' | string;
    versionKey?: string;
    debounceMs?: number;
    binary?: boolean;
    onConflict?: (local: any, remote: any) => any;
}
export interface RelayFlowOptions extends StreamRelayOptions { }
export interface SyncIntegrityOptions {
    sl?: string;
    ms?: string;
    rt?: string;
    windowSize?: number;
    chunkRetries?: number;
    retryBackoffMs?: number;
    timeoutMs?: number;
    binary?: boolean;
    priority?: any;
    ttl?: number;
    onProgress?: (sent: number, acked: number, total: number) => void;
    onChunkFailed?: (seq: number, retries: number) => void;
}
export interface SyncIntegrityResult {
    success: boolean;
    delivered: number;
    acknowledged: number;
    failed: number[];
    durationMs: number;
}
export type ComboStrategy = 'arrival' | 'round-robin' | 'timestamp';

export interface HydraStage<T> {
    name: string;
    handler: (data: T) => T;
}
export type BackpressureRelayStrategy = 'drop-oldest' | 'drop-newest' | 'block' | 'drop' | 'latest' | 'error' | "pause";
export interface StreamRelayOptions {
    maxSubscribers?: number;
    bufferSize?: number;
    backpressureStrategy?: BackpressureRelayStrategy
    deliveryGuarantee?: 'at-most-once' | 'at-least-once';
    subscriberTimeoutMs?: number;
    onSubscriberDrop?: (id: string, reason: string) => void;
}
export interface SyncStreamOptions {
    windowSize?: number;
    retransmitMs?: number;
}
export interface SyncStreamSendHandle {
    push(p: unknown): void;
    pendingCount(): number;
    close(): void;
}
export interface SyncStreamHandler {
    onOrdered(cb: (p: unknown, seq: number) => void): void;
    onComplete(cb: () => void): void;
    close(): void;
}
export interface Outbound {
    seq: number;
    p: unknown;
    acked: boolean;
    sentAt: number;
    timer?: ReturnType<typeof setTimeout>;
}
export interface SIG_BUS_useEffect_FN {
    (effect: () => void | (() => void), deps: any[], k: string, sl: string, ms: string, rt: string): any;
    auto(effect: (scope: ReturnType<any>) => void, deps: any[], k: string, sl: string, ms: string, rt: string): any;
    layout(effect: any, deps: any, k: string, sl: string, ms: string, rt: string): any
}
export interface SIG_BUS_STREAM_FN {
    (p: any, onChunk: (chunk: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, chain?: 'chain' | 'rechain', binary?: boolean): Promise<void>;
    chunk(streamId: string, chunk: string, k: string, sl?: string, ms?: string, rt?: string): void
    done(streamId: string, chunk: string, k: string, sl?: string, ms?: string, rt?: string): void
    cancel(streamId: string, chunk: string, k: string, sl?: string, ms?: string, rt?: string): void
    liminal<T = unknown>(upstream: StreamAddress, downstream: StreamAddress, onChunk: (event: LiminalChunk<T>) => void,): { id: string; done: Promise<void>; close: () => void; }
    constellation(
        options?: ConstellationOptions,
    ): (
        onChunk?: (event: ConstellationChunk) => void,
    ) => ConstellationHandle
    constellation2(
        options?: ConstellationOptions2,
    ): (
        onChunk: (event: ConstellationChunk2) => void,
    ) => ConstellationHandle2
    negotiate(offer: StreamContractOffer, k: string, sl?: string, ms?: string, rt?: string, timeoutMs?: number,): Promise<NegotiatedStreamContract>
    probabilistic<T>(send: ProbabilisticSender, options: ProbabilisticOptions<T>,): ProbabilisticSender
    readable(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): ReadableStream<any>;
    writable(k?: SU, sl?: string, ms?: string, rt?: string): WritableStream<any>;
    StreamRelay(k?: SU, sl?: string, ms?: string, rt?: string, opts?: StreamRelayOptions): any;
    transform(readConfig: {
        k: string;
        sl?: string | undefined;
        ms?: string | undefined;
        rt?: string | undefined;
    }, writeConfig: {
        k?: string | undefined;
        sl?: string | undefined;
        ms?: string | undefined;
        rt?: string | undefined;
    }, transformer?: (chunk: any) => any | Promise<any>): {
        sub: TransformStream<any, any>;
        send: TransformStream<any, any>;
    };
    pipeline<T = any>(k?: SU, sl?: string, ms?: string, rt?: string, stages?: HydraStage<T>[]): {
        unsubscribe: () => void;
    };
    route<T = any>(k?: SU, sl?: string, ms?: string, rt?: string, selectKey?: (p: T) => string, outPrefix?: string, opts?: {
        defaultKey?: string;
        onUnmatched?: (p: T, key: string) => void;
    }): {
        unsubscribe: () => void;
        stats: () => Record<string, number>;
    };
    syncGuard(chunks: any[], k: string, options?: SyncIntegrityOptions): Promise<SyncIntegrityResult>;
    relayWithFlowControl(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, options?: RelayFlowOptions): any;
    useDRSWithConsensus(vState: any, k?: SU, sl?: string, ms?: string, rt?: string, options?: DRSConflictOptions): any;

    sync_2(chunks: any[], k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, onAck?: (seq: number) => void, windowSize?: number, binary?: boolean): Promise<void>;
    sync(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: SyncStreamOptions): any;

    relay(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, options?: {
        maxSubscribers?: number;
        bufferSize?: number;
        backpressureStrategy?: 'drop' | 'pause' | 'error';
    }): any;
    openSync(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        windowSize?: number;
    }): any;
    priority(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    transactional(chunks: any[], k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): Promise<{
        committed: boolean;
        error?: string;
    }>;
    delta<T extends any>(computeDelta: (prev: T, next: T) => any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    presence(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    authority<T = any>(v: T, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    heartbeat(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        idleThresholdMs?: number;
    }): any;
    backpressure(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        windowSize?: number;
    }): any;
    stateful(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        key?: string;
    }): any;
    multicast(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        key?: string;
    }): any;
    partitioned(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        partitionCount?: number;
    }): any;
    batch(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        maxSize?: number;
        maxWaitMs?: number;
    }): any;
    filtered(predicate: (p: any) => boolean, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    deadLetter(p: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        maxRetries?: number;
        backoff?: any;
    }): Promise<{
        delivered: boolean;
    }>;
    idempotent(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    lateArrival(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    checkpoint(streamKey: string, opts?: {
        every?: number;
    }): any;
    rateLimited(opts: {
        ratePerSecond: number;
        burst?: number;
    }, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    combo(k: string, sl: string[], ms?: string | undefined, rt?: string | undefined, strategy?: ComboStrategy): any;
    transformative(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    fanout(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        key?: string;
    }): any;
    useDRSS<T extends Record<string, unknown> = any, P = any>(v: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): any;
    useDRSSSync(v: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): any;
}
export interface SIG_BUS_HANDLER_FN { }






export interface SIG_BUS_CELL_DRS_FN {
    (...args: [...QD_INI, type?: CELL_TYPE, chain?: CHAIN_TYPE]): any
    crdt<T = any>(...args: [...INI_QD<T>]): any
    cell(...args: [...QD_INI, type?: CELL_TYPE, chain?: CHAIN_TYPE]): any
    rifts: {
        <T = any>(module?: any, named_export?: any, store?: STORE_TYPE, wait?: number, chain?: CHAIN_TYPE): any
        mailbox<T = any>(...args: [...INI_QD<T>, STORE_TYPE]): any
    }
    crdtb<T = any>(...args: [...INI_QD<T>, nodeId?: string]): any
    topology(k: string, sl?: string, ms?: string, rt?: string, chain?: 'chain' | 'rechain', selfId?: string, opts?: { probeTimeoutMs?: number }): any
    map<K, V>(k: string, v: Map<K, V>, sl?: string, ms?: string, rt?: string, type?: CELL_TYPE, chain?: CHAIN_TYPE): any
    set<T = any>(k: string, v: Iterable<T>, sl?: string, ms?: string, rt?: string, type?: CELL_TYPE, chain?: CHAIN_TYPE): any
    array<T = any>(k: string, v: T[], sl?: string, ms?: string, rt?: string, type?: CELL_TYPE, chain?: CHAIN_TYPE): any
    obj<T extends Record<PropertyKey, any>>(k: string, v?: T, sl?: string, ms?: string, rt?: string, type?: CELL_TYPE, chain?: CHAIN_TYPE): any
    string(k: string, v: string, sl?: string, ms?: string, rt?: string, type?: CELL_TYPE, chain?: CHAIN_TYPE): any
    num(k: string, v: number, sl?: string, ms?: string, rt?: string, type?: CELL_TYPE, chain?: CHAIN_TYPE): any
    boolean(k: string, v: boolean, sl?: string, ms?: string, rt?: string, type?: CELL_TYPE, chain?: CHAIN_TYPE): any
    stream(...args: [...INI_QD, opts?: any]): any
    duplex(...args: [...INI_QD, chain?: CHAIN_TYPE, opts?: any,]): any
    time_travel(...args: [...INI_QD,]): any
    gated(predicate: (topo: any, ...ctx: any[]) => boolean, value: any, deps: any[], k: any, sl?: string, ms?: string, rt?: string): any
    transaction(...args: [...QD_INI,]): any
    signal<T = any>(v?: T | (() => T), k?: string, sl?: string, ms?: string, rt?: string, chain?: CHAIN_TYPE): any
    graph(...args: [...QD_INI,]): any
    distributed(...args: [...QD_INI,]): any
    synchronization(...args: [...QD_INI,]): any
    replication(...args: [...QD_INI,]): any
    resilience(...args: [...QD_INI,]): any
    temporal(...args: [...QD_INI,]): any
    mesh<T = any>(v?: T, reactor?: StateMeshReactor<T>, k?: string, sl?: string, ms?: string, rt?: string,): StateMesh<T>
    store(...args: [...INI_QD,]): any
    mailbox(...args: [...INI_QD,]): any
    mailbox2(...args: [...INI_QD,]): any
    stateStore(...args: [...INI_QD,]): any
    liveStore(...args: [...INI_QD, nodeId?: string]): any
    live(...args: [...INI_QD,]): any
    observable(...args: [...INI_QD,]): any
    ref(...args: [...INI_QD,]): any
    umbrella(v?: Record<string, any>, k?: string, sl?: string, ms?: string, rt?: string): any
    context(v?: Record<string, any>, k?: string, sl?: string, ms?: string, rt?: string): any
}
export type SIG_BUS_SS_FN = {
    // ── callable: creates a signal handle ────────────────────────────────────────────────────
    <T = any>(v?: any, key?: string, sl?: string, ms?: string, rt?: string, chain?: 'chain' | 'rechain', options?: SignalOptions<T>): any;
    update(node: SignalNode | ComputedNode | EffectScopeNode): boolean
    notify(effect: EffectNode): any








    _bindComponentToSignal(rk: string, sl?: string, ms?: string, rt?: string): void;
    _hashTuple(tuple: unknown[]): string
    _serializeTuple(tuple: any[]): string
    create<T = any>(key: string, v?: any, sl?: string, ms?: string, rt?: string, options?: SignalOptions<T>): string;
    read<T>(key: string, sl?: string, ms?: string, rt?: string,): any
    write<T>(key: string, sl?: string, ms?: string, rt?: string,): any
    normalizeKey(rawKey: string): any
    runTeardown(t: Teardown): void
    reportError(e: unknown): void
    untrackFn<T>(fn: () => T): T
    untrack<T>(fn: () => T): T
    
    setEffectErrorHandler(fn: EffectErrorHandler | null): void
    getActiveSub(): ReactiveNode | undefined
    setActiveSub(sub?: ReactiveNode): any
    getBatchDepth(): number
    startBatch(): any
    endBatch(): any
    isSignal(fn: () => void): boolean
    isComputed(fn: () => void): boolean
    isEffect(fn: () => void): boolean
    isEffectScope(fn: () => void): boolean
    signal<T>(v?: T): { (): T | undefined; (value: T | undefined): void; }
    computed<T>(getter: (previousValue?: T) => T): () => T
    effect(fn: () => void | (() => void), onError?: EffectErrorHandler): (that: EffectNode) => void
    effectScope(fn: () => void, onError?: EffectErrorHandler): (that: EffectScopeNode) => void
    trigger(fn: () => void): any
    updateComputed(c: ComputedNode): boolean
    updateSignal(s: SignalNode): boolean
    run(e: EffectNode): void
    flushSS(): void
    runCleanup(e: EffectNode): void
    disposeAllDepsInReverse(sub: ReactiveNode): void
    purgeDeps(sub: ReactiveNode): any

    // ── ergonomic helpers ────────────────────────────────────────────────────────────────────
    sysEffect(fn: () => void | (() => void)): () => void;

    // ── internals exposed on the namespace ───────────────────────────────────────────────────
    _validateSchema(rk: string, value: any, sl?: string, ms?: string, rt?: string): any;
    _hashTuple(tuple: unknown[]): string;
    _recordCausal(rk: string, value: any, source: string, sl?: string, ms?: string, rt?: string, cause?: string): void;
    _resolveConflict(rk: string, prev: any, next: any, sl?: string, ms?: string, rt?: string): any;
    _writeResolved(rk: string, value: any, source: string, sl?: string, ms?: string, rt?: string, cause?: string): void;

    // ── key + schema ─────────────────────────────────────────────────────────────────────────
    resolveKey(key: any, sl?: string, ms?: string, rt?: string): string;
    registerSchema<T = any>(key: any, schema: SignalSchema<T>, sl?: string, ms?: string, rt?: string): void;

    // ── signal CRUD ──────────────────────────────────────────────────────────────────────────
    write<T = any>(key: any, value: T | ((prev: T | undefined) => T), sl?: string, ms?: string, rt?: string, source?: string): void;
    read<T = any>(key: any, sl?: string, ms?: string, rt?: string): T | undefined;
    peek<T = any>(key: any, sl?: string, ms?: string, rt?: string): T | undefined;
    subscribe<T>(key: string, listener: (value: T, previous: T) => void, sl?: string, ms?: string, rt?: string,): Unsubscribe
    has(key: any, sl?: string, ms?: string, rt?: string): boolean;
    delete(key: any, sl?: string, ms?: string, rt?: string): void;

    // ── signal state modifiers ───────────────────────────────────────────────────────────────
    freeze(key: any, sl?: string, ms?: string, rt?: string): void;
    seal(key: any, sl?: string, ms?: string, rt?: string): void;
    reset(key: any, sl?: string, ms?: string, rt?: string): void;
    hydrate<T = any>(key: any, value: T, sl?: string, ms?: string, rt?: string): void;

    clone(srcKey: any, destKey: any, src: rts, dest: rts,): void;

    // ── persistence ──────────────────────────────────────────────────────────────────────────
    persist<T = any>(key: any, value: T, sl?: string, ms?: string, rt?: string, options?: { serialize?: (v: T) => string }): Promise<void>;
    unpersist(key: any, sl?: string, ms?: string, rt?: string): Promise<void>;

    // ── messaging ────────────────────────────────────────────────────────────────────────────
    sub<T = any>(k: string, handler: any, sl?: string, ms?: string, rt?: string): () => void;
    send(p: any, fromKey: any, toKey: any, ms?: string, rt?: string): void;

    // ── derived ──────────────────────────────────────────────────────────────────────────────
    derive<T = any>(
        key: any,
        deps: any[],
        compute: (...values: any[]) => T, sl?: string, ms?: string, rt?: string,
        options?: { eager?: boolean; onError?: (err: Error) => void }
    ): string;
    invalidateDerived(key: any): void;

    // ── async ────────────────────────────────────────────────────────────────────────────────
    createAsync<T = any>(
        key: any,
        fetcher: (signal: AbortSignal) => Promise<T>, sl?: string, ms?: string, rt?: string,
        options?: { fallback?: T }
    ): AsyncSignalHandles;
    invalidateAsync(key: any, sl?: string, ms?: string, rt?: string): void;
    mutateAsync<T = any>(key: any, optimistic: T, sl?: string, ms?: string, rt?: string): void;
    abortAsync(key: any, sl?: string, ms?: string, rt?: string): void;
    prefetchAsync<T = any>(key: any, fetcher: () => Promise<T>, sl?: string, ms?: string, rt?: string): void;
    readAsync<T = any>(key: any, sl?: string, ms?: string, rt?: string): T;

    // ── batch / tx ───────────────────────────────────────────────────────────────────────────
    batch(fn: () => void): void;
    tx(fn: () => void): void;
    transaction(block: () => void): void;

    // ── history / time travel ────────────────────────────────────────────────────────────────
    enableHistory(key: any, sl?: string, ms?: string, rt?: string, options?: { max: number }): void;
    undo(key: any, sl?: string, ms?: string, rt?: string): void;
    redo(key: any, sl?: string, ms?: string, rt?: string): void;
    signalTimeline(key: any, sl?: string, ms?: string, rt?: string): SignalTimelineEntry[];
    snapshot(): Record<string, any>;
    restore(snapshot: Record<string, any>): void;
    diffSnapshots(a: Record<string, any>, b: Record<string, any>): Record<string, { from: any; to: any }>;
    applyPatch(patch: Record<string, { from: any; to: any }>): void;
    replay(key: any, sl?: string, ms?: string, rt?: string, options?: { speed?: number }): Promise<void>;

    // ── causal / conflict / contracts ────────────────────────────────────────────────────────
    getCausalChain(key: any, sl?: string, ms?: string, rt?: string): CausalEntry[];
    conflictPolicy<T = any>(key: any, policy: ConflictPolicy<T>): void;
    declareContract(
        name: string,
        key: any,
        postcondition: (next: any, prev: any) => boolean, sl?: string, ms?: string, rt?: string,
        options?: { block?: boolean }
    ): void;
    removeContract(name: string): void;

    // ── scopes ───────────────────────────────────────────────────────────────────────────────
    createScope(id: string): SignalScopeHandle;

    // ── effects ──────────────────────────────────────────────────────────────────────────────

    effectOnce(
        keys: any[],
        predicate: (...v: any[]) => boolean,
        fn: (...v: any[]) => void
    ): () => void;

    // ── operators ────────────────────────────────────────────────────────────────────────────
    map<A = any, B = any>(srcKey: any, destKey: any, fn: (v: A) => B, src: rts, dest: rts): () => void;
    filter<T = any>(srcKey: any, destKey: any, pred: (v: T) => boolean, src: rts, dest: rts): () => void;
    debounce(sourceKey: any, delay: number, src: rts, dest: rts): [string, () => void];
    throttle(srcKey: any, destKey: any, ms: number, src: rts, dest: rts): () => void;
    merge(srcKeys: any[], destKey: any, src: rts, dest: rts): () => void;
    zip(srcKeys: any[], destKey: any, src: rts, dest: rts): () => void;
    combine(srcKeys: any[], destKey: any, src: rts, dest: rts): () => void;
    scan<T = any, A = any>(srcKey: any, destKey: any, reducer: (a: A, v: T) => A, seed: A, src: rts, dest: rts): () => void;
    switch(srcKey: any, destKey: any, src: rts, dest: rts): () => void;
    buffer(srcKey: any, destKey: any, count: number, src: rts, dest: rts): () => void;
    window(srcKey: any, destKey: any, ms: number, src: rts, dest: rts): () => void;
    distinct<T = any>(srcKey: any, destKey: any, equals?: (a: T, b: T) => boolean, src?: rts, dest?: rts,): any;
    audit(srcKey: any, destKey: any, ms: number, src: rts, dest: rts): () => void;
    sample(srcKey: any, triggerKey: any, destKey: any, src: rts, dest: rts): () => void;
    gate(srcKey: any, gateKey: any, destKey: any, src: rts, dest: rts): () => void;
};
export interface AsyncSignalHandles {
    dataKey: string;
    loadingKey: string;
    errorKey: string;
}
export interface SignalScopeHandle {
    add(key: any): void;
    suspend(): void;
    resume(): void;
    dispose(): void;
    snapshot(): Record<string, any>;
    restore(snapshot: Record<string, any>): void;
    fork(): SignalScopeHandle;
    merge(forked: SignalScopeHandle): void;
}
export type Teardown =
    | void
    | null
    | (() => void)
    | { unsubscribe(): void }
    | { [Symbol.dispose](): void }
    | Teardown[];
export interface Link {
    version: number;
    dep: ReactiveNode;
    sub: ReactiveNode;
    prevSub: Link | undefined;
    nextSub: Link | undefined;
    prevDep: Link | undefined;
    nextDep: Link | undefined;
    bus?: any
    value?: any
    label?: string
}
export interface Stack<T> {
    value: T;
    prev: Stack<T> | undefined;
}
export const enum ReactiveFlags {
    None = 0,
    Mutable = 1,
    Watching = 2,
    RecursedCheck = 4,
    Recursed = 8,
    Dirty = 16,
    Pending = 32,
}
export interface EffectScopeNode extends ReactiveNode {
    onError?: EffectErrorHandler;
    children?: Set<ReactiveNode>;
}
export type EffectErrorHandler = (err: unknown, node: ReactiveNode) => void;
export interface ReactiveNode {
    deps?: Link;
    depsTail?: Link;
    subs?: Link;
    subsTail?: Link;
    flags: ReactiveFlags;
}
export interface AsyncNode<T = any> extends ReactiveNode {
    fetcher: (signal: AbortSignal) => Promise<T>;
    value: T | undefined;
    error: unknown;
    pending: boolean;
    controller: AbortController | null;
    version: number;
    onError?: EffectErrorHandler;
}
export interface EffectNode extends ReactiveNode {
    fn(): (() => void) | void;
    cleanup: (() => void) | void;
    onError?: EffectErrorHandler;
}
export interface ComputedNode<T = any> extends ReactiveNode {
    value: T | undefined;
    getter: (previousValue?: T) => T;
}
export interface SignalNode<T = any> extends ReactiveNode {
    currentValue: T;
    pendingValue: T;
}
export interface SignalScope {
    id: string
    keys: Set<string>
    effects: Set<any>
    suspended: boolean
    pendingFlush: Map<string, any>
}
export type SignalListener = { (value: any, source?: string): void }
export interface SignalLifecycle<T = any> {
    onCreate?: () => void;
    onWrite?: (value: T, prev: T | undefined) => void;
    onRead?: (value: T) => void;
    onDelete?: () => void;
    onFreeze?: () => void;
    onExpire?: () => void;
    onError?: (err: Error) => void;
}
export interface SignalEffect {
    keys: string[];
    fn: (...values: any[]) => (() => void) | void | Promise<(() => void) | void>;
    cleanup: (() => void) | null;
    controller: AbortController | null;
}
export interface AsyncSignalState<T> {
    fetcher: () => Promise<T> | void;
    controller: AbortController | null;
    retryCount: number;
    staleValue?: T;
}
export type ConflictPolicy2<T = any> = | ConflictPolicyName | ((current: T, incoming: T, meta: { key: string; timestamp: number }) => T)
//export interface ConflictPolicy<T = any> { resolve?: (prev: T | undefined, next: T) => T | undefined; }
export interface ConflictPolicy<T = any> { resolve?: (prev: T | undefined, next: T) => T | undefined; }
export interface SignalOptions<T = any> {
    schema?: SignalSchema<T>;
    conflict?: ConflictPolicy<T>;
    history?: { max: number };
    lifecycle?: SignalLifecycle<T>;
    persist?: boolean;
    ttl?: number;
    broadcast?: boolean;
    trigger_render?: boolean;
    conflictStrategy?: any
}
export interface SysEntry {
    read: () => any;
    write: (v: any) => void;
    node: any;
    isComputed: boolean;
}
export interface Metrics {
    readCount: number;
    writeCount: number;
    subscriberCount: number;
    lastWrite: number | null;
    flushDuration: number;
}
export interface SignalHandle<T = any> {
    value: T;
    peek(): T;
}
export interface ComputedHandle<T = any> {
    value: T;
    peek(): T;
}
export interface SignalSchema<T = any> {
    validate: (v: any) => boolean;
    coerce?: (v: any) => T;
}
export interface SignalLifecycle<T = any> {
    onCreate?: () => void;
    onWrite?: (value: T, prev: T | undefined) => void;
    onRead?: (value: T) => void;
    onDelete?: () => void;
    onFreeze?: () => void;
    onExpire?: () => void;
    onError?: (err: Error) => void;
}
export interface SignalEffect {
    keys: string[];
    fn: (...values: any[]) => (() => void) | void | Promise<(() => void) | void>;
    cleanup: (() => void) | null;
    controller: AbortController | null;
}
export interface AsyncSignalState<T = any> {
    fetcher: () => Promise<T> | void;
    controller: AbortController | null;
    retryCount: number;
    staleValue?: T;
}
export interface SignalOptions<T = any> {
    schema?: SignalSchema<T>;
    conflict?: ConflictPolicy<T>;
    history?: { max: number };
    lifecycle?: SignalLifecycle<T>;
    persist?: boolean;
    ttl?: number;
    broadcast?: boolean;
}
export interface SignalTimelineEntry {
    value: any;
    timestamp: number;
    source?: string;
}
export type ConflictPolicyName = 'last-write-wins' | 'first-write-wins' | 'merge' | 'reject-on-conflict' | 'queue'
export interface CausalEntry {
    key: string
    value: any
    timestamp: number
    source?: 'write' | 'effect' | 'derived' | 'staff' | 'ngin' | string
    cause?: string
}
export interface DOMBinding {
    node: Node
    update: (node: Node, value: any) => void
    active?: boolean
}
export interface CallbackHookState extends HookState {
    callback: (...args: any[]) => any
    deps: any[]
}

export function chain<T = any>(value: MaybePromise<T>) { return Promise.resolve(value); }

// #endregion
// #region MATBE GENERIC

// #region MaybeScope
export interface ScopeOptions {
    sl?: any
    ms?: any
    rt?: any
    k?: any
}
export type MS1 = symbol;


export interface maybe_ch_payload {

    v?: any
    rt?: SU
    ms?: SU
    sl?: SU
    k?: SU
}
export interface maybe_rt {
    sl?: SU
    ms?: SU
    rt?: SU
}
export interface SauronRegistry extends SauronState {
  name: string
  destroy(): void
}
export interface SAURON_REGISTRY_STORAGE {
  get<T>(key: string, opts?: ScopeOptions): T | undefined
  set<T>(key: string, value: T | ((prev: T | undefined) => T), opts?: { triggerRender?: boolean } & ScopeOptions): void
  delete(key: string, opts?: ScopeOptions): boolean
  getByPrefix<T>(prefix: string, opts?: ScopeOptions): { key: string; value: T }[]
  getAll<T = any>(opts?: ScopeOptions): Record<string, T>
  subscribe<T>(key: string, listener: (value: T) => void, opts?: ScopeOptions): () => void
  subscribeAll(listener: (key: string, value: any) => void, opts?: ScopeOptions): () => void
  batch(key: string, fn: () => void, opts?: ScopeOptions): void
  clear(opts?: ScopeOptions): void

  name: string
  destroy(): void
}

// #endregion
// #endregion


export type GateContext<TPayload = unknown> = {
    p: TPayload;
    store: Map<string, unknown>;
    reply: (data: unknown, targetrt?: string) => Promise<unknown>;
};
export type GateMatcher<TPayload = unknown> = (p: TPayload, ctx: GateContext<TPayload>) => MaybePromise<boolean>;
export type GateHandler<TPayload = unknown, TResult = unknown> = (p: TPayload, ctx: GateContext<TPayload>) => MaybePromise<TResult>;
export type GateDefinition<TPayload = unknown, TResult = unknown> = {
    /**
     * Higher values are checked first in sequential mode.
     * In concurrent mode priority only provides deterministic ordering metadata.
     */
    priority?: number;

    matcher: GateMatcher<TPayload>;
    handler?: GateHandler<TPayload, TResult>;
};
export type GateMap<TPayload = unknown> = Record<string, GateMatcher<TPayload> | GateDefinition<TPayload>>;
export type GateRunResult<TResult = unknown> = {
    name: string;
    matched: boolean;
    success: boolean;
    result?: TResult;
    error?: unknown;
};
export type GateMasterOptions = {
    /**
     * true: match all gates and run all matches in parallel
     * false: match and run one gate at a time, in priority order
     */
    concurrency?: boolean;

    /**
     * In sequential mode, stop after the first successful matching handler.
     * Defaults to false because Gate Master is intended to fan out to all matches.
     */
    stopAfterFirstMatch?: boolean;

    /**
     * If true, a failed matcher/handler stops sequential processing.
     * Defaults to false, so other independent gates keep running.
     */
    failFast?: boolean;

    onError?: (
        error: unknown,
        gateName: string,
        phase: "match" | "execute",
        p: unknown
    ) => void;
};
export type Awaitable<T> = T | Promise<T>;
export type NodeId = string;
export type RunId = string;
export type PlinkoOutcome = | "success" | "failure" | "skipped" | "cancelled";
export type PlinkoRunStatus = | "idle" | "running" | "succeeded" | "failed" | "cancelled";
export type SerializedError = {
    name: string;
    message: string;
    stack?: string;
    cause?: SerializedError;
};
export type PlinkoRetryPolicy = {
    maxAttempts?: number;
    delayMs?: number;
    maxDelayMs?: number;
    backoff?: "fixed" | "linear" | "exponential";
    jitter?: "none" | "full";
    retryIf?: (error: unknown, attempt: number) => boolean;
};
export type PlinkoNodeContext<TInput, TResults extends Record<string, unknown> = Record<string, unknown>,> = {
    readonly runId: RunId;
    readonly nodeId: NodeId;
    readonly attempt: number;
    readonly input: TInput;
    readonly results: Readonly<TResults>;
    readonly variables: ReadonlyMap<string, unknown>;
    readonly signal: AbortSignal;

    emit(name: string, p?: unknown): void;
};
export type ActionNode<TInput, TResults extends Record<string, unknown> = Record<string, unknown>, TOutput = unknown,> = {
    kind?: "action";
    label?: string;

    when?: (
        ctx: PlinkoNodeContext<TInput, TResults>,
    ) => Awaitable<boolean>;

    run: (
        ctx: PlinkoNodeContext<TInput, TResults>,
    ) => Awaitable<TOutput>;

    timeoutMs?: number;
    retry?: PlinkoRetryPolicy;
    on?: Partial<Record<PlinkoOutcome, NodeId>>;
};
export type PlinkoDefinition<TInput> = {
    id: string;
    version?: string;
    start: NodeId;
    nodes: Record<NodeId, ActionNode<TInput>>;
};
export type CompiledGraph<TInput> = Readonly<{
    id: string;
    version?: string;
    start: NodeId;
    nodes: Readonly<Record<NodeId, ActionNode<TInput>>>;
}>;
export type PlinkoEvent =
    | {
        type: "run.started";
        runId: RunId;
        graphId: string;
        graphVersion?: string;
        input: unknown;
        at: number;
    }
    | {
        type: "node.selected";
        runId: RunId;
        nodeId: NodeId;
        at: number;
    }
    | {
        type: "node.started";
        runId: RunId;
        nodeId: NodeId;
        attempt: number;
        at: number;
    }
    | {
        type: "node.skipped";
        runId: RunId;
        nodeId: NodeId;
        reason: string;
        at: number;
    }
    | {
        type: "node.succeeded";
        runId: RunId;
        nodeId: NodeId;
        attempt: number;
        result: unknown;
        durationMs: number;
        at: number;
    }
    | {
        type: "node.failed";
        runId: RunId;
        nodeId: NodeId;
        attempt: number;
        error: SerializedError;
        durationMs: number;
        willRetry: boolean;
        at: number;
    }
    | {
        type: "node.retrying";
        runId: RunId;
        nodeId: NodeId;
        attempt: number;
        delayMs: number;
        at: number;
    }
    | {
        type: "node.cancelled";
        runId: RunId;
        nodeId: NodeId;
        attempt: number;
        reason?: unknown;
        at: number;
    }
    | {
        type: "transition.taken";
        runId: RunId;
        from: NodeId;
        outcome: PlinkoOutcome;
        to?: NodeId;
        at: number;
    }
    | {
        type: "run.event";
        runId: RunId;
        nodeId: NodeId;
        name: string;
        p?: unknown;
        at: number;
    }
    | {
        type: "run.completed";
        runId: RunId;
        status: Extract<
            PlinkoRunStatus,
            "succeeded" | "failed" | "cancelled"
        >;
        result: Record<string, unknown>;
        error?: SerializedError;
        at: number;
    };
export type PlinkoEnvelope = {
    __plinko: 1;
    graphId: string;
    graphVersion?: string;
    runId: RunId;
    event: PlinkoEvent;
    snapshot: PlinkoRunSnapshot;
};
export type PlinkoRunSnapshot = Readonly<{
    id: RunId;
    graphId: string;
    graphVersion?: string;
    status: PlinkoRunStatus;
    currentNodeId?: NodeId;
    input: unknown;
    results: Readonly<Record<string, unknown>>;
    events: readonly PlinkoEvent[];
    startedAt?: number;
    endedAt?: number;
    error?: SerializedError;
}>;
export type MutablePlinkoRunSnapshot = {
    id: RunId;
    graphId: string;
    graphVersion?: string;
    status: PlinkoRunStatus;
    currentNodeId?: NodeId;
    input: unknown;
    results: Record<string, unknown>;
    events: PlinkoEvent[];
    startedAt?: number;
    endedAt?: number;
    error?: SerializedError;
};
export type PlinkoAttemptEvent<TOutput> =
    | {
        type: "started";
        attempt: number;
    }
    | {
        type: "succeeded";
        attempt: number;
        result: TOutput;
        durationMs: number;
    }
    | {
        type: "failed";
        attempt: number;
        error: SerializedError;
        durationMs: number;
        willRetry: boolean;
    }
    | {
        type: "retrying";
        attempt: number;
        delayMs: number;
    }
    | {
        type: "cancelled";
        attempt: number;
        reason?: unknown;
    };
export type PlinkoNodeExecution<TOutput> = {
    outcome: PlinkoOutcome;
    result?: TOutput;
    error?: SerializedError;
    attempt: number;
};
export type PlinkoStartOptions = {
    runId?: RunId;
    k?: string;
    sl?: SU;
    ms?: SU;
    rt?: SU;
    ttl?: number;
    maxTransitions?: number;
};
export type PlinkoRunHandle = Readonly<{
    id: RunId;
    done: Promise<PlinkoRunSnapshot>;

    cancel(reason?: unknown): void;
}>;
export type PlinkoDefinitionHandle<TInput> = Readonly<{
    graph: CompiledGraph<TInput>;

    start(
        input: TInput,
        options?: PlinkoStartOptions,
    ): PlinkoRunHandle;
}>;
export type SIG_BUS_PLINKO_FN = {
    <TInput>(
        definition: PlinkoDefinition<TInput>,
    ): PlinkoDefinitionHandle<TInput>;

    define<TInput>(
        definition: PlinkoDefinition<TInput>,
    ): PlinkoDefinitionHandle<TInput>;

    compile<TInput>(
        definition: PlinkoDefinition<TInput>,
    ): CompiledGraph<TInput>;
};
export class PlinkoDefinitionError extends Error {
    constructor(
        message: string,
        readonly errors: readonly string[],
        readonly warnings: readonly string[] = [],
    ) {
        super(message);
        this.name = "PlinkoDefinitionError";
    }
}
export class PlinkoTimeoutError extends Error {
    constructor(
        readonly nodeId: NodeId,
        readonly timeoutMs: number,
    ) {
        super(
            `Plinko node "${nodeId}" timed out after ${timeoutMs}ms.`,
        );
        this.name = "PlinkoTimeoutError";
    }
}
export class PlinkoTransitionLimitError extends Error {
    constructor(
        readonly graphId: string,
        readonly runId: RunId,
        readonly limit: number,
    ) {
        super(
            `Plinko graph "${graphId}" run "${runId}" exceeded maxTransitions (${limit}).`,
        );
        this.name = "PlinkoTransitionLimitError";
    }
}
export type StartOptions = {
    eventSink?: EventSink;
    maxTransitions?: number;
    runId?: RunId;

    /**
     * Used for non-durable diagnostics/telemetry. If omitted, telemetry append
     * failures are ignored. Event-sink failures are never ignored.
     */
    onTelemetryError?: (error: unknown, event: PlinkoEvent) => void;
};
export type RunSnapshot = Readonly<{
    id: RunId;
    graphId: string;
    graphVersion?: string;
    status: RunStatus;
    currentNodeId?: NodeId;
    input: unknown;
    results: Readonly<Record<string, unknown>>;
    events: readonly PlinkoEvent[];
    startedAt?: number;
    endedAt?: number;
    error?: SerializedError;
}>;
export type MutableRunSnapshot = {
    id: RunId;
    graphId: string;
    graphVersion?: string;
    status: RunStatus;
    currentNodeId?: NodeId;
    input: unknown;
    results: Record<string, unknown>;
    events: PlinkoEvent[];
    startedAt?: number;
    endedAt?: number;
    error?: SerializedError;
};
export type ReadonlyValue<T> = T extends object ? Readonly<T> : T;
export type Outcome = | "success" | "failure" | "skipped" | "cancelled";
export type RunStatus = | "idle" | "running" | "succeeded" | "failed" | "cancelled";
export type RetryPolicy = {
    maxAttempts?: number;
    delayMs?: number;
    maxDelayMs?: number;
    backoff?: "fixed" | "linear" | "exponential";
    jitter?: "none" | "full";
    retryIf?: (error: unknown, attempt: number) => boolean;
};
export type NodeContext<TInput, TResults extends Record<string, unknown> = Record<string, unknown>,> = {
    readonly runId: RunId;
    readonly nodeId: NodeId;
    readonly attempt: number;
    readonly input: TInput;
    readonly results: Readonly<TResults>;
    readonly variables: ReadonlyMap<string, unknown>;
    readonly signal: AbortSignal;
    emit(name: string, p?: unknown): void;
};
export type AttemptEvent<TOutput> =
    | {
        type: "started";
        attempt: number;
    }
    | {
        type: "succeeded";
        attempt: number;
        result: TOutput;
        durationMs: number;
    }
    | {
        type: "failed";
        attempt: number;
        error: SerializedError;
        durationMs: number;
        willRetry: boolean;
    }
    | {
        type: "retrying";
        attempt: number;
        delayMs: number;
    }
    | {
        type: "cancelled";
        attempt: number;
        reason?: unknown;
    };
export type NodeExecution<TOutput = unknown> = {
    outcome: Outcome;
    result?: TOutput;
    error?: SerializedError;
    attempt: number;
};
export type EventSink = {
    append(event: PlinkoEvent): void | Promise<void>;
};
export type RunHandle = {
    id: RunId;
    done: Promise<RunSnapshot>;

    getSnapshot(): RunSnapshot;
    subscribe(listener: () => void): () => void;
    cancel(reason?: unknown): void;
};
export interface HandlerContext {
    rt: string;
    adapter?: SIG_BUS_Adapter;
    meta: SIG_BUS_MessageMeta;
}
export interface SwitchboardResult {
    success: boolean;
    matchedKey: string | null;
    result?: any;
    error?: Error;
    unmatched?: boolean;
}
export type SwitchboardRoute2<TPayload = any> = (p: TPayload, ctx?: any) => Promise<any> | any;
export type SwitchboardRoutes<TPayload = any, TKey extends string = string> = | { [K in TKey | 'default']?: SwitchboardRoute2<TPayload> } | Map<string, SwitchboardRoute2<TPayload>>;
export interface SwitchboardHandle<TPayload = any, TKey extends string = string> {
    unregister: () => void; // same as your prior unregister()
    registerRoute: (rawKey: string, route: SwitchboardRoute2<TPayload>) => void;
    unregisterRoute: (rawKey: string) => boolean;
    updateRoutes: (routes: Partial<Record<string, SwitchboardRoute2<TPayload>>>) => void;
    getRoutes: () => Record<string, SwitchboardRoute2<TPayload> | undefined>;
    changes: () => AsyncIterable<{ type: 'add' | 'remove' | 'update'; key: string }>;
}
export interface SwitchboardOptions2<TPayload = any, TKey extends string = string> {
    selectKey: (p: TPayload) => TKey;
    onUnmatched?: (p: TPayload, key: string | null) => void;
}
export type PlinkoConditionType2 = | 'onSuccess' | 'onFailure' | 'always' | 'envVariable' | 'configValue' | 'fileExists' | 'fileNotExists' | 'itemSuccess' | 'itemFailure' | 'custom' | 'and' | 'or' | 'not' | 'timeBased' | 'rateLimit' | 'random' | 'dependencies';
export type ExecutionMode2 = 'sequential' | 'parallel' | 'firstMatch' | 'allMatch' | 'race';
export type BackoffStrategy2 = 'exponential' | 'linear' | 'fixed' | 'none';
export interface RetryConfig2 {
    max: number;
    backoff: BackoffStrategy2;
    delay?: number;
    maxDelay?: number;
    retryOn?: string[]; // Error types to retry on
}
export interface PlinkoCondition2 {
    type: PlinkoConditionType2;
    // Environment/Config
    envKey?: string;
    configKey?: string;
    operator?: 'equals' | 'contains' | 'startsWith' | 'endsWith' | 'regex' | 'gt' | 'gte' | 'lt' | 'lte';
    value?: any;
    // File operations
    filePath?: string;
    // Item tracking
    itemLabel?: string;
    // Custom expressions
    expression?: string;
    // Logic operators
    conditions?: PlinkoCondition2[];
    // Time based
    window?: number; // Time window in ms
    limit?: number; // Rate limit count
    // Execution targets
    executeChain?: string | string[] | PlinkoStep2[];
    exe?: PlinkoStep2[];
    // Branching
    onSuccess?: string | PlinkoStep2[];
    onFailure?: string | PlinkoStep2[];
    // Priority (higher runs first)
    priority?: number;
    // Optional label
    label?: string;
    // Timeout for this condition's execution
    timeout?: number;
}
export interface PlinkoStep2 {
    id?: string;
    label?: string;
    path?: string;
    type: 'chain' | 'parallel' | 'conditionalTree' | 'function' | 'retry' | 'timeout' | 'circuitBreaker';
    args?: any[];
    // Execution
    execute?: (context: PlinkoContext2) => any | Promise<any>;
    // Chain execution (sequential steps)
    steps?: PlinkoStep2[];
    // Conditional tree args
    conditions?: PlinkoCondition2[];
    // Retry configuration
    retry?: RetryConfig2;
    // Timeout in ms
    timeout?: number;
    // Circuit breaker
    circuitBreaker?: {
        failureThreshold: number;
        resetTimeout: number;
        halfOpenMaxCalls: number;
    };
    // Condition to run this step
    condition?: (context: PlinkoContext2) => boolean | Promise<boolean>;
    // Priority
    priority?: number;
    // Dependencies
    dependsOn?: string[];
    // On complete hook
    onComplete?: (result: any, context: PlinkoContext2) => any | Promise<any>;
    onError?: (error: Error, context: PlinkoContext2) => any | Promise<any>;
    // Environment
    environment?: string | string[];
    metadata?: Record<string, any>;
}
export interface PlinkoContext22 {
    // Original p
    p: any;
    // Shared state
    state: Map<string, any>;
    // Results from each step
    results: Map<string, any>;
    // Execution history
    history: string[];
    // Variables (mutable)
    variables: Map<string, any>;
    // Step results with timestamps
    stepResults: Map<string, StepResult2>;
    // Session ID
    sessionId: string;
    // Start time
    startTime: number;
    // Parent context (for nested executions)
    parent?: PlinkoContext2;
    // Bus reference
    bus: any;
    // Metadata
    metadata: Map<string, any>;
}
export interface PlinkoContext2 {
    p: any;
    state: Map<any, any>;
    results: Map<any, any>;
    history: string[];
    variables: Map<any, any>;
    stepResults: Map<any, any>;
    sessionId: string;
    startTime: number;
    bus: any;
    metadata: Map<any, any>;
}
export interface StepResult2 {
    success: boolean;
    result?: any;
    error?: Error;
    duration: number;
    startTime: number;
    endTime: number;
    metadata?: Record<string, any>;
}
export interface PlinkoTree2<T = any> {
    [key: string]: PlinkoStep2 | PlinkoTree2<T> | ((context: PlinkoContext2) => any);
}
export interface PlinkoExecutionResult2 {
    sessionId: string;
    success: boolean;
    results: Map<string, StepResult2>;
    history: string[];
    duration: number;
    error?: Error;
    metadata: Record<string, any>;
}
export type GateMatcher1<T = any> = (p: T) => boolean | Promise<boolean>;
export type GateHandler1<T = any, R = any> = (
    p: T,
    context: {
        reply: (data: any, subrt?: string) => Promise<unknown>;
        store: Map<string, any>;
        bus: any;
    }
) => R | Promise<R>;
export interface GateDefinition1<T = any, R = any> {
    priority?: number;
    matcher: GateMatcher1<T>;
    execute: GateHandler1<T, R>;
    persistent?: boolean;
    blocking?: boolean;
}
export type GateInput1<T = any> =
    | GateMatcher1<T>
    | GateDefinition1<T>;
export type GateMap1<T = any> = Record<string, GateInput1<T>>;
export interface GateExecutionResult1 {
    gateId: string;
    fired: boolean;
    result?: any;
    error?: Error;
    duration: number;
}
export interface ResolvedGate1<T = any> extends GateDefinition1<T> {
    id: string;
}
export interface RelayHandle {
    publish: (chunk: any) => Promise<void>;
    subscribe: (handler: (chunk: any) => void) => {
        unsubscribe: () => void;
        pause: () => void;
        resume: () => void;
        getBufferSize: () => number;
    };
    end: () => Promise<void>;
    stats?(): { subscribers: number; ended: boolean };
}
export interface RelaySubscription {
    unsubscribe(): void;
    pause(): void;
    resume(): void;
    getBufferSize(): number;
}
export interface RelayOptions {
    maxSubscribers?: number;
    bufferSize?: number;
    backpressureStrategy?: 'drop' | 'pause' | 'error';
}
export interface OffsetCheckpoint {
    epoch: string;
    offset: number;
}
export interface RelaySub {
    id: string;
    buffer: WireEnvelope[];
    paused: boolean;
    closed: boolean;
    notify: (() => void) | null;
    pump: Promise<void>;
}
export interface OffsetStore {
    get(sid: string): Promise<OffsetCheckpoint | undefined>;
    set(sid: string, cp: OffsetCheckpoint): Promise<void>;
    delete(sid: string): Promise<void>;
}
export interface SyncSubOptions {
    name?: string;
    epoch?: string;          // resume a run from its checkpoint
    maxSkew?: number;
    bufferTtlMs?: number;
    nackDelayMs?: number;
    nackBatch?: number;
    graceMs?: number;
    offsetStore?: OffsetStore;
    checkpointEveryMs?: number;
    onDlq?: (env: WireEnvelope, reason: string) => MaybePromise<void>;
    onComplete?: (err?: Error) => void;
    signal?: AbortSignal;
}
export interface SyncHandle {
    close(): void;
    whenComplete(): Promise<void>;
    state(): { epoch: string | null; expected: number; buffered: number };
}
export interface SyncSendOptions {
    name?: string;
    epoch?: string;          // reuse to resume a prior interrupted run
    trace?: string;
    windowSize?: number;
    timeoutMs?: number;
    maxRetries?: number;
    backoffBaseMs?: number;
    onProgress?: (acked: number, total: number) => void;
    onDlq?: (env: WireEnvelope, reason: string) => MaybePromise<void>;
    signal?: AbortSignal;
}
export interface StreamLabMetrics {
    dataSent: number;
    dataAcked: number;
    dataRetransmitted: number;
    nackSent: number;
    nackReceived: number;
    overflow: number;
    dlq: number;
    dropped: number;
    errors: number;
    streamsActive: number;
    streamsCompleted: number;
    relaySent: number;
}
export type WireKind = 'data' | 'ack' | 'nack' | 'done' | 'abort' | 'dlq';
export interface WireEnvelope<T = unknown> {
    v: number
    kind: WireKind;
    sid: string;        // deterministic logical stream id
    epoch: string;      // run id — reusing an epoch resumes that run
    seq: number;
    total: number;
    data?: T;
    enc?: 'json' | 'base64';
    trace: string;
    retryOf?: number;
    reason?: string;
}
export interface SauronState {
    get<T>(key: string | symbol, opts?: ScopeOptions): T | undefined
    set<T>(key: string | symbol, value: T | ((prev: T | undefined) => T), opts?: { triggerRender?: boolean } & ScopeOptions): void
    delete(key: string | symbol, opts?: ScopeOptions): boolean
    getByPrefix<T>(prefix: string, opts?: ScopeOptions): { key: string; value: T }[]
    getAll<T = any>(opts?: ScopeOptions): Record<string | symbol, T>
    subscribe<T>(key: string | symbol, listener: (value: T) => void, opts?: ScopeOptions): () => void
    subscribeAll(listener: (key: string | symbol, value: any) => void, opts?: ScopeOptions): () => void
    clear(opts?: ScopeOptions): void
    waitFor<T = any>(key: string | symbol, opts: ScopeOptions): Promise<T>
    batch?(key: any, fn: () => void): void
}
export interface HookState {
    value: any
    deps?: any[]
    cleanup?: () => void
    ref?: any
    domRefs?: Map<string, Node>
    bindings?: Set<DOMBinding>
}
export interface ComponentInstance {
    id: string
    hooks: Map<string, HookState>
    unmount: Set<() => void>
    render?: () => void
    parent?: ComponentInstance | null
    contextProviders?: Map<string, { value: any; subscribe: (fn: () => void) => () => void }>
}
export interface OptimisticHookState extends HookState {
    previousValue: any
    isPending: boolean
}
export interface SauronContext<T> {
    id: string;
    DefaultValue?: T;
    Provider?: any;
    sl?: string
    ms?: string
    rt?: string
}
export interface RuntimeAdapter {
    getComponentInstance: () => { instance: ComponentInstance, forceUpdate: () => void }
    onHookSubscribe: (key: string, forceUpdate: () => void) => void
}
