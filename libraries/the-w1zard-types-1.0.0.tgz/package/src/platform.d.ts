export { }

type MaybePromise<R = any> = R;
function MaybePromise<R = any>(v: R): MaybePromise {
    return v !== undefined ? v as R : Promise.resolve(v) as Promise<R> 
}

declare global {
    var SSR: SOUL_SHARD_REGISTRY;
    var SE: SAURONS_EYE;
    // #region ═════════════════════════════════════════════════════════════ UPGRADED BASE ═══
    type MaybePromise<R = any> = R;
    var MaybePromise: typeof MaybePromise;
 
    // #endregion
    // #region ═══════════════════════════════════════════════════════════════════ PLATFORM ═══
    type AO = Record<S, A>;
    type AS = { self: A;[key: S]: A };
    type AF = (ctx: AS) => AO;
    type AOAF = AO | AF;
    type CHAIN = "chain" | "rechain";
    type SU<T = A> = string | undefined
    type XS<T = A> = any
    type Wildcard = "*";
    type SET<T = A> = Set<T>
    type L<T = A> = never
    type NB<T = A> = bigint
    type CACHE_TYPE = 
    "sauron" | 
    "disruptor" | 
    "cache" |
    "rifts" | 
    'sclass'| 
    'cookie' | 
    'scookie' | 
    'kvdb' | 
    'rdb' | 
    'tdb' | 
    'bdb' | 
    'gdb' | 
    'idb' | 
    'hpd' | 
    undefined;
    type CACHE  = CACHE_TYPE
    // #endregion
    // #region ═══════════════════════════════════════════════════════════════════ PLATFORM ═══
   

    type SlottedResult<S extends S = S> = {
        [K in S]?: S;
    } & {
        className?: S;
        class?: S;
        [key: S]: A;
    };
    type NamespaceAugment = A;
    // Define based on your implementation
    // ...args: [...INI_QD<T>,]
    //  mailbox<T = A>(...args: [...INI_QD<T>, ]): A
    // ...args: [...QD_INI,]
    //  mailbox(...args: [...QD_INI, ]): A
    // ...args: [...QD,]
    //  mailbox(...args: [...QD, ]): A
    type CELL_TYPE = "waitFor" | "sub" | "cell" | "none";
    type CHAIN_TYPE = "chain" | "rechain";
    type STORE_TYPE = "tc" | "rr" | "auto";
    type CELL = "waitFor" | "sub" | "cell" | "none";
    type CHAIN = "chain" | "rechain";
    type STORE = "tc" | "rr" | "auto";
    type INI_QD<T = A> = [v?: T, k?: A, sl?: S, ms?: S, rt?: S];
    type QD_INI = [k: A, v?: A, sl?: S, ms?: S, rt?: S];
    type QD = [k: A, sl?: S, ms?: S, rt?: S];
    interface ScopeOptions {
        k?: A;
        s?: A;
        m?: A;
        r?: A;
    }

    type MODULE_PAYLOAD = A;

type MODULE_CELL<P extends MODULE_PAYLOAD = MODULE_PAYLOAD> = {
    initial?: A;
     key: A;
     module: A;
    version?: N;
    module_type:  'class_fn_pool' |  'fn'| 'comp'| 'node_module';
    sealed?: B
    frozen?: B
    hasWritten?: B
    persisted?: B
    createdAt: N;
    label?: S;
    source?: S;
    meta?: Record<string, unknown>;
    rt?:S
ms?:S
sl?:S
k: A
conflict?:ConflictPolicy 
undoStack?:HistoryEntry[]
historyIndex?:N
history?: AtomHistoryEntry<T>[];
historyMax?: N
lifecycle?: SignalLifecycle
async?: AsyncSignalState<T>;
metrics?: Metrics
conflictStrategy?:"latest" | "fail" | "accumulate";
schema?: SignalSchema
contracts?:  Map<string, AtomContract<T>>
causal?:  CausalEntry[]
lastWriteSource?: S
batches?:Set<SignalKey>
batchQueue?: Map<SignalKey, unknown>
batchOpts?:Map<SignalKey, { triggerRender?: boolean }>
broadcast?:B
triggerRender?:B
boundary?: Boundary
};

    // #endregion
    // #region ══════════════════════════════════════════════════════════════════════ FREYR ═══

    interface freyr_interface {
        theme?: themesT | S;
        kernelTheme?: A;
        version?: versionT;
        mode?: modeT
        presets?: presetsT
        colors?: colorsT
        styles?: A
        enviroments?: enviromentsT
        themeswitcher?: themeswitcherT
        fonts?: fontsT
        children?: A
        className?: A
    }


    type themesT = 'default' | 'css' | "Acid-Trip" | "Another-Acid-Trip" | "Afterglow-Fade" | "Amazon-Jungle" | "Amethyst-Stone" | "Aqua-Glacier" | "Black-Velvet-Luxe" | "Blueprint-Grid" | "C-Carbon-6" | "Cirrus-Float" | "Cobalt-Ice" | "Concrete-slab" | "Crystal-Quartz" | "Cyber-Industrial" | "Cyber-Pop" | "Dark-Crimson" | "Deep-Abyss" | "Deep-Emerald" | "Deep-Ocean" | "Deep-Sea-Navigator" | "Deep-Teal" | "Deep-Void" | "Deep-Void-And-Beyond" | "Desert-Night" | "Espresso-High" | "Executive-Level" | "Fifth-Element-Aether" | "Forest-Tech" | "Frozen-Deep" | "Geek-Blue" | "Glacier-Blue" | "Graphite-Neutron-Moderator" | "Granite-Top" | "High-Alert-Crimson" | "Interstellar-Nebula" | "Loki" | "Mainframe-Terminal" | "Meadow-Whisper" | "Metropolis-Sky-Scape" | "Midas-Touch" | "Middle-Field-Canvas" | "Mineral-Forest" | "Modern-Retro" | "Monet-Impressionism" | "Nightshade-Venom" | "Obsidian-Wine" | "Oceanic-Gradient" | "Oceanic-Sunset" | "Office-Paper" | "Oracle-Vision" | "Pastel-Sorbet" | "Polymer-Flow" | "Retro-Arcade" | "Silk-Petal" | "Smoldering-Ember" | "Solar-Flare" | "Solstice-Heat" | "Sonic-Pulse" | "Sorbet-Swirl" | "Studio-Apartment" | "Synthwave-Neon" | "Tactical-Ops" | "Terra-Verde" | "Ti-Titanium-22" | "True-Veridian" | "Twilight-Bloom" | "Vanguard-Strike" | "Vintage-Heritage" | "Workplace-Chatter" | "Forest-Tech-2" | "Linear" | "DOOM" | "Metroid-Prime" | "Chrono-Trigger" | "Wipeout" | "Monochrome-Monitors" | "Synthwave" | "Frutiger-Aero" | "Command-Line-Interface" | "ASCII-Art" | "VHS-Analog-Horror-Grainy" | "Pac-Man" | "Fallout-PIP-Boy" | "Zelda" | "Final-Fantasy" | "Street-Fighter" | "Diablo" | "Diablo2" | "StarCraft-Terran" | "StarCraft-Protoss" | "StarCraft-Zerg" | "DOOM2" | "Linear"
    type presetsT = "DEFAULT" | "MODERN" | "CREATIVE" | "TECHNICAL" | "FINTECH" | "LUXURY" | "BRUTALIST" | "EDITORIAL" | "PLAYFUL" | "MINIMALIST" | "GAMING" | "MEDICAL" | "ECOMMERCE" | "CORPORATE" | "RETRO"
    type fontsT =
        // SANS-SERIF
        | "Inter" | "Roboto" | "Geist" | "Poppins" | "Montserrat" | "Outfit" | "Plus Jakarta Sans" | "DM Sans" | "Urbanist" | "Nunito" | "Lato" | "Barlow" | "Gabriela" | "Delius Swash Caps" | "Public Sans" | "Work Sans" | "Manrope" | "Figtree" | "Archivo"
        // SERIF
        | "Merriweather" | "Playfair Display" | "Lora" | "Source Serif 4" | "Libre Baskerville" | "Space Grotesk" | "PT Serif" | "Fraunces" | "Cormorant Garamond" | "Crimson Pro" | "EB Garamond" | "Newsreader" | "DM Serif Display" | "Prata" | "Bodoni Moda" | "Young Serif"
        // MONO
        | "JetBrains Mono" | "Fira Code" | "Geist Mono" | "IBM Plex Mono" | "Roboto Mono" | "Space Mono" | "Source Code Pro" | "Ubuntu Mono" | "Red Hat Mono" | "Cutive Mono" | "Nanum Gothic Coding"
        // DISPLAY
        | "Sora" | "Bricolage Grotesque" | "Clash Display" | "Syne" | "Unbounded" | "Cabinet Grotesk" | "Righteous" | "Lexend" | "Kanit"
    type enviromentsT = "VSCODE" | "OTHER"
    type colorsT = "NGIN" | "CUSTOM"
    type themeswitcherT = true | false
    type versionT = "v3" | "v4"
    type modeT = "light" | "dark" | "root"

    // #endregion
    // #region ═════════════════════════════════════════════════════════════════════ SAURON ═══
    interface SAURON_REGISTRY_STORAGE {
      get<T>(key: S, opts?: ScopeOptions): T | UD
      set<T>(key: S, value: T | ((prev: T | UD) => T), opts?: { triggerRender?: B } & ScopeOptions): V
      delete(key: S, opts?: ScopeOptions): B
      getByPrefix<T>(prefix: S, opts?: ScopeOptions): { key: S; value: T }[]
      getAll<T = A>(opts?: ScopeOptions): Record<S, T>
      subscribe<T>(key: S, listener: (value: T) => V, opts?: ScopeOptions): () => V
      subscribeAll(listener: (key: S, value: A) => V, opts?: ScopeOptions): () => V
      batch(key: S, fn: () => V, opts?: ScopeOptions): V
      clear(opts?: ScopeOptions): V
    
      name: S
      destroy(): V
    }
    type StateOptions<T, S = T> = {
        equals?: (prev: S, next: S) => B
        selector?: (value: T) => S
        derive?: (value: T) => A
    }
    interface SauronState {
        get<T>(key: S | symbol, opts?: ScopeOptions): T | UD
        set<T>(key: S | symbol, value: T | ((prev: T | UD) => T), opts?: { triggerRender?: B } & ScopeOptions): V
        delete(key: S | symbol, opts?: ScopeOptions): B
        getByPrefix<T>(prefix: S, opts?: ScopeOptions): { key: S; value: T }[]
        getAll<T = A>(opts?: ScopeOptions): Record<S | symbol, T>
        subscribe<T>(key: S | symbol, listener: (value: T) => V, opts?: ScopeOptions): () => V
        subscribeAll(listener: (key: S | symbol, value: A) => V, opts?: ScopeOptions): () => V
        clear(opts?: ScopeOptions): V
        waitFor<T = A>(key: S | symbol, opts: ScopeOptions): Promise<T>
        batch?(key: A, fn: () => V): V
    }
    interface HookState {
        value: A
        deps?: A[]
        cleanup?: () => V
        ref?: A
        domRefs?: Map<S, Node>
        bindings?: Set<DOMBinding>
    }
    interface ComponentInstance {
        id: S
        hooks: Map<S, HookState>
        unmount: Set<() => V>
        render?: () => V
        parent?: ComponentInstance | null
        contextProviders?: Map<S, { value: A; subscribe: (fn: () => V) => () => V }>
    }
    interface OptimisticHookState extends HookState {
        previousValue: A
        isPending: B
    }
    interface SauronContext<T> {
        id: S;
        DefaultValue?: T;
        Provider?: A;
        sl?: S
        ms?: S
        rt?: S
    }
    interface RuntimeAdapter {
        getComponentInstance: () => { instance: ComponentInstance, forceUpdate: () => V }
        onHookSubscribe: (key: S, forceUpdate: () => V) => V
    }
    // #endregion
    // #region ══════════════════════════════════════════════════════════════════ THE_CLOUD ═══
    interface FieldRef<T = A> {
        get(): T | Promise<T>
        set(value: T): V | P<A>
    }
    interface ForbiddenBoundaryArgs {
        location: { pathname: S; search: S; params: Record<S, S> }
        wardPath: S
    }
    interface GlitchBoundaryArgs {
        error: U
        location: { pathname: S; search: S; params: Record<S, S> }
    }
    interface HXRequest {
        method: S;
        path: S;
        trigger?: S;
        triggerName?: S;
        currentURL?: S;
        target?: S;
        swap?: SwapStrategy;
        values?: Record<S, A>;
        formData?: Record<S, A>;
        headers: Record<S, S>;
    }
    type SwapStrategy =
        | 'innerHTML'
        | 'outerHTML'
        | 'beforebegin'
        | 'afterbegin'
        | 'beforeend'
        | 'afterend'
        | 'delete'
        | 'none';
    type OutletFrame = {
        childHtml: S
        depth?: N
        warlock?: B
    }
    interface RouterResult {
        status: N
        headers: Record<S, S>
        body: A
    }
















    type SwapStrategy =
        | 'outerHTML'
        | 'innerHTML'
        | 'beforeend'
        | 'afterbegin'
        | 'beforebegin'
        | 'afterend'

    interface SwapPayload {
        domTargetId: S
        html: S
        strategy: SwapStrategy
    }
    interface HXResponse {
        html: S;
        target?: S;
        swap?: SwapStrategy;
        swapDelay?: N;
        settleDelay?: N;
        headers?: Record<S, S>;
        triggers?: S | Record<S, A>;
        pushURL?: S;
        replaceURL?: S;
        reTarget?: S;
        reSelect?: S;
        hxTrigger?: S;
        hxTriggerAfterSettle?: S;
        hxTriggerAfterSwap?: S;
    }
    type RenderTracker = {
        clientId: S
        fragmentId: S
        deps: Set<S | symbol>
    }
    type Location = { pathname: S; search: S; params: Record<S, S> }
    type Match = { path: S; params: Record<S, S>; handle: A }

    type FragmentTrailEntry = { categoryName: S; fragmentId: S; domTargetId: S }
    interface WardResponse {
        __wardResponse: true
        status: N
        headers: Record<S, S>
        body: A
    }

    interface RouteErrorResponse {
        status: N
        statusText: S
        data: A
    }
    type OutletFrame = { childHtml: S }
    type RenderContext = {
        clientId: S;
        location: Location;
        session: Session;
        matches: Match[];
        currentError?: U;
        currentAsyncValue?: U;
        portals: Map<S, S[]>;
        cleanups: (() => V)[];
        formData?: FormData;
        fragmentTrail: FragmentTrailEntry[];
        customContexts?: Map<S, A>;
        outletStack: OutletFrame[]
        currentWardDepth?: N
    }
    interface LinkProps {
        to: S
        className?: S
        children: S
        [attr: S]: A
    }

    interface NavLinkProps extends LinkProps {
        activeClassName?: S
        end?: B
    }

    interface WarlockLinkProps extends LinkProps { }

    interface RouteConfig {
        pattern: S;
        GET?: (req: HXRequest) => Promise<HXResponse | S> | HXResponse | S;
        POST?: (req: HXRequest) => Promise<HXResponse | S> | HXResponse | S;
        PUT?: (req: HXRequest) => Promise<HXResponse | S> | HXResponse | S;
        PATCH?: (req: HXRequest) => Promise<HXResponse | S> | HXResponse | S;
        DELETE?: (req: HXRequest) => Promise<HXResponse | S> | HXResponse | S;
        WS?: (ws: WebSocket, req: HXRequest) => V;
        CSE?: (rt: S, req: HXRequest) => V;
    }
    interface HTMXTriggerConfig {
        event?: S        // 'click' | 'change' | 'submit' | 'revealed' | etc — default 'click'
        method?: 'GET' | 'POST'
        target?: S        // domTargetId to swap into — default self
        swap?: SwapStrategy     // default 'outerHTML'
        poll?: S           // e.g. '5s' — overrides event-based trigger entirely
        debounce?: S       // e.g. '300ms' — applied to event, ignored when polling
    }
    type HTMXEvent = {
        clientId: S
        domTargetId: S
        key: S
        value: A
    }









    interface DeferredData {
        __deferred: true
        data: Record<S, A>
    }
    interface Task {
        cancel(): V
        reprioritize(next: Priority): V
    }
    interface ScheduledTask {
        priority: Priority
        scope: symbol | S
        fn: () => V
        signal?: AbortSignal
        cancelled: B
    }
    type Priority = 'immediate' | 'user-blocking' | 'normal' | 'background' | 'idle'
    type BatchScope = symbol;
    type FlushCallback = () => V;

    interface ORSetState<T = A> { adds: { item: T; tag: S; }[]; removes: { item: T; tag: S; }[]; }

    interface HLCState { wall: N; logical: N; node: S; }
    interface LWWState<T = A> { value: T | UD; stamp: S; _hlc?: HLCState; }
    interface MVEntry<T> { value: T; stamp: S }

    interface PNCounterState {
        positive: Record<S, N>;
        negative: Record<S, N>;
    }
    type CBCircuitState = 'closed' | 'open' | 'half-open';

    interface CBCircuitBreakerOptions {
        failureThreshold: N;
        cooldownMs: N;
        cooldownMaxMs: N;
        cooldownFactor: N;
        halfOpenMaxAttempts: N;
        isFailure?: (err: U) => B; // default: everything counts as a failure
        timeoutMs?: N;                     // slow calls count as failures
    }
    interface SStorageState {
        get<T>(key: S, opts?: ScopeOptions): T | UD
        set<T>(key: S, value: T | ((prev: T | UD) => T), opts?: { triggerRender?: B } & ScopeOptions): V
        delete(key: S, opts?: ScopeOptions): B
        getByPrefix<T>(prefix: S, opts?: ScopeOptions): { key: S; value: T }[]
        getAll<T = A>(opts?: ScopeOptions): Record<S, T>
        subscribe<T>(key: S, listener: (value: T) => V, opts?: ScopeOptions): () => V
        subscribeAll(listener: (key: S, value: A) => V, opts?: ScopeOptions): () => V
        batch(key: S, fn: () => V, opts?: ScopeOptions): V
        clear(opts?: ScopeOptions): V

        name: S
        destroy(): V
    }
    interface SauronRegistry extends SauronState {
        name: S
        destroy(): V
    }
    type MatchPredicate<TInput> = ((val: TInput) => B) | RegExp | S | N;

    type ActionHandler<TInput = A> = (val: TInput) => A;

    type ConditionBranch<TInput = A> =
        | ActionHandler<TInput>
        | { match: MatchPredicate<TInput>; run: ActionHandler<TInput> };

    type ConditionHandlers<TInput = A> =
        | Record<S, ConditionBranch<TInput>>
        | Map<S, ConditionBranch<TInput>>;

    type Gate<TValue, TResult> = {
        match: (value: TValue) => MaybePromise<B>;
        execute: (value: TValue) => MaybePromise<TResult>;
    };
    type GateMap2<TValue, TResult> = Record<S, Gate<TValue, TResult>
    >;
    interface KernelContext {
        self: A;
        config: A;
        variables: A;
    }
    type ConditionMode = 'switch' | 'if' | 'ifelse';
    type GateMasterOptions2 = {
        mode?: "concurrent" | "sequential";
        execution?: "all" | "first";
    };
    interface WritableLike {
        write(chunk: Uint8Array | S): V
        end(): V
        destroy?(error?: Error): V
        flush?(): V
    }
    type SearchFunction = (buffer: Uint8Array, startIndex?: N) => N
    type PartialTailSearchFunction = (buffer: Uint8Array) => N
    interface ActionResult<T = A> {
        data?: T
        error?: S
        status: 'success' | 'error'
    }
    type ActionArgs = { request: Request; params: Record<S, S> }
    type ActionFunction<T = U> = (args: ActionArgs) => Promise<Response> | Response | Promise<T> | T

    type Action = ReturnType<typeof createAction>
    type ClientAction = ReturnType<typeof createClientAction>
    type ReferrerPolicy =
        | "no-referrer-when-downgrade"
        | "no-referrer"
        | "origin-when-cross-origin"
        | "origin"
        | "same-origin"
        | "strict-origin-when-cross-origin"
        | "strict-origin"
        | "unsafe-url";
    type HandleConventionArguments<Data = U> = {
        id: S;
        data: Data;
        params: Params;
        matches: ReturnType<typeof useMatches>;
        location: Location;
        parentsData: RouterState["loaderData"];
    };
    type SafeHtml = String & { readonly [kSafeHtml]: true }
    type ScriptProps = Omit<
        React.HTMLProps<HTMLScriptElement>,
        | "children"
        | "async"
        | "defer"
        | "src"
        | "type"
        | "noModule"
        | "dangerouslySetInnerHTML"
        | "suppressHydrationWarning"
    >;
    type CloudKind = "loader" | "action"
    interface CloudRunRequest {
        kind: CloudKind
        routeId: S
        url: S
        method?: S
        body?: A
        headers?: Record<S, S>
    }



    interface RouterLocation {
        pathname: S;
        search: S;
        hash: S;
        full: S;
    }

    interface RouterMatchEntry {
        id: S;
        pathname: S;
        params: Record<S, S>;
        data: A;
        actionData: A;
        error: A;
    }

    interface RouterStoreType {
        location: RouterLocation;
        state: A;
        data: A;
        actionData: A;
        error: A;
        isNavigating: B;
        matches: RouterMatchEntry[];
    }

    interface RouterStoreInterface {
        RouterLocation: RouterLocation;
        RouterMatchEntry: RouterMatchEntry;
        RouterStore: RouterStoreType;
    }

    interface RouterStoreTypes { }


    type NavigationState = "idle" | "loading" | "submitting";
    type FetcherState = "idle" | "loading" | "submitting" | "success" | "error";

    interface RouteLocation {
        pathname: S;
        search: S;
        hash: S;
        full: S;
    }

    interface RouteMatch {
        id: S;
        pathname: S;
        params: Record<S, S>;
        data: U;
        actionData: U;
        error: U;
    }

    interface NavigateOptions {
        replace?: B;
        state?: U;
        scroll?: B;
        resetScroll?: B;
    }

    interface RouterStore {
        location: RouteLocation;
        state: U;
        data: U;
        actionData: U;
        error: U;
        matches: RouteMatch[];
        isNavigating: B;
        listeners?: Set<() => V>;
    }

    interface NavigateResult {
        go: (delta: N) => V;
        push: (path: S, opts?: NavigateOptions) => V;
        replace: (path: S, opts?: NavigateOptions) => V;
        back: () => V;
        forward: () => V;
        reload: (hard?: B) => V;
        prefetch: (path: S) => V;
        transition: (fn: () => V) => V;
    }

    interface FetcherResult {
        data: A;
        error: Error | null;
        state: FetcherState;
        submit: (p: U, path?: S) => P<A>;
        load: (path: S) => P<A>;
        reset: () => V;
    }

    type LdJsonPrimitive = S | N | B | null;
    interface LdJsonObject {
        [Key: S]: LdJsonValue | UD;
    }
    type LdJsonArray = LdJsonValue[] | readonly LdJsonValue[];
    type LdJsonValue = LdJsonPrimitive | LdJsonObject | LdJsonArray;

    type MetaDescriptor =
        | { charSet: "utf-8" }
        | { title: S }
        | { name: S; content: S }
        | { property: S; content: S }
        | { httpEquiv: S; content: S }
        | { "script:ld+json": LdJsonObject }
        | { tagName: "meta" | "link";[name: S]: S }
        | { [name: S]: U };

    interface ClientActionArgs {
        request: Request;
        params: Record<S, S>;
        serverAction: () => Promise<A>;
    }

    interface ClientLoaderArgs {
        request: Request;
        params: Record<S, S>;
        serverLoader: () => Promise<A>;
    }

    interface MetaArgs {
        data: A;
        params: Record<S, S>;
        location: { pathname: S; search: S; hash: S };
        matches: {
            id: S;
            pathname: S;
            params: Record<S, S>;
            data: A;
            handle?: RouteHandle;
            meta: MetaDescriptor[];
            error?: U;
        }[];
        error?: U;
    }

    interface ShouldRevalidateArgs {
        currentUrl: URL;
        nextUrl: URL;
        params: Record<S, S>;
        formMethod?: S;
        formAction?: S;
        defaultShouldRevalidate: B;
    }

    type ClientActionFunction = (
        args: ClientActionArgs
    ) => Promise<A> | A;

    type ClientLoaderFunction = ((
        args: ClientLoaderArgs
    ) => Promise<A> | A) & { hydrate?: B };

    interface BackoffOptions {
        base?: N;
        factor?: N;
        max?: N;
        jitter?: B;
    }

    interface MetricsSnapshot {
        timestamp: N;
        nodeId: S;
        uptime: N;

        // Queue Metrics
        queue: {
            currentSize: N;
            maxSize: N;
            fillPercent: N;
            peakSize: N;
            totalEnqueued: N;
            totalDropped: N;
            totalProcessed: N;
            drainCount: N;
            avgDrainTime: N;
            deadLetterSize: N;
        };

        // Flood Gate Metrics - THE MONEY SHOT
        floodGates: {
            openGates: N;
            gate1: { hits: N; errors: N; lastHit: N; avgLatency: N };
            gate2: { hits: N; errors: N; lastHit: N; avgLatency: N };
            gate3: { hits: N; errors: N; lastHit: N; avgLatency: N };
            gate4: { hits: N; errors: N; lastHit: N; avgLatency: N };
            totalHits: N;
            totalErrors: N;
            bypassRate: N;
            avgLatency: N;
            throughputPerSecond: N;
        };

        // Lane Metrics - SPREAD 'EM
        lanes: {
            normal: { processed: N; avgLatency: N; errors: N; throughput: N };
            signal: { processed: N; avgLatency: N; errors: N; throughput: N };
            binary: { processed: N; avgLatency: N; errors: N; throughput: N };
            signal_save_value: { processed: N; avgLatency: N; errors: N; throughput: N };
        };

        // Adapter Metrics - ALL OF THEM
        adapters: Array<{
            id: S;
            total: N;
            failures: N;
            avgLatency: N;
            throughput: N;
            errorRate: N;
            healthy: B;
            floodGateProcessed: N;
        }>;

        // Backpressure Metrics
        backpressure: {
            throttled: B;
            throttleCount: N;
            lastThrottle: N;
            avgQueueDepth: N;
            maxQueueDepth: N;
            totalBackpressureEvents: N;
        };

        // Channel Metrics
        channels: {
            total: N;
            activeSubs: N;
            totalMessages: N;
            topChannels: Array<{ name: S; count: N }>;
        };

        // System Metrics
        system: {
            memoryUsage: NodeJS.MemoryUsage;
            cpuUsage: NodeJS.CpuUsage;
            eventLoopLag: N;
            activeHandlers: N;
            pendingRequests: N;
        };

        // Feature Usage Metrics
        features: {
            beacon: N;
            radar: N;
            vessel: N;
            dock: N;
            convoy: N;
            sonar: N;
            heartbeat: N;
            watchdog: N;
            floodGate: N;
            pipeline: N;
            tide: N;
            mesh: N;
            crdt: N;
            synapse: N;
            transaction: N;
            circuitBreaker: N;
            rateLimit: N;
        };
    }
    interface ILazy<T> { readonly isValueCreated: B; readonly value: T; }

    type StageName =
        | 'enqueue' | 'floodgate_check' | 'floodgate_bypass'
        | 'classify_lane' | 'dispatch' | 'route' | 'transform'
        | 'adapter_send' | 'invoke_handlers' | 'ack' | 'nak' | 'dead_letter';

    interface StageEvent {
        stage: StageName;
        ts: N;
        durationMs?: N;
        detail?: Record<S, U>;
    }
    type LaneName = 'normal' | 'signal' | 'binary' | 'signal_save_value'
    type GateNumber = 1 | 2 | 3 | 4
    interface MessageTrace {
        id: S;
        rt: S;
        ms?: S;
        createdAt: N;
        finishedAt?: N;
        totalMs?: N;
        lane?: LaneName;
        gate?: GateNumber;
        adapterId?: S;
        outcome?: 'delivered' | 'queued' | 'dropped' | 'dead_lettered' | 'error';
        payloadSize?: N;
        stages: StageEvent[];
    }

    type ShouldRevalidateFunction = (
        args: ShouldRevalidateArgs
    ) => B;

    interface RingLike<T = U> {
        /** Ring capacity (power of two typically). */
        readonly capacity: N
        /** Monotonic producer sequence — next slot to be written. */
        producerSequence(): N
        /** Read the slot at an absolute sequence N without consuming. */
        peek(seq: N): T | UD
        /** Bulk-load N entries into the ring from a cold source. Blocks producers. */
        bulkLoad(entries: Iterable<[S, T]>): V
    }
    type CBORValue = UD | null | B | N | S | Uint8Array | CBORValue[] | { [k: S]: CBORValue }

    interface RingCursor {
        /** Next sequence this cursor wants to consume. */
        position(): N
        /** Advance the cursor — signals the ring the slot is free to overwrite. */
        advance(toSeq: N): V
    }
    interface BackoffOptions {
        base?: N;
        factor?: N;
        max?: N;
        jitter?: B;
    }
    interface IdbSinkOptions {
        dbName?: S
        storeName?: S
        /** How often to flush, in ms. 0 = flush on every microtask batch. */
        flushMs?: N
        /** Max entries per IDB transaction. */
        maxBatch?: N
        onError?: (err: U) => V
    }
    type RouteHandle = A;

    interface RouteModule {
        default: (args: {
            params: Record<S, S>;
            search: URLSearchParams;
            data: A;
        }) => VNode;
        ErrorBoundary?: (error: A) => Node;
        layout?: (
            child: Node,
            ctx: {
                params: Record<S, S>;
                search: URLSearchParams;
                data: A;
            }
        ) => Node;
        links?: LinksFunction;
        meta?: MetaFunction;
        handle?: RouteHandle;
        clientLoader?: ClientLoaderFunction;
        clientAction?: ClientActionFunction;
        shouldRevalidate?: ShouldRevalidateFunction;
    }
    interface PortalOptions {
        target?: Element | S
        before?: Node | null
    }
    interface RouteModules {
        [routeId: S]: RouteModule | UD;
    }

    interface EntryRoute {
        id: S;
        module: S;
    }
    interface PresenceOptions {
        onEnter?: (node: Node) => V
        onExit?: (node: Node, done: () => V) => V
        enterClass?: S
        exitClass?: S
        exitDuration?: N
    }

    interface RoutesModulesTypes {
        ClientActionFunction: ClientActionFunction;
        ClientLoaderFunction: ClientLoaderFunction;
        LinksFunction: LinksFunction;
        MetaDescriptor: MetaDescriptor;
        MetaFunction: MetaFunction;
        ShouldRevalidateFunction: ShouldRevalidateFunction;
        LdJsonObject: LdJsonObject;
        LdJsonArray: LdJsonArray;
        LdJsonPrimitive: LdJsonPrimitive;
        LdJsonValue: LdJsonValue;
        RouteHandle: RouteHandle;
    }

    interface RoutesModulesInterface {
        RouteModules: RouteModules;
        RouteModule: RouteModule;
        ClientActionArgs: ClientActionArgs;
        ClientLoaderArgs: ClientLoaderArgs;
        LinkDescriptor: LinkDescriptor;
        MetaArgs: MetaArgs;
        ShouldRevalidateArgs: ShouldRevalidateArgs;
        EntryRoute: EntryRoute;
    }
    interface RouteState {
        location: RouteLocation;
        pathname: S;
        search: S;
        hash: S;
        params: Record<S, S>;
        query: Record<S, S | S[]>;
        state: U;
        data: U;
        actionData: U;
        error: U;
        matches: RouteMatch[];
        parent: RouteMatch | null;
        children: RouteMatch[];
        outlet: U;
        isNavigating: B;
        revalidate: () => V;
    }

    interface RouterYHooksInterface {
        RouteLocation: RouteLocation;
        RouteMatch: RouteMatch;
        NavigateOptions: NavigateOptions;
        RouterStore: RouterStore;
        memGet: () => Promise<RouteLocation>;
        memSet: (loc: RouteLocation) => P<A>;
        parsePath: (path: S) => RouteLocation;
        parseQuery: (search: S) => Record<S, S | S[]>;
        parseParams: (pathname: S, pattern: S) => Record<S, S>;
        getBrowserLocation: () => RouteLocation;
        notifyRouterListeners: () => V;
        useRouteDataY: (routeId: S) => U;
        useRouteY: (pattern?: S, __sauron_id__?: S) => RouteState;
        useNavigateY: (__sauron_id__?: S) => NavigateResult;
        useFetcherY: <T = U>(__sauron_id__?: S) => FetcherResult;
    }

    interface RouterYHooksTypes {
        NavigateResult: NavigateResult;
        FetcherResult: FetcherResult;
        RouteState: RouteState;
    }

    interface RouterYHooksEnums {
        NavigationState: NavigationState;
        FetcherState: FetcherState;
    }
    interface CloudRunResponse<T = U> {
        ok: B
        status: N
        data?: T
        error?: A
    }

    interface RouteNode {
        id: S;
        path?: S;
        index?: B;
        parentId?: S;
        file: S;
        children: RouteNode[];
    }

    interface RouteMatchRuntime {
        node: RouteNode;
        params: Record<S, S>;
        search: URLSearchParams;
        data: A;
        element: Node;
    }

    interface Router {
        navigate: (to: S, opts?: { replace?: B }) => V;
        current: () => RouteMatchRuntime | null;
        mountRoot: (container: Element) => V;
    }

    interface RouterRuntimeInterface {
        RouteNode: RouteNode;
        Router: Router;
        RouteMatch: RouteMatchRuntime;
    }

    interface RouterRuntimeTypes {
        RouteNode: RouteNode;
        RouteMatch: RouteMatchRuntime;
    }

    type UIMatch<D = AppData, H = RouteHandle> = UIMatchRR<
        SerializeFrom<D>,
        H
    >;

    interface FileRoute {
        id: S
        file: S
        path?: S
        index?: B
        parentId?: S
    }
    interface RouteManifest {
        [id: S]: FileRoute
    }
    interface CreateRoutesOptions {
        appDir?: S
        routesDir?: S
        ignore?: S[]
    }
    type SafeHtmlHelper = {
        /**
         * A tagged template function that escapes interpolated values as HTML.
         *
         * @param strings The template strings
         * @param values The values to interpolate
         * @returns A `SafeHtml` value
         */
        (strings: TemplateStringsArray, ...values: Interpolation[]): SafeHtml
        /**
         * A tagged template function that does not escape interpolated values.
         *
         * Similar to `String.raw`, this preserves the raw values without escaping.
         * Only use with trusted content or pre-escaped HTML.
         *
         * @param strings The template strings
         * @param values The values to interpolate
         * @returns A `SafeHtml` value
         */
        raw(strings: TemplateStringsArray, ...values: Interpolation[]): SafeHtml
    }

    interface SerializedState {
        components: Record<S, ComponentState>
        listeners: Record<S, ListenerState>
        global: Record<S, A>
        router?: { pathname: S; search: S; hash: S }
        forms?: Record<S, A>
        scroll?: Record<S, N>
    }

    interface RouteConfig {
        path: S
        component: S
        loader?: S
    }


    interface ComponentState {
        props: Props
        /** Hook state keyed by the hook key createHook uses: `${componentId}:${hookName}:${sauronId}` */
        hooks: Record<S, A>
        context: Record<S, A>
        children: S[]
        /** Module URL the inline resume script dynamic-imports */
        module: S
        interactive: B
    }

    interface ListenerState {
        type: S
        componentId: S
        handler: S
        module: S
        options?: AddEventListenerOptions
    }
    type VNode =
        | S | N | B | null | UD
        | { tag: S; props: Props; children: VNode[] }
        | { raw: S }
        | VNode[]
    interface JsonOptions {
        status?: N
        headers?: HeadersInit
    }
    type UploadHandlerArgs = {
        name: S;
        filename: S;
        contentType: S;
        data: AsyncIterable<Uint8Array>;
    };
    interface HeadersFunctionArgs {
        request: Request
        parentHeaders?: Headers
        loaderHeaders?: Headers
        actionHeaders?: Headers
        errorHeaders?: Headers
    }
    interface RedirectOptions {
        headers?: HeadersInit
    }

    interface RedirectBackOptions {
        fallback: S
        status?: N
        headers?: HeadersInit
    }
    interface RouteErrorResponse {
        status: N
        statusText: S
        data: U
        internal: B
        error?: Error
    }
    type HeadersFunction = (args: HeadersFunctionArgs) => Headers | HeadersInit

    type UploadHandler = (args: UploadHandlerArgs) => Promise<File | Blob | S | UD>;

    type MemoryUploadHandlerFilterArgs = {
        filename: S;
        contentType: S;
        name: S;
    };

    type MemoryUploadHandlerOptions = {
        maxPartSize?: N;
        filter?(args: MemoryUploadHandlerFilterArgs): B | Promise<B>;
    };

    interface RouteModule {
        loader?: (args: RouteArgs) => U | Promise<U>
        action?: (args: RouteArgs) => U | Promise<U>
    }

    type FileUploadHandlerFilterArgs = {
        filename: S;
        contentType: S;
        name: S;
    };

    type FileUploadHandlerPathResolverArgs = {
        filename: S;
        contentType: S;
        name: S;
    };

    type FileUploadHandlerPathResolver = (
        args: FileUploadHandlerPathResolverArgs
    ) => S | UD;

    type FileUploadHandlerOptions = {
        avoidFileConflicts?: B;
        directory?: S | FileUploadHandlerPathResolver;
        file?: FileUploadHandlerPathResolver;
        maxPartSize?: N;
        filter?(args: FileUploadHandlerFilterArgs): B | Promise<B>;
    };
    /**
     * Options for `createFetchProxy`.
     */
    interface FetchProxyOptions {
        /**
         * The `fetch` function to use for the actual fetch.
         *
         * @default globalThis.fetch
         */
        fetch?: typeof globalThis.fetch
        /**
         * Set `false` to prevent the `Domain` attribute of `Set-Cookie` headers from being rewritten. By
         * default the domain will be rewritten to the domain of the incoming request.
         *
         * @default true
         */
        rewriteCookieDomain?: B
        /**
         * Set `false` to prevent the `Path` attribute of `Set-Cookie` headers from being rewritten. By
         * default the portion of the pathname that matches the proxy target's pathname will be removed.
         *
         * @default true
         */
        rewriteCookiePath?: B
        /**
         * Set `true` to add `X-Forwarded-Proto` and `X-Forwarded-Host` headers to the proxied request.
         *
         * @default false
         */
        xForwardedHeaders?: B
    }

    /**
     * A [`fetch` function](https://developer.mozilla.org/en-US/docs/Web/API/Window/fetch)
     * that forwards requests to another server.
     *
     * @param input The URL or request to forward
     * @param init Optional request init options
     * @returns A promise that resolves to the proxied response
     */
    interface FetchProxy {
        (input: URL | RequestInfo, init?: RequestInit): Promise<Response>
    }
    interface StubRouteObject {
        id: S
        path: S
        loader?: (args: { request: Request; params: Record<S, S> }) => U | Promise<U>
        action?: (args: { request: Request; params: Record<S, S> }) => U | Promise<U>
        handle?: U
        errorElement?: ReactNode
        children?: StubRouteObject[]
    }

    interface CreateStubOptions {
        routes: StubRouteObject[]
        initialPath?: S
        initialLoaderData?: Record<S, U>
        initialActionData?: U
    }

    interface StubContextValue {
        loaderData: Record<S, U>
        actionData: U
        error: U
        navigate: (to: S) => V
        currentPath: S
    }

    interface RouteArgs {
        request: Request
        params: Record<S, S>
    }
    type Encoding = 'br' | 'gzip' | 'deflate'

    interface CompressionOptions {
        /**
         * Minimum size in bytes to compress (only enforced if Content-Length present).
         * Default: 1024
         */
        threshold?: N

        /**
         * Optional filter to control which responses get compressed based on media type.
         * If not provided, uses compressible media types from mime-db.
         */
        filterMediaType?: (mediaType: S) => B

        /**
         * Which encodings the server supports for negotiation in order of preference.
         * Can be static or a function that returns encodings based on the response.
         *
         * Default: ['br', 'gzip', 'deflate']
         */
        encodings?: Encoding[] | ((response: Response) => Encoding[])

        /**
         * node:zlib options for gzip/deflate compression.
         * Can be static or a function that returns options based on the response.
         *
         * See: https://nodejs.org/api/zlib.html#class-options
         */
        zlib?: ZlibOptions | ((response: Response) => ZlibOptions)

        /**
         * node:zlib options for Brotli compression.
         * Can be static or a function that returns options based on the response.
         *
         * See: https://nodejs.org/api/zlib.html#class-brotlioptions
         */
        brotli?: BrotliOptions | ((response: Response) => BrotliOptions)
    }
    interface RouteManifestEntry {
        filePath: S
        pattern: S
        keys: S[]
        regex: RegExp
        module?: RouteModule
    }

    interface APIRoutesOptions {
        routesDir?: S
        convention?: 'flat' | 'folder' | 'both'
    }
    type LoaderArgs = { request: Request; params: Record<S, S> }
    type LoaderFunction<T = U> = (args: LoaderArgs) => Promise<Response> | Response | Promise<T> | T

    type Loader = ReturnType<typeof createLoader>
    type ClientLoader = ReturnType<typeof createClientLoader>
    interface HeaderValue {
        toString(): S
    }
    type HTTPMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE' | 'HEAD' | 'OPTIONS'

    type RouteHandler = (request: Request, context: RouteContext) => Response | Promise<Response>

    interface RouteContext {
        params: Record<S, S>
        url: URL
    }

    type MethodHandlers = Partial<Record<HTTPMethod, RouteHandler>>

    interface APIRouteOptions {
        cors?: B | CORSOptions
        middleware?: Middleware[]
    }

    interface CORSOptions {
        origin?: S | S[]
        methods?: HTTPMethod[]
        headers?: S[]
        credentials?: B
        maxAge?: N
    }

    type Middleware = (
        request: Request,
        context: RouteContext,
        next: () => Promise<Response>
    ) => Response | Promise<Response>

    type ParsedMediaType = {
        type: S;
        subtype: S;
        params: Record<S, S>;
    };
    type CrossOrigin = "anonymous" | "use-credentials";

    type ScriptType = "module" | "text/javascript";

    type ScriptDescriptor = {
        /** Render a `<link rel="preload">` for this script during SSR */
        preload?: B;
        /** @see https://developer.mozilla.org/en-US/docs/Web/HTML/Element/script#async */
        async?: B;
        /** @see https://developer.mozilla.org/en-US/docs/Web/HTML/Element/script#attr-crossorigin */
        crossOrigin?: CrossOrigin;
        /** @see https://developer.mozilla.org/en-US/docs/Web/HTML/Element/script#attr-defer */
        defer?: B;
        /** @see https://developer.mozilla.org/en-US/docs/Web/HTML/Element/script#attr-integrity */
        integrity?: S;
        /** @see https://developer.mozilla.org/en-US/docs/Web/HTML/Element/script#attr-nomodule */
        noModule?: B;
        /** @see https://developer.mozilla.org/en-US/docs/Web/HTML/Element/script#attr-nonce */
        nonce?: S;
        /** @see https://developer.mozilla.org/en-US/docs/Web/HTML/Element/script#attr-referrerpolicy */
        referrerPolicy?: ReferrerPolicy;
        /** @see https://developer.mozilla.org/en-US/docs/Web/HTML/Element/script#attr-src */
        src: S;
        /** @see https://developer.mozilla.org/en-US/docs/Web/HTML/Element/script#attr-type */
        type?: ScriptType;
        /** Optional element ID for explicit later reference */
        id?: S;
    };

    type ExternalScriptsFunction<Loader = U> = (
        args: HandleConventionArguments<Loader>,
    ) => ScriptDescriptor[];

    /**
     * Shape of the `handle`  for routes that need external scripts.
     * @example
     *  let handle: ExternalScriptsHandle = { scripts: [...] }
     * @example
     *  let handle: ExternalScriptsHandle<SerializeFrom<typeof loader>> = {
     *   scripts({ data }) { return [...] }
     * }
     */
    interface ExternalScriptsHandle<Data = U> {
        scripts?: ExternalScriptsFunction<Data> | ScriptDescriptor[];
    }
    interface ActionOptions {
        action?: S
        method?: 'get' | 'post' | 'put' | 'patch' | 'delete'
        encType?: 'application/x-www-form-urlencoded' | 'multipart/form-data' | 'text/plain'
        routeId?: S
        url?: S
        headers?: Record<S, S>
    }
    type PlatformAdapter = (
        formData: FormData,
        options: ActionOptions
    ) => Promise<ActionResult>
    interface FileUploadHandler {
        (file: FileUpload): V | null | S | Blob | Promise<V | null | S | Blob>
    }
    interface FormDataOptions extends ParseFormDataOptions {
        suppressErrors?: B
        uploadHandler?: FileUploadHandler
    }
    interface ParseFormDataOptions extends MultipartParserOptions {
        maxFiles?: N
    }

    interface ReadableLike {
        readableHighWaterMark?: N
        readable?: B
        on(event: 'data', listener: (chunk: Uint8Array | S) => V): this
        on(event: 'error', listener: (error: Error) => V): this
        on(event: 'end', listener: () => V): this
        on(event: 'close', listener: () => V): this
        once(event: 'error' | 'end' | 'close', listener: (...args: A[]) => V): this
        off(event: 'data' | 'error' | 'end' | 'close', listener: (...args: A[]) => V): this
        pause?(): V
        resume?(): V
        destroy?(error?: Error): V
    }
    interface FormProps extends UseFormOptions {
        id: S
        children: ((form: FormInstance) => A) | A
        className?: S
    }
    /**
     * Options for parsing a multipart message.
     */
    interface ParseMultipartOptions {
        /**
         * The boundary S used to separate parts in the multipart message,
         * e.g. the `boundary` parameter in the `Content-Type` header.
         */
        boundary: S
        /**
         * The maximum allowed size of a header in bytes. If an individual part's header
         * exceeds this size, a `MaxHeaderSizeExceededError` will be thrown.
         *
         * @default 8192 (8 KiB)
         */
        maxHeaderSize?: N
        /**
         * The maximum allowed size of a file in bytes. If an individual part's content
         * exceeds this size, a `MaxFileSizeExceededError` will be thrown.
         *
         * @default 2097152 (2 MiB)
         */
        maxFileSize?: N
    }

    type MultipartParserOptions = Omit<ParseMultipartOptions, 'boundary'>

    type UploadHandlerPart = {
        name: S
        filename?: S
        contentType: S
        data: AsyncIterable<Uint8Array>
    }

    type UploadHandler = (
        part: UploadHandlerPart
    ) => Promise<File | S | null | UD>

    interface ActionResult<T = A> {
        data?: T
        error?: S
        status: 'success' | 'error'
    }

    interface ActionOptions {
        action?: S
        method?: 'get' | 'post' | 'put' | 'patch' | 'delete'
        encType?: 'application/x-www-form-urlencoded' | 'multipart/form-data' | 'text/plain'
        routeId?: S
        url?: S
        headers?: Record<S, S>
    }

    type PlatformAdapter = (
        formData: FormData,
        options: ActionOptions
    ) => Promise<ActionResult>

    // #endregion
    // #region ══════════════════════════════════════════════════════════════════ FACTORIES ═══
    type ObjectType = Record<S, IncantationsConfig<A, A, A, A, A, A, A, A, A, A>>;
    type SelfType = { self: A;[category: S]: A };
    type SelfType = { self: A;[category: S]: A };
    type Factory = (ctx: SelfType) => ObjectType
    var IncantationsConfig: IncantationsConfigCreator = (config) => config;
    type AnySelfType = { self: A;[key: S]: A };
    type AnyObject = Record<S, A>;
    type AnyFactory = (ctx: AnySelfType) => AnyObject;
    type AnyType = AnyObject | AnyFactory;
    type incan_vars_obj = Record<S, A>;
    type incan_vars_ctx = { self: A;[category: S]: A };
    type incan_vars_vault_factory = (ctx: incan_vars_ctx) => incan_vars_obj | incan_vars_obj;
    type ArcheTypeCtx = { self: A;[category: S]: A };
    type ArcheTypeCtx = { self: A;[category: S]: A };
    type VaultFactory = (ctx: ArcheTypeCtx) => Record<S, A>;
    // #endregion
    // #region ══ PRIMTIVES - EXECUTE MASTER ════════════════════════════════════════════════════════════════════
    type ExeMasterMode = "concurrent" | "sequential";
    type ExeTask<TResult = U> = {
        /**
         * Lower N runs in an earlier batch.
         * Equal priorities run in the same concurrent batch.
         */
        priority?: N;

        execute: () => TResult | Promise<TResult>;

        on_success?: (
            result: TResult,
        ) => V | P<A>;

        on_error?: (
            error: U,
        ) => V | P<A>;
    };
    type ExeFactory<TCtx extends Record<S, A> = Record<S, A>> = (ctx: TCtx,) => Record<S, ExeTask>;
    type ExeMasterOptions = {
        /**
         * concurrent:
         * Every executor is scheduled in batch 0.
         *
         * sequential:
         * Priorities create ordered batches:
         * 0 → wait → 1 → wait → 2.
         */
        mode?: ExeMasterMode;

        /**
         * Maximum active tasks within one batch.
         * Infinity means every task in the released batch starts immediately.
         */
        concurrent?: N;

        retry?: N;
        timeout?: N;

        chain?: "chain" | "rechain";
    };
    // #endregion
    // #region ══ PRIMTIVES - HTTP CLIENT ════════════════════════════════════════════════════════════════════
    type Interceptor<T> = {
        fulfilled: (value: T) => T | Promise<T>;
        rejected?: (error: A) => A;
    };
    interface axiosRetryConfig {
        attempts?: N;
        retryOn?: N[];               // status codes to retry, default [408,429,500,502,503,504]
        base?: N;                    // ms, default 300
        factor?: N;                  // default 2
        max?: N;                     // ms, default 8000
    }
    interface HttpResponse<T = U> {
        data: T;
        status: N;
        headers: Headers;
        config: RequestConfig;
        raw: Response;
    }
    // #endregion
    // #region ══ PRIMTIVES - FUNCTION TYPES ════════════════════════════════════════════════════════════════════
    type vault_source = {
        variants?: Record<S, Record<S, A>>;
        base?: ClassInput;
        slots?: Record<S, ClassInput>;
        compoundVariants?: A[];
        defaultVariants?: Record<S, A>;
        animation?: A;
        aliases?: A;
    };
    type base_props = {
        className?: S;
        class?: S;
        children?: A;
        style?: A;
        [key: S]: A;
    };
    type ClassInput = | S | N | B | null | UD | ClassInput[] | Record<S, B | null | UD>;
    type AsConfig = Record<S, ClassInput>;
    type AnimationVariant = {
        enter?: ClassInput;
        exit?: ClassInput;
        hover?: ClassInput;
        focus?: ClassInput;
        active?: ClassInput;
    };
    type MotionVariant = {
        v?: Record<S, A>;
        animate?: Record<S, A>;
        exit?: Record<S, A>;
        transition?: Record<S, A>;
        whileHover?: Record<S, A>;
        whileFocus?: Record<S, A>;
        whileTap?: Record<S, A>;
    };
    type AsNode = Record<S, A> & { parent: S };
    type SlotRecord = Record<S, ClassInput>;
    type VariantSchema = Record<S, Record<S, ClassInput>>;
    type AnyVariantSchema = | VariantSchema | SlotVariantSchema;
    type AnimationPresetMap = Record<S, AnimationVariant | MotionVariant>;
    type ExposedVariants = Record<S, VariantGroup>;

    // #endregion
    // #region ══ PRIMTIVES - BASE PROPS ════════════════════════════════════════════════════════════════════
    type BaseProps = {
        className?: S;
        class?: S;
        children?: A;
        style?: A;
        [key: S]: A;
    };
    // #endregion
    // #region ══ PRIMTIVES - VARIANT ════════════════════════════════════════════════════════════════════
    type VariantGroup = Record<S, ClassInput> & {
        extend: (
            overrides: Record<S, ClassInput>
        ) => Record<S, ClassInput>;
    };
    type VariantProps = {
        [key: S]: A;
        animation?: S;
        preset?: S;
        class?: A;
        className?: A;
        __instanceId__?: S;
        freyr?: FreyrConfig | ((props: A) => A);
    };
    // #endregion
    // #region ══ PRIMTIVES - COMPOUND VARIANTS ════════════════════════════════════════════════════════════════════
    type CompoundVariant = {
        variants: Record<S, S>;
        className?: ClassInput;
        style?: React.CSSProperties;
        class?: ClassInput;
    };
    type SlotVariantSchema1 = Record<S, Record<S, SlotRecord>>;
    type SlotVariantSchema = Record<S, Record<S, SlotRecord>>;
    type SlotCompoundVariant = {
        variants?: Record<S, S>;
        slots?: S[];
        class: ClassInput;
    };
    // #endregion
    // #region ══ PRIMTIVES - STATE MACHINE ════════════════════════════════════════════════════════════════════
    interface StateMachineConfig1 {
        [ComponentVariantKey: S]: {
            v: S;
            transitions: Record<S, S[]>;
            guards?: Record<S, (props: A, prev: S, next: S) => B>;
            onEnter?: Record<S, (props: A, prev: S, next: S) => V>;
            onExit?: Record<S, (props: A, prev: S, next: S) => V>;
            onTransition?: (props: A, prev: S, next: S) => V;
        };
    }
    interface StateMachineConfig {
        v: S;
        transitions: Record<S, S[]>;
        guards?: Record<S, (props: A, prev: S, next: S) => B>;
        onEnter?: Record<S, (props: A, prev: S, next: S) => V>;
        onExit?: Record<S, (props: A, prev: S, next: S) => V>;
        onTransition?: (props: A, prev: S, next: S) => V;
    }




    type PipelineStage = {
        match: (value: A) => B;
        execute: (value: A) => A;
    };

    type PipelineFactory = (ctx: Record<S, A>) => PipelineStage[];

    type machine_state = {
        currentState: Record<S, S>
    };
    type kernelLogicMachineConfigFactory<V> = | kernelLogicMachineConfig<V> | ((ctx: { self: A; send: (event: S) => V }) => kernelMachineRegistry<V>);
    interface kernelMachineRegistry<V> {
        initial?: S;
        states: Record<S, A>;
        toggles?: Record<S, A>;
        layout_toggles?: Record<S, A>;
        persistence?: Record<S, A>;
        shortcuts?: Record<S, A>;
        functions?: Record<S, A>;
    }
    interface kernelLogicMachineConfig<V> {
        initial: S;
        states: Record<S, {
            on?: Record<S, S>;
            targets?: { [ComponentKey in keyof V]?: S | Record<S, A> };
        }>;
        setup: (ctx: { self: A; send: (event: S) => V }) => kernelMachineRegistry<V>;
    }

    type machine_runner = {
        states: Record<S, S>
        send: (
            variantKey: S,
            event: S,
            currentProps: A
        ) => Record<S, S> | UD
    }
    // #endregion
    // #region ══ PRIMTIVES - MACHINE TYPES ════════════════════════════════════════════════════════════════════
    type MachineState = { currentState: Record<S, S>; };
    type LogicMachine = {
        [logicalState: S]: {
            ON?: Record<S, S>;
            ASYNC_GUARD?: (props: A) => Promise<A> | B;
            actions?: S[];
        };
    };
    type MachineRunner = {
        states: Record<S, S>;
        send: (
            variantKey: S,
            event: S,
            currentProps: A
        ) => Record<S, S> | UD;
    };
    // #endregion
    // #region ══ PRIMTIVES - VAULT TYPES ════════════════════════════════════════════════════════════════════
    type VaultSource = {
        variants?: Record<S, Record<S, A>>;
        base?: ClassInput;
        slots?: Record<S, ClassInput>;
        compoundVariants?: A[];
        defaultVariants?: Record<S, A>;
        animation?: A;
        aliases?: A;
    };
    type VaultEntry = {
        source: VaultSource;
        variants?: { [variantKey: S]: { [entryKey: S]: S } };
    };
    type VaultConfig = {
        vault?: VaultEntry;
        [key: S]: IncantationsConfig | VaultEntry | UD;
    };
    // #endregion
    // #region ══ PRIMTIVES - FREYR ════════════════════════════════════════════════════════════════════
    type FreyrMode = "light" | "dark" | "system" | S;
    type FreyrTheme = "default" | "ocean" | "forest" | "sunset" | S;
    type FreyrVersion = "v1" | "v2" | "v3" | S;
    type FreyrFonts = "sans" | "serif" | "mono" | S;
    type FreyrPresets = "minimal" | "modern" | "vintage" | S;
    type IncantationsFreyrContext = {
        theme: FreyrTheme;
        version: FreyrVersion;
        mode: FreyrMode;
    };

    type IncantationsFreyr = {
        mode?: FreyrMode;
        theme?: FreyrTheme;
        version?: FreyrVersion;
        fonts?: FreyrFonts;
        presets?: FreyrPresets;
    };
    type FreyrConfig = {
        mode?: FreyrMode;
        theme?: FreyrTheme;
        version?: FreyrVersion;
        fonts?: FreyrFonts;
        presets?: FreyrPresets;
    };
    // #endregion
    // #region ══ PRIMTIVES - INCANTATIONS ════════════════════════════════════════════════════════════════════
    type variant_group = Record<S, ClassInput> & {
        extend: (
            overrides: Record<S, ClassInput>
        ) => Record<S, ClassInput>;
    };
    type IncantationsLvl3 = {
        db: A;
        bus: A;
        form: A;
        rdb: A;
        loader: A;
        session_mgmt: A;
        signals: A;
        jobs: A;
        fetch: A;
        sauron: A;
        htmx: A;
        cloud: A;
        cron: A;
        action: A;
        auth: A;
        realtime: A;
        reflect: A;
    };
    type vault_entry = {
        source: vault_source;
        variants?: { [variantKey: S]: { [entryKey: S]: S } };
    };
    type KERNEL_PROPS<T extends (...args: A[]) => S> = T extends (props?: infer P) => S ? P extends { [K in keyof P]: A } ? P : never : never
    type INTERFACE_PROPS<T extends (...args: A[]) => S> = T extends { interface: infer I } ? I : never
    type TYPES_PROPS<T extends (...args: A[]) => S> = T extends { types: infer TY } ? TY : never
    // ─── kernel AND kernel FUNCTION TYPES ────────────────────────────────────────────────────────────────────
    type OmitUndefined<T> = T extends UD ? never : T;
    type kernelProps<Component extends (...args: A) => A> = Omit<OmitUndefined<Parameters<Component>[0]>, "class" | "className">;

    // #endregion
    // #region ══ PRIMTIVES - INCANTATIONS CONFIG ════════════════════════════════════════════════════════════════════
    type IncantationsConfig<
        S extends S = never,
        V extends Record<S, Record<S, A>> = Record<S, Record<S, A>>,
        T = U,
        I = U,
        E = U,
        C = U,
        SP = U,
        SO = U,
        CL = U,
        G = U
    > = {
        // Identifiers
        __S__?: S;
        __V__?: V;
        __T__?: T;
        __I__?: I;
        __E__?: E;
        __C__?: C;
        __SP__?: SP;
        __SO__?: SO;
        __CL__?: CL;
        __G__?: G;
        // NEED TO WORK ON THESE
        timeMachine?: A
        useMachine?: A
        useTimeMachine?: A
        logicMachine?: A
        inlineStyles?: A
        theme?: A
        className?: A
        preset?: A
        __Incantations__?: A
        meta?: A
        staticMeta?: A
        machinesMachine?: A
        router?: A


        // Types
        enums?: E;
        types?: T;
        interfaces?: I;
        generics?: G;

        interface?: I;
        enum?: I;

        // Styles
        styles?: {
            base?: React.CSSProperties;
            variants?: Record<S, Record<S, React.CSSProperties>>;
            defaultVariants?: Record<S, S>;
        };
        slots?: Record<S, ClassInput>;
        // Freyr & Global
        global?: () => G;
        freyrClasses?: S;
        freyrIncantations?: React.CSSProperties;
        __globalContent?: Record<S, A>;
        __isGlobalized__?: B;
        freyr?: IncantationsFreyr | ((props: A) => A);
        classNames?: A;
        customTheme?: A;
        customCSS?: A;
        // Variants
        variants?: V;
        compoundVariants?: S extends never ? CompoundVariant[] : SlotCompoundVariant[];
        defaultVariants?: { [K in keyof V]?: keyof V[K] };
        base?: ClassInput;

        // Animations
        animation?: S extends never
        ? AnimationVariant | AnimationPresetMap
        : Record<S, AnimationVariant> | UD;
        transition?: S extends never
        ? AnimationVariant | AnimationPresetMap
        : Record<S, AnimationVariant> | UD;

        // Extend & Sync
        extend?: S;
        cloud?: CL;
        sync?: S;
        master?: B;

        // Context
        context?: (props: A) => A;
        useContext?: A;
        createContext?: A;
        sauronContext?: A;
        reactContext?: A;
        useReactContext?: A;
        _compiledReactContext?: A;

        // State Machines
        stateMachine?: { [K in keyof V]?: StateMachineConfig; };
        __logicMachineRunner?: A;
        getLogicState?: () => Record<S, S>;
        __machineRunner?: MachineRunner | null;
        getMachineState?: () => Record<S, S>;
        variantMachine?: A;



        // As
        as?: AsConfig;
        asName?: S;

        // Singles
        aliases?: { [K in keyof V]?: Record<S, keyof V[K]> };

        // Constants & Specs
        constants?: C;
        specs?: SP;
        source?: SO;

        // Documentation
        docs?: {
            [K in keyof V]?: {
                description?: S;
                values?: { [J in keyof V[keyof V]]?: S };
            };
        } & { description?: S };

        // Dev Tools
        __location?: {
            file: S;
            line: N;
            column: N;
            functionName: S;
        };
        __definitionName?: S;
        __concentrationEnumGraph?: Record<S, TypeGraph>;
        __concentrationInterfaceGraph?: Record<S, TypeGraph>;
        __concentrationGenericGraph?: Record<S, TypeGraph>;
        __IncantationsTypeGraph?: Record<S, TypeGraph>;
    };
    type IncantationsConfigCreator = <
        S extends S = never,
        V extends Record<S, Record<S, A>> = Record<S, Record<S, A>>,
        T = U,
        I = U,
        E = U,
        C = U,
        SP = U,
        SO = U,
        CL = U,
        G = U
    >(
        config: IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>
    ) => IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>;
    type InferIncantationsConfig = <
        Cfg extends {
            __S__?: A;
            __V__?: A;
            __T__?: A;
            __I__?: A;
            __E__?: A;
            __C__?: A;
            __SP__?: A;
            __SO__?: A;
            __CL__?: A;
            __G__?: A;
        }
    >(
        config: Cfg
    ) => {
        S: Cfg["__S__"];
        V: Cfg["__V__"];
        T: Cfg["__T__"];
        I: Cfg["__I__"];
        E: Cfg["__E__"];
        C: Cfg["__C__"];
        SP: Cfg["__SP__"];
        SO: Cfg["__SO__"];
        CL: Cfg["__CL__"];
        G: Cfg["__G__"];
        Config: Cfg;
    };
    type IncantationsResult<
        S extends S = never,
        V extends Record<S, Record<S, A>> = Record<S, Record<S, A>>,
        T = U,
        I = U,
        E = U,
        C = U,
        SP = U,
        SO = U,
        CL = U,
        G = U
    > = {
        // ── THE MAIN FUNCTION ────────────────────────────────────────────────────
        (props?: VariantProps & T & {
            animation?: keyof AnimationVariant | S;
            preset?: S;
            class?: A;
            className?: A;
            __instanceId__?: S;
            freyr?: FreyrConfig | ((props: A) => A);
        }): S;

        // ── IDENTIFIERS ──────────────────────────────────────────────────────────
        __S__?: S;
        __V__?: V;
        __T__?: T;
        __I__?: I;
        __E__?: E;
        __C__?: C;
        __SP__?: SP;
        __SO__?: SO;
        __CL__?: CL;
        __G__?: G;

        // ── TYPES ──────────────────────────────────────────────────────────────
        enums?: E;
        types?: T;
        interfaces?: I;
        generics?: G;

        // ── STYLES ──────────────────────────────────────────────────────────────
        styles?: {
            base?: React.CSSProperties;
            variants?: Record<S, Record<S, React.CSSProperties>>;
            defaultVariants?: Record<S, S>;
        };
        slots?: Record<S, ClassInput>;
        base?: ClassInput;

        // ── VARIANTS ──────────────────────────────────────────────────────────────
        variants?: V;
        compoundVariants?: S extends never ? CompoundVariant[] : SlotCompoundVariant[];
        defaultVariants?: { [K in keyof V]?: keyof V[K] };

        // ── ANIMATIONS ──────────────────────────────────────────────────────────
        animation?: S extends never
        ? AnimationVariant | AnimationPresetMap
        : Record<S, AnimationVariant> | UD;
        transition?: S extends never
        ? AnimationVariant | AnimationPresetMap
        : Record<S, AnimationVariant> | UD;

        // ── EXTEND & SYNC ──────────────────────────────────────────────────────
        extend?: S;
        cloud?: CL;
        sync?: S;
        master?: B;

        // ── CONTEXT ──────────────────────────────────────────────────────────────
        context?: (props: A) => A;
        useContext?: A;
        createContext?: A;
        sauronContext?: A;
        reactContext?: A;
        _compiledReactContext?: A;

        // ── STATE MACHINES ────────────────────────────────────────────────────
        stateMachine?: {
            [K in keyof V]?: StateMachineConfig;
        };
        logicMachine?: LogicMachine;
        __logicMachineRunner?: A;
        getLogicState?: () => Record<S, S>;
        __machineRunner?: MachineRunner | null;
        getMachineState?: () => Record<S, S>;
        variantMachine?: A;

        // ── FREYR & GLOBAL ──────────────────────────────────────────────────────
        global?: () => G;
        freyrClasses?: S;
        freyrIncantations?: React.CSSProperties;
        __globalContent?: Record<S, A>;
        __isGlobalized__?: B;
        freyr?: IncantationsFreyr | ((props: A) => A);
        classNames?: A;
        customTheme?: A;
        customCSS?: A;

        // ── AS ──────────────────────────────────────────────────────────────────
        as?: AsConfig;
        asName?: S;

        // ── SINGLES ──────────────────────────────────────────────────────────────
        aliases?: { [K in keyof V]?: Record<S, keyof V[K]> };

        // ── CONSTANTS & SPECS ──────────────────────────────────────────────────
        constants?: C;
        specs?: SP;
        source?: SO;

        // ── DOCUMENTATION ──────────────────────────────────────────────────────
        docs?: {
            [K in keyof V]?: {
                description?: S;
                values?: { [J in keyof V[keyof V]]?: S };
            };
        } & { description?: S };

        // ── DEV TOOLS ──────────────────────────────────────────────────────────
        __location?: {
            file: S;
            line: N;
            column: N;
            functionName: S;
        };
        __definitionName?: S;
        __concentrationEnumGraph?: Record<S, TypeGraph>;
        __concentrationInterfaceGraph?: Record<S, TypeGraph>;
        __concentrationGenericGraph?: Record<S, TypeGraph>;
        __IncantationsTypeGraph?: Record<S, TypeGraph>;

        // ── REACT CONTEXT (Added by wizard template) ──────────────────────────
        ReactContext: React.Context<A>;
        createReactContext: (props?: A) => React.ComponentType<{ children: React.ReactNode }>;
        useReactContext: () => A;

        // ── SUB-COMPONENT UTILITIES ─────────────────────────────────────────────
        extendResult: (
            overrides: Partial<IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>>
        ) => IncantationsResult<S, V, T, I, E, C, SP, SO, CL, G>;
    };
    type IncantationsResultCreator = <
        S extends S = never,
        V extends AnyVariantSchema = A,
        T = U,
        I = U,
        C = U,
        SP = U,
        SO = U,
        CL = U,
        E = U,
        G = U
    >(
        config: ((
            props?: VariantProps & T & {
                animation?: keyof AnimationVariant | S;
                preset?: S;
                class?: A;
                className?: A;
                __instanceId__?: S;
                freyr?: FreyrConfig | ((props: A) => A);
            }
        ) => S) & {
            // ── CORE HOOKS & PROCESSING ENGINE ──────────────────────────────────────
            slots: (
                props?: VariantProps & {
                    preset?: S;
                    class?: Partial<Record<S, ClassInput>>;
                    className?: Partial<Record<S, ClassInput>>;
                    __instanceId__?: S;
                    freyr?: FreyrConfig | ((props: A) => A);
                }
            ) => SlottedResult<S>;

            // ── THE INLINE STYLES SYSTEM ───────────────────────────────────────────
            styles?: Record<S, A>;
            inlineStyles?: React.CSSProperties;
            freyrClasses?: S;
            freyrIncantations?: React.CSSProperties;
            classNames?: A;
            customTheme?: A;
            customCSS?: A;

            // ── BLUEPRINT ECHOES (CONFIG TO RESULT COPIES) ───────────────────────────
            types: T;
            interface: I;
            enum: E;
            constants: C;
            specs: SP;
            source: SO;
            cloud: CL;
            as: AsConfig;
            variants: ExposedVariants;
            compoundVariants?: A[];
            defaultVariants?: Record<S, A>;
            aliases?: Record<S, S>;
            docs?: S;

            // ── ADVANCED NESTED ENGINES ──────────────────────────────────────────────
            variantMachine?: Record<S, A>;
            transition?: {
                show?: Record<S, A>;
                hide?: Record<S, A>;
                [key: S]: A;
            };

            // ── SYSTEM MIGRATION & REACTION THREADS ──────────────────────────────────
            sync?: S;
            master?: B;
            context: (props: A, __sauron_id__?: S) => I;
            createContext?: A;
            sauronContext?: A;
            global: NamespaceAugment;

            // ── STATE ENGINE ACCESSORS (EXPOSED RUNTIMES) ────────────────────────────
            stateMachine?: Record<S, A>;
            logicMachine?: Record<S, A>;
            __machineRunner?: A;
            __logicMachineRunner?: A;
            getMachineState?: () => Record<S, A>;
            getLogicState?: () => Record<S, A>;
            useMachine?: (props?: A) => {
                state: Record<S, A>;
                setState: (key: S, value: A) => V;
            } & Record<S, (value: A) => V>;

            // ── GLOBALIZATION & COMPILER PROFILES ────────────────────────────────────
            __globalContent?: A;
            __isGlobalized__?: B;
            __location: S;
            __definitionName: S;

            // ── SUB-COMPONENT UTILITIES ─────────────────────────────────────────────
            extend: (
                overrides: Partial<IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>>
            ) => IncantationsResult<S, V, T, I, C, SP, SO, CL, E, G>;
        }
    ) => IncantationsResult<S, V, T, I, C, SP, SO, CL, E, G>;

    // #endregion
    // #region ══ PRIMTIVES - TYPEGRAPH ════════════════════════════════════════════════════════════════════
    type GraphKey = typeof GRAPH_KEYS[N];

    type concentrationTypeFlags = | "Any" | "Unknown" | "Boolean" | "Number" | "String" | "Object" | "Function" | "TypeParameter" | "Union" | "Intersection"
    type concentrationTypeEnv = Record<S, concentrationTypeId>
    type concentrationTypeId = S
    type concentrationTypeParameter = {
        id: concentrationTypeId
        name: S
        constraint?: concentrationTypeId
        default?: concentrationTypeId
    }
    type concentrationSignature = {
        typeParameters?: concentrationTypeParameter[]
        parameters: { name: S; type: concentrationTypeId }[]
        returnType: concentrationTypeId
    }
    type concentrationType = {
        id: concentrationTypeId
        flags: concentrationTypeFlags[]
        name?: S
        signatures?: concentrationSignature[]
        aliasOf?: concentrationTypeId
    }
    type KernelTypeParameter = {
        helpers: {
            generateTypeString: (typeDef: A, paramValues?: Record<S, S>) => S
            validateGenericUsage: (typeDef: A, providedParams: S[]) => B
        }
    }
    interface CGInterface<C> {
        arg1: S | C
        arg2?: C | KernelTypeParameter
        arg3?: KernelTypeParameter
    }
    type ExtractFactory<A1, A2> = A1 extends S ? Extract<A2, (...args: A[]) => A> : Extract<A1, (...args: A[]) => A>








    type CompiledGraph<TInput> = Readonly<{
        id: S;
        version?: S;
        start: NodeId;
        nodes: Readonly<Record<NodeId, ActionNode<TInput>>>;
    }>;
    type TypeFlags =
        | "Any"
        | "Unknown"
        | "Boolean"
        | "Number"
        | "String"
        | "Object"
        | "Array"
        | "Function"
        | "TypeParameter"
        | "Union"
        | "Intersection"
        | "Literal"
        | "Enum"
        | "Interface"
        | "Class"
        | "Generic"
        | "Record"
        | "Tuple"
        | "Optional"
        | "Nullable"
        | "Readonly";

    type TypeGraph = {
        // Core identification
        id?: S;
        name?: S;
        type: TypeFlags;
        kind?: "primitive" | "composite" | "reference" | "generic";

        // Value representation
        value?: A;
        defaultValue?: A;

        // Type structure
        properties?: Record<S, TypeGraph>;
        elements?: TypeGraph[];
        indexSignature?: TypeGraph;

        // Type parameters (generics)
        typeParameters?: TypeGraph[];
        typeArguments?: TypeGraph[];
        constraint?: TypeGraph;

        // Union/Intersection members
        unionMembers?: TypeGraph[];
        intersectionMembers?: TypeGraph[];

        // Function types
        parameters?: TypeGraph[];
        returnType?: TypeGraph;
        isAsync?: B;

        // Class/Interface
        extends?: TypeGraph[];
        implements?: TypeGraph[];
        constructors?: TypeGraph[];
        methods?: Record<S, TypeGraph>;
        accessors?: Record<S, TypeGraph>;

        // Enum
        enumMembers?: Record<S, S | N>;
        isStringEnum?: B;
        isNumericEnum?: B;

        // Record types
        keyType?: TypeGraph;
        valueType?: TypeGraph;

        // Tuple
        tupleElements?: TypeGraph[];
        isFixedLength?: B;
        restElement?: TypeGraph;

        // Modifiers
        isOptional?: B;
        isNullable?: B;
        isReadonly?: B;
        isAbstract?: B;
        isStatic?: B;

        // Generic constraints
        extendsConstraint?: TypeGraph;
        defaultType?: TypeGraph;

        // Metadata
        description?: S;
        tags?: Record<S, A>;
        source?: {
            file: S;
            line: N;
            column: N;
        };

        // Dependencies
        imports?: Record<S, S[]>;
        s?: S[];
        references?: TypeGraph[];

        // Runtime info
        runtimeType?: A;
        validator?: (value: A) => B;
        serializer?: (value: A) => A;
        deserializer?: (value: A) => A;

        // Graph relationships
        parent?: TypeGraph;
        children?: TypeGraph[];
        dependencies?: TypeGraph[];

        // Custom metadata
        metadata?: Record<S, A>;

        // Timestamps
        createdAt?: Date;
        updatedAt?: Date;
        version?: S;
    };
    type TypeGraphPredicates = {
        isPrimitive: (graph: TypeGraph) => B;
        isComposite: (graph: TypeGraph) => B;
        isGeneric: (graph: TypeGraph) => B;
        isUnion: (graph: TypeGraph) => B;
        isIntersection: (graph: TypeGraph) => B;
        isObject: (graph: TypeGraph) => B;
        isArray: (graph: TypeGraph) => B;
        isFunction: (graph: TypeGraph) => B;
        isEnum: (graph: TypeGraph) => B;
        isOptional: (graph: TypeGraph) => B;
        isNullable: (graph: TypeGraph) => B;
    };
    type TypeGraphTransformers = {
        // Traverse graph
        traverse: (
            graph: TypeGraph,
            visitor: (node: TypeGraph) => V
        ) => V;

        // Find nodes
        findNodes: (
            graph: TypeGraph,
            predicate: (node: TypeGraph) => B
        ) => TypeGraph[];

        // Transform nodes
        mapNodes: (
            graph: TypeGraph,
            mapper: (node: TypeGraph) => TypeGraph
        ) => TypeGraph;

        // Collect types
        collectTypes: (graph: TypeGraph) => Set<TypeFlags>;

        // Resolve references
        resolveReferences: (
            graph: TypeGraph,
            context: Record<S, TypeGraph>
        ) => TypeGraph;

        // Validate
        validate: (
            graph: TypeGraph,
            value: A
        ) => B;
    };

    // #endregion
    // #region ══ PRIMTIVES - SLOTTED RESULT ════════════════════════════════════════════════════════════════════
  
    // #endregion
    // #region ══ PRIMTIVES - NAMESPACE AUGMENT ════════════════════════════════════════════════════════════════════
  
    // #endregion
    // #region ══ STREAMS ════════════════════════════════════════════════════════════════════
   







    type MemberRuntime = {
        member: Required<
            Pick<
                ConstellationMember,
                | 'id'
                | 'p'
                | 'k'
                | 'sl'
                | 'ms'
                | 'rt'
                | 'binary'
                | 'weight'
            >
        >
        queue: A[]
        status: ConstellationMemberStatus
        error?: Error
        failures: N
        healthy: B
        busy: N
        lastUsed: N
        meta?:A
    }
    type MemberRuntime = {
        member: Required<
            Pick<
                ConstellationMember2,
                | 'id'
                | 'p'
                | 'k'
                | 'sl'
                | 'ms'
                | 'rt'
                | 'binary'
                | 'weight'
            >
        >;
        queue: A[];
        status: ConstellationMemberStatus2;
        error?: Error;
        healthy: B;
        busy: N;
        lastUsed: N;
        failures: N;
        meta?: Record<S, U>;
    };
    interface SyncStreamSendHandle665 {
        push(p: U): V;
        pendingCount(): N;
        close(): V;
    }
    interface CVReducerState {
        registrationOrder: Array<{ waiterId: S; nodeId: S }>;
        latestState: A;
    }
    interface Waiter {
        id: S;
        nodeId: S;
        predicate: (state: TState) => B;
        resolve: () => V;
        reject: (err: Error) => V;
        timeoutTimer?: A;
        abortHandler?: () => V;
        abortSignal?: AbortSignal;
    }
    interface StreamState {
        expectedSeq: N;
        buffer: Map<N, A>;
        lastActivity: N;
        totalChunks: N;
        receivedChunks: N;
        completed: B;
    }
    interface OffsetStore {
        get(sid: S): Promise<OffsetCheckpoint | UD>;
        set(sid: S, cp: OffsetCheckpoint): P<A>;
        delete(sid: S): P<A>;
    }
    interface SyncSubOptions {
        name?: S;
        epoch?: S;          // resume a run from its checkpoint
        maxSkew?: N;
        bufferTtlMs?: N;
        nackDelayMs?: N;
        nackBatch?: N;
        graceMs?: N;
        offsetStore?: OffsetStore;
        checkpointEveryMs?: N;
        onDlq?: (env: WireEnvelope, reason: S) => MaybePromise<V>;
        onComplete?: (err?: Error) => V;
        signal?: AbortSignal;
    }
    interface SyncHandle {
        close(): V;
        whenComplete(): P<A>;
        state(): { epoch: S | null; expected: N; buffered: N };
    }
    interface SyncSendOptions {
        name?: S;
        epoch?: S;          // reuse to resume a prior interrupted run
        trace?: S;
        windowSize?: N;
        timeoutMs?: N;
        maxRetries?: N;
        backoffBaseMs?: N;
        onProgress?: (acked: N, total: N) => V;
        onDlq?: (env: WireEnvelope, reason: S) => MaybePromise<V>;
        signal?: AbortSignal;
    }
    interface StreamLabMetrics {
        dataSent: N;
        dataAcked: N;
        dataRetransmitted: N;
        nackSent: N;
        nackReceived: N;
        overflow: N;
        dlq: N;
        dropped: N;
        errors: N;
        streamsActive: N;
        streamsCompleted: N;
        relaySent: N;
    }
    type WireKind = 'data' | 'ack' | 'nack' | 'done' | 'abort' | 'dlq';
    interface WireEnvelope<T = U> {
        v: N
        kind: WireKind;
        sid: S;        // deterministic logical stream id
        epoch: S;      // run id — reusing an epoch resumes that run
        seq: N;
        total: N;
        data?: T;
        enc?: 'json' | 'base64';
        trace: S;
        retryOf?: N;
        reason?: S;
    }
    interface RelayHandle {
        publish: (chunk: A) => P<A>;
        subscribe: (handler: (chunk: A) => V) => {
            unsubscribe: () => V;
            pause: () => V;
            resume: () => V;
            getBufferSize: () => N;
        };
        end: () => P<A>;
        stats?(): { subscribers: N; ended: B };
    }
    interface RelaySubscription {
        unsubscribe(): V;
        pause(): V;
        resume(): V;
        getBufferSize(): N;
    }
    interface RelayOptions {
        maxSubscribers?: N;
        bufferSize?: N;
        backpressureStrategy?: 'drop' | 'pause' | 'error';
    }
    interface OffsetCheckpoint {
        epoch: S;
        offset: N;
    }
    interface RelaySub {
        id: S;
        buffer: WireEnvelope[];
        paused: B;
        closed: B;
        notify: (() => V) | null;
        pump: P<A>;
    }
    type RunSnapshot = Readonly<{
        id: RunId;
        graphId: S;
        graphVersion?: S;
        status: RunStatus;
        currentNodeId?: NodeId;
        input: U;
        results: Readonly<Record<S, U>>;
        events: readonly PlinkoEvent[];
        startedAt?: N;
        endedAt?: N;
        error?: SerializedError;
    }>;
    type MutableRunSnapshot = {
        id: RunId;
        graphId: S;
        graphVersion?: S;
        status: RunStatus;
        currentNodeId?: NodeId;
        input: U;
        results: Record<S, U>;
        events: PlinkoEvent[];
        startedAt?: N;
        endedAt?: N;
        error?: SerializedError;
    };
    type ReadonlyValue<T> = T extends object ? Readonly<T> : T;
    type Outcome = | "success" | "failure" | "skipped" | "cancelled";
    type RunStatus = | "idle" | "running" | "succeeded" | "failed" | "cancelled";
    type RetryPolicy = {
        maxAttempts?: N;
        delayMs?: N;
        maxDelayMs?: N;
        backoff?: "fixed" | "linear" | "exponential";
        jitter?: "none" | "full";
        retryIf?: (error: U, attempt: N) => B;
    };
    type NodeContext<TInput, TResults extends Record<S, U> = Record<S, U>,> = {
        readonly runId: RunId;
        readonly nodeId: NodeId;
        readonly attempt: N;
        readonly input: TInput;
        readonly results: Readonly<TResults>;
        readonly variables: ReadonlyMap<S, U>;
        readonly signal: AbortSignal;
        emit(name: S, p?: U): V;
    };
    type AttemptEvent<TOutput> =
        | {
            type: "started";
            attempt: N;
        }
        | {
            type: "succeeded";
            attempt: N;
            result: TOutput;
            durationMs: N;
        }
        | {
            type: "failed";
            attempt: N;
            error: SerializedError;
            durationMs: N;
            willRetry: B;
        }
        | {
            type: "retrying";
            attempt: N;
            delayMs: N;
        }
        | {
            type: "cancelled";
            attempt: N;
            reason?: U;
        };
    type NodeExecution<TOutput = U> = {
        outcome: Outcome;
        result?: TOutput;
        error?: SerializedError;
        attempt: N;
    };
    type EventSink = {
        append(event: PlinkoEvent): V | P<A>;
    };
    type RunHandle = {
        id: RunId;
        done: Promise<RunSnapshot>;

        getSnapshot(): RunSnapshot;
        subscribe(listener: () => V): () => V;
        cancel(reason?: U): V;
    };
    interface HandlerContext {
        rt: S;
        adapter?: SIG_BUS_Adapter;
        meta: SIG_BUS_MessageMeta;
    }
    interface DuplexStream<TSend = A, TRecv = A> {
        send: (p: TSend) => V;
        onData: (handler: (chunk: TRecv, seq: N) => V) => () => B;
        onError: (handler: (err: DuplexError) => V) => () => B;
        onRemoteClose: (handler: () => V) => () => B;
        closeUp?: () => V;
        closeDown?: () => V;
        close: () => V;
        isFullyClosed: () => B;
        isFatallyErrored: () => B;
    }
    interface DuplexError {
        dir: 'up' | 'down';
        message: S;
        fatal: B;
        retryable?: B;
        code?: S;
    }
    type LateArrivalStrategy = 'discard' | 'delay' | 'reorder';
    type CompressFormat = 'gzip' | 'deflate' | 'deflate-raw' | 'brotli' | 'zstd';
    interface HANDLER_FN {
        (handler: (d: A) => A, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, binary?: B): A;
        syncGuard(handler: (chunk: A, seq: N, streamId: S) => P<A> | V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, options?: SyncSubGuardOptions): V;
        sync(k: S, sl?: S, ms?: S, rt?: S): A;
        sync_2(handler: (chunk: A, seq: N) => P<A> | V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, binary?: B): V;
        openSync(handler: (chunk: A, seq: N) => P<A> | V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): () => V;
        priority(handler: (p: A) => V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): () => V;
        transactional(apply: (chunks: A[]) => P<A> | V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): () => V;
        delta<T>(applyPatch: (current: T, diff: A) => T, v: T, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): A;
        presence(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, onUpdate?: (all: Record<S, A>) => V): A;
        authority<T>(resolve: (guess: T) => Promise<T> | T, k: S, sl: S, ms: S, rt: S): () => V;
        heartbeat(onDead: () => V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: { deadThresholdMs?: N }): A;
        backpressure(handler: (p: A) => P<A> | V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): () => V;
        stateful(handler: (p: A) => V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: { key?: S }): A;
        multicast(receiverId: S, handler: (p: A, seq: N) => V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: { key?: S; startFrom?: 'beginning' | 'now' }): Promise<A>;
        partitioned(handler: (key: S, p: A, partition: N) => V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: { partitions?: N[]; partitionCount?: N }): A;
        batch(handler: (p: A) => V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): () => V;
        filtered(handler: (p: A) => V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, predicate?: (p: A) => B): () => V;
        deadLetter(handler: (entry: SIG_BUS_Message) => Promise<B> | B): A;
        idempotent(handler: (p: A) => P<A> | V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: { keyPrefix?: S; ttlMs?: N }): A;
        lateArrival(handler: (p: A, seq: N) => V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: { strategy?: LateArrivalStrategy; toleranceMs?: N }): () => V;
        checkpoint(streamKey: S, handler: (p: A, seq: N) => P<A> | V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: { every?: N }): Promise<A>;
        rateLimited(handler: (p: A) => V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): () => V;
        combo(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): A;
        transform<T = A, R = A>(fn: (p: T) => Promise<R> | R, onResult: (result: R, seq: N) => V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: { concurrency?: N }): () => V;
        map<T = A, R = A>(fn: (item: T) => R, onResult: (r: R, seq: N) => V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: { concurrency?: N }): () => V;
        filter<T = A>(predicate: (item: T) => B, onResult: (item: T, seq: N) => V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): () => V;
        reduce<T = A, R = A>(fn: (acc: R, item: T) => R, v: R, onUpdate: (acc: R) => V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): () => V;
        fanout(receiverId: S, handler: (p: A, seq: N) => V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: { key?: S; startFrom?: 'beginning' | 'now' }): Promise<A>;
        useDRSS<T extends Record<S, U>>(v: A, handler: (chunk: A, state: A) => A | Promise<T>, k: S, sl?: S, ms?: S, rt?: S, binary?: B): A;
        useDRSSSync(v: A, handler: (chunk: A, seq: N, state: A) => A | Promise<A>, k: S, sl?: S, ms?: S, rt?: S, binary?: B): A;
    }
    interface SyncSubGuardOptions {
        sl?: S;
        ms?: S;
        rt?: S;
        maxBufferSize?: N;
        streamTTLMs?: N;
        maxStreams?: N;
        binary?: B;
        onStreamComplete?: (streamId: S, totalChunks: N) => V;
        onStreamError?: (streamId: S, error: S) => V;
    }
    interface FieldTouch {
        field: S;
        action: 'viewing' | 'editing';
        userId?: S;
        timestamp?: N;
        [key: S]: A;
    }
    interface DRSConflictOptions {
        k?: S;
        sl?: S;
        ms?: S;
        rt?: S;
        conflictStrategy?: 'lww' | 'version-vector' | 'custom' | S;
        versionKey?: S;
        debounceMs?: N;
        binary?: B;
        onConflict?: (local: A, remote: A) => A;
    }
    interface RelayFlowOptions extends StreamRelayOptions { }
    interface SyncIntegrityOptions {
        sl?: S;
        ms?: S;
        rt?: S;
        windowSize?: N;
        chunkRetries?: N;
        retryBackoffMs?: N;
        timeoutMs?: N;
        binary?: B;
        priority?: A;
        ttl?: N;
        onProgress?: (sent: N, acked: N, total: N) => V;
        onChunkFailed?: (seq: N, retries: N) => V;
    }
    interface SyncIntegrityResult {
        success: B;
        delivered: N;
        acknowledged: N;
        failed: N[];
        durationMs: N;
    }
    type ComboStrategy = 'arrival' | 'round-robin' | 'timestamp';

    interface HydraStage<T> {
        name: S;
        handler: (data: T) => T;
    }
    type BackpressureRelayStrategy = 'drop-oldest' | 'drop-newest' | 'block' | 'drop' | 'latest' | 'error' | "pause";
    interface StreamRelayOptions {
        maxSubscribers?: N;
        bufferSize?: N;
        backpressureStrategy?: BackpressureRelayStrategy
        deliveryGuarantee?: 'at-most-once' | 'at-least-once';
        subscriberTimeoutMs?: N;
        onSubscriberDrop?: (id: S, reason: S) => V;
    }
    interface SyncStreamOptions {
        windowSize?: N;
        retransmitMs?: N;
    }
    interface SyncStreamSendHandle {
        push(p: U): V;
        pendingCount(): N;
        close(): V;
    }
    interface SyncStreamHandler {
        onOrdered(cb: (p: U, seq: N) => V): V;
        onComplete(cb: () => V): V;
        close(): V;
    }
    interface Outbound {
        seq: N;
        p: U;
        acked: B;
        sentAt: N;
        timer?: ReturnType<typeof setTimeout>;
    }
    type StreamEncoding = 'json' | 'msgpack' | 'binary';
    type StreamRetryMode = | 'none' | 'at-least-once' | 'idempotent';
    type StreamContractOffer = {
        protocol: 'stream-contract';
        version: 1;

        schemas: readonly S[];
        encodings: readonly StreamEncoding[];

        limits: {
            maxChunkBytes: N;
            maxInFlightChunks: N;
            maxInFlightBytes?: N;
        };

        retry: {
            modes: readonly StreamRetryMode[];
            maxAttempts: N;
        };

        capabilities?: Record<S, B>;
    };
    type NegotiatedStreamContract = {
        protocol: 'stream-contract';
        version: 1;

        schema: S;
        encoding: StreamEncoding;

        limits: {
            maxChunkBytes: N;
            maxInFlightChunks: N;
            maxInFlightBytes?: N;
        };

        retry: {
            mode: StreamRetryMode;
            maxAttempts: N;
        };

        capabilities: Record<S, B>;
    };
    type NegotiationChunk =
        | {
            type: 'negotiate.accept';
            contract: NegotiatedStreamContract;
        }
        | {
            type: 'negotiate.reject';
            code: S;
            message: S;
        };
    type ConstellationFailureMode2 = 'continue' | 'fail-fast';
    type ConstellationMember2 = {
        id: S;
        p: A;
        k: S;
        sl?: SU;
        ms?: SU;
        rt?: SU;
        binary?: B;

        /**
         * Relative scheduling priority.
         * 1 = one turn, 2 = two turns, etc.
         */
        weight?: N;
    };
    type ConstellationChunk2 = {
        memberId: S;
        chunk: A;
        receivedAt: N;
    };
    type ConstellationMemberStatus2 = | 'running' | 'done' | 'error' | 'removed';
    type ConstellationMemberSnapshot2 = {
        id: S;
        status: ConstellationMemberStatus2;
        queuedChunks: N;
        error?: Error;
    };
    type ConstellationStrategy = | 'round-robin' | 'weighted' | 'least-busy' | 'first-alive';
    type ConstellationFailover = | 'next-member' | 'retry-same' | 'abort';
    type ConstellationOptions2 = {
        failure?: ConstellationFailureMode2;
        maxQueuedChunksPerMember?: N;
        onMemberStatus?: (
            member: ConstellationMember,
            status: ConstellationMemberStatus,
            error?: Error,
        ) => V;

        // ---- from constellation3 ----
        /** Selection strategy for picking the next ready member. Default: 'weighted'. */
        strategy?: ConstellationStrategy;

        /** What to do when a member's stream throws or rejects. Default: 'next-member'. */
        failover?: ConstellationFailover;

        /** Max retries before giving up (used by 'retry-same' and 'next-member'). Default: 2. */
        maxRetries?: N;

        /** How many consecutive failures before a member is marked unhealthy. Default: 3. */
        unhealthyAfterFailures?: N;

        /** Interval (ms) for the health/idle sweep. 0 disables. Default: 5_000. */
        healthCheckMs?: N;

        /** Evict idle members after this many ms of no use. 0 disables. Default: 0. */
        idleEvictMs?: N;

        /** Called when a member joins the constellation. */
        onMemberJoin?: (member: ConstellationMember) => V;

        /** Called when a member leaves (manual, idle, or error). */
        onMemberLeave?: (
            member: ConstellationMember,
            reason?: 'error' | 'manual' | 'idle',
        ) => V;

        /** Called when a failover occurs: `to` is null if no successor was available. */
        onFailover?: (
            from: ConstellationMember,
            to: ConstellationMember | null,
            error: U,
        ) => V;
    };
    type ConstellationHandle2 = {
        readonly done: P<A>;

        join(member: ConstellationMember2): V;

        /**
         * Stops forwarding output from this member.
         * This does not mutate or depend on your existing fn implementation.
         */
        remove(memberId: S): B;

        /**
         * Stops forwarding all future output and rejects `done`.
         */
        abort(reason?: U): V;

        members(): readonly ConstellationMemberSnapshot2[];
        setHealth(memberId: A, healthy: A): A
        on(event: S, handler: (e: Event) => V): A
        dispose(): A
    };
    type ConstellationFactory2 = (options?: ConstellationOptions2,) => (onChunk?: (event: ConstellationChunk2) => V,) => ConstellationHandle2;
    type ConstellationFactory = (options?: ConstellationOptions,) => (onChunk?: (event: ConstellationChunk) => V,) => ConstellationHandle
    type ConstellationOptions = {
        strategy?: 'round-robin' | 'weighted' | 'least-busy' | 'first-alive'
        failure?: 'continue' | 'fail-fast'
        maxQueuedChunksPerMember?: N
        maxRetries?: N
        onMemberStatus?: (
            member: ConstellationMember,
            status: ConstellationMemberStatus,
            error?: Error,
        ) => V
        onFailover?: (
            from: ConstellationMember,
            to: ConstellationMember | null,
            error: U,
        ) => V
    }
    type ConstellationMember = {
        id: S
        p: A
        k: S
        sl?: SU
        ms?: SU
        rt?: SU
        binary?: B
        weight?: N
    }
    type ConstellationMemberStatus = | 'running' | 'done' | 'error' | 'removed'
    type ConstellationChunk = {
        memberId: S
        chunk: A
        receivedAt: N
    }
    type ConstellationHandle = {
        done: P<A>

        join(member: ConstellationMember): V

        remove(memberId: S): B

        abort(reason?: U): V

        members(): Array<{
            id: S
            status: ConstellationMemberStatus
            queuedChunks: N
            error?: Error
        }>
    }
    type StreamAddress = {
        streamId: S;
        k: S;
        s?: SU;
        m?: SU;
        r?: SU;
    };
    type LiminalState = 'waiting' | 'live' | 'closed';
    type LiminalChunk<T = U> = {
        type: 'liminal';
        direction: 'upstream->downstream' | 'downstream->upstream';
        data: T;
        upstreamStreamId: S;
        downstreamStreamId: S;
        observedAt: N;
    };
    type StreamChunk<T = U> = {
        type: 'chunk';
        data: T;
        streamId?: S;
        ts?: N;
    };
    type StreamDone = {
        type: 'done';
        streamId?: S;
        ts?: N;
    };
    type StreamError = {
        type: 'error';
        error: S | Error | U;
        streamId?: S;
        ts?: N;
    };
    type StreamEvent<T = U> =
        | StreamChunk<T>
        | StreamDone
        | StreamError;
    type StateMeshReactor<T = A, A = A> = (state: T, action: A, snapshot: T) => T;
    type StateMeshUpdater<T> = T | ((current: T) => T);
    interface StateMesh<T = A, A = A> {
        state: T;
        snapshot(): T;
        set(next: StateMeshUpdater<T>): V;
        transition: <B = A>(action: B, reactor?: StateMeshReactor<T, B>) => V;

        commit(): V;
        rollback(): V;
    }
    interface SyncStreamOptions665 {
        /** Max unacknowledged in-flight payloads before the sender backs off. */
        windowSize?: N;
        /** Retransmit timeout per in-flight seq (default 5s). Keeps a lost ack from wedging the window. */
        retransmitMs?: N;
    }
    type SBackpressureStrategy665 = "drop" | "pause" | "error";
    interface StreamRelayOptions665 {
        maxSubscribers?: N;
        bufferSize?: N;
        backpressureStrategy?: SBackpressureStrategy665;
    }
    interface PipelineStage665<T> {
        name: S;
        handler: (data: T) => T | Promise<T>;
        errorHandler?: (err: Error, data: T) => T | Promise<T>;
    }
    type PipelineEvent665<T> = | { type: "stage:enter"; stage: S; data: T } | { type: "stage:exit"; stage: S; data: T } | { type: "error"; stage: S; data?: T; error: S };
    interface MeshOptions665 {
        peerId?: S;
        announceInterval?: N; // ms
        peerTimeout?: N;      // ms — peer considered stale
        maxPeers?: N;
    }
    interface MeshPeer665<TMeta extends Record<S, U> = Record<S, U>> {
        id: S;
        metadata: TMeta;
        latency: N;
        lastSeen: N;
    }
    interface MeshMessage665<T> {
        from: S;
        p: T;
        timestamp: N;
    }
    interface MeshState665 {
        peerId: S;
        peers: Array<{ id: S; metadata: Record<S, U> }>;
        meshSize: N;
    }
    interface CRDTStateHook665<S> {
        (v: S): [S, (patch: U) => V];
    }
    interface StreamLabOptions665 {
        /** Route all bus traffic through the flood-gate transport fabric. */
        floodGates?: B;
        /** Transport provider for flood gates (memory by default in the VM). */
    }
    interface Outbound {
        seq: N;
        p: U;
        acked: B;
        sentAt: N;
        timer?: ReturnType<typeof setTimeout>;
    }
    interface SyncStreamHandler665 {
        onOrdered: (cb: (p: U, seq: N) => V) => V;
        onComplete: (cb: () => V) => V;
        close: () => V;
    }
    // #endregion
    // #region ══ PLINKO & GATES ════════════════════════════════════════════════════════════════════


    type PlinkoConditionType2 = | 'onSuccess' | 'onFailure' | 'always' | 'envVariable' | 'configValue' | 'fileExists' | 'fileNotExists' | 'itemSuccess' | 'itemFailure' | 'custom' | 'and' | 'or' | 'not' | 'timeBased' | 'rateLimit' | 'random' | 'dependencies';
    type ExecutionMode2 = 'sequential' | 'parallel' | 'firstMatch' | 'allMatch' | 'race';
    type BackoffStrategy2 = 'exponential' | 'linear' | 'fixed' | 'none';
    interface RetryConfig2 {
        max: N;
        backoff: BackoffStrategy2;
        delay?: N;
        maxDelay?: N;
        retryOn?: S[]; // Error types to retry on
    }
    interface PlinkoCondition2 {
        type: PlinkoConditionType2;
        // Environment/Config
        envKey?: S;
        configKey?: S;
        operator?: 'equals' | 'contains' | 'startsWith' | 'endsWith' | 'regex' | 'gt' | 'gte' | 'lt' | 'lte';
        value?: A;
        // File operations
        filePath?: S;
        // Item tracking
        itemLabel?: S;
        // Custom expressions
        expression?: S;
        // Logic operators
        conditions?: PlinkoCondition2[];
        // Time based
        window?: N; // Time window in ms
        limit?: N; // Rate limit count
        // Execution targets
        executeChain?: S | S[] | PlinkoStep2[];
        exe?: PlinkoStep2[];
        // Branching
        onSuccess?: S | PlinkoStep2[];
        onFailure?: S | PlinkoStep2[];
        // Priority (higher runs first)
        priority?: N;
        // Optional label
        label?: S;
        // Timeout for this condition's execution
        timeout?: N;
    }
    interface PlinkoStep2 {
        id?: S;
        label?: S;
        path?: S;
        type: 'chain' | 'parallel' | 'conditionalTree' | 'function' | 'retry' | 'timeout' | 'circuitBreaker';
        args?: A[];
        // Execution
        execute?: (context: PlinkoContext2) => A | Promise<A>;
        // Chain execution (sequential steps)
        steps?: PlinkoStep2[];
        // Conditional tree args
        conditions?: PlinkoCondition2[];
        // Retry configuration
        retry?: RetryConfig2;
        // Timeout in ms
        timeout?: N;
        // Circuit breaker
        circuitBreaker?: {
            failureThreshold: N;
            resetTimeout: N;
            halfOpenMaxCalls: N;
        };
        // Condition to run this step
        condition?: (context: PlinkoContext2) => B | Promise<B>;
        // Priority
        priority?: N;
        // Dependencies
        dependsOn?: S[];
        // On complete hook
        onComplete?: (result: A, context: PlinkoContext2) => A | Promise<A>;
        onError?: (error: Error, context: PlinkoContext2) => A | Promise<A>;
        // Environment
        environment?: S | S[];
        metadata?: Record<S, A>;
    }
    interface PlinkoContext22 {
        // Original p
        p: A;
        // Shared state
        state: Map<S, A>;
        // Results from each step
        results: Map<S, A>;
        // Execution history
        history: S[];
        // Variables (mutable)
        variables: Map<S, A>;
        // Step results with timestamps
        stepResults: Map<S, StepResult2>;
        // Session ID
        sessionId: S;
        // Start time
        startTime: N;
        // Parent context (for nested executions)
        parent?: PlinkoContext2;
        // Bus reference
        bus: A;
        // Metadata
        metadata: Map<S, A>;
    }
    interface PlinkoContext2 {
        p: A;
        state: Map<A, A>;
        results: Map<A, A>;
        history: S[];
        variables: Map<A, A>;
        stepResults: Map<A, A>;
        sessionId: S;
        startTime: N;
        bus: A;
        metadata: Map<A, A>;
    }
    interface StepResult2 {
        success: B;
        result?: A;
        error?: Error;
        duration: N;
        startTime: N;
        endTime: N;
        metadata?: Record<S, A>;
    }
    interface PlinkoTree2<T = A> {
        [key: S]: PlinkoStep2 | PlinkoTree2<T> | ((context: PlinkoContext2) => A);
    }
    interface PlinkoExecutionResult2 {
        sessionId: S;
        success: B;
        results: Map<S, StepResult2>;
        history: S[];
        duration: N;
        error?: Error;
        metadata: Record<S, A>;
    }
    type GateMatcher1<T = A> = (p: T) => B | Promise<B>;
    type GateHandler1<T = A, R = A> = (
        p: T,
        context: {
            reply: (data: A, subrt?: S) => Promise<U>;
            store: Map<S, A>;
            bus: A;
        }
    ) => R | Promise<R>;
    interface GateDefinition1<T = A, R = A> {
        priority?: N;
        matcher: GateMatcher1<T>;
        execute: GateHandler1<T, R>;
        persistent?: B;
        blocking?: B;
    }
    type GateInput1<T = A> =
        | GateMatcher1<T>
        | GateDefinition1<T>;
    type GateMap1<T = A> = Record<S, GateInput1<T>>;
    interface GateExecutionResult1 {
        gateId: S;
        fired: B;
        result?: A;
        error?: Error;
        duration: N;
    }
    interface ResolvedGate1<T = A> extends GateDefinition1<T> {
        id: S;
    }

    type StartOptions = {
        eventSink?: EventSink;
        maxTransitions?: N;
        runId?: RunId;

        /**
         * Used for non-durable diagnostics/telemetry. If omitted, telemetry append
         * failures are ignored. Event-sink failures are never ignored.
         */
        onTelemetryError?: (error: U, event: PlinkoEvent) => V;
    };
    type GateContext<TPayload = U> = {
        p: TPayload;
        store: Map<S, U>;
        reply: (data: U, targetrt?: S) => Promise<U>;
    };
    type GateMatcher<TPayload = U> = (p: TPayload, ctx: GateContext<TPayload>) => MaybePromise<B>;
    type GateHandler<TPayload = U, TResult = U> = (p: TPayload, ctx: GateContext<TPayload>) => MaybePromise<TResult>;
    type GateDefinition<TPayload = U, TResult = U> = {
        /**
         * Higher values are checked first in sequential mode.
         * In concurrent mode priority only provides deterministic ordering metadata.
         */
        priority?: N;
        execute?: A
        matcher: GateMatcher<TPayload>;
        handler?: GateHandler<TPayload, TResult>;
    };
    type GateMap<TPayload = U> = Record<S, GateMatcher<TPayload> | GateDefinition<TPayload>>;
    type GateRunResult<TResult = U> = {
        name: S;
        matched: B;
        success: B;
        result?: TResult;
        error?: U;
    };
    type GateMasterOptions = {
        /**
         * true: match all gates and run all matches in parallel
         * false: match and run one gate at a time, in priority order
         */
        concurrency?: B;

        /**
         * In sequential mode, stop after the first successful matching handler.
         * Defaults to false because Gate Master is intended to fan out to all matches.
         */
        stopAfterFirstMatch?: B;

        /**
         * If true, a failed matcher/handler stops sequential processing.
         * Defaults to false, so other independent gates keep running.
         */
        failFast?: B;

        onError?: (
            error: U,
            gateName: S,
            phase: "match" | "execute",
            p: U
        ) => V;
    };
    type Awaitable<T> = T | Promise<T>;
    type NodeId = S;
    type RunId = S;
    type PlinkoOutcome =  "idle" | "success" | "failure" | "skipped" | "cancelled"| "failed"| "succeeded" ;
                                                            type PlinkoRunStatus =  "idle" | "running" | "succeeded" | "failed" | "cancelled"| "success" | "skipped";
    type SerializedError = {
        name: S;
        message: S;
        stack?: S;
        cause?: SerializedError;
    };
    type PlinkoRetryPolicy = {
        maxAttempts?: N;
        delayMs?: N;
        maxDelayMs?: N;
        backoff?: "fixed" | "linear" | "exponential";
        jitter?: "none" | "full";
        retryIf?: (error: U, attempt: N) => B;
    };
    type PlinkoNodeContext<TInput, TResults extends Record<S, U> = Record<S, U>,> = {
        readonly runId: RunId;
        readonly nodeId: NodeId;
        readonly attempt: N;
        readonly input: TInput;
        readonly results: Readonly<TResults>;
        readonly variables: ReadonlyMap<S, U>;
        readonly signal: AbortSignal;

        emit(name: S, p?: U): V;
    };
    type ActionNode<TInput, TResults extends Record<S, U> = Record<S, U>, TOutput = U,> = {
        kind?: "action";
        label?: S;

        when?: (
            ctx: PlinkoNodeContext<TInput, TResults>,
        ) => Awaitable<B>;

        run: (
            ctx: PlinkoNodeContext<TInput, TResults>,
        ) => Awaitable<TOutput>;

        timeoutMs?: N;
        retry?: PlinkoRetryPolicy;
        on?: Partial<Record<PlinkoOutcome, NodeId>>;
    };
    type PlinkoDefinition<TInput> = {
        id: S;
        version?: S;
        start: NodeId;
        nodes: Record<NodeId, ActionNode<TInput>>;
    };

    type PlinkoEvent =
           {
            type: "run.started";
            runId: RunId;
            graphId: S;
            graphVersion?: S;
            input: U;
            at: N;
        } | {
            type: "node.selected";
            runId: RunId;
            nodeId: NodeId;
            at: N;
        } | {
            type: "node.started";
            runId: RunId;
            nodeId: NodeId;
            attempt: N;
            at: N;
        } | {
            type: "node.skipped";
            runId: RunId;
            nodeId: NodeId;
            reason: S;
            at: N;
        }
        | {
            type: "node.succeeded";
            runId: RunId;
            nodeId: NodeId;
            attempt: N;
            result: U;
            durationMs: N;
            at: N;
        }
        | {
            type: "node.failed";
            runId: RunId;
            nodeId: NodeId;
            attempt: N;
            error: SerializedError;
            durationMs: N;
            willRetry: B;
            at: N;
        }
        | {
            type: "node.retrying";
            runId: RunId;
            nodeId: NodeId;
            attempt: N;
            delayMs: N;
            at: N;
        }
        | {
            type: "node.cancelled";
            runId: RunId;
            nodeId: NodeId;
            attempt: N;
            reason?: U;
            at: N;
        }
        | {
            type: "transition.taken";
            runId: RunId;
            from: NodeId;
            outcome: PlinkoOutcome;
            to?: NodeId;
            at: N;
        }
        | {
            type: "run.event";
            runId: RunId;
            nodeId: NodeId;
            name: S;
            p?: U;
            at: N;
        }
        | {
            type: "run.completed";
            runId: RunId;
            status: Extract<
                PlinkoRunStatus,
                "succeeded" | "failed" | "cancelled"
            >;
            result: Record<S, U>;
            error?: SerializedError;
            at: N;
        };
    type PlinkoEnvelope = {
        __plinko: 1;
        graphId: S;
        graphVersion?: S;
        runId: RunId;
        event: PlinkoEvent;
        snapshot: PlinkoRunSnapshot;
    };
    type PlinkoRunSnapshot = Readonly<{
        id: RunId;
        graphId: S;
        graphVersion?: S;
        status: PlinkoRunStatus;
        currentNodeId?: NodeId;
        input: U;
        results: Readonly<Record<S, U>>;
        events: readonly PlinkoEvent[];
        startedAt?: N;
        endedAt?: N;
        error?: SerializedError;
    }>;
    type MutablePlinkoRunSnapshot = {
        id: RunId;
        graphId: S;
        graphVersion?: S;
        status: PlinkoRunStatus;
        currentNodeId?: NodeId;
        input: U;
        results: Record<S, U>;
        events: PlinkoEvent[];
        startedAt?: N;
        endedAt?: N;
        error?: SerializedError;
    };
    type PlinkoAttemptEvent<TOutput> =
        | {
            type: "started";
            attempt: N;
        }
        | {
            type: "succeeded";
            attempt: N;
            result: TOutput;
            durationMs: N;
        }
        | {
            type: "failed";
            attempt: N;
            error: SerializedError;
            durationMs: N;
            willRetry: B;
        }
        | {
            type: "retrying";
            attempt: N;
            delayMs: N;
        }
        | {
            type: "cancelled";
            attempt: N;
            reason?: U;
        };
    type PlinkoNodeExecution<TOutput> = {
        outcome: PlinkoOutcome;
        result?: TOutput;
        error?: SerializedError;
        attempt: N;
    };
    type PlinkoStartOptions = {
        runId?: RunId;
        k?: S;
        sl?: SU;
        ms?: SU;
        rt?: SU;
        ttl?: N;
        maxTransitions?: N;
    };
    type PlinkoRunHandle = Readonly<{
        id: RunId;
        done: Promise<PlinkoRunSnapshot>;

        cancel(reason?: U): V;
    }>;
    type PlinkoDefinitionHandle<TInput> = Readonly<{
        graph: CompiledGraph<TInput>;

        start(
            input: TInput,
            options?: PlinkoStartOptions,
        ): PlinkoRunHandle;
    }>;
    interface PlinkoContext665<TState, TPayload> {

        state: TState;
        p: TPayload;
        path: S[];
        metadata: Map<S, A>;
        reply: (data: U, targetSc?: S) => Promise<U>;
        abort: (reason?: S) => never;
        send?(rt: S, p: U): V;
    }
    interface PlinkoNode665<TState, TPayload> {
        matcher: (p: TPayload, ctx: PlinkoContext665<TState, TPayload>) => B | Promise<B>;
        execute?: (p: TPayload, ctx: PlinkoContext665<TState, TPayload>) => U | Promise<U>;
        branches?: Record<S, PlinkoNode665<TState, TPayload>>;
        hooks?: {
            beforeEnter?: (p: TPayload, ctx: PlinkoContext665<TState, TPayload>) => V | P<A>;
            afterExit?: (result: U, ctx: PlinkoContext665<TState, TPayload>) => V | P<A>;
        };
    }
    type PlinkoTree665<TState, TPayload> = Record<S, PlinkoNode665<TState, TPayload>>;
    interface PlinkoOptions665<TState = A, TPayload = A> {
        autoResetOnTerminal?: B;
        onTransition?: (from: S[], to: S[], p: TPayload) => V;
        onError?: (err: Error, path: S[], p: TPayload) => V;
    }
    interface PlinkoEvaluation665<TState, TPayload> {
        success: B;
        path: S[];
        result: U;
        terminal: B;
        state?: TState;
        metadata?: Map<S, A>;
    }
    interface PlinkoHandle665<TState, TPayload> {
        evaluate(p: TPayload, replyFn?: (data: U, targetSc?: S) => Promise<U>): Promise<PlinkoEvaluation665<TState, TPayload>>;
        getState(): TState;
        getPath(): S[];
        reset(): V;
    }
    // #endregion
    // #region ══ SWITCHBOARD ════════════════════════════════════════════════════════════════════

    interface SwitchboardResult {
        success: B;
        matchedKey: S | null;
        result?: A;
        error?: Error;
        unmatched?: B;
    }
    type SwitchboardRoute2<TPayload = A> = (p: TPayload, ctx?: A) => Promise<A> | A;
    type SwitchboardRoutes<TPayload = A, TKey extends S = S> = | { [K in TKey | 'default']?: SwitchboardRoute2<TPayload> } | Map<S, SwitchboardRoute2<TPayload>>;
    interface SwitchboardHandle<TPayload = A, TKey extends S = S> {
        unregister: () => V; // same as your prior unregister()
        registerRoute: (rawKey: S, route: SwitchboardRoute2<TPayload>) => V;
        unregisterRoute: (rawKey: S) => B;
        updateRoutes: (routes: Partial<Record<S, SwitchboardRoute2<TPayload>>>) => V;
        getRoutes: () => Record<S, SwitchboardRoute2<TPayload> | UD>;
        changes: () => AsyncIterable<{ type: 'add' | 'remove' | 'update'; key: S }>;
    }
    interface SwitchboardOptions2<TPayload = A, TKey extends S = S> {
        selectKey: (p: TPayload) => TKey;
        onUnmatched?: (p: TPayload, key: S | null) => V;
    }
    interface SwitchboardContext665<TPayload> {
        p: TPayload;
        reply: (data: U) => Promise<U>;
        store: Map<S, A>;
    }
    interface SSwitchboardResult665 {
        success: B;
        matchedKey: S | null;
        unmatched: B;
        result?: U;
        error?: Error;
    }
    interface SwitchboardRoute665<TPayload> {
        (p: TPayload, ctx: SwitchboardContext665<TPayload>): U;
    }
    type SwitchboardRoutes665<TPayload, TKey extends S = S> = { [K in TKey]?: SwitchboardRoute665<TPayload> | "unmatched"; } & { default?: SwitchboardRoute665<TPayload> };
    interface SwitchboardOptions665<TPayload, TKey extends S = S> {
        rt?: S;
        subrt?: S;
        selectKey: (p: TPayload) => TKey;
        onUnmatched?: (p: TPayload, key: S) => V;
        onDispatch?: (route: S, p: TPayload, result: U) => V;
    }
    // #endregion
    // #region ══ SIGNALS ════════════════════════════════════════════════════════════════════
  interface CSEMiddleware {
	name: string;
	/** Return msg to pass through, a replacement msg, or throw to abort the send. */
	onSend?: (msg: CSEMessage) => CSEMessage | Promise<CSEMessage>;
}
type Listener = (...v: A[]) => void;
type CSEHandler = (p: A,) => A | Promise<A>;

// Structural wiring shapes — what MQ_SEND consults. The real shards satisfy these.
interface SCHEMA_WIRE { checkSchema(rt: S, msg: CSEMessage): { valid: B; errors: S[] }; setChannelSchema(s: CSESchema, rt: S): void; getChannelSchema(rt: S): CSESchema | null; }
interface PERMISSIONS_WIRE { check(rt: S, action: S, ctx?: A): B; setChannelPermissions(p: ChannelPermissions, rt: S): void; getChannelPermissions(rt: S): ChannelPermissions | null; }
interface HISTORY_WIRE { record(msg: CSEMessage): void; has(id: S): B; }
interface MIDDLEWARE_WIRE { run(msg: CSEMessage): Promise<CSEMessage>; }
interface ROUTING_WIRE { resolve(rt: S, ms: S, sl: S, k: S): RouteTarget[]; }
interface BACKPRESSURE_WIRE { shouldBackpressure(): B; armThrottle(): void; stage(msg: CSEMessage, priority?: CSEPriority): Promise<A>; dispatchOne: (msg: CSEMessage) => Promise<A>; }
interface SUB_WIRE extends MQ_SUB_SHARD {}

type RouteTarget = {
	/** Adapter id — 'same_boundary' | 'cross_boundary' | 'http' | 'reliableSocket' | 'workerThreadAdapter' | ... */
	adapter: S;
	/** Addressing convention: [rt][ms][sl][k] as in RITUAL_OF_SOULS. */
	rt: S; ms: S; sl: S; k: S;
};

interface MIDDLEWARE_WIRE { matchesPattern(pattern: S, rt: S): B; }
  interface Transform {
	name?: S;
	incoming?: (msg: CSEMessage) => CSEMessage | Promise<CSEMessage>;
	outgoing?: (msg: CSEMessage) => CSEMessage | Promise<CSEMessage>;
}

  interface GroupOptions { enabled?: B; middleware?: (msg: CSEMessage) => B | void; }
  interface RouteRule {
	name: S;
	/** Match against the channel (rt). Same glob convention as MQ_SUB: * one segment, ** everything. */
	match: A;
	/** Rewrite the target address. Missing fields pass through. */
	target?: Partial<Omit<RouteTarget, 'adapter'>>;
	/** Which adapter carries it. Omit = same boundary. */
	adapter?: S;
	priority?: CSEPriority;
	enabled?: B;
}




 interface SignalOptions {
    schema?: SignalSchema;
    lifecycle?: SignalLifecycle;
    conflict?: ConflictPolicy;
    conflictStrategy?: ConflictStrategy;
    triggerRender?: boolean;
    history?: { max?: number };
}

 type ConflictStrategy = "latest" | "fail" | "accumulate";

 type Boundary = "same-app" | "cross-app" | "isolated" | string;

 interface AtomWriteOptions {
    source?: string;
    cause?: string;
    triggerRender?: boolean;
    recordHistory?: boolean;
}

 type Unsubscribe = () => void;

 interface Change<T> {
    key: SignalKey;
    previous: T;
    current: T;
    version: number;
    timestamp: number;
    source?: string;
}

 interface AtomHistoryEntry<T> {
    k: number;
    value: T;
    prev?: T;
    next?: T;
    timestamp: number;
    source?: string;
    undone?: boolean;
}

 interface CausalEntry {
    value: unknown;
    source?: string;
    cause?: string;
    timestamp: number;
}

 interface AtomContract<T> {
    name: string;
    precondition?: (v: A) => boolean
    postcondition(next: T, previous: T): boolean;
    invariant?: (snapshot: Record<string, A>) => boolean
    block?: boolean;
}

 interface Metrics {
    writeCount: number;
    lastWrite: number;
}

 interface SIGNAL_CELL<T = unknown> {
    // ---- Identity ------------------------------------------------------
    readonly key: SignalKey;
    readonly initial: T;
    readonly node: AlienSignal<T>;

    // ---- Listener storage (exposed publicly in class) ------------------
    readonly globalListeners: Set<(key: SignalKey, value: unknown) => void>;
    readonly listeners: Set<(change: Change<T>) => void>;
    readonly externalSubscribers: Set<() => void>;
    readonly waiters: Set<(value: T) => void>;

    // ---- Conflict handling --------------------------------------------
    conflict?: ConflictPolicy;
    conflictStrategy?: ConflictStrategy;

    // ---- Versioning & history -----------------------------------------
    version: number;
    undoStack?: HistoryEntry[];
    historyIndex: number;
    history?: AtomHistoryEntry<T>[];
    historyMax: number;
    persisted: boolean;
    hasWritten: boolean;

    // ---- Lifecycle / async / metrics ----------------------------------
    lifecycle?: SignalLifecycle<T>;
    async?: AsyncSignalState<T>;
    metrics?: Metrics;

    // ---- Guard flags ---------------------------------------------------
    sealed: boolean;
    frozen: boolean;

    // ---- Schema / contracts / causality -------------------------------
    schema?: SignalSchema;
    readonly contracts: Map<string, AtomContract<T>>;
    causal: CausalEntry[];
    lastWriteSource?: string;

    // ---- Batching ------------------------------------------------------
    batches: Set<SignalKey>;
    batchQueue: Map<SignalKey, unknown>;
    batchOpts: Map<SignalKey, { triggerRender?: boolean }>;

    // ---- Rendering -----------------------------------------------------
    triggerRender: boolean;
    boundary: Boundary;

    // ---- Core reads / writes ------------------------------------------
    read(): T;
    peek(): T;
    write(
        incoming: T | ((previous: T) => T),
        options?: AtomWriteOptions,
    ): T;

    // ---- Subscriptions -------------------------------------------------
    subscribe(listener: (change: Change<T>) => void): Unsubscribe;
    subscribeExternal(callback: () => void): Unsubscribe;
    waitForNext(): Promise<T>;

    // ---- Chainable configuration --------------------------------------
    setSchema(schema?: SignalSchema): this;
    setLifecycle(lifecycle?: SignalLifecycle<T>): this;
    setConflict(
        conflict?: ConflictPolicy,
        strategy?: ConflictStrategy,
    ): this;

    // ---- Guard mutators -----------------------------------------------
    setFrozen(): void;
    setUnfrozen(): void;
    setSealed(): void;
    setUnsealed(): void;
    setBoundary(): void;

    // ---- History / time travel ----------------------------------------
    getHistory(): readonly AtomHistoryEntry<T>[];
    timeTravel(steps?: number): T | undefined;
    back(steps?: number): T | undefined;
    forward(steps?: number): T | undefined;
    goto(sequence: number): T | undefined;
}
// ============================================================================
// Scope handles — these are the sl / ms / rt triples threaded everywhere
// ============================================================================

/**
 * Scope locator. Whatever identifies "which signal instance in which scope".
 * Opaque on purpose; WarLock only ever passes it through.
 */
 interface ScopeLocator {
    readonly kind: string;
    readonly id: string | symbol | number;
}

/** Aliases so signatures stay readable. */
 type SL = ScopeLocator;
 type MS = ScopeLocator;
 type RT = ScopeLocator;

// ============================================================================
// Resolved key — what resolveKey returns and atom_reg is keyed by
// ============================================================================

/**
 * A composite key after scope resolution. Must be usable as a Map key,
 * so it's either a primitive or a frozen branded object with a stable hash.
 */
 type ResolvedKey = SignalKey | { readonly __rk: true; readonly hash: string };

// ============================================================================
// The atom handle returned by atom<T>()
// ============================================================================

 interface AtomHandle<T> {
    value: T;
    current: T;
    crt: T;
    set: T;
    peek(): T;
}


// ============================================================================
// AtomRegistry — what atom_reg() returns
// ============================================================================


 interface AtomRegistry {
    get<T = unknown>(rk: ResolvedKey): SIGNAL_CELL<T> | undefined;
    set<T = unknown>(rk: ResolvedKey, cell: SIGNAL_CELL<T>): this;
    has(rk: ResolvedKey): boolean;
    delete(rk: ResolvedKey): boolean;
    keys(): IterableIterator<ResolvedKey>;
    clear(): void;
    readonly size: number;
}

// ============================================================================
// The WarLock interface (the object `this` is inside `atom` / `read`)
// ============================================================================

 interface IWarLock {
    // ---- Scope defaults ------------------------------------------------
    readonly sl: SL;
    readonly ms: MS;
    readonly rt: RT;

    // ---- Internal id generator ----------------------------------------
    /** Returns a fresh unique id (used to build default signal keys). */
    _sid(): string | number;

    // ---- Core factory --------------------------------------------------
    atom<T = any>(
        v: T | null,
        key?: SignalKey,
        sl?: SL,
        ms?: MS,
        rt?: RT,
        options?: SignalOptions,
    ): AtomHandle<T>;

    // ---- Cell creation / lookup ---------------------------------------
    /** Creates & registers a new SIGNAL_CELL. */
    create<T>(
        key: SignalKey,
        initial: T,
        options?: SignalOptions,
        sl?: SL,
        ms?: MS,
        rt?: RT,
    ): AtomHandle<T>;

    /** Resolves a user-facing key into the composite registry key. */
    resolveKey(
        key: SignalKey,
        sl?: SL,
        ms?: MS,
        rt?: RT,
    ): ResolvedKey;

    /** Returns the registry for the given scope triple. */
    atom_reg(sl?: SL, ms?: MS, rt?: RT): AtomRegistry;

    // ---- Read / write --------------------------------------------------
    read<T>(
        key: SignalKey,
        sl?: SL,
        ms?: MS,
        rt?: RT,
    ): T | undefined;

    /** `write` is referenced by the atom handle but not shown in your snippet. */
    write<T>(
        key: SignalKey,
        value: T | ((previous: T) => T),
        source?: string,
        sl?: SL,
        ms?: MS,
        rt?: RT,
    ): T | undefined;

    // ---- Component binding --------------------------------------------
    /** Wires the currently-rendering component to this signal key. */
    _bindComponentToSignal(
        rk: ResolvedKey,
        sl?: SL,
        ms?: MS,
        rt?: RT,
    ): void;
}













    type CSEHandler = (p: A, ctx?: HandlerContext) => A | Promise<A>;
    interface CSEAdapter {
        id?: S;
        send(msg: AdapterSendPayload): V;
        onMessage(handler: (msg: AdapterSendPayload) => V): () => V;
        onConnect?(handler: () => V): V;
        onDisconnect?(handler: () => V): V;
    }

    interface CSEMessage {
        id: S;
        r: S;
        m?: S;
        s?: S;
        k?: S;
        topic?: S;
        p: U;
        ttl?: N;
        ts?: N;
        _ack?: B;
        _adapter?: CSEAdapter;
        priority?: CSEPriority;
        tags?: S[];
        streamId?: S;
        sessionId?: A;
        token?: A;
        binary?: 'signal_save_value' | 'signal' | true | false | S;
        error?: A
        adapter_id?: A
        cross_cse_ngin_connect_adapter_id?: A
        cross_app_adapter_adapter_id?: A
        type?: S
    }
    interface CSE_Multiplexed_Msg {
        id: S;
        r: S;
        m?: S;
        s?: S;
        k?: S;
        full_channel?: S;
        p: U;
        ttl?: N;
        ts?: N;
        _ack?: B;
        _adapter?: CSEAdapter;
        priority?: CSEPriority;
        tags?: S[];
        streamId?: S;
        sessionId?: A;
        token?: A;
        binary?: 'signal_save_value' | 'signal' | true | false | S;
        error?: A
        adapter_id?: A
        type?: S
    }
    type AtomWriteOptions = {
        source?: S;
        triggerRender?: B;
        cause?: S;
        recordHistory?: B;
    };
    type AtomHistoryEntry<T> = {
        k: N;
        value: T;
        timestamp: N;
        source?: S;
        next?:T;
        prev?: T;
        undone?:any;
    };
    type AtomHistoryEntry1<T> = {
        k: N;
        value: T;
        timestamp: N;
        source?: S;
        next?:A
    };
    type HistoryOptions = {
        max?: N;
    };
    type HistoryEntry<T = U> = {
        k: N;
        value: T;
        timestamp: N;
        source?: S;
        prev?: A
        undone?: A
    };
    type HistoryOpts = ScopeOptions & {
        cap?: N;
    };
    type HistoryChannels = {
        s?: A; m?: A; r?: A;
    };
    type Boundary = 'same-app' | 'same-node' | 'cross-node'

    type AlienWritable<T> = {
        (): T;
        (value: T): V;
        peek?: () => T;
    };
    interface AsyncSignalState<T = A> {
        fetcher: () => Promise<T> | V;
        controller: AbortController | null;
        retryCount: N;
        staleValue?: T;
    }
    interface SignalOptions {
        schema?: SignalSchema;
        conflict?: ConflictPolicy;
        history?: { max: N };
        lifecycle?: SignalLifecycle;
        persist?: B;
        ttl?: N;
        broadcast?: B;
        triggerRender?: B;
        conflictStrategy?: "latest" | "fail" | "accumulate";
    }
    interface SignalTimelineEntry {
        value: A;
        timestamp: N;
        source?: S;
    }
    type ConflictPolicyName = 'last-write-wins' | 'first-write-wins' | 'merge' | 'reject-on-conflict' | 'queue'
    interface CausalEntry {
        key: S
        value: A
        timestamp: N
        source?: 'write' | 'effect' | 'derived' | 'staff' | 'ngin' | S
        cause?: S
    }
    interface DOMBinding {
        node: Node
        update: (node: Node, value: A) => V
        active?: B
    }
    interface CallbackHookState extends HookState {
        callback: (...args: A[]) => A
        deps: A[]
    }
    interface Metrics {
        readCount: N;
        writeCount: N;
        subscriberCount: N;
        lastWrite: N | null;
        flushDuration: N;
    }
    interface SignalHandle<T = A> {
        value: T;
        peek(): T;
    }
    interface ComputedHandle<T = A> {
        value: T;
        peek(): T;
    }
    interface SignalSchema {
        validate: (v: A) => B;
        coerce?: (v: A) => A;
    }
    interface SignalLifecycle {
        onCreate?: () => V;
        onWrite?: (value: A, prev: A | UD) => V;
        onRead?: (value: A) => V;
        onDelete?: () => V;
        onFreeze?: () => V;
        onExpire?: () => V;
        onError?: (err: Error) => V;
    }
    interface SignalEffect {
        keys: S[];
        fn: (...values: A[]) => (() => V) | V | Promise<(() => V) | V>;
        cleanup: (() => V) | null;
        controller: AbortController | null;
    }
    interface AsyncSignalHandles {
        dataKey: S;
        loadingKey: S;
        errorKey: S;
    }
    interface SignalScopeHandle {
        add(key: A): V;
        suspend(): V;
        resume(): V;
        dispose(): V;
        snapshot(): Record<S, A>;
        restore(snapshot: Record<S, A>): V;
        fork(): SignalScopeHandle;
        merge(forked: SignalScopeHandle): V;
    }
    type Teardown =
        | V
        | null
        | (() => V)
        | { unsubscribe(): V }
        | { [Symbol.dispose](): V }
        | Teardown[];
    interface Link {
        version: N;
        dep: ReactiveNode;
        sub: ReactiveNode;
        prevSub: Link | UD;
        nextSub: Link | UD;
        prevDep: Link | UD;
        nextDep: Link | UD;
        bus?: A
        value?: A
        label?: S
    }
    interface Stack<T> {
        value: T;
        prev: Stack<T> | UD;
    }

    interface EffectScopeNode extends ReactiveNode {
        onError?: EffectErrorHandler;
        children?: Set<ReactiveNode>;
    }
    type EffectErrorHandler = (err: U, node: ReactiveNode) => V;
    interface ReactiveNode {
        deps?: Link;
        depsTail?: Link;
        subs?: Link;
        subsTail?: Link;
        flags: ReactiveFlags;
    }
    interface AsyncNode<T = A> extends ReactiveNode {
        fetcher: (signal: AbortSignal) => Promise<T>;
        value: T | UD;
        error: U;
        pending: B;
        controller: AbortController | null;
        version: N;
        onError?: EffectErrorHandler;
    }
    interface EffectNode extends ReactiveNode {
        fn(): (() => V) | V;
        cleanup: (() => V) | V;
        onError?: EffectErrorHandler;
    }
    interface ComputedNode<T = A> extends ReactiveNode {
        value: T | UD;
        getter: (previousValue?: T) => T;
    }
    interface SignalNode<T = A> extends ReactiveNode {
        currentValue: T;
        pendingValue: T;
    }
    interface SignalScope {
        id: S
        keys: Set<S>
        effects: Set<A>
        suspended: B
        pendingFlush: Map<S, A>
    }
    type SignalListener = { (value: A, source?: S): V }
    interface SignalLifecycle<T = A> {
        onCreate?: () => V;
        onWrite?: (value: T, prev: T | UD) => V;
        onRead?: (value: T) => V;
        onDelete?: () => V;
        onFreeze?: () => V;
        onExpire?: () => V;
        onError?: (err: Error) => V;
    }
    interface SignalEffect {
        keys: S[];
        fn: (...values: A[]) => (() => V) | V | Promise<(() => V) | V>;
        cleanup: (() => V) | null;
        controller: AbortController | null;
    }
    interface AsyncSignalState<T> {
        fetcher: () => Promise<T> | V;
        controller: AbortController | null;
        retryCount: N;
        staleValue?: T;
    }
    type ConflictPolicy2<T = A> = | ConflictPolicyName | ((current: T, incoming: T, meta: { key: S; timestamp: N }) => T)
    // interface ConflictPolicy<T = A> { resolve?: (prev: T | UD, next: T) => T | UD; }
    interface ConflictPolicy { resolve?: (prev: A | UD, next: A) => A | UD; }

    interface SysEntry {
        read: () => A;
        write: (v: A) => V;
        node: A;
        isComputed: B;
    }
    type SignalKey = A;
    type SOUL_KEY = A;

    type Signal<T> = {
        (): T;
        (next: T): V;
        peek?: () => T;
    };
    type CURRENT_SOUL_SHARD<T> = {
        (): T;
        (next: T): V;
        peek?: () => T;
    };
    type Change<T> = {
        key: SignalKey;
        previous: T;
        current: T;
        version: N;
        timestamp: N;
        source?: S;
    };
    type AtomContract<T> = {
        name: S;
        postcondition: (next: T, previous: T) => B;
        block: B;
    };
    type SyncJob = () => V;
    type AsyncEffectJob = {
        id: S;
        priority: N;
        run: () => V | P<A>;
        retry?: N;
        timeout?: N;
    };
    type Unsubscribe = () => V;
    type ConflictMeta = { at: N; node: S; userId?: S };
    type ConflictEnvelope<T = A> = { value: T; meta: ConflictMeta };
    type ConflictStrategy<T = A> = | 'lww' | 'merge' | { priority: S[] } | ((local: ConflictEnvelope<T> | UD, remote: ConflictEnvelope<T>) => ConflictEnvelope<T>);

    // #endregion
    // #region ══ BUS NESTS ════════════════════════════════════════════════════════════════════
    type SIG_BUS_PLINKO_FN = {
        <TInput>(
            definition: PlinkoDefinition<TInput>,
        ): PlinkoDefinitionHandle<TInput>;

        define<TInput>(
            definition: PlinkoDefinition<TInput>,
        ): PlinkoDefinitionHandle<TInput>;

        compile<TInput>(
            definition: PlinkoDefinition<TInput>,
        ): CompiledGraph<TInput>;
    };

    interface SIG_BUS_useEffect_FN {
        (effect: () => V | (() => V), deps: A[], k: S, sl: S, ms: S, rt: S): A;
        auto(effect: (scope: ReturnType<A>) => V, deps: A[], k: S, sl: S, ms: S, rt: S): A;
        layout(effect: A, deps: A, k: S, sl: S, ms: S, rt: S): A
    }
    interface SIG_BUS_STREAM_FN {
        (p: A, onChunk: (chunk: A) => V, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, chain?: 'chain' | 'rechain', binary?: B): P<A>;
        chunk(streamId: S, chunk: S, k: S, sl?: S, ms?: S, rt?: S): V
        done(streamId: S, chunk: S, k: S, sl?: S, ms?: S, rt?: S): V
        cancel(streamId: S, chunk: S, k: S, sl?: S, ms?: S, rt?: S): V
        liminal<T = U>(upstream: StreamAddress, downstream: StreamAddress, onChunk: (event: LiminalChunk<T>) => V,): { id: S; done: P<A>; close: () => V; }
        constellation(
            options?: ConstellationOptions,
        ): (
            onChunk?: (event: ConstellationChunk) => V,
        ) => ConstellationHandle
        constellation2(
            options?: ConstellationOptions2,
        ): (
            onChunk: (event: ConstellationChunk2) => V,
        ) => ConstellationHandle2
        negotiate(offer: StreamContractOffer, k: S, sl?: S, ms?: S, rt?: S, timeoutMs: N,): Promise<NegotiatedStreamContract>
        probabilistic<T>(send: ProbabilisticSender, options: ProbabilisticOptions<T>,): ProbabilisticSender
        readable(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): ReadableStream<A>;
        writable(k?: SU, sl?: S, ms?: S, rt?: S): WritableStream<A>;
        StreamRelay(k?: SU, sl?: S, ms?: S, rt?: S, opts?: StreamRelayOptions): A;
        transform(readConfig: {
            k: S;
            sl?: S | UD;
            ms?: S | UD;
            rt?: S | UD;
        }, writeConfig: {
            k?: S | UD;
            sl?: S | UD;
            ms?: S | UD;
            rt?: S | UD;
        }, transformer?: (chunk: A) => A | Promise<A>): {
            sub: TransformStream<A, A>;
            send: TransformStream<A, A>;
        };
        pipeline<T = A>(k?: SU, sl?: S, ms?: S, rt?: S, stages?: HydraStage<T>[]): {
            unsubscribe: () => V;
        };
        route<T = A>(k?: SU, sl?: S, ms?: S, rt?: S, selectKey?: (p: T) => S, outPrefix?: S, opts?: {
            defaultKey?: S;
            onUnmatched?: (p: T, key: S) => V;
        }): {
            unsubscribe: () => V;
            stats: () => Record<S, N>;
        };
        syncGuard(chunks: A[], k: S, options?: SyncIntegrityOptions): Promise<SyncIntegrityResult>;
        relayWithFlowControl(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, options?: RelayFlowOptions): A;
        useDRSWithConsensus(vState: A, k?: SU, sl?: S, ms?: S, rt?: S, options?: DRSConflictOptions): A;

        sync_2(chunks: A[], k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, onAck?: (seq: N) => V, windowSize?: N, binary?: B): P<A>;
        sync(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: SyncStreamOptions): A;

        relay(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, options?: {
            maxSubscribers?: N;
            bufferSize?: N;
            backpressureStrategy?: 'drop' | 'pause' | 'error';
        }): A;
        openSync(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: {
            windowSize?: N;
        }): A;
        priority(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): A;
        transactional(chunks: A[], k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): Promise<{
            committed: B;
            error?: S;
        }>;
        delta<T extends A>(computeDelta: (prev: T, next: T) => A, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): A;
        presence(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): A;
        authority<T = A>(v: T, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): A;
        heartbeat(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: {
            idleThresholdMs?: N;
        }): A;
        backpressure(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: {
            windowSize?: N;
        }): A;
        stateful(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: {
            key?: S;
        }): A;
        multicast(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: {
            key?: S;
        }): A;
        partitioned(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: {
            partitionCount?: N;
        }): A;
        batch(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: {
            maxSize?: N;
            maxWaitMs?: N;
        }): A;
        filtered(predicate: (p: A) => B, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): A;
        deadLetter(p: A, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: {
            maxRetries?: N;
            backoff?: A;
        }): Promise<{
            delivered: B;
        }>;
        idempotent(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): A;
        lateArrival(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): A;
        checkpoint(streamKey: S, opts?: {
            every?: N;
        }): A;
        rateLimited(opts: {
            ratePerSecond: N;
            burst?: N;
        }, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): A;
        combo(k: S, sl: S[], ms?: S | UD, rt?: S | UD, strategy?: ComboStrategy): A;
        transformative(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): A;
        fanout(k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, opts?: {
            key?: S;
        }): A;
        useDRSS<T extends Record<S, U> = A, P = A>(v: A, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, binary?: B): A;
        useDRSSSync(v: A, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, binary?: B): A;
    }

    interface SIG_BUS_SCLASS_DRS_FN {
        (...args: [...INI_QD,  chain?: CHAIN_TYPE]): A
        signal<T = A>(...args: [...INI_QD,  chain?: CHAIN_TYPE]): A
        crdt<T = A>(...args: [...INI_QD, type?:CELL, chain?: CHAIN, nodeId:S]): A
        stream<T = A>(...args: [...INI_QD, opts: { coalesceMs?: N },  chain?: CHAIN_TYPE]): A
        duplex<T = A>(...args: [...INI_QD,  chain?: CHAIN, opts: { window?: N; coalesceMs?: N }]): A
        crdtb<T = A>(...args: [...INI_QD,  nodeId:S]): A
        mailbox<T = A>(...args: [...INI_QD]): A
        mailbox2<T = A>(...args: [...INI_QD]): A
    }





    interface SIG_BUS_RIFTS_DRS_FN {
  <T = A>( v?: T, module?: S, named_?: S, ms?: S  , rt?: S  , chain?: CHAIN_TYPE): A
            mailbox<T = A>(module:A, named_ ?, ms?: S , rt?: S , wait?: N, store?:STORE_TYPE  ): A
            import<T = A>(module?: A, named_?: A, store?:STORE_TYPE , wait?: N, chain?: CHAIN_TYPE): A
    }
    interface SIG_BUS_HANDLER_FN { }
    interface SIG_BUS_CELL_DRS_FN {
        (...args: [...INI_QD, type?: CELL_TYPE, chain?: CHAIN_TYPE]): A
        crdt<T = A>(...args: [...INI_QD<T>]): A
        crdtb<T = A>(...args: [...INI_QD<T>, nodeId?: S]): A
        topology(k: S, sl?: S, ms?: S, rt?: S, chain?: 'chain' | 'rechain', selfId?: S, opts?: { probeTimeoutMs?: N }): A
        map<K, V>( v: Map<K, V>,k: A, sl?: S, ms?: S, rt?: S, type?: CELL_TYPE, chain?: CHAIN_TYPE): A
        set<T = A>( v: Iterable<T>,k:A, sl?: S, ms?: S, rt?: S, type?: CELL_TYPE, chain?: CHAIN_TYPE): A
        array<T = A>( v: T[],k: A, sl?: S, ms?: S, rt?: S, type?: CELL_TYPE, chain?: CHAIN_TYPE): A
        obj<T extends Record<PropertyKey, A>>( v?: T,k: A, sl?: S, ms?: S, rt?: S, type?: CELL_TYPE, chain?: CHAIN_TYPE): A
        string( v: S,k: A, sl?: S, ms?: S, rt?: S, type?: CELL_TYPE, chain?: CHAIN_TYPE): A
        num( v: N,k: A, sl?: S, ms?: S, rt?: S, type?: CELL_TYPE, chain?: CHAIN_TYPE): A
        boolean( v: B,k: A, sl?: S, ms?: S, rt?: S, type?: CELL_TYPE, chain?: CHAIN_TYPE): A
        stream(...args: [...INI_QD, opts?: A]): A
        duplex(...args: [...INI_QD, chain?: CHAIN_TYPE, opts?: A,]): A
        time_travel(...args: [...INI_QD,]): A
        gated(predicate: (topo: A, ...ctx: A[]) => B, value: A, deps: A[], k: A, sl?: S, ms?: S, rt?: S): A
        transaction(...args: [...INI_QD,]): A
        signal<T = A>(v?: T | (() => T), k?: S, sl?: S, ms?: S, rt?: S, chain?: CHAIN_TYPE): A
        graph(...args: [...INI_QD,]): A
        distributed(...args: [...INI_QD,]): A
        synchronization(...args: [...INI_QD,]): A
        replication(...args: [...INI_QD,]): A
        resilience(...args: [...INI_QD,]): A
        temporal(...args: [...INI_QD,]): A
        mesh<T = A>(v?: T, reactor?: StateMeshReactor<T>, k?: S, sl?: S, ms?: S, rt?: S,): StateMesh<T>
        store(...args: [...INI_QD,]): A
        mailbox(...args: [...INI_QD,]): A
        mailbox2(...args: [...INI_QD,]): A
        stateStore(...args: [...INI_QD,]): A
        liveStore(...args: [...INI_QD, nodeId?: S]): A
        live(...args: [...INI_QD,]): A
        observable(...args: [...INI_QD,]): A
        ref(...args: [...INI_QD,]): A
        umbrella(v?: Record<S, A>, k?: A, sl?: S, ms?: S, rt?: S): A
        context(v?: Record<S, A>, k?: A, sl?: S, ms?: S, rt?: S): A
    }
    type SIG_BUS_SS_FN = {
        // ── callable: creates a signal handle ────────────────────────────────────────────────────
        <T = A>(v?: A, key?: S, sl?: S, ms?: S, rt?: S, chain?: 'chain' | 'rechain', options?: SignalOptions<T>): A;
        update(node: SignalNode | ComputedNode | EffectScopeNode): B
        notify(effect: EffectNode): A








        _bindComponentToSignal(rk: S, sl?: S, ms?: S, rt?: S): V;
        _hashTuple(tuple: U[]): S
        _serializeTuple(tuple: A[]): S
        create<T = A>(key: S, v?: A, sl?: S, ms?: S, rt?: S, options?: SignalOptions<T>): S;
        read<T>(key: S, sl?: S, ms?: S, rt?: S,): A
        write<T>(key: S, sl?: S, ms?: S, rt?: S,): A
        normalizeKey(rawKey: S): A
        runTeardown(t: Teardown): V
        reportError(e: U): V
        untrackFn<T>(fn: () => T): T
        untrack<T>(fn: () => T): T

        setEffectErrorHandler(fn: EffectErrorHandler | null): V
        getActiveSub(): ReactiveNode | UD
        setActiveSub(sub?: ReactiveNode): A
        getBatchDepth(): N
        startBatch(): A
        endBatch(): A
        isSignal(fn: () => V): B
        isComputed(fn: () => V): B
        isEffect(fn: () => V): B
        isEffectScope(fn: () => V): B
        signal<T>(v?: T): { (): T | UD; (value: T | UD): V; }
        computed<T>(getter: (previousValue?: T) => T): () => T
        effect(fn: () => V | (() => V), onError?: EffectErrorHandler): (that: EffectNode) => V
        effectScope(fn: () => V, onError?: EffectErrorHandler): (that: EffectScopeNode) => V
        trigger(fn: () => V): A
        updateComputed(c: ComputedNode): B
        updateSignal(s: SignalNode): B
        run(e: EffectNode): V
        flushSS(): V
        runCleanup(e: EffectNode): V
        disposeAllDepsInReverse(sub: ReactiveNode): V
        purgeDeps(sub: ReactiveNode): A

        // ── ergonomic helpers ────────────────────────────────────────────────────────────────────
        sysEffect(fn: () => V | (() => V)): () => V;

        // ── internals exposed on the namespace ───────────────────────────────────────────────────
        _validateSchema(rk: S, value: A, sl?: S, ms?: S, rt?: S): A;
        _hashTuple(tuple: U[]): S;
        _recordCausal(rk: S, value: A, source: S, sl?: S, ms?: S, rt?: S, cause?: S): V;
        _resolveConflict(rk: S, prev: A, next: A, sl?: S, ms?: S, rt?: S): A;
        _writeResolved(rk: S, value: A, source: S, sl?: S, ms?: S, rt?: S, cause?: S): V;

        // ── key + schema ─────────────────────────────────────────────────────────────────────────
        resolveKey(key: A, sl?: S, ms?: S, rt?: S): S;
        registerSchema<T = A>(key: A, schema: SignalSchema<T>, sl?: S, ms?: S, rt?: S): V;

        // ── signal CRUD ──────────────────────────────────────────────────────────────────────────
        write<T = A>(key: A, value: T | ((prev: T | UD) => T), sl?: S, ms?: S, rt?: S, source?: S): V;
        read<T = A>(key: A, sl?: S, ms?: S, rt?: S): T | UD;
        peek<T = A>(key: A, sl?: S, ms?: S, rt?: S): T | UD;
        subscribe<T>(key: S, listener: (value: T, previous: T) => V, sl?: S, ms?: S, rt?: S,): Unsubscribe
        has(key: A, sl?: S, ms?: S, rt?: S): B;
        delete(key: A, sl?: S, ms?: S, rt?: S): V;

        // ── signal state modifiers ───────────────────────────────────────────────────────────────
        freeze(key: A, sl?: S, ms?: S, rt?: S): V;
        seal(key: A, sl?: S, ms?: S, rt?: S): V;
        reset(key: A, sl?: S, ms?: S, rt?: S): V;
        hydrate<T = A>(key: A, value: T, sl?: S, ms?: S, rt?: S): V;

        clone(srcKey: A, destKey: A, src: rts, dest: rts,): V;

        // ── persistence ──────────────────────────────────────────────────────────────────────────
        persist<T = A>(key: A, value: T, sl?: S, ms?: S, rt?: S, options?: { serialize?: (v: T) => S }): P<A>;
        unpersist(key: A, sl?: S, ms?: S, rt?: S): P<A>;

        // ── messaging ────────────────────────────────────────────────────────────────────────────
        sub<T = A>(k: S, handler: A, sl?: S, ms?: S, rt?: S): () => V;
        send(p: A, fromKey: A, toKey: A, ms?: S, rt?: S): V;

        // ── derived ──────────────────────────────────────────────────────────────────────────────
        derive<T = A>(
            key: A,
            deps: A[],
            compute: (...values: A[]) => T, sl?: S, ms?: S, rt?: S,
            options?: { eager?: B; onError?: (err: Error) => V }
        ): S;
        invalidateDerived(key: A): V;

        // ── async ────────────────────────────────────────────────────────────────────────────────
        createAsync<T = A>(
            key: A,
            fetcher: (signal: AbortSignal) => Promise<T>, sl?: S, ms?: S, rt?: S,
            options?: { fallback?: T }
        ): AsyncSignalHandles;
        invalidateAsync(key: A, sl?: S, ms?: S, rt?: S): V;
        mutateAsync<T = A>(key: A, optimistic: T, sl?: S, ms?: S, rt?: S): V;
        abortAsync(key: A, sl?: S, ms?: S, rt?: S): V;
        prefetchAsync<T = A>(key: A, fetcher: () => Promise<T>, sl?: S, ms?: S, rt?: S): V;
        readAsync<T = A>(key: A, sl?: S, ms?: S, rt?: S): T;

        // ── batch / tx ───────────────────────────────────────────────────────────────────────────
        batch(fn: () => V): V;
        tx(fn: () => V): V;
        transaction(block: () => V): V;

        // ── history / time travel ────────────────────────────────────────────────────────────────
        enableHistory(key: A, sl?: S, ms?: S, rt?: S, options?: { max: N }): V;
        undo(key: A, sl?: S, ms?: S, rt?: S): V;
        redo(key: A, sl?: S, ms?: S, rt?: S): V;
        signalTimeline(key: A, sl?: S, ms?: S, rt?: S): SignalTimelineEntry[];
        snapshot(): Record<S, A>;
        restore(snapshot: Record<S, A>): V;
        diffSnapshots(a: Record<S, A>, b: Record<S, A>): Record<S, { from: A; to: A }>;
        applyPatch(patch: Record<S, { from: A; to: A }>): V;
        replay(key: A, sl?: S, ms?: S, rt?: S, options?: { speed?: N }): P<A>;

        // ── causal / conflict / contracts ────────────────────────────────────────────────────────
        getCausalChain(key: A, sl?: S, ms?: S, rt?: S): CausalEntry[];
        conflictPolicy<T = A>(key: A, policy: ConflictPolicy<T>): V;
        declareContract(
            name: S,
            key: A,
            postcondition: (next: A, prev: A) => B, sl?: S, ms?: S, rt?: S,
            options?: { block?: B }
        ): V;
        removeContract(name: S): V;

        // ── scopes ───────────────────────────────────────────────────────────────────────────────
        createScope(id: S): SignalScopeHandle;

        // ── effects ──────────────────────────────────────────────────────────────────────────────

        effectOnce(
            keys: A[],
            predicate: (...v: A[]) => B,
            fn: (...v: A[]) => V
        ): () => V;

        // ── operators ────────────────────────────────────────────────────────────────────────────
        map<A = A, B = A>(srcKey: A, destKey: A, fn: (v: A) => B, src: rts, dest: rts): () => V;
        filter<T = A>(srcKey: A, destKey: A, pred: (v: T) => B, src: rts, dest: rts): () => V;
        debounce(sourceKey: A, delay: N, src: rts, dest: rts): [S, () => V];
        throttle(srcKey: A, destKey: A, ms: N, src: rts, dest: rts): () => V;
        merge(srcKeys: A[], destKey: A, src: rts, dest: rts): () => V;
        zip(srcKeys: A[], destKey: A, src: rts, dest: rts): () => V;
        combine(srcKeys: A[], destKey: A, src: rts, dest: rts): () => V;
        scan<T = A, A = A>(srcKey: A, destKey: A, reducer: (a: A, v: T) => A, seed: A, src: rts, dest: rts): () => V;
        switch(srcKey: A, destKey: A, src: rts, dest: rts): () => V;
        buffer(srcKey: A, destKey: A, count: N, src: rts, dest: rts): () => V;
        window(srcKey: A, destKey: A, ms: N, src: rts, dest: rts): () => V;
        distinct<T = A>(srcKey: A, destKey: A, equals?: (a: T, b: T) => B, src?: rts, dest?: rts,): A;
        audit(srcKey: A, destKey: A, ms: N, src: rts, dest: rts): () => V;
        sample(srcKey: A, triggerKey: A, destKey: A, src: rts, dest: rts): () => V;
        gate(srcKey: A, gateKey: A, destKey: A, src: rts, dest: rts): () => V;
    };
    type rts = { s?: A; m?: A; r?: A }
    type SIG_BUS_Boundary = 'same-app' | 'same-node' | 'cross-node'
    type SIG_BUS_Priority = 'high' | 'normal' | 'low';
    type CSEPriority = 'high' | 'normal' | 'low';
    type SIG_BUS_Strategy = 'overwrite' | 'merge' | 'skip';
    type SIG_BUS_SyncDirection = 'memory->adapter' | 'adapter->memory' | 'both';
    type SIG_BUS_DeliveryStatus = 'ack' | 'nak';
    type SIG_BUS_AdapterSendPayload = | SIG_BUS_Message | Uint8Array | SIG_BUS_SecureEnvelope;
    type SIG_BUS_Handler = (p: A, ctx?: SIG_BUS_HandlerContext) => A | Promise<A>;
    type SIG_BUS_CBORValue = null | B | N | S | Uint8Array | SIG_BUS_CBORValue[] | { [k: S]: SIG_BUS_CBORValue }
    type SIG_BUS_QueryExpr = | { type: 'eq'; key: S; value: U } | { type: 'and'; exprs: SIG_BUS_QueryExpr[] } | { type: 'or'; exprs: SIG_BUS_QueryExpr[] };
    interface SIG_BUS_Adapter {
        id?: S;
        send(msg: SIG_BUS_AdapterSendPayload): V;
        onMessage(handler: (msg: SIG_BUS_AdapterSendPayload) => V): () => V;
        onConnect?(handler: () => V): V;
        onDisconnect?(handler: () => V): V;
        close?(): V
    }
    interface SIG_BUS_SecureEnvelope {
        sessionId: S;
        token: S;
        p: SIG_BUS_Message | SIG_BUS_CBORValue;
    }
    interface SIG_BUS_Message {
        id: S | Uint32Array<ArrayBufferLike> |N |A;
        r?: A;
        m?: A;
        s?: A;
        k: A;
        topic?:A;
        p: A;
        ttl?: N;
        ts?: N;
        _ack?: B;
        _adapter?: SIG_BUS_Adapter;
        priority?: S;
        tags?: S[];
        streamId?: S;
        sessionId?: A;
        token?: A;
        binary?: 'signal_save_value' | 'signal' | true | false | S;
        error?: A
        adapter_id?: A
        cross_cse_ngin_connect_adapter_id?: A
        cross_app_adapter_adapter_id?: A
        type?: S
        boundary?: SIG_BUS_Boundary
        transport?: 'soa' | 'particle'
    }
    interface SIG_BUS_BackpressureConfig {
        maxQueueSize?: N;
        slowConsumerThresholdMs?: N;
        throttleMs?: N;
    }
    interface SIG_BUS_Schema {
        validate(p: U): B;
        coerce?(p: U): U;
    }
    interface SIG_BUS_rtPermissions {
        allow?: S[];
        deny?: S[];
        read?: S[];
        write?: S[];
    }
    interface SIG_BUS_rtInfo {
        rt: S;
        handlers: N;
        adapters: S[];
        middleware: N;
        messageCount: N;
        tags: S[];
    }
    interface SIG_BUS_AdapterMetrics {
        id: S;
        latencyMs: N;
        failureRate: N;
        throughputPerSec: N;
        healthy: B;
        disabled: B;
    }
    interface SIG_BUS_RouteRule {
        name: S;
        match: (msg: SIG_BUS_Message | SIG_BUS_CBORValue) => B;
        targetAdapters?: S[];
        targetrts?: S[];
    }
    interface SIG_BUS_Transform {
        outgoing?(msg: SIG_BUS_Message | SIG_BUS_CBORValue): SIG_BUS_Message | Promise<SIG_BUS_Message>;
        incoming?(msg: SIG_BUS_Message | SIG_BUS_CBORValue): SIG_BUS_Message | Promise<SIG_BUS_Message>;
    }
    interface SIG_BUS_EncryptionConfig {
        rt?: S;
        adapterId?: S;
        secret?: S;
        publicKey?: S;
        algorithm?: S;
    }
    interface SIG_BUS_DurableOptions {
        subscriberId: S;
        fromOffset?: N;
        fromTimestamp?: N;
        tags?: S[];
    }
    interface SIG_BUS_ReplayOptions {
        rt: S;
        fromOffset?: N;
        toOffset?: N;
        fromTimestamp?: N;
        toTimestamp?: N;
        tags?: S[];
    }
    interface SIG_BUS_GroupOptions {
        enabled?: B;
        middleware?: (msg: SIG_BUS_Message | SIG_BUS_CBORValue) => B | V;
    }
    interface SIG_BUS_SendOptions {
        ttl?: N;
        priority?: SIG_BUS_Priority;
        tags?: S[];
        metadata?: Record<S, U>;
        expectReply?: B;
    }
    interface SIG_BUS_BatchItem {
        rt: S;
        p: Record<S, U>;
    }
    interface SIG_BUS_HandlerContext {
        rt: S;
        adapter?: SIG_BUS_Adapter;
        meta: SIG_BUS_MessageMeta;
    }
    interface SIG_BUS_ClusterConfig {
        nodeId: S;
        peers: S[];
    }
    interface SIG_BUS_WebRTCAdapterOptions {
        signalingAdapter: SIG_BUS_Adapter;
        peerId: S;
        iceServers?: RTCIceServer[];
    }
    interface SIG_BUS_MessageMeta {
        id?: S;
        ttl?: N;
        priority?: SIG_BUS_Priority;
        tags?: S[];
        timestamp?: N;
        streamId?: S;
        [key: S]: U;
    }
    interface SIG_BUS_CompressionConfig {
        rt?: S;
        adapterId?: S;
        algorithm: S;
    }



    interface RITUAL_OF_SOULS_SEND_FN {
        (ppayload: U, k: S, sl?: S, ms?: S, rt?: S, ttl?: N, chain?: CHAIN, binary?: B, adapter?:S): Promise<U>
        broadcast(p: U, k: S, sl?: S, ms?: S, rt?: S, ttl?: N, binary?: B, adapter?:S): Promise<U>
        broadcastState(state: A, k: S, sl: S  , ms: S, rt: S, chain?: CHAIN): A
        bare_metal(p: A, k: S, sl?: S, ms?: S, rt?: S, chain?: CHAIN, adapter?: S, binary?:B ): Promise<U>
        emit(k: S, p: A, sl?: S, ms?: S, rt?: S): V
    }
    interface SIG_BUS_SUB_FN {
        (handler: A, k: S, sl?: S, ms?: S, rt?: S, boundary?: Boundary): A
        hot(handler: CSEHandler, k: A, s: S , m: S , r: S)
        subscribe(handler: (d: U) => MaybePromise<V>, quad: S, trip: S, sub: S, ch: S,): A
    }

    interface SIG_BUS_SEND_FN {
        <T =A>(p: U, k: A, s?: S, m?: S, r?: S, ttl?: N, chain?: CHAIN, binary?: B, adapter?:S): T
        bare_metal<T = A>(p: A, k: S, s?: S, m?: S, r?: S, chain?: CHAIN, adapter?: S, binary?:B ): T
        broadcast(p: U, k: S, s?: S, m?: S, r?: S, ttl?: N, binary?: B, adapter?:S): A
        broadcastState(state: A, k: S, s: S  , m: S, r: S, chain?: CHAIN): A
        emit(k: S, p: A, s?: S, n?: S, r?: S): V
    }
    var send:SIG_BUS_SEND_FN
    interface JEDI_SUB_FN {
        (handler: A, k: S, s?: S, m?: S, r?: S, boundary?: Boundary): A 
        subscribe(handler: (d: U) => MaybePromise<V>, quad: S, trip: S, sub: S, ch: S,): A
    }
    var sub:JEDI_SUB_FN
    interface ATOM_FN {
        <T = A>(v: T, key?: SignalKey, s?: S, m?: S, r?: S, options?: SignalOptions): T;
    }

    interface SIGNAL_FN {
        <T = A>(v: T): T;
    }

    var atom: ATOM_FN;
    var signal: SIGNAL_FN;

    interface SIG_BUS_BOUNDARY_FN {
        register(k: S, sl?: S, ms?: S, rt?: S, boundary?: Boundary): A
        probe<T = A>(p: U, k: S, sl?: S, ms?: S, rt?: S, boundary?: Boundary): A
        same_app(k: S, sl?: S, ms?: S, rt?: S): A
        same_node(k: S, sl?: S, ms?: S, rt?: S): A
        cross_node(k: S, sl?: S, ms?: S, rt?: S): A
        sub_poll(k: S, sl?: S, ms?: S, rt?: S): A

    }
    interface SIG_BUS_CELL_FN {
        <T = A>(k: S, sl?: S, ms?: S, rt?: S, chain?: 'chain' | 'rechain', v?: T): A
        send<T = A>(p: U, k: S, sl?: S, ms?: S, rt?: S, chain?: 'chain' | 'rechain'): A
        cell<T = A>(k: S, sl?: S, ms?: S, rt?: S, type?: 'waitFor' | 'sub' | 'cell', chain?: 'chain' | 'rechain', v?: T): A
        crdt<T = A>(k: S, sl?: S, ms?: S, rt?: S, chain?: 'chain' | 'rechain', v?: T): A
    }



    interface SIG_BUS_DEPLUX_FN {
        (k: S, sl?: S, ms?: S, rt?: S, opts?: { windowSize?: N; livenessId?: S; }, type?: S): A;
        async<TUp = A, TDown = A>(...args: [...QD, opts?: { windowSize?: N }]): A;
        solo(readConfig: { k: S; sl?: S; ms?: S; rt?: S },
            writeConfig: { k?: S; sl?: S; ms?: S; rt?: S }
        ): { sub: ReadableStream; send: WritableStream }
        open(...args: [opts: A, ...QD,]): A
        sx(...args: [...QD, opts: A]): A
    }
    interface DUPLEX_HANDLER_FN {
        <TUp = A, TDown = A>(handlerFn: (data: TUp, stream: A) => V | P<A>, k: S, sl?: S, ms?: S, rt?: S, opts?: { windowSize?: N; }, type?: 'default' | 'sync' | 'stream-relay' | 'rate-limited' | 'fan-out' | 'priority' | 'transactional' | 'presence' | 'authority' | 'multicast' | 'partitioned' | 'batch' | 'filtered' | 'idempotent' | 'checkpoint' | 'transform'): A;

        async<TUp = A, TDown = A>(handlerFn: (data: TUp, stream: DuplexStream<TDown, TUp>) => V | P<A>, k: S, sl?: S, ms?: S, rt?: S, opts?: { windowSize?: N }): A;
    }
    interface SHADOW_FN {
        <T = A>(
            v: T | (() => T),
            key: S,
            sl?: S | UD,
            ms?: S | UD,
            rt?: S | UD,
        ): {
            get: () => T;
            set: (value: T | ((prev: T) => T)) => V;
            subscribe: (fn: (value: T) => V) => () => V;
            destroy: () => V;
            exists: () => B;
        };

        use<T>(
            v: T | (() => T),
            key: S,
            sl?: S | UD,
            ms?: S | UD,
            rt?: S | UD,
        ): readonly [T, (value: T | ((prev: T) => T)) => V];

        withTTL<T>(
            v?: T | (() => T),
            k?: S | UD,
            sl?: S | UD,
            ms?: S | UD,
            rt?: S | UD,
            ttlMs?: N,
        ): {
            get: () => T | null;
            set: (value: T | ((prev: T) => T)) => V;
            subscribe: (fn: (value: T | null) => V) => () => V;
            refresh: () => V;
            destroy: () => V;
            exists: () => B;
            getTimeRemaining: () => N;
        };

        batch<T extends Record<S, A>>(
            v: T,
            options?: { debounceMs?: N },
            key?: S | UD,
            sl?: S | UD,
            ms?: S | UD,
            rt?: S | UD,
        ): {
            get: () => T;
            set: (updates: Partial<T> | ((prev: T) => Partial<T>)) => V;
            subscribe: (fn: (value: T) => V) => () => V;
            flush: () => V;
        };
    }
    interface PORTAL_FN {
        (k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD): A;
        use(v?: A, k?: SU, sl?: S, ms?: S, rt?: S): A;
        crdt(v?: A, k?: SU, sl?: S, ms?: S, rt?: S, trigger_render?: B, nodeId?: A): A;
        umbrella(v: Record<S, A> | UD, k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, trigger_render?: B): A;
        effect(effect: () => V | (() => V), k: S, sl?: S | UD, ms?: S | UD, rt?: S | UD, deps?: A[]): V;
        context: {
            (v: Record<S, A>, k: S, sl: S, ms: S, rt: S, trigger_render: B): A;
        };
        state: {
            (v?: A, k?: SU, sl?: S, ms?: S, rt?: S): A;
            use(v?: A, k?: SU, sl?: S, ms?: S, rt?: S, trigger_render?: B): A;
        };
        store: {
            (v?: A | (() => A), key?: S | UD, sl?: S | UD, ms?: S | UD, rt?: S | UD): A;
            use(v?: A | (() => A), key?: S | UD, sl?: S | UD, ms?: S | UD, rt?: S | UD, trigger_render?: B): A;
        };
    }
    // #endregion
    // #region ══ HADRON COLLIDER ════════════════════════════════════════════════════════════════════


    interface TransportRoute {
        peer: PeerRegistryEntry
        outbound: RING_BUFFER
        inbound?: RING_BUFFER
    }

    interface SharedDepotBuffer {
        /** The underlying unmapped shared memory block */
        buffer: SharedArrayBuffer;
        /** Atomic byte index where the producer writes next */
        writeHead: Int32Array;
        /** Atomic byte index where the consumer reads next */
        readHead: Int32Array;
        /** Mutex state indicator for high-contention spin-locks */
        atomicLock: Int32Array;
        /** Storage region for serialized binary p frames */
        storage: Uint8Array;
    }
    interface HadronColliderEngine {
        /** Runs a single pass over the buffer/ring */
        pass(): V;
        /** Returns current buffer pressure or queue utilization as a 0.00 - 1.00 ratio */
        getLoadFactor(): N;
        // flushMutations(): V;

    }
    interface HadronBatchItem {
        pid: Pid;
        x?: N;
        y?: N;
        val: N;
    }
    interface HadronBatchItem {
        pid: Pid;
        x?: N;
        y?: N;
        val: N;
    }
    interface ScopeComponents {
        r: N;
        m: N;
        s: N;
    }
    type CBORValue = UD | null | B | N | S | Uint8Array | CBORValue[] | { [k: S]: CBORValue }
    type SubscriberCallback = (value: A) => V;
    type ListenerFn = (pid: N, value: N) => V;
    type Pid = N;

    type SIG_BUS_AdapterSendPayload = | SIG_BUS_Message | Uint8Array | A;

    interface SIG_BUS_Adapter {
        id?: S;
        send(msg: SIG_BUS_AdapterSendPayload): V;
        onMessage(handler: (msg: SIG_BUS_AdapterSendPayload) => V): () => V;
        onConnect?(handler: () => V): V;
        onDisconnect?(handler: () => V): V;
    }
    type SIG_BUS_Boundary = 'same-app' | 'same-node' | 'cross-node'

    interface SIG_BUS_Message {
        id: S  | U32;
        r: S;
        m?: S;
        s?: S;
        k?: S;
        topic?: S;
        p: U;
        ttl?: N;
        ts?: N;
        _ack?: B;
        _adapter?: SIG_BUS_Adapter;
        priority?: A;
        tags?: S[];
        streamId?: S;
        sessionId?: A;
        token?: A;
        binary?: 'signal_save_value' | 'signal' | true | false | S;
        error?: A
        adapter_id?: A
        cross_cse_ngin_connect_adapter_id?: A
        cross_app_adapter_adapter_id?: A
        type?: S
        boundary?: SIG_BUS_Boundary
    }
    interface PeerRegistryEntry {
        addressSpaceId: N;
        boundaryType: 'INTRA_THREAD' | 'WORKER' | 'PROCESS' | 'NETWORK';
        sharedBufferRef?: SharedArrayBuffer;
        writeHeadOffset?: N;
        readHeadOffset?: N;
        k?: S;
        sl?: S;
        ms?: S;
        rt?: S;
    }

    interface HeaderViews {
        headerInt32: Int32Array; // Views first 16 bytes as Int32 slots
        payloadUint8: Uint8Array; // Views from byte 64 to end of buffer
        capacity: N;
    }
    interface ScopeComponents {
        rt: N;
        ms: N;
        sl: N;
    }
    interface DecodedFrame {
        topicId: N;
        topicName: S | UD;
        p: Uint8Array;
    }
    interface SharedDepotBuffer {
        /** The underlying unmapped shared memory block */
        buffer: SharedArrayBuffer;
        /** Atomic byte index where the producer writes next */
        writeHead: Int32Array;
        /** Atomic byte index where the consumer reads next */
        readHead: Int32Array;
        /** Mutex state indicator for high-contention spin-locks */
        atomicLock: Int32Array;
        /** Storage region for serialized binary p frames */
        storage: Uint8Array;
    }
    interface PeerRegistryEntry {
        addressSpaceId: N;
        boundaryType: 'INTRA_THREAD' | 'WORKER' | 'PROCESS' | 'NETWORK';
        sharedBufferRef?: SharedArrayBuffer;
        writeHeadOffset?: N;
        readHeadOffset?: N;
        k?: S;
        sl?: S;
        ms?: S;
        rt?: S;
    }
    interface TransformTier {
        name: S;
        /** how many transforms in this tier run concurrently per batch */
        concurrency: N;
        /** max transforms drained into a single batch flush for this tier */
        batch: N;
        /** the work */
        run: (input: { rt: ChannelKey; bytes: Uint8Array; seq: N }) => Promise<Uint8Array> | Uint8Array | A;
    }
    interface RouteTarget {
        topic?: S;
        addressSpaceId?: S;
        processId?: S;
        isLocal?: B;
        sl_reg: S
        ms_reg: S
        gb_reg: S
    }

    type SamplingRate = {
        numerator: N;
        denominator: N;
    };
    type ProbabilisticSampling = {
        version: 1;
        algorithm: 'fnv1a64';
        seed: S;
        rate: SamplingRate;
        namespace: S;
    };
    type ProbabilisticOptions<T> = {
        // Exact probability as a fraction. { numerator: 1, denominator: 10 } means keep approximately 10%. Avoids float ambiguity across runtimes.
        rate: SamplingRate;
        // Shared deterministic seed. Same seed + namespace + key = same sampling decision.
        seed: S | N;

        // Stable identity of the logical item. Must remain unchanged across producer, consumer, retries, replay, reconnects, and process restarts. Prefer event ID / record ID / trace ID.
        key: (chunk: T, index: N) => S;
        // Separates unrelated sampled populations that happen to use the same seed. Keep this constant on both ends.

        namespace?: S;
    };
    type ProbabilisticSender = (
        p: A,
        onChunk: (chunk: A) => V,
        k: S,
        sl?: SU,
        ms?: SU,
        rt?: SU,
        chain?: 'chain' | 'rechain',
        binary?: B,
    ) => P<A>;
    type SamplingEnvelope<T> = {
        __probabilistic: ProbabilisticSampling;
        data: T;
    };
    type SamplingConfig = {
        version?: 1;
        rate: N; // 0..1
        seed: S | N;
        algorithm?: 'fnv1a64';
    };
    // #endregion
    // #region ══ INDEXED_DB KV ════════════════════════════════════════════════════════════════════
    type Subscriber<T> = (value: T) => V
    type Selector<T, S> = (value: T) => S
    type ConflictResolver<T> = (local: T, remote: T, meta: {
        key: S
        localHlc: S
        remoteHlc: S
        nodeId: S
    }) => T

    interface EntryRecord<T = U> {
        value: T
        hlc: S
        nodeId: S
        ts: N
    }

    interface IndexedDbOptions {
        dbName?: S
        storeName?: S
        version?: N
        ttlMs?: N
        nodeId?: S
        /** Optional bridge into your hook-system's flush scheduler. */
        onFlush?: (fn: () => V) => V
        /** Optional error sink. Defaults to reportError. */
        onError?: (err: U) => V
    }

    interface OpenOptions {
        dbName: S
        version: N
        upgrade?: (db: IDBDatabase, oldVersion: N, newVersion: N) => V
    }

    type Migration = (db: IDBDatabase, oldVersion: N) => V

    // ─── Internal ────────────────────────────────────────────────────────────────
    type PendingOp =
        | { kind: 'get'; key: S; resolve: (v: A) => V; reject: (e: A) => V }
        | { kind: 'put'; key: S; value: A; resolve: () => V; reject: (e: A) => V }
        | { kind: 'del'; key: S; resolve: () => V; reject: (e: A) => V }
        | { kind: 'has'; key: S; resolve: (v: B) => V; reject: (e: A) => V }
        | { kind: 'keys'; resolve: (v: S[]) => V; reject: (e: A) => V }
        | { kind: 'clear'; resolve: () => V; reject: (e: A) => V }
        | { kind: 'cursor'; range: IDBKeyRange | UD; resolve: (v: [S, A][]) => V; reject: (e: A) => V }
    // #endregion
    // #region ══ RIFTS ════════════════════════════════════════════════════════════════════
    type RiftListener<T> = (value: T) => V;
    interface RiftLike<T = A> {
        readonly createdAt: N;
        readonly openedAt: N | UD;
        wait(timeoutMs?: N): T// Promise<T>;
        // wait(timeoutMs?: N): Promise<T>;
        open(value?: T): V;
        reset(): V;
        claim(): B;
        onOpen(listener: RiftListener<T>): () => V;
        readonly isOpen: B;
        readonly isClaimed: B;
        readonly current: T | UD;
    }
    interface RiftRecord<T> {
        opened: B;
        claimed: B;
        value: T | UD;
        createdAt: N;
        openedAt: N | UD;
    }
    // #endregion
    // #region ══ DRS ════════════════════════════════════════════════════════════════════
















    type CompiledGate = {
        name: S;
        priority: N;
        matcher: GateMatcher<TPayload>;
        handler: GateHandler<TPayload>;
        index: N;
    };
    type KnowledgeEntry = {
        key: S;
        value: A;
        confidence: N; // 0-1
        source: S;
        timestamp: N;
        tags: S[];
    };
    type SagaStep = {
        name: S;
        execute: (ctx: TContext) => Promise<Partial<TContext>>;
        compensate: (ctx: TContext) => P<A>;
    };
    type Stage = {
        name: S;
        handler: (data: T) => T | Promise<T>;
        errorHandler?: (err: Error, data: T) => T;
    };
    type AnchorState = {
        data: TState;
        sequence: N;
        lastSnapshotTimestamp: N;
        walBuffer: Array<{ op: 'set' | 'merge'; p: A; seq: N; timestamp: N }>;
    };
    type StormState = {
        stream: TEvent[];
        detectedPatterns: Array<{ pattern: S; triggeredAt: N; sampleCount: N }>;
    };
    type FabricRecord = {
        key: S;
        value: T;
        partitionKey: S;
        version: N;
        vectorClock: Record<S, N>;
        nodeId: S;
        timestamp: N;
    };
    type JugglerNode = {
        nodeId: S;
        weight: N;
        activeConnections: N;
        failures: N;
        status: 'active' | 'quarantined' | 'dead';
        lastHeartbeat: N;
    };
    type RegistryName = 'channels' | 'sub_channels' | 'trip_channels' | 'quad_channels';

    type MultiSubEntry = {
        ms: S;
        handlerCount: N;
    };

    type ChannelEntry = {
        registry: RegistryName;
        rt: S;
        nativeSubCount: N;
        multiSubChannels: MultiSubEntry[];
    };
    type VesselRequest = {
        vesselId: S;
        nodeId: S;
        priority: N;        // Higher integers execute first
        p: U;
        arrivedAt: N;
        expiresAt: N;
    };
    type Frame = { __drs_frame: 1; k: N; v: A; from: symbol | S };
    type Ack = { __drs_ack: 1; k: N; from: symbol | S };
    type CELL_MODE = "waitFor" | "sub" | "cell" | "none";
    type CELL_CHAIN = "chain" | "rechain";
    type CELL_ARGS = [
        k: S,
        v?: A,
        sl?: SU,
        ms?: SU,
        rt?: SU,
        type?: CELL_MODE,
        chain?: CELL_CHAIN
    ];
    type CellSetter<T> = (next: T | ((previous: T) => T)) => V;
    // #endregion
    // #region ══ QUEUE ════════════════════════════════════════════════════════════════════
    type TierTask<T = U> = {
        label: S;
        task: () => Promise<T>;
        resolve: (value: T | UD) => V;
        reject: (reason?: U) => V;
    };

    type TierDef = {
        name?: S,
        concurrent?: N;
        retry?: N;
        timeout?: N;
        on_success?: () => V;
        on_error?: () => V;
        execute?: () => A;
        http_req?: Record<S, {
            url: S;
            method: S;
            headers?: Record<S, S>;
            body?: A;
            on_success?: () => V;
            on_error?: () => V;
        }>;
    };

    type TierOptions = {
        concurrent?: N;
        retry?: N;
        timeout?: N;
    };

    type UseQueueResult<T = A> = {
        add: (task: () => Promise<T>, options?: { priority?: N }) => Promise<T>;
        results: T[];
        errors: Error[];
        pending: N;
        active: N;
        size: N;
        isEmpty: B;
        isRunning: B;
        start: () => V;
        stop: () => V;
        clear: () => V;
        flush: () => V;
    };
    type QueueOptions = {
        concurrent?: N;
        retry?: N;
        timeout?: N;
        priority?: B;
        onError?: (error: Error, task: A) => V;
        onComplete?: (result: A) => V;
        onChange?: () => V;
    };
    type QueueTask<T> = {
        fn: () => Promise<T>;
        priority?: N;
        resolve: (value: T) => V;
        reject: (error: Error) => V;
        label?: S;
    };
    type QueueFunction = {
        <T>(taskOrTasks: (() => Promise<T>) | (() => Promise<T>)[], taskOptions?: { priority?: N; label?: S }): Promise<T | T[]>;
        start: () => V;
        stop: () => V;
        clear: () => V;
        flush: () => V;
        onIdle: () => P<A>;
        peek: () => QueueTask<A> | UD;
        peekAll: () => QueueTask<A>[];
        getRunning: () => QueueTask<A>[];
        removeAt: (index: N) => V;
        moveUp: (index: N) => V;
        moveDown: (index: N) => V;
        moveToNext: (index: N) => V;
        moveToLast: (index: N) => V;
        setOptions: (opts: Partial<QueueOptions>) => V;
        readonly size: N;
        readonly isEmpty: B;
        readonly isRunning: B;
        readonly isPausedState: B;
        readonly pending: N;
        readonly active: N;
    };
    // #endregion
    // #region ══ PCRXDB ════════════════════════════════════════════════════════════════════
    // #endregion
    // #region ══ INDEXED DB ════════════════════════════════════════════════════════════════════
    // #endregion
    // #region ══ KVDB ════════════════════════════════════════════════════════════════════
    type BrowserStorageType = 'localStorage' | 'indexedDB'

    interface NginSelectorOptions {
        globalStoragePath?: S
        workspaceStoragePath?: S
        kvNamespace?: A
        browserStorage?: BrowserStorageType
        ttlDays?: N
        dbName?: S
        workerThread?: import('worker_threads').Worker
        electronMain?: { ipcMain: { on: Function; handle: Function; removeHandler: Function }; win: { webContents: { send: Function; once: Function } } }
        electronRenderer?: { ipcRenderer: { on: Function; send: Function; invoke: Function; removeListener: Function } }
        nativeMessagingPort?: { onMessage: { addListener: Function }; onDisconnect: { addListener: Function }; postMessage: Function }
        custom_file_writer?: B
    }
    // tyr/core/types.ts


    // ─── Branded primitives ───────────────────────────────────────────────────────

    declare const __brand: unique symbol
    type Brand<T, B> = T & { [__brand]: B }

    type UserId = Brand<S, 'UserId'>
    type TenantId = Brand<S, 'TenantId'>
    type OrgId = Brand<S, 'OrgId'>
    type TeamId = Brand<S, 'TeamId'>
    type SessionId = Brand<S, 'SessionId'>
    type DeviceId = Brand<S, 'DeviceId'>
    type CredId = Brand<S, 'CredId'>
    type RoleId = Brand<S, 'RoleId'>
    type PolicyId = Brand<S, 'PolicyId'>
    type TokenId = Brand<S, 'TokenId'>
    type KeyId = Brand<S, 'KeyId'>
    type FlowId = Brand<S, 'FlowId'>
    type RequestId = Brand<S, 'RequestId'>
    type AuditId = Brand<S, 'AuditId'>

    // ─── Identity ─────────────────────────────────────────────────────────────────

    type ActorKind = 'user' | 'service' | 'bot' | 'system' | 'impersonator'

    interface Actor {
        id: UserId
        tenantId: TenantId | null
        orgId: OrgId | null
        kind: ActorKind
        roles: RoleId[]
        meta: Record<S, U>
    }

    interface User {
        id: UserId
        tenantId: TenantId | null
        email: S
        emailVerified: B
        phone: S | null
        phoneVerified: B
        displayName: S | null
        avatarUrl: S | null
        createdAt: N
        updatedAt: N
        deletedAt: N | null
        locked: B
        meta: Record<S, U>
    }

    interface Account {
        id: S
        userId: UserId
        provider: CredentialType
        providerId: S
        createdAt: N
    }

    // ─── Credentials ──────────────────────────────────────────────────────────────

    type CredentialType =
        | 'password'
        | 'passkey'
        | 'totp'
        | 'otp_email'
        | 'otp_sms'
        | 'magic_link'
        | 'oauth'
        | 'saml'
        | 'oidc'
        | 'api_key'
        | 'service_token'
        | 'recovery_code'

    interface Credential {
        id: CredId
        userId: UserId
        type: CredentialType
        secret: S
        createdAt: N
        expiresAt: N | null
        meta: Record<S, U>
    }

    // ─── Sessions ─────────────────────────────────────────────────────────────────

    type SessionMode = 'cookie' | 'server' | 'hybrid'

    interface SessionData {
        _id: SessionId
        _userId: UserId | null
        _tenantId: TenantId | null
        _created: N
        _accessed: N
        _fingerprint: S | UD
        _csrf: S | UD
        _flash: Record<S, U>
        [key: S]: U
    }

    interface Session {
        id?: SessionId
        get?<T = U>(key: S): T | UD
        set?(key: S, value: U): V
        unset?(key: S): V
        flash?(key: S, value: U): V
        getFlash?<T = U>(key: S): T | UD
        rotate?(): V
        invalidate?(): V
        csrf?(): S
        readonly data?: Record<S, U>
        readonly isNew?: B
        readonly isInvalidated?: B
        readonly userId?: UserId | null
        readonly tenantId?: TenantId | null
           status?: DocLifecycleStatus;
    state?: { acl: Record<string, DocRole> };
    canonicalVersion?: number;
    raft?: Observable<T>;
    canEdit?(userId: string): boolean;
    grantAccess?(userId: string, role: DocRole): void;
    revokeAccess?(userId: string): void;
    archive?(): void;
    markCanonical?(version: number): void;
    dispatch?(command: any): void;
    }

    interface CommitResult {
        headers: Headers
    }

    // ─── Device ───────────────────────────────────────────────────────────────────

    interface Device {
        id: DeviceId
        userId: UserId
        fingerprint: S
        trusted: B
        lastSeenAt: N
        createdAt: N
        meta: Record<S, U>
    }

    // ─── Roles & permissions ──────────────────────────────────────────────────────

    interface Role {
        id: RoleId
        tenantId: TenantId | null
        name: S
        inherits: RoleId[]
        perms: S[]
    }

    interface Permission {
        action: S
        resource: S
        effect: 'allow' | 'deny'
    }

    interface Policy {
        id: PolicyId
        tenantId: TenantId | null
        name: S
        statements: PolicyStatement[]
    }

    interface PolicyStatement {
        effect: 'allow' | 'deny'
        actions: S[]
        resources: S[]
        conditions: PolicyCondition[]
    }

    interface PolicyCondition {
        key: S
        operator: 'eq' | 'neq' | 'gt' | 'lt' | 'gte' | 'lte' | 'in' | 'nin'
        value: U
    }

    interface PolicyEvalInput {
        actor: Actor
        action: S
        resource: PolicyResource
        env: Record<S, U>
    }

    interface PolicyResource {
        type: S
        id: S
        ownerId: UserId | null
        attrs: Record<S, U>
    }

    interface PolicyEvalResult {
        allowed: B
        reason: S
        matched: PolicyId | null
    }

    // ─── Tenants & orgs ───────────────────────────────────────────────────────────

    interface Tenant {
        id: TenantId
        name: S
        createdAt: N
        meta: Record<S, U>
    }

    interface Org {
        id: OrgId
        tenantId: TenantId
        name: S
        createdAt: N
        meta: Record<S, U>
    }

    interface Team {
        id: TeamId
        orgId: OrgId
        tenantId: TenantId
        name: S
        createdAt: N
        meta: Record<S, U>
    }

    interface OrgMembership {
        userId: UserId
        orgId: OrgId
        roles: RoleId[]
        joinedAt: N
    }

    // ─── Flows ────────────────────────────────────────────────────────────────────

    type FlowStatus = 'pending' | 'running' | 'completed' | 'failed' | 'cancelled'

    interface FlowContext {
        flowId: FlowId
        stepId: S
        sessionId: SessionId
        actor: Actor | null
        tenantId: TenantId | null
        data: Record<S, U>
        meta: Record<S, U>
    }

    interface FlowResult {
        completed: B
        nextStep: S | null
        ctx: FlowContext
        error: TyrError | null
    }

    // ─── Crypto keys ──────────────────────────────────────────────────────────────

    interface CryptoKey_ {
        id: KeyId
        raw: S
    }

    type EncryptionMode = 'sealed' | 'signed'

    // ─── Events ───────────────────────────────────────────────────────────────────

    type TyrEventType =
        | 'user.created'
        | 'user.updated'
        | 'user.deleted'
        | 'user.locked'
        | 'user.unlocked'
        | 'session.created'
        | 'session.rotated'
        | 'session.invalidated'
        | 'session.expired'
        | 'auth.success'
        | 'auth.failure'
        | 'auth.mfa.required'
        | 'auth.mfa.success'
        | 'auth.mfa.failure'
        | 'auth.stepup.required'
        | 'auth.stepup.success'
        | 'flow.started'
        | 'flow.completed'
        | 'flow.failed'
        | 'policy.allowed'
        | 'policy.denied'
        | 'credential.created'
        | 'credential.rotated'
        | 'credential.revoked'
        | 'device.trusted'
        | 'device.revoked'
        | 'org.member.added'
        | 'org.member.removed'

    interface TyrEvent<P = U> {
        id: S
        type: TyrEventType
        tenantId: TenantId | null
        actorId: UserId | null
        sessionId: SessionId | null
        p: P
        ts: N
    }

    // ─── Errors ───────────────────────────────────────────────────────────────────

    type TyrErrorCode =
        | 'UNAUTHORIZED'
        | 'FORBIDDEN'
        | 'NOT_FOUND'
        | 'CONFLICT'
        | 'VALIDATION'
        | 'EXPIRED'
        | 'RATE_LIMITED'
        | 'CRYPTO_FAILURE'
        | 'STORAGE_FAILURE'
        | 'FLOW_FAILURE'
        | 'POLICY_FAILURE'
        | 'SESSION_INVALID'
        | 'SESSION_EXPIRED'
        | 'CSRF_INVALID'
        | 'FINGERPRINT_MISMATCH'
        | 'CREDENTIAL_INVALID'
        | 'ACCOUNT_LOCKED'
        | 'MFA_REQUIRED'
        | 'UNKNOWN'

    interface TyrError {
        code: TyrErrorCode
        message: S
        detail: Record<S, U>
        cause: U
    }
    interface FingerprintConfig {
        enabled: B
        signals: ('ip' | 'ua')[]
        tolerance: N           // 0–1, fraction of chars that may differ
    }

    interface CsrfConfig {
        enabled: B
        mode: 'double-submit' | 'signed'
        fieldName: S
        headerName: S
    }

    // ─── Storage (tyr-internal adapter shape) ─────────────────────────────────────

    interface TyrStorageAdapter {
        get(key: S): Promise<U>
        set(key: S, value: U): P<A>
        delete(key: S): P<A>
        getMemory(key: S): Promise<U>
        setMemory(key: S, value: U): P<A>
        deleteMemory(key: S): P<A>
        expire(key: S, ms: N): P<A>
        watch(key: S, handler: (value: U) => V): Promise<U>
    }
    interface LifetimeConfig {
        absolute: N   // seconds
        idle: N   // seconds
    }
    interface CookieConfig {
        name: S
        path: S
        domain?: S
        secure: B
        httpOnly: B
        sameSite: 'strict' | 'lax' | 'none'
    }
    interface HybridConfig {
        cookieFields: S[]
    }
    interface EncryptionConfig {
        enabled: B
        mode: 'sealed' | 'signed'
    }
    interface RotationConfig {
        enabled: B
        onEveryRequest: B
    }
    interface SessionManagerConfig {
        mode: SessionMode
        keys: CryptoKey_[]
        storage?: TyrStorageAdapter
        events?: A
        lifetime?: Partial<LifetimeConfig>
        cookie?: Partial<CookieConfig>
        hybrid?: Partial<HybridConfig>
        encryption?: Partial<EncryptionConfig>
        fingerprint?: Partial<FingerprintConfig> | B
        csrf?: Partial<CsrfConfig> | B
        flash?: B
        rotation?: Partial<RotationConfig> | B
    }
    // ─── CSE shape (subset tyr depends on) ───────────────────────────────────────

    interface TyrCSE {
        send(rt: S, p: U, ttl?: N): Promise<U>
        sub(rt: S, handler: (p: U) => V): () => V
        stream(rt: S, p: U, onChunk: (chunk: S, done: B) => V): P<A>
        scope(prefix: S): TyrCSEScope
    }

    interface TyrCSEScope {
        send(rt: S, p: U, ttl?: N): Promise<U>
        sub(rt: S, handler: (p: U) => V): () => V
        scope(subprefix: S): TyrCSEScope
    }

    // ─── Top-level config shape (referenced across modules) ───────────────────────

    interface TyrConfig {
        storage: TyrStorageAdapter
        staff: TyrCSE
        keys: CryptoKey_[]
        tenantId: TenantId | null
    }

    // #endregion
    // #region ══ RDB ════════════════════════════════════════════════════════════════════
    // ─── FIELD TYPES ─────────────────────────────────────────────────────────────
    type FieldKind =
        | 'uuid'
        | 'S'
        | 'N'
        | 'B'
        | 'timestamp'
        | 'json'
        | 'enum'
    interface FieldDef {
        kind: FieldKind
        primaryKey: B
        unique: B
        nullable: B
        defaultValue: 'now' | 'uuid' | U | UD
        enumValues?: S[]
        validator?: (value: U) => B | S
        computed?: (row: Record<S, U>) => U
    }
    interface TableDef<
        TName extends S = S,
        TSchema extends Record<S, FieldDef> = Record<S, FieldDef>
    > {
        name: TName
        schema: TSchema
        relations: RelationDef[]
        indexes: IndexDef[]
        rls?: RLSPolicy
        softDelete: B
        audit: B
    }
    type AllRelationshipTypes = | 'one-to-one' | 'one-to-many' | 'many-to-one' | 'many-to-many' | 'self-referencing' | 'unary' | 'binary' | 'ternary' | 'n-ary' | 'identifying' | 'non-identifying' | 'mandatory' | 'optional' | 'strong' | 'weak' | 'disjoint' | 'overlapping' | 'polymorphic' | 'many-to-A' | 'bidirectional' | 'one-way' | 'primary' | 'secondary' | 'generalized' | 'simple' | 'complex' | 'recursive' | 'hierarchical' | 'network' | 'associative' | 'composite' | 'aggregation' | 'composition' | 'inheritance' | 'specialization' | 'generalization' | 'foreign-key' | 'independent' | 'zero-to-one' | 'zero-to-many' | 'one-to-zero' | 'one-to-optional' | 'many-to-optional' | 'optional-to-one' | 'optional-to-many' | 'exclusive' | 'non-exclusive' | 'total' | 'partial' | 'referential' | 'non-referential' | 'existence-dependent' | 'existence-independent' | 'value-dependent' | 'value-independent' | 'time-dependent' | 'time-independent' | 'spatial' | 'temporal' | 'transitive' | 'intransitive' | 'symmetric' | 'asymmetric' | 'cyclic' | 'acyclic' | 'circular' | 'linear' | 'adjacency' | 'closure' | 'path' | 'distance' | 'weighted' | 'unweighted' | 'directed' | 'undirected' | 'labeled' | 'unlabeled' | 'attributed' | 'unattributed' | 'versioned' | 'unversioned' | 'audited' | 'unaudited' | 'soft-deleted' | 'hard-deleted' | 'archived' | 'active' | 'draft' | 'published' | 'pending' | 'approved' | 'rejected' | 'locked' | 'unlocked' | 'system-defined' | 'user-defined' | 'built-in' | 'custom' | 'default' | 'explicit' | 'implicit' | 'natural' | 'surrogate';

    interface RelationDef {
        type: AllRelationshipTypes;
        from: S;
        to: S;
        foreignKey: S;
        throughTable?: S;
        onDelete?: 'cascade' | 'restrict' | 'set-null' | 'no-action' | 'set-default';
        onUpdate?: 'cascade' | 'restrict' | 'no-action' | 'set-null' | 'set-default';
    }
    interface IndexDef {
        fields: S[]
        unique: B
        fullText: B
        spatial: B
    }
    // ─── ROW LEVEL SECURITY ───────────────────────────────────────────────────────
    type RLSContext = Record<S, U> & {
        userId?: S
        role?: S
    }
    type RLSRule = (ctx: RLSContext) =>
        | true
        | false
        | { field: S; op: S; value: U }
        | { field: S; op: S; value: U }[]
    interface RLSPolicy {
        read?: RLSRule
        write?: RLSRule
        delete?: RLSRule
        fields?: (ctx: RLSContext) => S[] | '*'
    }
    // ─── SCHEMA SNAPSHOT ─────────────────────────────────────────────────────────
    interface SchemaSnapshot {
        version: N
        tables: Record<S, SnapshotTable>
    }
    interface SnapshotTable {
        fields: Record<S, {
            kind: FieldKind
            primaryKey: B
            unique: B
            nullable: B
            enumValues?: S[]
        }>
        indexes: IndexDef[]
        relations: RelationDef[]
        softDelete: B
        audit: B
    }
    // ─── MIGRATION OPS ───────────────────────────────────────────────────────────
    type MigrationOp =
        | { op: 'create_table'; table: S; fields: Record<S, FieldDef>; softDelete: B; audit: B }
        | { op: 'drop_table'; table: S }
        | { op: 'add_field'; table: S; field: S; def: FieldDef }
        | { op: 'drop_field'; table: S; field: S }
        | { op: 'add_index'; table: S; index: IndexDef }
        | { op: 'drop_index'; table: S; fields: S[] }
    interface MigrationRecord {
        id: S
        version: N
        op: S
        table: S
        appliedAt: N
        checksum: S
    }
    // ─── QUERY TYPES ─────────────────────────────────────────────────────────────
    type WhereOperator =
        | '=' | '!=' | '<' | '<=' | '>' | '>='
        | 'like' | 'in' | 'not in' | 'is null' | 'is not null'

    interface WhereClause {
        field: S
        op: WhereOperator
        value: U
        conjunction: 'and' | 'or'
    }
    interface JoinClause {
        table: S
        on: [S, S]
        type: 'inner' | 'left' | 'right'
    }
    interface OrderClause {
        field: S
        dir: 'asc' | 'desc'
    }
    interface GroupClause {
        fields: S[]
        having?: WhereClause[]
    }
    interface AggregateClause {
        fn: 'count' | 'sum' | 'avg' | 'min' | 'max'
        field: S
        alias: S
    }
    interface CursorPagination {
        field: S
        value: U
        dir: 'asc' | 'desc'
        limit: N
    }
    interface SubqueryClause {
        alias: S
        plan: QueryPlan
    }
    interface QueryPlan {
        table: S
        wheres: WhereClause[]
        joins: JoinClause[]
        orders: OrderClause[]
        group?: GroupClause
        aggregates?: AggregateClause[]
        subqueries?: SubqueryClause[]
        selectedFields: S[] | '*'
        limitVal?: N
        offsetVal?: N
        cursor?: CursorPagination
        isCount: B
        isDistinct: B
        withDeleted?: B
        rlsContext?: RLSContext
    }
    // ─── STORAGE ADAPTER ─────────────────────────────────────────────────────────
    interface StorageAdapter {
        getBinary(key: S): Promise<S | null>;
        setBinary(key: S, value: S): P<A>;
        deleteBinary(key: S): P<A>;
        init(): P<A>
        close(): P<A>
        isHealthy(): Promise<B>

        getSnapshot(): Promise<SchemaSnapshot | null>
        saveSnapshot(snap: SchemaSnapshot): P<A>

        createTable(table: S, fields: Record<S, FieldDef>, softDelete: B, audit: B): P<A>
        dropTable(table: S): P<A>
        addField(table: S, field: S, def: FieldDef): P<A>
        dropField(table: S, field: S): P<A>
        createIndex(table: S, index: IndexDef): P<A>
        dropIndex(table: S, fields: S[]): P<A>

        insert(table: S, row: Record<S, U>): Promise<Record<S, U>>
        update(table: S, id: U, patch: Record<S, U>): Promise<Record<S, U>>
        delete(table: S, id: U, soft?: B): P<A>
        restore(table: S, id: U): P<A>
        upsert(table: S, row: Record<S, U>, conflictField: S): Promise<Record<S, U>>

        query(plan: QueryPlan): Promise<Record<S, U>[]>
        count(plan: QueryPlan): Promise<N>
        aggregate(table: S, aggregates: AggregateClause[], plan: QueryPlan): Promise<Record<S, U>>

        beginTransaction(): Promise<S>
        commitTransaction(txId: S): P<A>
        rollbackTransaction(txId: S): P<A>

        fullTextSearch(table: S, fields: S[], query: S): Promise<Record<S, U>[]>
        spatialSearch(table: S, field: S, lat: N, lng: N, radiusKm: N): Promise<Record<S, U>[]>

        Table(table: S): Promise<Record<S, U>[]>
        importTable(table: S, rows: Record<S, U>[], strategy: ImportStrategy): P<A>
        backup(destPath: S): P<A>

        getMigrations(): Promise<MigrationRecord[]>
        recordMigration(record: MigrationRecord): P<A>
    }
    // ─── IMPORT STRATEGY ─────────────────────────────────────────────────────────
    type ImportStrategy = 'overwrite' | 'merge' | 'skip'
    // ─── REACTIVE ────────────────────────────────────────────────────────────────
    interface Subscription {
        unsubscribe(): V
    }
    interface ReactiveQuery<T> {
        get(): T[]
        subscribe(handler: (rows: T[]) => V): Subscription
        on(busKey: S): ReactiveQuery<T>
    }
    // ─── TRANSACTION ─────────────────────────────────────────────────────────────
    interface TransactionContext {
        id: S
        insert(table: S, row: Record<S, U>): Promise<Record<S, U>>
        update(table: S, id: U, patch: Record<S, U>): Promise<Record<S, U>>
        delete(table: S, id: U): P<A>
        upsert(table: S, row: Record<S, U>, conflictField: S): Promise<Record<S, U>>
    }
    // ─── DEVTOOLS ────────────────────────────────────────────────────────────────
    interface QueryRecord {
        id: S
        plan: QueryPlan
        executionMs: N
        rowCount: N
        timestamp: N
        busKey?: S
    }
    interface HistoryEntry {
        ts: N
        table: S
        op: 'insert' | 'update' | 'delete'
        before: Record<S, U> | null
        after: Record<S, U> | null
        rt: S | null
        url: S | null
    }
    interface CompiledTable {
        fields: Record<S, FieldDef>
        relations: RelationDef[]
    }

    interface CompiledSchema {
        name: S
        dbType: S
        memory?: B
        path?: S
        tables: Record<S, CompiledTable>
    }
    // ─── ADAPTER CONFIG ───────────────────────────────────────────────────────────
    type DBType =
        | 'sqlite'
        | 'bun-sqlite'
        | 'deno-sqlite'
        | 'indexeddb'
        | 'mongodb'
        | 'mysql'
        | 'postgres'
    interface AdapterConfig {
        name: S
        dbType: DBType
        memory: B
        path?: S
        dbName?: S
        host?: S
        port?: N
        user?: S
        password?: S
        database?: S
        connectionString?: S
    }
    // ─── INFER ROW TYPE ──────────────────────────────────────────────────────────
    type InferFieldType<F extends FieldDef> =
        F['kind'] extends 'uuid' ? S :
        F['kind'] extends 'S' ? S :
        F['kind'] extends 'N' ? N :
        F['kind'] extends 'B' ? B :
        F['kind'] extends 'timestamp' ? Date :
        F['kind'] extends 'json' ? U :
        F['kind'] extends 'enum' ? S :
        never
    type InferRow<T extends TableDef> = {
        [K in keyof T['schema']]: T['schema'][K]['nullable'] extends true
        ? InferFieldType<T['schema'][K]> | null
        : InferFieldType<T['schema'][K]>
    }

    // #endregion
    // #region ══ GDB ════════════════════════════════════════════════════════════════════
    type GDBId = S

    type GDBPrimitive =
        | S
        | N
        | B
        | bigint
        | Date
        | Uint8Array
        | null

    type GDBValue =
        | GDBPrimitive
        | GDBPrimitive[]
        | GDBValue[]
        | { [key: S]: GDBValue }

    type GDBDirection = 'in' | 'out' | 'both'

    type GDBRelationshipType =
        | 'one-to-one'
        | 'one-to-many'
        | 'many-to-one'
        | 'many-to-many'
        | 'self-referencing'
        | 'unary'
        | 'binary'
        | 'ternary'
        | 'n-ary'
        | 'identifying'
        | 'non-identifying'
        | 'mandatory'
        | 'optional'
        | 'strong'
        | 'weak'
        | 'disjoint'
        | 'overlapping'
        | 'polymorphic'
        | 'many-to-A'
        | 'bidirectional'
        | 'one-way'
        | 'primary'
        | 'secondary'
        | 'generalized'
        | 'simple'
        | 'complex'
        | 'recursive'
        | 'hierarchical'
        | 'network'
        | 'associative'
        | 'composite'
        | 'aggregation'
        | 'composition'
        | 'inheritance'
        | 'specialization'
        | 'generalization'
        | 'foreign-key'
        | 'independent'
        | 'zero-to-one'
        | 'zero-to-many'
        | 'one-to-zero'
        | 'one-to-optional'
        | 'many-to-optional'
        | 'optional-to-one'
        | 'optional-to-many'
        | 'exclusive'
        | 'non-exclusive'
        | 'total'
        | 'partial'
        | 'referential'
        | 'non-referential'
        | 'existence-dependent'
        | 'existence-independent'
        | 'value-dependent'
        | 'value-independent'
        | 'time-dependent'
        | 'time-independent'
        | 'spatial'
        | 'temporal'
        | 'transitive'
        | 'intransitive'
        | 'symmetric'
        | 'asymmetric'
        | 'cyclic'
        | 'acyclic'
        | 'circular'
        | 'linear'
        | 'adjacency'
        | 'closure'
        | 'path'
        | 'distance'
        | 'weighted'
        | 'unweighted'
        | 'directed'
        | 'undirected'
        | 'labeled'
        | 'unlabeled'
        | 'attributed'
        | 'unattributed'
        | 'versioned'
        | 'unversioned'
        | 'audited'
        | 'unaudited'
        | 'soft-deleted'
        | 'hard-deleted'
        | 'archived'
        | 'active'
        | 'draft'
        | 'published'
        | 'pending'
        | 'approved'
        | 'rejected'
        | 'locked'
        | 'unlocked'
        | 'system-defined'
        | 'user-defined'
        | 'built-in'
        | 'custom'
        | 'default'
        | 'explicit'
        | 'implicit'
        | 'natural'
        | 'surrogate'

    interface GDBNode {
        id: GDBId
        labels: S[]
        properties: Record<S, GDBValue>
        createdAt: Date
        updatedAt: Date
        deletedAt?: Date | null
    }

    interface GDBRelationship {
        id: GDBId
        type: S
        from: GDBId
        to: GDBId
        properties: Record<S, GDBValue>
        createdAt: Date
        updatedAt: Date
        deletedAt?: Date | null
    }

    interface GDBNodeInput {
        id?: GDBId
        labels?: S | S[]
        properties?: Record<S, GDBValue>
    }

    interface GDBRelationshipInput {
        id?: GDBId
        type: S
        from: GDBId
        to: GDBId
        properties?: Record<S, GDBValue>
    }

    interface GDBNodeUpdate {
        labels?: S | S[]
        properties?: Record<S, GDBValue>
    }

    interface GDBRelationshipUpdate {
        type?: S
        from?: GDBId
        to?: GDBId
        properties?: Record<S, GDBValue>
    }

    interface GDBSearchOptions {
        labels?: S | S[]
        where?: Record<S, U>
        limit?: N
        offset?: N
        orderBy?: S | S[]
        order?: 'asc' | 'desc'
        distinct?: B
    }

    interface GDBTraversalOptions {
        direction?: GDBDirection
        type?: S | S[]
        labels?: S | S[]
        minDepth?: N
        maxDepth?: N
        limit?: N
        unique?: B
        includeStart?: B
    }

    interface GDBPath {
        nodes: GDBNode[]
        relationships: GDBRelationship[]
        distance: N
        weight?: N
    }

    interface GDBStats {
        nodes: N
        relationships: N
        labels: N
        relationshipTypes: N
    }

    interface GDBStatus {
        state: 'created' | 'open' | 'closed' | 'error'
        adapter: S
        nodes: N
        relationships: N
        uptime: N
    }

    interface GDBHealth {
        healthy: B
        state: GDBStatus['state']
        latency: N
        adapter: S
        errors: N
    }
    interface GDBMigration {
        id: S
        name: S
        version: N
        up: (
            db: GDBMigrationContext,
        ) => V | P<A>
        down?: (
            db: GDBMigrationContext,
        ) => V | P<A>
        createdAt?: N
    }

    interface GDBMigrationRecord {
        id: S
        name: S
        version: N
        appliedAt: N
        executionTime: N
    }
    interface GDBPersistenceOptions {
        format?:
        | 'json'
        | 'binary'
        | 'native'
        includeDeleted?: B
        includeSchema?: B
        includeIndexes?: B
        compress?: B
    }
    interface BDBConfig {
        dbPath: S;
        chunkSize?: N; // default 4MB
        dedup?: B; // default true
        verifyIntegrity?: B; // default true
        lazyLoad?: B;
        lazyLoadPrefix?: S;
        folderStructure?: B;
    }

    interface BlobReference {
        id: S;
        blobId: S;
        refKey: S;
        created_at: S;
    }
    interface GDB {
        version: N
        type: 'graph'
        name: S
        createdAt: N
        schema?: A
        nodes: GDBNodeRecord[]
        relationships: GDBRelationshipRecord[]
    }

    interface GDBBackup extends GDB {
        backupId: S
        sourceVersion?: S
    }

    interface GDBPersistence {
        (
            options?: GDBPersistenceOptions,
        ): Promise<
            GDB | Uint8Array
        >

        import(
            data:
                | GDB
                | Uint8Array,
            options?: GDBPersistenceOptions,
        ): P<A>

        backup(
            options?: GDBPersistenceOptions,
        ): Promise<GDBBackup | Uint8Array>

        restoreBackup(
            backup:
                | GDBBackup
                | Uint8Array,
            options?: GDBPersistenceOptions,
        ): P<A>
    }
    interface GDBMigrationContext {
        createNodeType: (
            type: S,
            definition: A,
        ) => V | P<A>

        dropNodeType: (
            type: S,
        ) => V | P<A>

        createRelationshipType: (
            type: S,
            definition: A,
        ) => V | P<A>

        dropRelationshipType: (
            type: S,
        ) => V | P<A>

        createIndex: (
            definition: A,
        ) => V | P<A>

        dropIndex: (
            name: S,
        ) => V | P<A>

        renameNodeType: (
            from: S,
            to: S,
        ) => V | P<A>

        renameRelationshipType: (
            from: S,
            to: S,
        ) => V | P<A>

        execute: (
            operation: A,
        ) => V | P<A>
    }

    interface GDBMigrationStatus {
        current: N
        latest: N
        pending: GDBMigration[]
        applied: GDBMigrationRecord[]
    }

    interface GDBStorage {
        getNode(id: GDBId): Promise<GDBNode | null>
        getNodes(ids: GDBId[]): Promise<GDBNode[]>
        insertNode(node: GDBNode): P<A>
        updateNode(node: GDBNode): P<A>
        deleteNode(id: GDBId): P<A>
        restoreNode(id: GDBId): P<A>
        existsNode(id: GDBId): Promise<B>

        getRelationship(id: GDBId): Promise<GDBRelationship | null>
        getRelationships(ids: GDBId[]): Promise<GDBRelationship[]>
        insertRelationship(relationship: GDBRelationship): P<A>
        updateRelationship(relationship: GDBRelationship): P<A>
        deleteRelationship(id: GDBId): P<A>
        restoreRelationship(id: GDBId): P<A>
        existsRelationship(id: GDBId): Promise<B>

        getOutgoing(nodeId: GDBId): Promise<GDBRelationship[]>
        getIncoming(nodeId: GDBId): Promise<GDBRelationship[]>

        allNodes(): Promise<GDBNode[]>
        allRelationships(): Promise<GDBRelationship[]>

        clear(): P<A>
    }

    // #endregion
    // #region ══ BDB ════════════════════════════════════════════════════════════════════
    // #endregion
    // #region ══ TDB ════════════════════════════════════════════════════════════════════
    // ============================================================
    // TemporalDB — types (mirrors RDB's types.ts structure exactly,
    // with bitemporal additions layered into each section)
    // ============================================================

    // ─── FIELD TYPES ─────────────────────────────────────────────────────────────
    type FieldKind =
        | 'uuid' | 'S' | 'N' | 'B' | 'timestamp' | 'json' | 'enum'

    interface FieldDef {
        kind: FieldKind
        primaryKey: B
        unique: B
        nullable: B
        defaultValue: 'now' | 'uuid' | U | UD
        enumValues?: S[]
        validator?: (value: U) => B | S
        computed?: (row: Record<S, U>) => U
        temporalIndex?: B   // indexed on _valid_from/_valid_to range scans, on top of RDB's normal indexing
    }

    interface TableDef<
        TName extends S = S,
        TSchema extends Record<S, FieldDef> = Record<S, FieldDef>
    > {
        name: TName
        schema: TSchema
        relations: RelationDef[]
        indexes: IndexDef[]
        rls?: RLSPolicy
        softDelete: B   // in TemporalDB, soft delete = close _valid_to; hard delete is always evict()
        audit: B         // in TemporalDB this is implied always-true — every write is inherently audited
        retention?: { keepVersions?: N; keepDuration?: S }
    }
    type AllRelationshipTypes = | 'one-to-one' | 'one-to-many' | 'many-to-one' | 'many-to-many' | 'self-referencing' | 'unary' | 'binary' | 'ternary' | 'n-ary' | 'identifying' | 'non-identifying' | 'mandatory' | 'optional' | 'strong' | 'weak' | 'disjoint' | 'overlapping' | 'polymorphic' | 'many-to-A' | 'bidirectional' | 'one-way' | 'primary' | 'secondary' | 'generalized' | 'simple' | 'complex' | 'recursive' | 'hierarchical' | 'network' | 'associative' | 'composite' | 'aggregation' | 'composition' | 'inheritance' | 'specialization' | 'generalization' | 'foreign-key' | 'independent' | 'zero-to-one' | 'zero-to-many' | 'one-to-zero' | 'one-to-optional' | 'many-to-optional' | 'optional-to-one' | 'optional-to-many' | 'exclusive' | 'non-exclusive' | 'total' | 'partial' | 'referential' | 'non-referential' | 'existence-dependent' | 'existence-independent' | 'value-dependent' | 'value-independent' | 'time-dependent' | 'time-independent' | 'spatial' | 'temporal' | 'transitive' | 'intransitive' | 'symmetric' | 'asymmetric' | 'cyclic' | 'acyclic' | 'circular' | 'linear' | 'adjacency' | 'closure' | 'path' | 'distance' | 'weighted' | 'unweighted' | 'directed' | 'undirected' | 'labeled' | 'unlabeled' | 'attributed' | 'unattributed' | 'versioned' | 'unversioned' | 'audited' | 'unaudited' | 'soft-deleted' | 'hard-deleted' | 'archived' | 'active' | 'draft' | 'published' | 'pending' | 'approved' | 'rejected' | 'locked' | 'unlocked' | 'system-defined' | 'user-defined' | 'built-in' | 'custom' | 'default' | 'explicit' | 'implicit' | 'natural' | 'surrogate';

    interface RelationDef {
        type: AllRelationshipTypes
        from: S
        to: S
        foreignKey: S
        throughTable?: S
        onDelete?: 'cascade' | 'restrict' | 'set-null' | 'no-action' | 'set-default'
        onUpdate?: 'cascade' | 'restrict' | 'no-action' | 'set-null' | 'set-default'
        onEvict?: 'cascade' | 'restrict' | 'no-action'   // temporal-specific: what a GDPR purge does to related versions
    }

    interface IndexDef {
        fields: S[]
        unique: B
        fullText: B
        spatial: B
    }

    // ─── TEMPORAL META (new section — no RDB equivalent) ─────────────────────────
    interface TemporalMeta {
        _valid_from: Date
        _valid_to: Date | null
        _tx_from: Date
        _tx_to: Date | null
    }
    type TemporalRow<T> = T & TemporalMeta
    type VersionId = S

    // ─── ROW LEVEL SECURITY (identical to RDB) ────────────────────────────────────
    type RLSContext = Record<S, U> & { userId?: S; role?: S }
    type RLSRule = (ctx: RLSContext) =>
        | true | false
        | { field: S; op: S; value: U }
        | { field: S; op: S; value: U }[]
    interface RLSPolicy {
        read?: RLSRule
        write?: RLSRule
        delete?: RLSRule
        evict?: RLSRule   // temporal-specific: hard purge needs its own, stricter gate
        fields?: (ctx: RLSContext) => S[] | '*'
    }

    // ─── SCHEMA SNAPSHOT ─────────────────────────────────────────────────────────
    interface SchemaSnapshot {
        version: N
        tables: Record<S, SnapshotTable>
    }
    interface SnapshotTable {
        fields: Record<S, {
            kind: FieldKind
            primaryKey: B
            unique: B
            nullable: B
            enumValues?: S[]
        }>
        indexes: IndexDef[]
        relations: RelationDef[]
        softDelete: B
        audit: B
        hiddenFields?: S[]

    }

    // ─── MIGRATION OPS ────────────────────────────────────────────────────────────
    type MigrationOp =
        | { op: 'create_table'; table: S; fields: Record<S, FieldDef>; softDelete: B; audit: B }
        | { op: 'drop_table'; table: S }
        | { op: 'add_field'; table: S; field: S; def: FieldDef }
        | { op: 'drop_field'; table: S; field: S }
        | { op: 'add_index'; table: S; index: IndexDef }
        | { op: 'drop_index'; table: S; fields: S[] }

    interface MigrationRecord {
        id: S
        version: N
        op: S
        table: S
        appliedAt: N
        checksum: S
        // temporal-specific: old versions written under a prior schema still need
        // to resolve correctly — this maps schema version to a lazy upgrade fn
        upgrade?: (row: Record<S, U>) => Record<S, U>
    }

    // ─── QUERY TYPES (RDB's full plan, plus temporal scoping) ────────────────────
    type WhereOperator =
        | '=' | '!=' | '<' | '<=' | '>' | '>='
        | 'like' | 'in' | 'not in' | 'is null' | 'is not null'

    interface WhereClause {
        field: S
        op: WhereOperator
        value: U
        conjunction: 'and' | 'or'
    }
    interface JoinClause { table: S; on: [S, S]; type: 'inner' | 'left' | 'right' }
    interface OrderClause { field: S; dir: 'asc' | 'desc' }
    interface GroupClause { fields: S[]; having?: WhereClause[] }
    interface AggregateClause { fn: 'count' | 'sum' | 'avg' | 'min' | 'max'; field: S; alias: S }
    interface CursorPagination { field: S; value: U; dir: 'asc' | 'desc'; limit: N }
    interface SubqueryClause { alias: S; plan: QueryPlan }

    // temporal scope — how "which point(s) in time" gets attached to a plan
    type TemporalScope =
        | { kind: 'current' }
        | { kind: 'as-of'; validTime: Date; txTime?: Date }
        | { kind: 'between'; validFrom: Date; validTo: Date }
        | { kind: 'all-history' }

    interface QueryPlan {
        table: S
        wheres: WhereClause[]
        joins: JoinClause[]
        orders: OrderClause[]
        group?: GroupClause
        aggregates?: AggregateClause[]
        subqueries?: SubqueryClause[]
        selectedFields: S[] | '*'
        limitVal?: N
        offsetVal?: N
        cursor?: CursorPagination
        isCount: B
        isDistinct: B
        withDeleted?: B   // in TemporalDB: withDeleted means include valid_to-closed rows
        rlsContext?: RLSContext
        temporal: TemporalScope   // required — every temporal query plan must declare its time scope
    }

    // ─── STORAGE ADAPTER (RDB's contract + versioning ops) ────────────────────────
    interface StorageAdapter {
        getBinary(key: S): Promise<S | A>;
        setBinary(key: S, value: S): P<A>;
        deleteBinary(key: S): P<A>;
        init(): P<A>
        close(): P<A>
        isHealthy(): Promise<B>

        getSnapshot(): Promise<SchemaSnapshot | null>
        saveSnapshot(snap: SchemaSnapshot): P<A>

        createTable(table: S, fields: Record<S, FieldDef>, softDelete: B, audit: B): P<A>
        dropTable(table: S): P<A>
        addField(table: S, field: S, def: FieldDef): P<A>
        dropField(table: S, field: S): P<A>
        createIndex(table: S, index: IndexDef): P<A>
        dropIndex(table: S, fields: S[]): P<A>

        // versioned writes replace RDB's plain insert/update/delete — every write
        // is a new version, never an in-place mutation

        insertVersion(table: S, row: Record<S, U>, opts: TemporalWriteOptions, txId?: S): Promise<Record<S, U>>
        updateVersion(table: S, id: U, patch: Record<S, U>, opts: TemporalWriteOptions, txId?: S): Promise<Record<S, U>>
        closeVersion(table: S, id: U, at: Date, txId?: S): P<A>
        evict(table: S, id: U, opts: EvictOptions, txId?: S): P<A>
        restore(table: S, id: U, txId?: S): P<A>
        upsertVersion(table: S, row: Record<S, U>, conflictField: S, opts: TemporalWriteOptions, txId?: S): Promise<Record<S, U>>

        query(plan: QueryPlan): Promise<Record<S, U>[]>
        count(plan: QueryPlan): Promise<N>
        aggregate(table: S, aggregates: AggregateClause[], plan: QueryPlan): Promise<Record<S, U>>
        history(table: S, id: U): Promise<HistoryEntry<Record<S, U>>[]>
        diff(table: S, id: U, t1: Date, t2: Date): Promise<DiffResult<Record<S, U>>>

        beginTransaction(): Promise<S>
        commitTransaction(txId: S): P<A>
        rollbackTransaction(txId: S): P<A>

        fullTextSearch(table: S, fields: S[], query: S, temporal: TemporalScope): Promise<Record<S, U>[]>
        spatialSearch(table: S, field: S, lat: N, lng: N, radiusKm: N, temporal: TemporalScope): Promise<Record<S, U>[]>

        Table(table: S, temporal: TemporalScope): Promise<Record<S, U>[]>
        importTable(table: S, rows: Record<S, U>[], strategy: ImportStrategy): P<A>
        backup(destPath: S): P<A>

        getMigrations(): Promise<MigrationRecord[]>
        recordMigration(record: MigrationRecord): P<A>

    }

    interface TemporalWriteOptions {
        validFrom?: Date
        validTo?: Date
        systemTime?: Date
    }
    interface EvictOptions {
        before?: Date
        after?: Date
        reason: S   // required, not optional — every hard purge is accountable
    }
    interface HistoryEntry<T> { version: VersionId; data: T; meta: TemporalMeta }
    interface DiffResult<T> {
        from: VersionId; to: VersionId
        changed: Partial<Record<keyof T, { before: U; after: U }>>
        added: (keyof T)[]; removed: (keyof T)[]
    }

    type ImportStrategy = 'overwrite' | 'merge' | 'skip'

    // ─── REACTIVE (RDB's shape + AS-OF-change semantics) ─────────────────────────
    interface Subscription { unsubscribe(): V }
    interface ReactiveQuery<T> {
        get(): T[]
        subscribe(handler: (rows: T[]) => V): Subscription
        on(busKey: S): ReactiveQuery<T>
    }
    interface AsOfChangeEvent<T> { id: S; previous: T | null; current: T | null; changedAt: Date }
    type SubscribeHandler<T> = (event: AsOfChangeEvent<T>) => V

    // ─── TRANSACTION ──────────────────────────────────────────────────────────────
    interface TransactionContext {
        id: S
        insertVersion(table: S, row: Record<S, U>, opts: TemporalWriteOptions): Promise<Record<S, U>>
        updateVersion(table: S, id: U, patch: Record<S, U>, opts: TemporalWriteOptions): Promise<Record<S, U>>
        closeVersion(table: S, id: U, at: Date): P<A>
        evict(table: S, id: U, opts: EvictOptions): P<A>
    }

    // ─── DEVTOOLS ─────────────────────────────────────────────────────────────────
    interface QueryRecord {
        id: S; plan: QueryPlan; executionMs: N; rowCount: N; timestamp: N; busKey?: S
    }
    interface WriteHistoryEntry {
        ts: N; table: S; op: 'insert' | 'update' | 'close' | 'evict'
        before: Record<S, U> | null; after: Record<S, U> | null
        rt: S | null; url: S | null
    }

    // ─── ADAPTER CONFIG (identical to RDB — reused tier) ──────────────────────────
    type DBType = 'sqlite' | 'bun-sqlite' | 'deno-sqlite' | 'indexeddb' | 'mongodb' | 'mysql' | 'postgres'
    interface AdapterConfig {
        name: S; dbType: DBType; memory: B
        path?: S; dbName?: S; host?: S; port?: N
        user?: S; password?: S; database?: S; connectionString?: S
    }

    // ─── INFER ROW TYPE ────────────────────────────────────────────────────────────
    type InferFieldType<F extends FieldDef> =
        F['kind'] extends 'uuid' ? S :
        F['kind'] extends 'S' ? S :
        F['kind'] extends 'N' ? N :
        F['kind'] extends 'B' ? B :
        F['kind'] extends 'timestamp' ? Date :
        F['kind'] extends 'json' ? U :
        F['kind'] extends 'enum' ? S :
        never

    type InferRow<T extends TableDef> = {
        [K in keyof T['schema']]: T['schema'][K]['nullable'] extends true
        ? InferFieldType<T['schema'][K]> | null
        : InferFieldType<T['schema'][K]>
    } & TemporalMeta

    // #endregion
    // #region ══ VDB ════════════════════════════════════════════════════════════════════
    interface RpConfig {
        projectedDim: N
        metric?: VdbMetric
    }
    interface SubRecord {
        id: S
        table: S
        busKey: S | null
        active: B
        lastFired: N
    }
    type AnnIndexType =
        | 'flat'
        | 'hnsw'
        | 'ivf'
        | 'pq'
        | 'opq'
        | 'lsh'
        | 'rp'

    interface AnnIndexConfig {
        type: AnnIndexType
        params?: Record<S, U>
    }

    interface IvfConfig {
        nLists: N
        trainingSamples?: N
        metric?: VdbMetric
    }
    interface HnswConfig {
        M: N
        efConstruction: N
        efSearch: N
        levelLambda: N
    }
    interface OpqConfig {
        subvectorCount: N
        codebookSize: N
        metric?: VdbMetric
        maxIterations?: N
    }

    interface VDB_CONFIG_T {
        db_name: S
        db_type: DB_TT
        storage_path: S

        memory?: B
        connection_string?: S
        database?: S
        host?: S
        port?: N
        user?: S
        password?: S
    }

    type DBType =
        | 'sqlite'
        | 'bun-sqlite'
        | 'deno-sqlite'
        | 'indexeddb'
        | 'mongodb'
        | 'mysql'
        | 'postgres'


    type WhereOperator =
        | '='
        | '!='
        | '<'
        | '<='
        | '>'
        | '>='
        | 'null'
        | 'eq'
        | 'neq'
        | 'lt'
        | 'lte'
        | 'gt'
        | 'gte'
        | 'between'
        | 'like'
        | 'ilike'
        | 'in'
        | 'not in'
        | 'contains'
        | 'has'
        | 'is null'
        | 'is not null'
        | 'notnull'
        | 'regex'
        | 'custom'

    interface WhereClause {
        field: S
        op: WhereOperator
        value: U
        conjunction: 'and' | 'or'
    }
    interface JoinClause {
        table: S
        on: [S, S]
        type: 'inner' | 'left' | 'right'
    }
    interface OrderClause {
        field: S
        dir: 'asc' | 'desc'
    }
    interface GroupClause {
        fields: S[]
        having?: WhereClause[]
    }
    interface AggregateClause {
        fn: 'count' | 'sum' | 'avg' | 'min' | 'max'
        field: S
        alias: S
    }
    interface CursorPagination {
        field: S
        value: U
        dir: 'asc' | 'desc'
        limit: N
    }
    interface SubqueryClause {
        alias: S
        plan: QueryPlan
    }
    type RLSContext = Record<S, U> & {
        userId?: S
        role?: S
    }
    interface QueryPlan {
        table: S
        wheres: WhereClause[]
        joins: JoinClause[]
        orders: OrderClause[]
        group?: GroupClause
        aggregates?: AggregateClause[]
        subqueries?: SubqueryClause[]
        selectedFields: S[] | '*'
        limitVal?: N
        offsetVal?: N
        cursor?: CursorPagination
        isCount: B
        isDistinct: B
        withDeleted?: B
        rlsContext?: RLSContext
    }
    interface QueryRecord {
        id: S
        plan: QueryPlan
        executionMs: N
        rowCount: N
        timestamp: N
        busKey?: S
    }
    interface HistoryEntry {
        ts: N
        table: S
        op: 'insert' | 'update' | 'delete'
        before: Record<S, U> | null
        after: Record<S, U> | null
        rt: S | null
        url: S | null
    }
    // ─── VECTOR CORE TYPES ───────────────────────────────────────────────────────
    type Vector = N[]

    type VdbMetric = 'cosine' | 'dot' | 'l2'

    interface VdbRecord {
        id: S
        vector: Vector
        metadata?: Record<S, U>
        createdAt: N
        updatedAt: N
    }

    interface VdbCollectionConfig {
        name: S
        dimension: N
        metric?: VdbMetric
        // future: adapterConfig, indexConfig, etc.
    }

    interface VdbIndexConfig {
        type: 'flat' | 'hnsw' | 'ivf'
        params?: Record<S, U>
    }

    interface VdbSearchFilter {
        field: S
        op: WhereOperator
        value?: A
        values?: A[]
        min?: N
        max?: N
        pattern?: S
        fn?: (meta: Record<S, U>) => B
    }

    interface VdbSearchOrder {
        field: 'score' | 'createdAt' | 'updatedAt' | S
        dir: 'asc' | 'desc'
    }

    interface VdbSearchOptions {
        k?: N
        limit?: N
        offset?: N
        filters?: VdbSearchFilter[]
        order?: VdbSearchOrder[]
        since?: N
        until?: N
        minScore?: N
        maxDistance?: N
        metricOverride?: VdbMetric
        [key: S]: A
    }

    interface VdbSearchResult extends VdbRecord {
        score: N
        distance: N
    }

    // ANN index interface
    interface AnnIndex {
        insert(rec: VdbRecord): V
        bulkInsert(records: Iterable<VdbRecord>): V
        update(rec: VdbRecord): V
        delete(id: S): V
        rebuild(records: Iterable<VdbRecord>, metric: VdbMetric): V
        search(
            query: Vector,
            opts: { k?: N; minScore?: N; maxDistance?: N },
            metric: VdbMetric,
            allRecords?: Map<S, VdbRecord>
        ): { id: S; score: N; distance: N; rec: VdbRecord }[]
    }
    interface ScopeOptions {
        sl_reg?: A
        ms_reg?: A
        globalKey?: A
    }
    interface SauronRegistry {
        name: S
        get<T>(key: S | symbol): T | UD
        set<T>(key: S | symbol, value: T | ((prev: T | UD) => T), opts?: { triggerRender?: B }): V
        delete(key: S | symbol): B
        getByPrefix<T>(prefix: S): { key: S; value: T }[]
        getAll<T>(): Record<S | symbol, T>
        subscribe<T>(key: S | symbol, listener: (value: T) => V): () => V
        subscribeAll(listener: (key: S | symbol, value: A) => V): () => V
        batch(key: S | symbol, fn: () => V): V
        clear(): V
        destroy(): V
    }
    interface SauronState {
        get<T>(key: A): T | UD
        set<T>(key: A, value: T | ((prev: T | UD) => T), opts?: { triggerRender?: B }): V
        delete(key: A): B
        getByPrefix<T>(prefix: S): { key: S; value: T }[]
        getAll<T>(): Record<A, T>
        subscribe<T>(key: A, listener: (value: T) => V): () => V
        subscribeAll(listener: (key: A, value: A) => V): () => V
        batch(key: A, fn: () => V): V
        clear(): V
    }



    interface StorageAdapter {
        // Binary operations
        getBinary(key: S): Promise<S | null>
        setBinary(key: S, value: S): P<A>
        deleteBinary(key: S): Promise<S | null>

        // Memory operations
        getMemory(key: S): Promise<A>
        setMemory(key: S, value: A): P<A>
        deleteMemory(key: S): P<A>
        getManyMemory(keys: S[]): Promise<Record<S, A>>
        setManyMemory(entries: Record<S, A>): P<A>
        deleteManyMemory(keys: S[]): P<A>

        // LocalStorage operations
        getLocalStorage(key: S): Promise<A>
        setLocalStorage(key: S, value: S | object): P<A>
        deleteLocalStorage(key: S): P<A>
        getManyLocalStorage(keys: S[]): Promise<Record<S, A>>
        setManyLocalStorage(entries: Record<S, A>): P<A>
        deleteManyLocalStorage(keys: S[]): P<A>

        // SessionStorage operations
        getSessionStorage(key: S): Promise<A>
        setSessionStorage(key: S, value: A): P<A>
        deleteSessionStorage(key: S): P<A>
        getManySessionStorage(keys: S[]): Promise<Record<S, A>>
        setManySessionStorage(entries: Record<S, A>): P<A>
        deleteManySessionStorage(keys: S[]): P<A>

        // Cookie operations
        getCookie(key: S): Promise<A>
        setCookie(key: S, value: A, options?: { maxAge?: N; path?: S; domain?: S; secure?: B; httpOnly?: B; sameSite?: 'strict' | 'lax' | 'none' }): P<A>
        deleteCookie(key: S, path?: S, domain?: S): P<A>
        getManyCookie(keys: S[]): Promise<Record<S, A>>
        setManyCookie(entries: Record<S, A>, options?: { maxAge?: N; path?: S; domain?: S; secure?: B; httpOnly?: B; sameSite?: 'strict' | 'lax' | 'none' }): P<A>
        deleteManyCookie(keys: S[], path?: S, domain?: S): P<A>

        // Global This operations
        getGT(label: S): Promise<A>
        setGT(label: S, value: A): P<A>
        deleteGT(label: S): P<A>
        getManyGT(keys: S[]): Promise<Record<S, A>>
        setManyGT(entries: Record<S, A>): P<A>
        deleteManyGT(keys: S[]): P<A>

        // Cache operations
        getCache(key: S): Promise<A>
        setCache(key: S, value: A, ttl?: N): P<A>
        deleteCache(key: S): P<A>
        clearCache(): P<A>

        // Collection operations
        createCollection(config: VdbCollectionConfig, indexConfig?: VdbIndexConfig): P<A>
        getCollection(name: S): Promise<A>
        dropCollection(name: S): P<A>

        // Record operations
        insert(collection: S, record: { id: S; vector: Vector; metadata?: Record<S, U> }): Promise<VdbRecord>
        bulkInsert(collection: S, records: { id: S; vector: Vector; metadata?: Record<S, U> }[]): Promise<VdbRecord[]>
        upsert(collection: S, record: { id: S; vector: Vector; metadata?: Record<S, U> }): Promise<VdbRecord>
        update(collection: S, id: S, patch: { vector?: Vector; metadata?: Record<S, U> }): Promise<VdbRecord>
        delete(collection: S, id: S): P<A>
        get(collection: S, id: S): Promise<VdbRecord | null>
        exists(collection: S, id: S): Promise<B>
        count(collection: S): Promise<N>
        truncate(collection: S): P<A>

        // Bulk operations
        upsertMany(collection: S, rows: { id: S; vector: Vector; metadata?: Record<S, U> }[]): P<A>
        deleteMany(collection: S, idsOrFilters: S[] | VdbSearchFilter[]): P<A>

        // Search operations
        search(collection: S, queryVector: Vector, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchById(collection: S, id: S, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchByIds(collection: S, ids: S[], opts: VdbSearchOptions): Promise<Record<S, VdbSearchResult[]>>
        searchMany(collection: S, queryVectors: Vector[], opts: VdbSearchOptions): Promise<VdbSearchResult[][]>
        searchByField(collection: S, queryVector: Vector, field: S, value: U, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchMultiField(collection: S, queryVector: Vector, fields: { field: S; op?: S; value: U }[], opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchLike(collection: S, queryVector: Vector, field: S, pattern: S, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchILike(collection: S, queryVector: Vector, field: S, pattern: S, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchWhere(collection: S, queryVector: Vector, filters: VdbSearchFilter[], opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchOrWhere(collection: S, queryVector: Vector, orGroups: VdbSearchFilter[][], opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchWhereInAdvanced(collection: S, queryVector: Vector, builder: (meta: Record<S, U>) => B, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchSelective(collection: S, queryVector: Vector, selector: (r: VdbSearchResult) => B, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchByDateRange(collection: S, queryVector: Vector, field: S, fromTs: N, toTs: N, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchRecent(collection: S, queryVector: Vector, field: S, sinceTs: N, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchNull(collection: S, queryVector: Vector, field: S, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchNotNull(collection: S, queryVector: Vector, field: S, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchBetween(collection: S, queryVector: Vector, field: S, min: N, max: N, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchNotEqual(collection: S, queryVector: Vector, field: S, value: U, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchPaginated(collection: S, queryVector: Vector, page: N, pageSize: N, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchOrdered(collection: S, queryVector: Vector, order: VdbSearchOrder[], opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchBoundingBox(collection: S, queryVector: Vector, minDistance: N, maxDistance: N, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchRelevance(collection: S, queryVector: Vector, minScore: N, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchWithJoin(leftCollection: S, rightCollection: S, queryVector: Vector, joinOn: { leftField: S; rightField: S }, opts: VdbSearchOptions): Promise<{ left: VdbSearchResult; right: VdbRecord }[]>
        searchHybrid(collection: S, queryVector: Vector, metadataQuery: VdbSearchFilter[], opts: VdbSearchOptions & { alpha?: N }): Promise<VdbSearchResult[]>
        searchKNN(collection: S, queryVector: Vector, k: N, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchRange(collection: S, queryVector: Vector, minDistance: N, maxDistance: N, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchTopKPerGroup(collection: S, queryVector: Vector, groupField: S, kPerGroup: N, opts: VdbSearchOptions): Promise<Record<S, VdbSearchResult[]>>
        searchFacets(collection: S, queryVector: Vector, facetFields: S[], opts: VdbSearchOptions): Promise<Record<S, Record<S, N>>>
        searchExplain(collection: S, queryVector: Vector, opts: VdbSearchOptions): Promise<{ result: VdbSearchResult; explain: Record<S, U> }[]>
        searchNeighbors(collection: S, id: S, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchCluster(collection: S, queryVector: Vector, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchDrift(collection: S, a: S | Vector, b: S | Vector, metricOverride?: VdbMetric): Promise<{ score: N; distance: N }>
        searchOutliers(collection: S, opts: VdbSearchOptions & { threshold?: N }): Promise<VdbRecord[]>
        searchDuplicates(collection: S, opts: VdbSearchOptions & { minScore?: N }): Promise<[VdbRecord, VdbRecord][]>
        searchAnalogies(collection: S, a: Vector, b: Vector, c: Vector, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchProjection(collection: S, queryVector: Vector, projection: (v: Vector) => Vector, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchBatchExplain(collection: S, queryVectors: Vector[], opts: VdbSearchOptions): Promise<{ vector: Vector; results: A[] }[]>
        searchCrossCollection(collections: S[], queryVector: Vector, opts: VdbSearchOptions): Promise<Record<S, VdbSearchResult[]>>
        searchWeightedFields(collection: S, queryVector: Vector, weights: Record<S, N>, opts: VdbSearchOptions): Promise<VdbSearchResult[]>
        searchSemanticGraph(collection: S, queryVector: Vector, opts: VdbSearchOptions): Promise<Record<S, S[]>>
        searchPath(collection: S, fromId: S, toId: S, opts: VdbSearchOptions): Promise<S[]>
        searchStreaming(collection: S, queryVector: Vector, opts: VdbSearchOptions): AsyncGenerator<VdbSearchResult>
        searchAsync(collection: S, queryVector: Vector, opts: VdbSearchOptions): Promise<{ jobId: S }>
        getAsyncSearchResult(jobId: S): Promise<VdbSearchResult[] | null>

        // Relevance
        calculateRelevanceScore(collection: S, queryVector: Vector, target: Vector | S, metricOverride?: VdbMetric): N

        // Seed//Import/Backup
        seed(collection: S, rows: { id: S; vector: Vector; metadata?: Record<S, U> }[]): P<A>
        (collection: S): Promise<VdbRecord[]>
        import(collection: S, rows: VdbRecord[], strategy: 'overwrite' | 'merge' | 'skip'): P<A>
        backup(collection: S, destPath: S): P<A>

        // Migrations & Health
        getMigrations(): Promise<A[]>
        isHealthy(): Promise<B>

        // Transactions
        beginTransaction(): Promise<S>
        commitTransaction(txId: S): P<A>
        rollbackTransaction(txId: S): P<A>
        transaction<T>(fn: (tx: { insert: A; update: A; delete: A; get: A }) => Promise<T>): Promise<T>

        // Index operations
        indexStats(collection: S): Record<S, U>
        rebuildIndex(collection: S): P<A>
        reindexRecord(collection: S, id: S): P<A>

        // Collection management
        copyCollection(source: S, target: S): P<A>
        moveToCollection(source: S, target: S, id: S): P<A>
        diffCollections(left: S, right: S): Promise<{ onlyLeft: S[]; onlyRight: S[]; both: S[] }>

        // Sauron/Registry operations
        publish(key: S | symbol, value: A, opts?: A): P<A>
        subscribe(key: S | symbol, listener: (value: A) => V, opts?: A): Promise<() => V>
        getAllSauron(opts?: A): Promise<Record<S | symbol, A>>
        setSauron(label: S, value: A, triggerRender?: B, sl_reg?: A, ms_reg?: A, globalKey?: A): P<A>
        getSauron(label: S, sl_reg?: A, ms_reg?: A, globalKey?: A): Promise<A>
        subSauron(label: S, fn: (value: A) => V, sl_reg?: A, ms_reg?: A, globalKey?: A): Promise<() => V>
        deleteSauron(label: S, sl_reg?: A, ms_reg?: A, globalKey?: A): Promise<B>
        subAllSauron(fn: (key: S | symbol, value: A) => V, sl_reg?: A, ms_reg?: A, globalKey?: A): Promise<() => V>

        // Registry operations
        createScopedReg(name: S): Promise<A>
        createRegistry(name: S): Promise<A>
        getRegistry(name: S): Promise<A>
        getAllRegistries(): Promise<Record<S, A>>
        getGR(label: S, registry: S): Promise<A>
    }

    // #endregion
    // #region ══ LIBRARIES ════════════════════════════════════════════════════════════════════

    interface OPTIONAL_IMPORT_OPTIONS<T, F = A> {
        moduleName?: S;
        fallback?: F | (() => F);
        preferRequire?: B;
        module?: B;
        importPromise?: A;
        comp_name?: S;
        [key: S]: A;
    }
    // #endregion
    // #region ══ PRIMTIVES - NO NO SQUARE ════════════════════════════════════════════════════════════════════

    interface NoNoSquareProps {
        theme?: A
        style?: A
        className?: A
        scope?: A
        children?: A
    }
    // #endregion
    // #region ══ DEV TOOLS ════════════════════════════════════════════════════════════════════

    type Layer = "LOADER" | "ACTION" | "COMPONENT" | "COMPILER" | "SERVER";

    interface RequestInfo {
        method: S;
        url: S;
        headers?: Record<S, S>;
    }

    interface SauronCompilerOptions {
        outdir: S;
        routesDirectory: S;
        ignoredFilePatterns?: S[];
        // Add other properties as needed
    }

    interface SauronBuildResult {
        success: B;
        errors: Array<{
            file?: S;
            line?: N;
            column?: N;
            message: S;
            suggestion?: S;
        }>;
        warnings: Array<{
            file?: S;
            line?: N;
            column?: N;
            message: S;
        }>;
        metafile?: U;
    }

    interface SauronDevServerOptions {
        compilerOptions: SauronCompilerOptions;
        port?: N;
        devPort?: N;
        appDirectory: S;
    }
    interface RequestHooks {
        onLoaderStart: () => V;
        onLoaderEnd: (duration: N, data: U) => V;
        onActionStart: (intent?: S) => V;
        onActionEnd: (duration: N, result: U) => V;
        onLoaderError: (err: Error, file: S, line?: N, col?: N) => V;
        onActionError: (err: Error, file: S, line?: N, col?: N) => V;
    }
    interface CollectedError {
        layer: Layer;
        file: S;
        line?: N;
        col?: N;
        message: S;
        source?: S;
        suggestion?: S;
        request?: RequestInfo;
        count: N;
    }

    type DevEvent =
        | { type: "route:registered"; route: ConfigRoute }
        | { type: "route:changed"; route: ConfigRoute }
        | { type: "route:removed"; path: S }
        | { type: "request:start"; id: S; method: S; url: S }
        | { type: "request:end"; id: S; status: N; duration: N }
        | { type: "loader:start"; id: S; route: S }
        | { type: "loader:end"; id: S; duration: N; data: U }
        | { type: "action:start"; id: S; route: S; intent?: S }
        | { type: "action:end"; id: S; duration: N; result: U }
        | { type: "error"; layer: Layer; file: S; line?: N; col?: N; message: S; source?: S; request?: RequestInfo }
        | { type: "build:start" }
        | { type: "build:end"; duration: N; routes: N }
        | { type: "build:error"; file: S; line?: N; message: S }
        | { type: "server:ready"; port: N; routes: ConfigRoute[] }
        | CronDevEvent;

    type DevCommand =
        | { type: "form:submit"; url: S; fields: Record<S, U>; headers?: Record<S, S> }
        | { type: "loader:trigger"; route: S; params?: Record<S, S> }
        | { type: "request:replay"; id: S }
        | { type: "session:inspect"; sessionId: S };

    // #endregion
    // #region ══ TOMB OF SECRETS ════════════════════════════════════════════════════════════════════
    type CoerceType = "S" | "N" | "B" | "json"

    type SecretCondition<S extends Schema> = (vals: Partial<Record<keyof S, A>>) => B

    type SchemaKey<T = A, S extends Schema = Schema> = {
        coerce?: CoerceType
        required?: SecretRequired
        requiredWhen?: SecretCondition<S>
        surface?: SecretSurface
        ttl?: N
        rotateEvery?: S
        inline?: B
        doc?: S
        validate?: (val: T) => B | S
        compute?: (vault: Partial<Record<S, A>>) => T
        dependsOn?: S[]
        allowedIn?: S[]
        canary?: B
        validFrom?: N
        validUntil?: N
        entropyMin?: N
    }

    type Schema = Record<S, SchemaKey>

    type Coerced<C extends CoerceType | UD> =
        C extends "N" ? N :
        C extends "B" ? B :
        C extends "json" ? U :
        S

    type ResolvedSchema<S extends Schema> = {
        [K in keyof S]: S[K]["compute"] extends (...args: A[]) => infer R
        ? R
        : Coerced<S[K]["coerce"]>
    }

    type VaultSource =
        | { type: "senv"; path: S }
        | { type: "processenv" }
        | { type: "object"; data: Record<S, S | null> }
        | { type: "adapter"; adapter: VaultAdapter }

    type VaultOptions = {
        env?: Env
        sources?: VaultSource[]
        encryptMemory?: B
        eagerValidation?: B
        surface?: SecretSurface
    }

    type AccessLogEntry = { key: S; at: N; from: S }
    type RotationEntry = { key: S; at: N; from: S | null; to: S | null }
    type ChangeListener = (key: S, prev: S | null, next: S | null) => V
    type RotateListener = (key: S, oldVal: S | null, newVal: S | null) => V


    type SauronSecretsViteOptions = {
        senvPath?: S
        schema: Schema
        env?: Env
        clientPrefix?: S
    }
    type SenvConfig = {
        path?: S
        env?: A
    }

    type VaultAdapter = {
        name: S
        fetch: (key: S, env: Env) => Promise<S | null>
        watch?: (key: S, cb: (val: S | null) => V) => () => V
    }

    type AdapterCacheEntry = {
        value: S | null
        at: N
    }

    // ─── ADAPTER FACTORY ──────────────────────────────────────────────────────────

    type AdapterOptions = {
        ttl?: N
    }

    type SauronSecretsEsbuildOptions = {
        senvPath?: S
        schema: Schema
        env?: Env
        surface?: "server" | "client"
    }
    type WorkspaceSecret = {
        key: S
        value: S | null
        source: S
    }

    type ResolvedWorkspace = {
        secrets: Record<S, S>
        sources: S[]
        errors: S[]
    }


    type FallbackChainOptions = {
        offlineSnapshot?: Map<S, S | null>
        cacheTTL?: N
    }

    type AWSAdapterOptions = AdapterOptions & {
        region: S
        accessKeyId: S
        secretAccessKey: S
        prefix?: S
    }


    type GCPAdapterOptions = AdapterOptions & {
        projectId: S
        accessToken: S
        prefix?: S
    }


    type HashiCorpAdapterOptions = AdapterOptions & {
        address: S
        token: S
        mount?: S
        prefix?: S
    }


    type DopplerAdapterOptions = AdapterOptions & {
        token: S
        project: S
        config: S
    }


    type InfisicalAdapterOptions = AdapterOptions & {
        token: S
        projectId: S
        env: Env
        siteUrl?: S
    }

    type RegistryEntry = {
        value: S | null
        env: Env
        source: S
    }


    type ServiceContract = {
        name: S
        exposes: S[]
        consumes: S[]
    }

    type ContractViolation = {
        service: S
        key: S
        reason: S
    }


    type SauronSecretsRollupOptions = SauronSecretsEsbuildOptions


    type SauronSecretsNextOptions = {
        senvPath?: S
        schema: Schema
        env?: Env
        publicPrefix?: S
    }

    type RemixSecretsContext = {
        server: Record<S, S>
        client: Record<S, S>
    }

    type Env = "dev" | "test" | "staging" | "prod" | (S & {})
    type SecretSurface = "server" | "client" | "build"
    type SecretRequired = B | Env | Env[]

    type RawSecretBlock = {
        key: S
        values: Partial<Record<Env, S | null>>
        base?: S | null
        required?: SecretRequired
        surface?: SecretSurface
        ttl?: N
        rotateEvery?: S
        inline?: B
        doc?: S
    }

    type ParsedSenv = {
        blocks: RawSecretBlock[]
        errors: S[]
    }












    // #endregion
    // #region ══ SSE ════════════════════════════════════════════════════════════════════
    type SSEStore = Record<S, {
        value: U;
        version: N;
        lastUpdated: N;
        lastFetched: N;
        pending: B;
        error?: Error;
    }>;
    type SSEChannel = {
        id: S;
        send: (event: S, data: U) => V;
        close: () => V;
        status: () => 'connected' | 'disconnected' | 'reconnecting';
    };

    type SSEEvent = {
        event: S;
        data: U;
        id?: S;
        timestamp: N;
    };

    type SSEMessage = {
        rt: S;
        event: S;
        data: U;
        id?: S;
        version?: N;
    };

    type SSEHandler = (data: U, metadata?: { id?: S; version?: N }) => V;

    type RetryConfig = {
        baseDelay?: N;    // Default: 1000ms
        maxDelay?: N;     // Default: 30000ms
        maxAttempts?: N;  // Default: 10
        backoff?: 'exponential' | 'linear' | 'fixed';
    };

    type ConflictStrategy = 'server-wins' | 'client-wins' | 'merge' | 'version' | 'custom';

    type YmirConfig<T = U> = {
        /** Conflict resolution strategy */
        conflictStrategy?: ConflictStrategy;
        /** Custom merge function */
        mergeFn?: (local: T, server: T) => T;
        /** Version field name for version-based resolution */
        versionField?: S;
        /** Auto-fetch on focus */
        prefetchOnFocus?: B;
        /** Prefetch threshold in ms (fetch if last fetch > threshold) */
        prefetchThreshold?: N;
        /** Debounce write in ms */
        debounce?: N;
        /** Retry configuration */
        retry?: RetryConfig;
    };



    // #endregion
    // #region ══ YJS ════════════════════════════════════════════════════════════════════

    type YataItem<T> = {
        id: S                    // HLC timestamp — this app's insert-order + causality marker
        content: T | null             // null once deleted (tombstone, content discarded)
        left: S | null           // id of left neighbor AT INSERT TIME (author's view)
        right: S | null          // id of right neighbor AT INSERT TIME — the originRight trick
        leftPtr: YataItem<T> | null   // actual current left neighbor (may shift after concurrent inserts)
        rightPtr: YataItem<T> | null
        deleted: B
    }
    type YataOp<T> =
        | { type: 'insert'; id: S; content: T; left: S | null; right: S | null; authorId: S; originalId?: S }
        | { type: 'delete'; id: S; authorId: S; content?: T };


    interface HLC {
        tick(): S
        compare(a: S, b: S): N   // <0, 0, >0
        update(remote: S): V
    }
    interface DocSessionOptions {
        docId: S;
        nodeId: S;
        peerIds: S[];
    }
    interface AwarenessState {
        userId: S;
        cursor?: { field: S; index: N };
        selection?: { field: S; start: N; end: N };
        meta?: Record<S, A>;
    [key: string]: any;
    }
    type DocRole = 'owner' | 'editor' | 'viewer'| (string & {});;

    interface DocLifecycleState {
        status: 'active' | 'archived' | 'deleted';
        acl: Record<S, DocRole>; // userId -> role
        canonicalVersion: N;
            text: string;
    marks?: string[];
    [key: string]: any;
    }
    type MapEntry<T> = { value: T; id: S; deleted: B };
    type MapOp<T> = | { type: 'set'; key: S; value: T; id: S } | { type: 'delete'; key: S; id: S };

    interface PresenceConfig {
        transport?: 'auto' | 'broadcastchannel' | 'websocket' | CSEAdapter;
    }
    interface Comment {
        id: S;
        userId: S;
        anchorId: S;   // ← the actual YATA item id at the anchor position, NOT a raw index
        body: S;
        resolved: B;
    createdAt?: number;
    [key: string]: any;
    }
    interface FieldTouch {
        userId: S;
        field: S;
        action: 'viewing' | 'editing';
        ts: N;
    userId?: string;
    timestamp?: number;
    [key: string]: any;
    }
    interface DocConfig {
        peers?: S[];
        ordering?: 'authority-arbitrated' | 'optimistic'; // authority-arbitrated is the default
    [key: string]: any;
    }
    interface CollabField {
        insertAt?: (userId: S, index: N, content: S) => V;
        toString?: () => S;
        set?: (userId: S, value: A) => V;
        get?: () => A;
        useField?: () => [A, (v: A) => V];
        announce: (userId: S, action: 'viewing' | 'editing') => V;
        onConflict: (handler: (a: A, b: A) => V) => () => V;
        watchers: () => Record<S, A>;
    }

    // #endregion
    // #region ══ STAFF ════════════════════════════════════════════════════════════════════










    type ConsumedPrimitive =
      | AnyObject
      | AnyFactory;
    
    type Factory<C> = (ctx: AnySelfType) => C;
    
    type VenomOutput<
      Consumed extends readonly ConsumedPrimitive[],
      Own extends AnyObject
    > = MirrorImage<
      MergeRawNodes<Consumed> & Own
    >;
    
    type MergeRawNodes<
      Consumed extends readonly ConsumedPrimitive[]
    > = UnionToIntersection<
      {
        [K in keyof Consumed]: RawNodes<Consumed[K]>;
      }[number]
    >;
    
    type RawNodes<P> =
      P extends { [RAW_NODES]: infer Raw }
        ? Raw
        : P extends AnyFactory
          ? ReturnType<P>
          : P;
    
    type UnionToIntersection<U> =
      (U extends any ? (arg: U) => void : never) extends
        (arg: infer I) => void
        ? I
        : never;
    
    type ReliableSocketStatus = 'connecting' | 'open' | 'reconnecting' | 'closed'
interface SecureEnvelope {
  sessionId?: string;
  token?: string;
  p: CSEMessage | CBORValue;
}
    type ReliableSocketOptions = {
        reconnect?: B
        initialDelay?: N
        maxDelay?: N
        backoffMultiplier?: N
        jitter?: B
        maxAttempts?: N
        queueEnabled?: B
        maxQueueSize?: N
        maxQueueAge?: N
        queueKey?: S
    }

    // #endregion
    // #region ══ TEMPORAL SHIFT ════════════════════════════════════════════════════════════════════
    type Unit = 'millisecond' | 'second' | 'minute' | 'hour' | 'day' | 'week' | 'month' | 'year'
    type Density = 'minute' | 'hour' | 'day' | 'week' | 'month'
    type Mode = 'single' | 'multi' | 'range' | 'range-min' | 'week' | 'quarter' | 'month' | 'year'
    type DateUnit = 'millisecond' | 'second' | 'minute' | 'hour' | 'day' | 'week' | 'month' | 'year'
    interface Range {
        start: Date
        end: Date
    }
    interface RRuleOptions {
        freq: 'daily' | 'weekly' | 'monthly' | 'yearly'
        interval?: N
        count?: N
        until?: Date
        byDay?: N[]
        byMonthDay?: N[]
    }
    interface RecurringEvent extends Range {
        rrule: RRuleOptions
    }
    interface Conflict {
        a: Range
        b: Range
        overlap: Range
    }

    // #endregion
    // #region ══ ADAPTERS ════════════════════════════════════════════════════════════════════
    interface WebTransportDatagramsLike {
        datagrams: {
            readable: ReadableStream<Uint8Array>
            writable: WritableStream<Uint8Array>
        }
        ready: P<A>
        closed: Promise<U>
    }
    interface WebTransportSessionLike {
        ready: P<A>
        closed: Promise<U>
        createBidirectionalStream(): Promise<{
            readable: ReadableStream<Uint8Array>
            writable: WritableStream<Uint8Array>
        }>
        incomingBidirectionalStreams: ReadableStream<{
            readable: ReadableStream<Uint8Array>
            writable: WritableStream<Uint8Array>
        }>
    }
    interface webRTCAdapterOptions {
        signalingAdapter: A
        peerId: S
        iceServers?: RTCIceServer[]
    }















    // #endregion
    // #region ══ GATE MASTER ════════════════════════════════════════════════════════════════════


     type MatchPredicate<TInput> = ((val: TInput) => B) | RegExp | S | N;

     type ActionHandler<TInput = A> = (val: TInput) => A;

     type ConditionBranch<TInput = A> =
        | ActionHandler<TInput>
        | { match: MatchPredicate<TInput>; run: ActionHandler<TInput> };

     type ConditionHandlers<TInput = A> =
        | Record<S, ConditionBranch<TInput>>
        | Map<S, ConditionBranch<TInput>>;

     type Gate<TValue, TResult> = {
        match: (value: TValue) => MaybePromise<B>;
        execute: (value: TValue) => MaybePromise<TResult>;
    };

     interface KernelContext {
        self: A;
        config: A;
        variables: A;
    }
     type ConditionMode = 'switch' | 'if' | 'ifelse';


    type GateMap2<TValue, TResult> = Record<S, Gate<TValue, TResult>
    >;
    type GateMasterOptions2 = {
        mode?: "concurrent" | "sequential";
        execution?: "all" | "first";
    };
    // #endregion
    // #region ══ RUNE HTTP ════════════════════════════════════════════════════════════════════

    interface RuneHTTPBatchOptions {
        name?: S;
        sequential?: B;
        concurrent?: B;
        retry?: N;
        timeout?: N;
        cache?: S;
        cacheTTL?: N;
        retry_delay?: N;
        retry_strategy?: S;
        circuit_breaker?: { failureThreshold: N; timeout: N };
        on_progress?: (progress: { percentage: N }) => V;
        signal?: AbortSignal;
        transform_request?: (data: A) => A;
        transform_response?: (data: A) => A;
        validate_status?: (status: N) => B;
        validate_response?: (data: A) => B;
        interceptors_request?: (config: A) => A;
        interceptors_response?: (res: A) => A;
        on_success?: (data: A) => V;
        on_error?: (error: A) => V;
    };
    // #endregion
    // #region ══ GENERICS ════════════════════════════════════════════════════════════════════
type StubHit = { category: S; key: S; prop: S; location: A };
const GRAPH_KEYS = ['types', 'enum', 'interface', 'generic'] as const;

    type GraphKey = typeof GRAPH_KEYS[N];
type ExtractFactory<A1, A2> =
    A1 extends S
    ? Extract<A2, (...args: A[]) => A>
    : Extract<A1, (...args: A[]) => A>
interface CloudState {
    get<T>(key: S | symbol): T | UD;
    set<T>(key: S | symbol, value: T | ((prev: T | UD) => T)): V;
    subscribe<T>(key: S | symbol, listener: (value: T) => V): () => V;
    clear(): V;
}
type Factory = (ctx: { self: A }) => Record<S, A>;
type ConcentrationGenericsCtx = { self: A;[category: S]: A };
type CGFactory = (ctx: ConcentrationGenericsCtx) => Record<S, A>
type types<C> = { [K in keyof ReturnType<Extract<C, (...args: A[]) => A>>]: ReturnType<Extract<C, (...args: A[]) => A>>[K] extends { types: infer T } ? T : never }
type __location = { file: S; line: N; column: N; functionName: S }
type KernelTypeParameter = {
    helpers: {
        generateTypeString: (typeDef: A, paramValues?: Record<S, S>) => S
        validateGenericUsage: (typeDef: A, providedParams: S[]) => B
    }
}
type arg1<C> = S | C
type arg2<C> = C | KernelTypeParameter

type AnySelfType = { self: A;[key: S]: A };
type AnyObject = Record<S, A>;
type AnyFactory = (ctx: AnySelfType) => AnyObject;
type AnyType = AnyObject | AnyFactory;
type concentrationTypeRef =
    | { kind: "Named"; name: S; args?: concentrationTypeRef[] }
    | { kind: "Union"; types: concentrationTypeRef[] }
    | { kind: "Function"; params: { name: S; type: concentrationTypeRef }[]; returnType: concentrationTypeRef }
    | { kind: "Object"; fields: Record<S, { type: concentrationTypeRef; optional?: B }> }
type concentrationGeneric = {
    name: S
    typeParameters: concentrationTypeParameter[]
    signature: concentrationTypeRef // always a Function here
}
type SubstEnv = Record<S, concentrationTypeRef>



interface CGInterface<C> {
    arg1: arg1<C>
    arg2?: C | KernelTypeParameter
    arg3?: KernelTypeParameter
}
type concentrationTypeFlags = | "Any" | "Unknown" | "Boolean" | "Number" | "String" | "Object" | "Function" | "TypeParameter" | "Union" | "Intersection"
type concentrationTypeEnv = Record<S, concentrationTypeId>
type concentrationTypeId = S
type concentrationTypeParameter = {
    id: concentrationTypeId
    name: S
    constraint?: concentrationTypeId
    default?: concentrationTypeId
}
type concentrationSignature = {
    typeParameters?: concentrationTypeParameter[]
    parameters: { name: S; type: concentrationTypeId }[]
    returnType: concentrationTypeId
}
type concentrationType = {
    id: concentrationTypeId
    flags: concentrationTypeFlags[]
    name?: S
    signatures?: concentrationSignature[]
    aliasOf?: concentrationTypeId
}

    // #endregion
   // #region ══ CHAINS ════════════════════════════════════════════════════════════════════
    interface PortalHostContext {
    CH_1: Channel;
    CH_2: Channel;
    CH_3: Channel;
    CH_4: Channel;
    _hlc: HLC;
    _sub<T = any>(
        handler: (p: T) => void,
        k: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): UnsubscribeFn;
    _send<T = any>(
        p: T,
        k: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): void;
    sub<T = any>(
        handler: (p: T) => void,
        k: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): UnsubscribeFn;
    stateDRS(
        k: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): any;
    useStateCRDT<T = any>(
        initial: T,
        key: string,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): readonly [T, Setter<T>];
    DRSStore<T = any>(
        initialValue: T | (() => T),
        key: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): StoreSignal<T>;
}
 interface PortalReadFn {
    (
        k: string,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): void;
}
 interface PortalStateReadFn {
    (
        initial?: any,
        k?: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): any;
}
 interface PortalStateUseFn {
    (
        initial?: any,
        k?: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel,
        trigger_render?: boolean
    ): any
}
 interface DRS_F1N {
    (k: string, sl: string, ms: string, rt: string): any;

    mailbox(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): any

    use(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): any

    effect: {
        (effect: () => void | (() => void), deps: any[], k: string, sl: string, ms: string, rt: string): any;
        auto(effect: (scope: ReturnType<typeof createLiveScope>) => void, deps: any[], k: string, sl: string, ms: string, rt: string): any;
    };
    state: {
        (k: string, sl: string, ms: string, rt: string): any;
        use(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): any
        mesh<T = any>(key: string, initial?: T, reactor?: StateMeshReactor<T>, k?: SU, sl?: SU, ms?: SU, rt?: SU): StateMesh<T>;
    };
    store: {
        (initialValue?: any | (() => any), k?: SU, sl?: SU, ms?: SU, rt?: SU): any
        use(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    };
    db: {
        <T = any>(initial: T, k: string, sl: string, ms: string, rt: string): any
        use<T extends string | object>(initial: T, k: string, sl: string, ms: string, rt: string): any
        optimistic<T extends string | object>(initial: T, k: string, sl: string, ms: string, rt: string): any
        rt: {
            <T = any>(initial: T, k: string, sl: string, ms: string, rt: string): Promise<T | null>
            use<T extends string | object>(initial: T, db: 'rdb' | 'kvdb' | 'tdb' | 'vdb' | 'gdb' | 'memory', k: string, sl: string, ms: string, rt: string): Promise<T | null>
        }
        raft: {
            <T = any>(initial: T, k: string, sl: string, ms: string, rt: string): any
            rx<T = any>(initial?: any, db?: 'rdb' | 'kvdb' | 'tdb' | 'vdb' | 'gdb' | 'memory', k?: SU, sl?: SU, ms?: SU, rt?: SU): any
        }
        yata: {
            <T = string>(k: string, sl: string, ms: string, rt: string): any
            rx<T = string>(initial?: T[], db?: 'rdb' | 'kvdb' | 'tdb' | 'vdb' | 'gdb' | 'memory', k?: SU, sl?: SU, ms?: SU, rt?: SU): any
        }
        crdt(k: string, sl: string, ms: string, rt: string): any
    };


}
 interface useEffect_FN {
    (effect: () => void | (() => void), deps: any[], k: string, sl: string, ms: string, rt: string): any;
    auto(effect: (scope: ReturnType<typeof createLiveScope>) => void, deps: any[], k: string, sl: string, ms: string, rt: string): any;

}

    type SEQ__FN = {
    (
        step:
            | ((input: any, done: (output?: any, err?: unknown) => void) => void)
            | ((input: any) => Producible<any>),
    ): ChainSelf;
    stream: (fn: (input: any) => Producible<any>) => ChainSelf;
    fn: (fn: (input: any, done: (output?: any, err?: unknown) => void) => void) => ChainSelf;
};
 interface SchedulerEventMap {
    "tick": CustomEvent<{ tick: number; passes: number; load: number }>;
    "idle": CustomEvent<{ idleTicks: number }>;
    "start": CustomEvent<{ priority: Priority }>;
    "stop": CustomEvent<{ reason: "idle" | "manual" | "error" }>;
    "task:enqueue": CustomEvent<{ task: Task; priority: Priority; scope?: string }>;
    "task:start": CustomEvent<{ task: Task; priority: Priority }>;
    "task:end": CustomEvent<{ task: Task; priority: Priority; duration: number }>;
    "task:cancel": CustomEvent<{ task: Task; reason?: unknown }>;
    "task:error": CustomEvent<{ task: Task; error: unknown }>;
    "backpressure": CustomEvent<{ queueDepth: number; highWaterMark: number }>;
    "yield": CustomEvent<{ to: "microtask" | "macrotask" | "animation" }>;
}
 type SchedulerEventType = keyof SchedulerEventMap;
 type EventOf<K extends SchedulerEventType> = SchedulerEventMap[K];
 type SchedulerListener<K extends SchedulerEventType> =
    | ((ev: SchedulerEventMap[K]) => void)
    | { handleEvent(ev: SchedulerEventMap[K]): void };
 interface SchedulerObservableFn {
    // The function itself (callable form, kept for parity with o/v/e/r/p/d/l/st/t)
    <T = any>(subscribe: (subscriber: Subscriber<T>) => Teardown): Producible<T>;

    // ── EventTarget surface ──
    addEventListener<K extends SchedulerEventType>(
        type: K,
        listener: SchedulerListener<K>,
        options?: boolean | AddEventListenerOptions,
    ): void;

    // Fallback overload for arbitrary strings (parity with DOM EventTarget)
    addEventListener(
        type: string,
        listener: EventListenerOrEventListenerObject,
        options?: boolean | AddEventListenerOptions,
    ): void;

    dispatchEvent<K extends SchedulerEventType>(event: SchedulerEventMap[K]): boolean;
    dispatchEvent(event: Event): boolean;

    removeEventListener<K extends SchedulerEventType>(
        type: K,
        callback: SchedulerListener<K> | null,
        options?: EventListenerOptions | boolean,
    ): void;

    removeEventListener(
        type: string,
        callback: EventListenerOrEventListenerObject | null,
        options?: EventListenerOptions | boolean,
    ): void;
}
 type SCHEDULER_OBSERVABLE_FN = SchedulerObservableFn;
 type SIGNALS__FN = {
    (data?: any, k?: string, sl?: string, ms?: string, rt?: string): _SIGNALS_CHAINS;

    create: () => void;
    read: () => void;
    write: () => void;
    subscribe: () => void;
    effect: () => void;
    computed: () => void;

    map: () => void;
    filter: () => void;
    sub: () => void;
    pipe: () => void;
    streamed: () => void;   // streamed value, no setter
    duplexed: () => void;   // getter + setter

    drs: () => void;
    useDRS: () => void;
    useEffectDRS: () => void;
    useMemoDRS: () => void;
    useReducerDRS: () => void;
    createContext: () => void;
    useContext: () => void;
    setHC: () => void;
    getHC: () => void;
    deleteHC: () => void;

    stream: () => void;
    relay: () => void;
    send: () => void;
};
 type CRDT__FN = {
    (): void;

    or_set<T = any>(key: string): SIGNALS_CHAIN;
    lww<T = any>(key: string, initial?: T): SIGNALS_CHAIN;
    pn_counter<T extends PN_COUNTER = PN_COUNTER>(key: string): SIGNALS_CHAIN;
};
 type YATA_FN = {
    <T = any>(): any;
    comments(doc: CollabDoc, field: string): CollabComments;

};
 type SS_FN = {
    // ── callable: creates a signal handle ────────────────────────────────────────────────────
    <T = any>(initial: T, options?: SignalOptions<T>): SignalHandle<T>;

    // ── ergonomic helpers ────────────────────────────────────────────────────────────────────
    sysEffect(fn: () => void | (() => void)): () => void;
    computed<T = any>(fn: () => T): ComputedHandle<T>;

    // ── internals exposed on the namespace ───────────────────────────────────────────────────
    _bindComponentToSignal(rk: string): void;
    _validateSchema(rk: string, value: any): any;
    _hashTuple(tuple: unknown[]): string;
    _recordCausal(rk: string, value: any, source: string, cause?: string): void;
    _resolveConflict(rk: string, prev: any, next: any): any;
    _writeResolved(rk: string, value: any, source: string, cause?: string): void;

    // ── key + schema ─────────────────────────────────────────────────────────────────────────
    resolveKey(key: any): string;
    registerSchema<T = any>(key: any, schema: SignalSchema<T>): void;

    // ── signal CRUD ──────────────────────────────────────────────────────────────────────────
    create<T = any>(key: any, initial?: T | (() => T), options?: SignalOptions<T>): string;
    write<T = any>(key: any, value: T | ((prev: T | undefined) => T), source?: string): void;
    read<T = any>(key: any): T | undefined;
    peek<T = any>(key: any): T | undefined;
    subscribe<T = any>(key: any, fn: (value: T, source?: string) => void): () => void;
    has(key: any): boolean;
    delete(key: any): void;

    // ── signal state modifiers ───────────────────────────────────────────────────────────────
    freeze(key: any): void;
    seal(key: any): void;
    reset(key: any): void;
    hydrate<T = any>(key: any, value: T): void;
    clone(srcKey: any, destKey: any): void;

    // ── persistence ──────────────────────────────────────────────────────────────────────────
    persist<T = any>(key: any, value: T, options?: { serialize?: (v: T) => string }): Promise<void>;
    unpersist(key: any): Promise<void>;

    // ── messaging ────────────────────────────────────────────────────────────────────────────
    sub<T = any>(key: any, fn: (p: T) => void): () => void;
    send(p: any, fromKey: any, toKey: any, ms?: string, rt?: string): void;

    // ── derived ──────────────────────────────────────────────────────────────────────────────
    derive<T = any>(
        key: any,
        deps: any[],
        compute: (...values: any[]) => T,
        options?: { eager?: boolean; onError?: (err: Error) => void }
    ): string;
    invalidateDerived(key: any): void;

    // ── async ────────────────────────────────────────────────────────────────────────────────
    createAsync<T = any>(
        key: any,
        fetcher: (signal: AbortSignal) => Promise<T>,
        options?: { fallback?: T }
    ): AsyncSignalHandles;
    invalidateAsync(key: any): void;
    mutateAsync<T = any>(key: any, optimistic: T): void;
    abortAsync(key: any): void;
    prefetchAsync<T = any>(key: any, fetcher: () => Promise<T>): void;
    readAsync<T = any>(key: any): T;

    // ── batch / tx ───────────────────────────────────────────────────────────────────────────
    batch(fn: () => void): void;
    tx(fn: () => void): void;
    transaction(block: () => void): void;

    // ── history / time travel ────────────────────────────────────────────────────────────────
    enableHistory(key: any, options: { max: number }): void;
    undo(key: any): void;
    redo(key: any): void;
    signalTimeline(key: any): SignalTimelineEntry[];
    snapshot(): Record<string, any>;
    restore(snapshot: Record<string, any>): void;
    diffSnapshots(a: Record<string, any>, b: Record<string, any>): Record<string, { from: any; to: any }>;
    applyPatch(patch: Record<string, { from: any; to: any }>): void;
    replay(key: any, options?: { speed?: number }): Promise<void>;

    // ── causal / conflict / contracts ────────────────────────────────────────────────────────
    getCausalChain(key: any): CausalEntry[];
    conflictPolicy<T = any>(key: any, policy: ConflictPolicy<T>): void;
    declareContract(
        name: string,
        key: any,
        postcondition: (next: any, prev: any) => boolean,
        options?: { block?: boolean }
    ): void;
    removeContract(name: string): void;

    // ── scopes ───────────────────────────────────────────────────────────────────────────────
    createScope(id: string): SignalScopeHandle;

    // ── effects ──────────────────────────────────────────────────────────────────────────────
    effect(
        keys: any,
        fn: (...values: any[]) => (() => void) | void | Promise<(() => void) | void>
    ): () => void;
    effectOnce(
        keys: any[],
        predicate: (...v: any[]) => boolean,
        fn: (...v: any[]) => void
    ): () => void;

    // ── operators ────────────────────────────────────────────────────────────────────────────
    map<A = any, B = any>(srcKey: any, destKey: any, fn: (v: A) => B): () => void;
    filter<T = any>(srcKey: any, destKey: any, pred: (v: T) => boolean): () => void;
    debounce(sourceKey: any, delay: number): [string, () => void];
    throttle(srcKey: any, destKey: any, ms: number): () => void;
    merge(srcKeys: any[], destKey: any): () => void;
    zip(srcKeys: any[], destKey: any): () => void;
    combine(srcKeys: any[], destKey: any): () => void;
    scan<T = any, A = any>(srcKey: any, destKey: any, reducer: (a: A, v: T) => A, seed: A): () => void;
    switch(srcKey: any, destKey: any): () => void;
    buffer(srcKey: any, destKey: any, count: number): () => void;
    window(srcKey: any, destKey: any, ms: number): () => void;
    distinct<T = any>(srcKey: any, destKey: any, equals?: (a: T, b: T) => boolean): () => void;
    audit(srcKey: any, destKey: any, ms: number): () => void;
    sample(srcKey: any, triggerKey: any, destKey: any): () => void;
    gate(srcKey: any, gateKey: any, destKey: any): () => void;
};
 interface STREAMS_FN {
    (p: any, onChunk: (chunk: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): Promise<void>;
    chains(data?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): any;
    readable(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): ReadableStream<any>;
    writable(k?: SU, sl?: SU, ms?: SU, rt?: SU): WritableStream<any>;
    duplex(readConfig: {
        k: string;
        sl?: string | undefined;
        ms?: string | undefined;
        rt?: string | undefined;
    }, writeConfig: {
        k?: string | undefined;
        sl?: string | undefined;
        ms?: string | undefined;
        rt?: string | undefined;
    }): {
        sub: ReadableStream<any>;
        send: WritableStream<any>;
    };
    StreamRelay(k?: SU, sl?: SU, ms?: SU, rt?: SU, opts?: StreamRelayOptions): any;
    transform(readConfig: {
        k: string;
        sl?: string | undefined;
        ms?: string | undefined;
        rt?: string | undefined;
    }, writeConfig: {
        k?: string | undefined;
        sl?: string | undefined;
        ms?: string | undefined;
        rt?: string | undefined;
    }, transformer?: (chunk: any) => any | Promise<any>): {
        sub: TransformStream<any, any>;
        send: TransformStream<any, any>;
    };
    pipeline<T = any>(k?: SU, sl?: SU, ms?: SU, rt?: SU, stages?: HydraStage<T>[]): {
        unsubscribe: () => void;
    };
    route<T = any>(k?: SU, sl?: SU, ms?: SU, rt?: SU, selectKey?: (p: T) => string, outPrefix?: string, opts?: {
        defaultKey?: string;
        onUnmatched?: (p: T, key: string) => void;
    }): {
        unsubscribe: () => void;
        stats: () => Record<string, number>;
    };
    from: {
        emitter(k?: SU, sl?: SU, ms?: SU, rt?: SU): Producible<any>;
        signal(sauron: SignalSurface, key: any): Producible<any>;
        any(src: any): Producible<any>;
        busChannel<T = any>(k?: SU, sl?: SU, ms?: SU, rt?: SU): Producible<T>;
        relay<T = any>(k?: SU, sl?: SU, ms?: SU, rt?: SU): Producible<T>;
    };
    to: {
        emitter(obs: Producible<any>, k?: SU, sl?: SU, ms?: SU, rt?: SU): Teardown;
        busChannel<T = any>(k?: SU, sl?: SU, ms?: SU, rt?: SU): (source: Producible<T>) => Producible<T>;
        relay(k?: SU, sl?: SU, ms?: SU, rt?: SU, outs?: string[]): {
            unsubscribe: () => void;
        };
    };
    syncGuard(chunks: any[], k: string, options?: SyncIntegrityOptions): Promise<SyncIntegrityResult>;
    relayWithFlowControl(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, options?: RelayFlowOptions): any;
    useDRSWithConsensus(initialState: any, k?: SU, sl?: SU, ms?: SU, rt?: SU, options?: DRSConflictOptions): any;
    sync(chunks: any[], k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, onAck?: (seq: number) => void, windowSize?: number, binary?: boolean): Promise<void>;
    relay(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, options?: {
        maxSubscribers?: number;
        bufferSize?: number;
        backpressureStrategy?: 'drop' | 'pause' | 'error';
    }): any;
    openSync(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        windowSize?: number;
    }): any;
    priority(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    transactional(chunks: any[], k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): Promise<{
        committed: boolean;
        error?: string;
    }>;
    delta<T extends any>(computeDelta: (prev: T, next: T) => any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    presence(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    authority<T = any>(initial: T, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    heartbeat(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        idleThresholdMs?: number;
    }): any;
    compression(p: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        threshold?: number;
    }): Promise<void>;
    backpressure(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        windowSize?: number;
    }): any;
    stateful(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        key?: string;
    }): any;
    multicast(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        key?: string;
    }): any;
    partitioned(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        partitionCount?: number;
    }): any;
    batch(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        maxSize?: number;
        maxWaitMs?: number;
    }): any;
    filtered(predicate: (p: any) => boolean, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    deadLetter(p: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        maxRetries?: number;
        backoff?: BackoffOptions;
    }): Promise<{
        delivered: boolean;
    }>;
    idempotent(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    lateArrival(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    checkpoint(streamKey: string, opts?: {
        every?: number;
    }): any;
    rateLimited(opts: {
        ratePerSecond: number;
        burst?: number;
    }, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    combo(k: string, sl: string[], ms?: string | undefined, rt?: string | undefined, strategy?: ComboStrategy): any;
    transformative(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    fanout(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        key?: string;
    }): any;
    useDRSS<T extends Record<string, unknown> = any, P = any>(initial: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): any;
    useDRSSSync(initial: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): any;
}
 interface OpenSyncHandle {
    push: (p: any) => void;
    pendingCount: () => number;
    close: () => void;
}
 interface PriorityHandle {
    push: (p: any) => void;
}
 interface DeltaHandle<T> {
    push: (next: T) => Promise<void>;
    reset: () => void;
}
 interface PresenceHandle {
    announce: (participantId: string, state: Record<string, any>) => void;
    clear: (participantId: string) => void;
}
 interface AuthorityHandle<T> {
    predict: (guess: T) => void;
    get: () => T;
    onChange: (handler: (value: T, wasCorrected: boolean) => void) => () => void;
    destroy: () => void;
}
 interface HeartbeatHandle {
    markAlive: () => void;
    lastSeen: () => number;
    close: () => void;
}
 interface BackpressureHandle {
    push: (p: any) => void;
    pendingCount: () => number;
    close: () => void;
}
 interface StatefulHandle {
    push: (p: any) => Promise<void>;
    replay: (handler: (p: any) => void) => Promise<void>;
    getCursor: () => number;
}
 interface MulticastHandle {
    push: (p: any) => Promise<void>;
}
 interface PartitionedHandle {
    push: (key: string, p: any) => Promise<void>;
    partitionOf: (key: string) => number;
    partitionCount: number;
}
 interface BatchHandle {
    push: (p: any) => void;
    flushNow: () => Promise<void>;
    pendingCount: () => number;
}
 interface FilteredHandle {
    push: (p: any) => Promise<void>;
}
 interface IdempotentHandle {
    push: (idempotencyKey: string, p: any) => Promise<void>;
}
 interface LateArrivalHandle {
    push: (p: any) => Promise<void>;
}
 interface CheckpointHandle {
    ready: Promise<void>;
    advance: (newPosition: number) => Promise<void>;
    saveNow: () => Promise<void>;
    getPosition: () => number;
}
 interface RateLimitedHandle {
    push: (p: any) => void;
    pendingCount: () => number;
    availableTokens: () => number;
}
 interface ComboHandle {
    onData: (handler: (chunk: any, source: string) => void) => () => void;
    close: () => void;
}
 interface TransformativeHandle {
    push: (p: any) => Promise<void>;
}
 interface RelayFlowHandle {
    publish: (chunk: any) => Promise<void>;
    subscribe: (handler: (chunk: any, sequence: number) => void) => {
        id: string;
        unsubscribe: () => void;
        pause: () => void;
        resume: () => void;
        getBufferSize: () => number;
        getSequence: () => number;
        flushBuffer: () => void;
    };
    end: () => Promise<void>;
}
 interface useDRS_SIGNALS_FN {
    (initial?: any, k?: string, sl?: string, ms?: string, rt?: string): any;
    stream<T = any>(initial?: T, k?: SU, sl?: SU, ms?: SU, rt?: SU, opts?: any): any
    duplex<T = any>(initial?: T, k?: SU, sl?: SU, ms?: SU, rt?: SU, opts?: any): any
    crdt<T = any>(initial?: T, k?: SU, sl?: SU, ms?: SU, rt?: SU, nodeId?: any): any
    topology(k?: SU, sl?: SU, ms?: SU, rt?: SU, selfId?: any, opts?: any): any
    time_travel(k?: SU, sl?: SU, ms?: SU, rt?: SU, selfId?: any): any
    gated(predicate: any, value: any, deps: any[], k: SU, sl?: SU, ms?: SU, rt?: SU, selfId?: any): any

    transaction<T = any>(k: SU, sl?: SU, ms?: SU, rt?: SU): any
    signal<T = any>(initial?: T | (() => T), k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    graph(k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    distributed(k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    synchronization(k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    replication(k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    resilience(k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    temporal(k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    mesh<T = any>(initial?: T, reactor?: StateMeshReactor<T>, k?: SU, sl?: SU, ms?: SU, rt?: SU,): StateMesh<T>
    store(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    mailbox(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    mailbox2(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    stateStore(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    liveStore(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU, nodeId?: string | undefined): any
    live(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    raft<TState = any>(initial?: TState | (() => TState), clusterId?: string, nodeId?: string, peerIds?: string[], sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any
    observable<T>(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    ref(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    umbrella(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    context(initial?: Record<string, any>, k?: SU, sl?: SU, ms?: SU, rt?: SU): any
    db: {
        <T = any>(initial: T, k: string, sl: string, ms: string, rt: string): any;
        optimistic<T = any>(initial: T, k: string, sl: string, ms: string, rt: string): any;
        crdt<T = any>(k: string, sl: string, ms: string, rt: string): any
        rt<T = any>(initial: T, db: 'rdb' | 'kvdb' | 'tdb' | 'vdb' | 'gdb' | 'memory', k: string, sl: string, ms: string, rt: string): any
        raft: {
            <T = any>(initial: T, k: string, sl: string, ms: string, rt: string): any;
            rx<T = any>(initial?: any, db?: 'rdb' | 'kvdb' | 'tdb' | 'vdb' | 'gdb' | 'memory', k?: SU, sl?: SU, ms?: SU, rt?: SU): any
        }
        yata: {
            <T = any>(k: string, sl: string, ms: string, rt: string): any;
            rx<T = any>(initial?: T[], db?: 'rdb' | 'kvdb' | 'tdb' | 'vdb' | 'gdb' | 'memory', k?: string | undefined, trip_channe?: string | undefined, ms?: string | undefined, rt?: string | undefined): any
        }
    }
}
 interface DeadLetter {
    id: string;
    ts?: number;
    rt: string;
    ms?: string;
    sl?: string;
    k?: string;
    topic?: string;
    p: unknown;
    ttl?: number;
    _ack?: boolean;
    _adapter?: CSEAdapter;
    priority?: CSEPriority;
    tags?: string[];
    streamId?: string;
    sessionId?: any;
    token?: any;
    binary?: 'signal_save_value' | 'signal' | true | false | string;
    error?: any
    adapter_id?: any
    cross_cse_ngin_connect_adapter_id?: any
    cross_app_adapter_adapter_id?: any
}
 interface SwitchboardContext<TPayload = any> {
    p?: TPayload;
    reply?: (data: unknown, targetSc?: string) => Promise<unknown>;
    store?: Map<string, any>;
    bus?: any,
    ctx?: SwitchboardContext<TPayload>,
    predicate?: (msg: any, context?: any) => boolean;
    target?: {
        k?: string;
        sl?: string;
        ms?: string;
        rt?: string;
    };
    priority?: number;
    transform?: (msg: any) => any;
    metadata?: any;
}
 interface SwitchboardOptions {
    routes: SwitchboardRoute[];
    defaultRoute?: {
        k: string;
        sl?: string;
        ms?: string;
        rt?: string;
    };
    mode?: 'first-match' | 'all-matches' | 'priority';
    binary?: boolean;
    ttl?: number;
    onRoute?: (msg: any, route: SwitchboardRoute) => void;
    onNoMatch?: (msg: any) => void;
}
 interface PlinkoLevel {
    name: string;
    matcher: (msg: any, context?: any) => boolean | number | string;
    targets: {
        [key: string]: {
            nextLevel?: PlinkoLevel;
            destination?: {
                k: string;
                sl?: string;
                ms?: string;
                rt?: string;
            };
            transform?: (msg: any) => any;
        };
    };
    defaultTarget?: string;
}
 interface MeshNode {
    id: string;
    processor: (msg: any, context?: any) => Promise<any> | any;
    next: string[]; // IDs of next nodes
    errorHandler?: (err: any, msg: any) => void;
    timeoutMs?: number;
    retryCount?: number;
}
 interface MeshPipelineOptions {
    nodes: Map<string, MeshNode>;
    entryNode: string;
    binary?: boolean;
    ttl?: number;
    concurrency?: number;
    onNodeComplete?: (nodeId: string, msg: any, result: any) => void;
    onNodeError?: (nodeId: string, err: any, msg: any) => void;
    onPipelineComplete?: (msg: any, path: string[]) => void;
}
 type StreamConfig = Record<string, any>;
 type StreamHandler = (p: any, stream: StreamInstance) => void | Promise<void>;
 interface StreamInstance {
    id: string;
    config: StreamConfig;
    rt: string;
    ms: string;
    sl: string;
    k: string;

    // Core methods
    send: (p: any) => void;
    onData: (handler: StreamHandler) => () => void;
    onError: (handler: (error: any) => void) => () => void;
    onRemoteClose: (handler: () => void) => () => void;
    close: () => void;

    // Advanced methods
    sx: (rt?: string, ms?: string, sl?: string, k?: string, binary?: boolean, type?: string) => StreamInstance;
    subscribe: (handler: StreamHandler) => () => void;
    pipe: (target: StreamInstance) => () => void;
    merge: (...streams: StreamInstance[]) => StreamInstance;
    split: (predicate: (p: any) => boolean) => [StreamInstance, StreamInstance];

    // All operation methods
    done: (handler?: StreamHandler) => void;
    cancel: (handler?: StreamHandler) => void;
    relay: (p: any, stream?: StreamInstance) => Promise<void>;
    openSync: (p: any, stream?: StreamInstance) => void;
    openSyncSub: (p: any, stream?: StreamInstance) => void;
    priority: (p: any, stream?: StreamInstance) => void;
    prioritySub: (p: any, stream?: StreamInstance) => void;
    delta: (p: any, stream?: StreamInstance) => void;
    deltaSub: (p: any, stream?: StreamInstance) => void;
    presence: (p: any, stream?: StreamInstance) => void;
    presenceSub: (p: any, stream?: StreamInstance) => void;
    authority: (p: any, stream?: StreamInstance) => void;
    authoritySub: (p: any, stream?: StreamInstance) => void;
    heartbeat: (p: any, stream?: StreamInstance) => void;
    heartbeatSub: (p: any, stream?: StreamInstance) => void;
    sendCompression: (p: any, stream?: StreamInstance) => void;
    compressionSub: (p: any, stream?: StreamInstance) => void;
    backpressure: (p: any, stream?: StreamInstance) => void;
    backpressureSub: (p: any, stream?: StreamInstance) => void;
    partitioned: (p: any, stream?: StreamInstance) => void;
    partitionedSub: (p: any, stream?: StreamInstance) => void;
    batch: (p: any, stream?: StreamInstance) => void;
    batchSub: (p: any, stream?: StreamInstance) => void;
    filtered: (p: any, stream?: StreamInstance) => void;
    filteredSub: (p: any, stream?: StreamInstance) => void;
    deadLetter: (p: any, stream?: StreamInstance) => void;
    deadLetterSub: (p: any, stream?: StreamInstance) => void;
    idempotent: (p: any, stream?: StreamInstance) => void;
    idempotentSub: (p: any, stream?: StreamInstance) => void;
    lateArrival: (p: any, stream?: StreamInstance) => void;
    lateArrivalSub: (p: any, stream?: StreamInstance) => void;
    checkpoint: (p: any, stream?: StreamInstance) => void;
    checkpointSub: (p: any, stream?: StreamInstance) => void;
    rateLimited: (p: any, stream?: StreamInstance) => void;
    rateLimitedSub: (p: any, stream?: StreamInstance) => void;
    combo: (p: any, stream?: StreamInstance) => void;
    comboSub: (p: any, stream?: StreamInstance) => void;
    transform: (p: any, stream?: StreamInstance) => void;
    transformSub: (p: any, stream?: StreamInstance) => void;
    map: (p: any, stream?: StreamInstance) => void;
    filter: (p: any, stream?: StreamInstance) => void;
    reduce: (p: any, stream?: StreamInstance) => void;
    fanout: (p: any, stream?: StreamInstance) => void;
    fanoutHandler: (p: any, stream?: StreamInstance) => void;
    useDRSS: (p: any, stream?: StreamInstance) => void;
    useDRSSHandler: (p: any, stream?: StreamInstance) => void;
    useDRSSSync: (p: any, stream?: StreamInstance) => void;
    useDRSSSyncHandler: (p: any, stream?: StreamInstance) => void;
}
 interface VirtualTask { 
    t: number;
     fn: () => void;
      signal?: AbortSignal;
       cancelled: boolean;
       seq: N
     }
 interface WPJob {
    id: string
    task: () => Promise<unknown>
    taskSource: string
    args: any[]
    priority: Priority
    resolve: (v: unknown) => void
    reject: (e: unknown) => void
    timeoutMs?: number
    timer?: ReturnType<typeof setTimeout>
}

 type _sid = () => string;
 type DBKind = 'rdb' | 'kvdb' | 'tdb' | 'vdb' | 'gdb' | 'memory';
 interface LiveScope {
    dispose(): void;
    add(cleanup: () => void): void;
}
 type createLiveScope = () => LiveScope;
type transition = <T = any, A = any>(action: A, reactor?: StateMeshReactor<T, A>) => any;
type transition2 = <T = any, A = any>(action: A, reactor?: StateMeshReactor<T, A>) => any;
 interface DRSStreamAuthority<T = any> {
    predict(guess: T): void;
    get(): T;
    onChange(cb: (value: T, wasCorrected: boolean) => void): () => void;
}
 type Channel<S = any> = S;
 type MarkType =
    | 'bold'
    | 'italic'
    | 'underline'
    | 'strike'
    | 'code'
    | 'link'
    | string;
 type DocLifecycleStatus =
    | 'active'
    | 'archived'
    | 'canonical'
    | 'draft'
    | string;
 interface FormattedRun {
    text: string;
    marks?: string[];
    [key: string]: any;
}
 interface Awareness<T = any> extends Observable<T> {
    all(): Record<string, AwarenessState>;
    get(userId: string): AwarenessState | undefined;
    set(userId: string, state: AwarenessState): void;
    clear(userId: string): void;
}
 interface Presence<T = any> extends Observable<T> {
    watchers(): Record<string, FieldTouch>;
    announce(
        userId: string,
        p: { field: string; action: 'viewing' | 'editing' }
    ): void;
    clear(userId: string): void;
}
 interface YMapLike<T = any> extends Observable<T> {
    get(key: string): T | undefined;
    set(key: string, value: T): void;
    delete(key: string): void;
    toObject(): Record<string, T>;
    undo(): void;
    redo(): void;
}
 interface YTextLike<T = any> extends Observable<T> {
    toString(): string;
}
 interface YRichTextLike<T = any> extends Observable<T> {
    toString(): string;
}
 interface YRichText<T = any> extends Observable<T> {
    insertAt(index: number, content: string): void;
    deleteAt(index: number): void;
    applyMark(type: MarkType, startIndex: number, endIndex: number): void;
    removeMark(type: MarkType, startIndex: number, endIndex: number): void;
    undoMark(): void;
    redoMark(): void;
    toFormattedRuns(): FormattedRun[];
    useFormattedText(): [FormattedRun[], () => void];
}
 interface CommentThreadLike<T = any> extends Observable<T> {
    id: string;
}
 interface CommentsHandle<T = any> extends Observable<T> {
    all(): Comment[];
    add(userId: string, index: number, body: string): Comment;
    resolve(id: string): void;
    currentIndex(id: string): number;
    map: Observable<T>;
}
 interface StaffChannels {
    CH_1: Channel;
    CH_2: Channel;
    CH_3: Channel;
    CH_4: Channel;
}
 interface StaffContext {
    CH_1: Channel;
    CH_2: Channel;
    CH_3: Channel;
    CH_4: Channel;
    yata_ngin: {
        doc(
            id: string,
            config?: DocConfig,
            k?: Channel,
            sl?: Channel,
            ms?: Channel,
            rt?: Channel
        ): Promise<CollabDoc>;
    };
    drs: {
        useStateDRS<T>(
            handler: (p: T) => void,
            topic: string,
            pattern: string,
            ms?: Channel,
            rt?: Channel
        ): [T | undefined, (value: T | undefined) => void];
    };
    sub(
        handler: (...args: any[]) => void,
        topic: string,
        pattern: string,
        ms?: Channel,
        rt?: Channel
    ): () => void;
}
 interface MapResult<T = any> {
    state: Record<string, T>;
    map: any;
    get(key: string): T | undefined;
    set(key: string, value: T): void;
    delete(key: string): void;
    undo(): void;
    redo(): void;
}
 interface CommentsResult {
    state: Comment[];
    comments: CommentsHandle;
    all(): Comment[];
    add(userId: string, index: number, body: string): Comment;
    resolve(id: string): void;
    currentIndex(id: string): number;
}
 interface PresenceResult {
    state: Record<string, FieldTouch>;
    presence: Presence;
    watchers(): Record<string, FieldTouch>;
    announce(
        userId: string,
        field: string,
        action: 'viewing' | 'editing'
    ): void;
    clear(userId: string): void;
}
 interface SessionResult {
    state: DocLifecycleState;
    session: any;
    status: DocLifecycleStatus;
    acl: Record<string, DocRole>;
    canonicalVersion: number;
    canEdit(userId: string): boolean;
    grantAccess(userId: string, role: DocRole): void;
    revokeAccess(userId: string): void;
    archive(): void;
    markCanonical(version: number): void;
    dispatch(command: any): void;
}
 interface TextResult {
    state: { text: string; marks: string[]; }[];
    text: CollabText;
    insertAt(index: number, content: string): void;
    deleteAt(index: number): void;
    applyMark(type: MarkType, startIndex: number, endIndex: number): void;
    removeMark(type: MarkType, startIndex: number, endIndex: number): void;
    undoMark(): void;
    redoMark(): void;
    refresh(): void;
    toFormattedRuns(): FormattedRun[];
}
 interface AwarenessResult {
    state: Record<string, AwarenessState>;
    awareness: Awareness | undefined;
}
 interface DRS_Effect_FN {
    (k: Channel, sl?: Channel, ms?: Channel, rt?: Channel): any;
    auto(
        effect: (scope: LiveScope) => void,
        deps?: any[],
        k?: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): void;
}
 interface DRS_State_FN {
    (k: Channel, sl?: Channel, ms?: Channel, rt?: Channel): any;
    use(initial?: any, k?: Channel, sl?: Channel, ms?: Channel, rt?: Channel):
        readonly [any, (next: any) => void];
    mesh<T = any, A = any>(
        key: string,
        initial?: T,
        reactor?: StateMeshReactor<T, A>,
        k?: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): StateMesh<T, A>;
}
 interface DRS_Store_FN {
    (
        initialValue?: any | (() => any),
        key?: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): {
        value: any;
        subscribe(fn: (val: any) => void): () => void;
        destroy(): void;
        resolvedKey: string;
    };
    use(initial?: any, k?: Channel, sl?: Channel, ms?: Channel, rt?: Channel):
        readonly [any, (next: any) => void];
}
 interface DRS_DB_RT_FN {
    <T = any>(k: Channel, sl?: Channel, ms?: Channel, rt?: Channel): Promise<T | null>;
    use<T extends string | object>(
        initial: T,
        db?: DBKind,
        k?: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): readonly [T, (next: T | ((prev: T) => T)) => void];
}
 interface DRS_DB_Raft_FN {
    <T = any>(initial: T, k: Channel, sl?: Channel, ms?: Channel, rt?: Channel):
        readonly [T, (next: T) => Promise<void>];
    rx<T = any>(
        initial?: any,
        db?: DBKind,
        k?: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): readonly [T, (next: T) => Promise<void>];
}
 interface DRS_DB_Yata_FN {
    <T = string>(k: Channel, sl?: Channel, ms?: Channel, rt?: Channel): {
        value: T[];
        insertAt(index: number, value: T): void;
        deleteAt(index: number): void;
    };
    rx<T = string>(
        initial?: T[],
        db?: DBKind,
        k?: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): {
        value: T[];
        insertAt(index: number, value: T): Promise<void>;
        deleteAt(index: number): Promise<void>;
    };
}
 interface DRS_DB_FN {
    <T = any>(initial: T, k: Channel, sl?: Channel, ms?: Channel, rt?: Channel): {
        get(): T;
        onChange(handler: (value: T) => void): () => void;
    };
    use<T extends string | object>(
        initial: T,
        k: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): readonly [T, (next: T | ((prev: T) => T)) => void];
    optimistic<T extends string | object>(
        initial: T,
        k: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): {
        setSnapshotSource(fn: () => T): void;
        setReconciler(fn: (guess: T) => T | Promise<T>): () => void;
        apply(guess: T): void;
        confirm(): T;
        fail(): void;
        getState(): T;
        isPending(): boolean;
        pendingCount(): number;
        on(event: 'change', handler: (value: T, wasCorrected: boolean) => void): () => void;
    };
    rt: DRS_DB_RT_FN;
    raft: DRS_DB_Raft_FN;
    yata: DRS_DB_Yata_FN;
}

 interface LIVE_STORE_FN {
    (initial?: any, k?: Channel, sl?: Channel, ms?: Channel, rt?: Channel): any;

    use(
        initial?: any,
        k?: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel,
        nodeId?: string
    ): readonly [any, (next: any) => void];
}
 interface CRDT_FN {
    (initial?: any, k?: Channel, sl?: Channel, ms?: Channel, rt?: Channel): any;

    use(
        initial?: any,
        k?: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel,
        nodeId?: string
    ): readonly [any, (next: any) => void];
}
 interface LIVE_FN {
    (k: Channel, sl?: Channel, ms?: Channel, rt?: Channel): any;
}
 interface DB_STREAN_FN {
    (k?: Channel, sl?: Channel, ms?: Channel, rt?: Channel): any;
    rt(k?: Channel, sl?: Channel, ms?: Channel, rt?: Channel): any;
}
 interface ShadowSignal<T = any> {
    get(): T;
    set(value: T | ((prev: T) => T)): void;
    subscribe(fn: (value: T) => void): () => void;
    destroy(): void;
    exists(): boolean;
}
 interface ShadowTTLSignal<T = any> {
    get(): T | null;
    set(value: T | ((prev: T) => T)): void;
    subscribe(fn: (value: T | null) => void): () => void;
    refresh(): void;
    destroy(): void;
    exists(): boolean;
    getTimeRemaining(): number;
}
 interface ShadowBatchSignal<T extends Record<string, any> = any> {
    get(): T;
    set(updates: Partial<T> | ((prev: T) => Partial<T>)): void;
    subscribe(fn: (value: T) => void): () => void;
    flush(): void;
}
 interface PORTAL_Context_FN {
    (initial?: Record<string, any>, k?: Channel, sl?: Channel, ms?: Channel, rt?: Channel, trigger_render?: boolean):
        [Record<string, any>, (next: any) => void];
    create(): void;
}
 interface UnsubscribeFn {
    (): void;
}
 interface CRDTState<T = any> {
    adds?: any[];
    removes?: any[];
    _hlc?: any;
    data?: T;
    timestamps?: Record<keyof T, string>;
}
 interface BusEnvelope<T = any> {
    app?: string;
    value?: T;
    from?: symbol;
    _hlc?: any;
    [key: string]: any;
}
 interface WizardConfig {
    app: {
        display_name?: string;
        name: string;
    };
}
 type Setter<T> = (next: T | ((prev: T) => T)) => void;

 interface PortalUseFn {
    <T = any>(
        initial?: T | (() => T),
        k?: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): readonly [T, Setter<T>];
}
 interface PortalCRDTFn {
    <T = any>(
        initial?: T | (() => T),
        k?: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel,
        trigger_render?: boolean,
        nodeId?: string
    ): readonly [T, Setter<T>];
}
 type UmbrellaState<T extends Record<string, any> = Record<string, any>> = T;
 interface PortalUmbrellaFn {
    (
        initial?: Record<string, any>,
        k?: string,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel,
        trigger_render?: boolean
    ): readonly [Record<string, any>, Setter<any>];
}
 interface PortalContextFn {
    (
        initial?: Record<string, any>,
        k?: string,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel,
        trigger_render?: boolean
    ): readonly [Record<string, any>, Setter<any>];
    create(): void;
}
 interface PortalEffectFn {
    (
        effect: () => void | UnsubscribeFn,
        deps?: any[],
        k?: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): void;
}
 interface StoreSignal<T = any> {
    value: T;
    subscribe(fn: (val: T) => void): UnsubscribeFn;
    destroy(): void;
    resolvedKey: string;
}
 interface PortalStoreFn {
    <T = any>(
        initialValue?: T | (() => T),
        key?: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel
    ): StoreSignal<T>;
}
 interface PortalStoreUseFn {
    <T = any>(
        initialValue?: T | (() => T),
        key?: Channel,
        sl?: Channel,
        ms?: Channel,
        rt?: Channel,
        trigger_render?: boolean
    ): readonly [T, Setter<T>, StoreSignal<T>];
}
 interface PortalStore extends PortalStoreFn {
    use: PortalStoreUseFn;
}
    type FROM_FN = {
       <T = any>(src: any): Producible<T>;
       Observable: <T = any>(src: any) => Producible<T>;
       promise: <T = any>(p: Promise<T>) => Producible<T>;
       event: <T = any>(target: EventTarget, event: string) => Producible<T>;
       array: <T = any>(arr: T[]) => Producible<T>;
   };
    interface Pool {
       run<R>(task: () => Promise<R>, priority?: Priority): Promise<R>;
       stats(): { active: number; queued: number; idle?: number };
       terminate(): Promise<void>;
   }
    interface HC_FN {
       (): any;
   
       // ── engine container (context_engine, transport_engine, db_engine) ──────────
       context_engine: HADRON_COLLIDER;
       transport_engine: HC_TRANSPORT_ENGINE_FN;
       db_engine: HC_DB_ENGINE_FN;
       notifications: HadronNotificationHub
       post_office: POST_OFFICE
       // ── duplex stream (raw) ─────────────────────────────────────────────────────
       stream<TUp = any, TDown = any>(
           k?: string,
           sl?: string,
           ms?: string,
           rt?: string,
           opts?: { windowSize?: number },
       ): DuplexStream<TUp, TDown>;
   
       // ── duplex handler (responder side) ─────────────────────────────────────────
       handler<TUp = any, TDown = any>(
           handlerFn: (data: TUp, stream: DuplexStream<TDown, TUp>) => void | Promise<void>,
           k?: string,
           sl?: string,
           ms?: string,
           rt?: string,
           opts?: { windowSize?: number },
       ): DuplexStream<TDown, TUp>;
   
       // ── storage verbs ───────────────────────────────────────────────────────────
       set: HC_SET_FN;
       get: HC_GET_FN;
       delete: HC_DELETE_FN;
       sub: HC_SUB_FN;
       context: HC_CONTEXT_FN;
   
       // ── post office / context helpers ───────────────────────────────────────────
       batchHC: () => any;
       waitForHC: () => any;
       getByPrefixHC: () => any;
       clearHC: () => any;
       createHCContext: () => any;
       useHCContext: () => any;
   }
    interface HADRON_COLLIDER {
       // ── config ─────────────────────────────────────────────────────────────────
       POST_OFFICE_CHANNEL: string;
       THE_WIZARD_ROOT_REG: string;
       SAURON_MASTER_REG: string;
       SAURON_SLAVE_REG: string;
   
       engine_capacity: number;
       notification_capacity: number;
       binary_capacity: number;
   
       // ── engines ────────────────────────────────────────────────────────────────
       queue: HADRON_QUEUE;
       engine: HADRON_COLLIDER_SOA_ENGINE;
       binary: HADRON_COLLIDER_BINARY_QUEUE_BOUNDARY;
       governor: GranularHadronGovernor;
       notifications: HadronNotificationHub;
       post_office: POST_OFFICE;
   
       // ── lifecycle ──────────────────────────────────────────────────────────────
       start(): void;
       stop(): void;
   
       // ── raw mutations ──────────────────────────────────────────────────────────
       admit(x: number, y: number, value: number, pid: Pid): void;
       edit(pid: Pid, x: number, y: number, value: number): void;
       delete(pid: Pid): void;
   
       // ── async queries (return a chainable) ─────────────────────────────────────
       getAsync(pid: Pid): any;
       pullGetMany(pid: Pid): any;
       placeSubscription(pid: Pid): any;
       WaitFor(pid: Pid): any;
   
       // ── sync get (promise) ─────────────────────────────────────────────────────
       pullGet(
           key: string,
           slaveReg?: string,
           masterReg?: string,
           globalKey?: string,
       ): Promise<any>;
   
       // ── write verbs (chainable) ────────────────────────────────────────────────
       pushSet(
           key: string,
           value: any,
           trigger_render?: boolean,
           slaveReg?: string,
           masterReg?: string,
           globalKey?: string,
       ): any;
   
       pushSetMany(items: { pid: Pid; x?: number; y?: number; val: any }[]): any;
       pushEdit(pid: Pid, x: number, y: number, val: number): any;
       pushDelete(pid: Pid): any;
       pushDeleteMany(pid: Pid): any;
       pullHas(pid: Pid): any;
   }
    interface HC_TRANSPORT_ENGINE_FN {
       (): any;
       zoom(): any;
   }
    interface HC_DB_ENGINE_FN {
       (): any;
       zooooom(): any;
   }
    interface HC_SET_FN {
       (): any;
       many(): any;
   }
    interface HC_GET_FN {
       (): any;
       all(): any;
       many(): any;
   }
    interface HC_DELETE_FN {
       (): any;
       many(): any;
   }
    interface HC_SUB_FN {
       (): any;
       many(): any;
       all(): any;
   }
    interface HC_CONTEXT_FN {
       (): any;
       many(): any;
       all(): any;
   }
    interface HADRON_QUEUE {
       enqueueAdmit(x: number, y: number, value: unknown, pid: Pid): void;
       enqueueEdit(pid: Pid, x: number, y: number, value: number): void;
       enqueueDelete(pid: Pid): void;
       enqueueDeleteMany(pid: Pid): void;
       enqueueGet(key: string, slaveReg: string | undefined,
           masterReg: string | undefined,
           globalKey: string | undefined,): void;
       enqueueGetAsync(pid: Pid): void;
       enqueueGetMany(pid: Pid): void;
       enqueueSubscription(pid: Pid): void;
       enqueueWaitFor(pid: Pid): void;
       enqueueHas(pid: Pid): void;
       enqueueSet(
           key: string,
           value: unknown,
           slaveReg: string,
           masterReg: string,
           globalKey: string,
       ): void;
       enqueueSetMany(items: { pid: Pid; x?: number; y?: number; val: any }[]): void;
       flushToBinary(): void;
   }
    interface HADRON_COLLIDER_SOA_ENGINE {
       pass(): void;
       getLoadFactor(): number;
       admitDirect(x: number, y: number, value: number, pid: Pid): void;
       editDirect(pid: Pid, x: number, y: number, value: number): void;
       deleteDirect(x: number, y: number, value: number, pid: Pid): void;
       onDbPassGetByPid(pid: Pid): void;
       readonly tick: number;
       readonly length: number;
   }
    interface HADRON_COLLIDER_BINARY_QUEUE_BOUNDARY {
       enqueueAdmit(x: number, y: number, value: unknown, pid: Pid): void;
       enqueueEdit(pid: Pid, x: number, y: number, value: unknown): void;
       enqueueDelete(pid: Pid): void;
       enqueueDeleteMany(pid: Pid): void;
       enqueueGet(pid: Pid, slaveReg: string | undefined,
           masterReg: string | undefined,
           globalKey: string | undefined,): void;
       enqueueGetAsync(pid: Pid): void;
       enqueueGetMany(pid: Pid): void;
       enqueueSubscription(pid: Pid): void;
       enqueueWaitFor(pid: Pid): void;
       enqueueHas(pid: Pid): void;
       enqueueSetMany(items: { pid: Pid; x?: number; y?: number; val: any }[]): void;
       flushMutations(): void;
       flush(
           onAdmit: (x: number, y: number, val: number, pid: Pid) => void,
           onEdit: (pid: Pid, x: number, y: number, val: number) => void,
           onDelete: (pid: Pid) => void,
       ): void;
       encodeToSlab(pid: number, value: unknown): number;
       readSlabValue<T = any>(pid: number): T | null;
       clearSlab(pid: number): void;
       readPayload<T = any>(pid: number): T | null;
       encode_msg(msg: any): Uint8Array;
       decode_msg(raw: any): any;
       readonly length: number;
       clear(): void;
   }
    interface GranularHadronGovernor {
       start(): void;
       stop(): void;
   }
    interface HadronNotificationHub {
       // getScopeHashForPid(pid: Pid): string | undefined;
       // subscribe?(scopeHash: string, handler: (p: any) => void): () => void;
       //  notify(scopeHash: string, p: any): void;
       getScopeHashForPid?(pid: number): number
       getExistingPid?(scopeHash: number): number
       hashComponent?(val: any, fallback: string): number
       getScopeHash?(key: string | symbol, sl_reg?: any, ms_reg?: any, globalKey?: any): number
       parseScopeKey?(pid: number): ScopeComponents
       allocateScopePid?(scopeHash: number, key: string | symbol, sl_reg?: any, ms_reg?: any, globalKey?: any): number
       markDirty?(pid: number): void
       subscribe?(pid: number, fn: ListenerFn): () => void
       flushNotifications?(): void
       notifyHook?(key: string): any
   }
    interface POST_OFFICE {
       enqueueGet(
           key?: string,
           callback?: SubscriberCallback,
           slaveReg?: string,
           masterReg?: string,
           globalKey?: string,
       ): void;
       _flushHookNotifications(): any
   }
    type ConsumerTeardown = | void | null | (() => void) | { unsubscribe(): void } | { [Symbol.dispose](): void } | Teardown[];
    type ConsumerOperator<I = any, O = any> = (consumer: Consumer<I>) => Consumer<O>;
    type ConsumableOperator<I = any, O = any> = (source: Consumable<I>) => Consumable<O>
    type Operator<A = any, B = any> = (source: Producible<A>) => Producible<B>;
    type AnyOp2<A, B> = Operator<A, B> & { __fuse?: () => (v: any) => any; __fuseComplete?: () => (sub: { next(v: any): void }) => void };
    type AnyOpConsumableOperator = ConsumableOperator<any, any> & { __fuse?: () => FuseStep; __fuseComplete?: () => FuseComplete; };
    interface Observer<T> {
       next?(t?: number, v?: T): void;
       error?(t?: number, e?: unknown): void;
       complete?(t?: number): void;
       signal?: AbortSignal;
   }
    interface ConsumerObserver<T = any> {
       next(value: T): any;
       error?(error: T): any;
       complete?(): any;
   }
    interface ConsumableObserver<T> {
       next?(t: number, v: T): void;
       error?(t: number, e: unknown): void;
       complete?(t: number): void;
       signal?: AbortSignal;
       //next(value: T): void | Promise<void>;
       // error?(error: unknown): void;
       //complete?(): void;
   }
    interface Consumer<T> {
       map<B>(fn: (v: T, i: number) => B | Promise<B>): Consumer<B>
       filter(fn: (v: T, i: number) => boolean | Promise<boolean>): Consumer<T>
       batch(n: number): Consumer<T[]>
       debounce(ms: number): Consumer<T>
       tap(fn: (data: T, i: number) => void | Promise<void>): Consumer<T>
       take(n: number): Consumer<T>
       skip(n: number): Consumer<T>
       catchError(fn: (error: unknown) => void | Promise<void>): Consumer<T>
       retry(attempts: number, opts: { delayMs?: number }): Consumer<T>
   
       consume(observer: ConsumerObserver<T>): ConsumerTeardown;
       observeExecution(ex: ExecutionConsumable | null): this;
       pipe(): Consumer<T>;
       pipe<A>(op1: ConsumerOperator<T, A>): Consumer<A>;
       pipe<A, B>(op1: ConsumerOperator<T, A>, op2: ConsumerOperator<A, B>): Consumer<B>;
       pipe(...ops: ConsumerOperator<any, any>[]): Consumer<any>
   }
    type SubscribeArgs<T> = | [] | [(value: T) => void] | [(value: T) => void, (err: unknown) => void] | [(value: T) => void, (err: unknown) => void, () => void] | [Observer<T>];
    interface SyncStreamOptions {
       windowSize?: number;
       retransmitMs?: number;
   }
    interface StreamGate {
       paused: boolean;
       pause(): void;
       resume(): void;
   }
    interface TaggedError extends Error {
       tag: string;
   }
    interface Job<T> {
       run(): Promise<T>;
       resolve(value: T): void;
       reject(err: unknown): void;
       priority: number;
       seq: number;
   }
    interface WorkerPoolOptions {
       size?: number;
       queueLimit?: number;
       onBusy?: (active: number) => void;
       onIdle?: () => void;
       smol?: any
       adaptive?: any
       maxSize?: number;
       minSize?: number;
   }
    interface ChannelOptionsWithStrategy extends ChannelOptions { }
    type SUBJECT_FN = {
       <T = any>(): any
   };
    type SUBJECT__FN = {
       <T = any>(): any;
       behavior: <T = any>(intial: T) => any;
       replay: <T = any>(size?: number) => any;
       async: <T = any>() => any
   };
    type BEHAVIOR_SUBJECT_FN = {
       <T = any>(initial: T, scope?: Scope): any
   };
    type REPLAY_SUBJECT_FN = {
       <T = any>(size?: number, scope?: Scope): any
   };
    type CHANNEL_FN = {
       <T = any>(opts: ChannelOptions): Channel<T>;
   };
    type CHANNEL__FN = {
       <T = any>(opts: ChannelOptions): any
   };
    type SUBSCRIBER_FN = {
       <T = any>(observer: Observer<T>): any
   };
    type SUB__FN = {
       <T = any>(observer: Observer<T>): any
   };
    type SUBSCRIPTION_FN = {
       (): any
   };
    type SUBSCRIPTION__FN = {
       (): any
   }
    type SCHEDULER__FN = SCHEDULER_FN;
    type BUFFER_FN = {
       (size: number): any;
       time(ms: number): any;
   };
    type DISTINCT_FN = {
       (): any;
       untilChanged(): any;
   };
    type LOG_FN = {
       (): any;
       error(): any;
   };
    type SEND__FN = {
       (): ChainSelf;
       async(): Promise<void>;
   };
    type PUBLISH__FN = {
       (): any;
       async(): Promise<void>;
   };
    type NEXT_FN = {
       (): any;
       async(): Promise<any>;
   };
    type PROMISE_FN = {
       (): Promise<any>;
       sync(): any;
   };
    type WORKER_FN = {
       parallel<A = any, B = any>(
           project: (a: A) => Promise<B> | Producible<B>,
           pool: WorkerPool | WorkerPoolOptions
       ): Operator<A, B>;
       makePool(
           opts: WorkerPoolOptions
       ): (task: () => Promise<unknown>, priority?: number) => Promise<unknown>;
   };
    interface PRODUCIBLE_FN {
       <T = any>(subscribe: (subscriber: Subscriber<T>) => Teardown): Producible<T>;
   
       inspect: any;
   
       map: {
           <A = any, B = any>(fn: (a: A, i: number) => B): Operator<any, any>;
           to: <A = any, B = any>(value: B) => any;
       };
   
       take: {
           <T = any>(n: number): Operator<any, any>;
           while: <T = any>(pred: (v: T) => boolean) => Operator<any, any>;
           until: <T = any>(notifier: Producible<unknown>) => Operator<any, any>;
       };
   
       merge: {
           <T = any>(...sources: Producible<T>[]): Producible<T>;
           map: <A, B>(project: (a: A, i: number) => Producible<B>, concurrency?: number) => Operator<any, any>;
       };
   
       concat: {
           <T = any>(...sources: Producible<T>[]): Producible<T>;
           map: <A, B>(project: (a: A, i: number) => Producible<B>) => Operator<any, any>;
           all: <T = any>() => Operator<any, any>;
       };
   
       observe: <T = any>(next: (v: T) => void, source: Producible<T>) => any;
       remember: <T = any>() => Operator<any, any>;
       imitate: <T = any>(other: Producible<T>) => Producible<T>;
       subscribe: <T = any>(next: (v: T) => void, source: Producible<T>) => any;
       transduce: <A = any, B = any>(
           transducer: (rf: (acc: B, x: A) => B) => (acc: B, x: A) => B,
           seed: B,
       ) => Operator<any, any>;
   
       listener: {
           add: (next: (v: any) => void) => any;
           remove: (s: any) => void;
       };
   
       delay: <T = any>(ms: number, opts?: { priority?: Priority; scope?: string | Scope }) => Operator<any, any>;
       debounce: <T = any>(ms: number, s?: Scheduler, opts?: { priority?: Priority; scope?: string | Scope }) => Operator<any, any>;
       throttle: <T = any>(ms: number, s?: Scheduler, opts?: { priority?: Priority; scope?: string | Scope }) => Operator<any, any>;
       timeout: <T = any>(ms: number, s?: Scheduler, opts?: { priority?: Priority; scope?: string | Scope }) => Operator<any, any>;
       audit: <T = any>(ms: number, s?: Scheduler, opts?: { priority?: Priority; scope?: string | Scope }) => Operator<any, any>;
       sample: <T = any>(notifier: Producible<unknown>) => Operator<any, any>;
       timeoutWith: <T = any>(
           ms: number,
           fallback: Producible<T>,
           sched: { schedule(fn: () => void, d: number): { cancel(): void } },
           opts?: { priority?: Priority; scope?: string | Scope }
       ) => Operator<any, any>;
       loop: (f: () => Producible<any>) => Promise<never>;
       during: <T = any>(t1: number, t2: number) => Operator<any, any>;
       since: <T = any>(t: number) => Operator<any, any>;
       until: <T = any>(signal: Producible<any>) => Operator<any, any>;
       continueWith: <T = any>(...values: T[]) => Operator<any, any>;
       chain: <A = any, B = any>(f: (a: A) => Producible<B>) => Operator<any, any>;
       compose: <A = any>(...ops: Operator<any, any>[]) => Operator<any, any>;
       flatten: <T = any>() => Operator<any, any>;
       fold: <A = any, B = any>(fn: (acc: B, a: A) => B, seed: B) => Operator<any, any>;
       endWhen: <T = any>(signal: Producible<any>) => Operator<any, any>;
       startWith: <T = any>(...values: T[]) => Operator<any, any>;
       drop: <T = any>(n: number) => Operator<any, any>;
   
       catch: {
           error: <T = any>(handler: (err: unknown, caught: Producible<T>) => Producible<T>) => Operator<any, any>;
           tag: <T = any>(tag: string, handler: (err: TaggedError) => Producible<T>) => Operator<any, any>;
       };
   
       reduce: <A = any, B = any>(fn: (acc: B, a: A) => B, seed: B) => Operator<any, any>;
       scan: <A = any, B = any>(fn: (acc: B, a: A) => B, seed: B) => Operator<any, any>;
       toArray: <T = any>() => Operator<any, any>;
       bufferCount: <T = any>(n: number) => Operator<any, any>;
       filter: <T = any>(pred: (v: T, i: number) => boolean) => Operator<any, any>;
       skip: <T = any>(n: number) => Operator<any, any>;
       first: <T = any>(pred?: (v: T) => boolean) => Operator<any, any>;
       last: <T = any>() => Operator<any, any>;
       distinctUntilChanged: <T = any>(eq?: (a: T, b: T) => boolean) => Operator<any, any>;
       tap: <T = any>(fn: (v: T) => void) => Operator<any, any>;
       finalize: <T = any>(fn: () => void) => Operator<any, any>;
       retry: <T = any>(count: number, delayMs?: number, s?: Scheduler) => Operator<any, any>;
   
       race: <T = any>(...sources: Producible<T>[]) => Producible<T>;
       combineLatest: <T extends readonly unknown[]>(sources: { [K in keyof T]: Producible<T[K]> }) => Producible<T>;
       zip: <T extends readonly unknown[]>(sources: { [K in keyof T]: Producible<T[K]> }) => Producible<T>;
       forkJoin: <T extends readonly unknown[]>(sources: { [K in keyof T]: Producible<T[K]> }) => Producible<T>;
       withLatestFrom: <A, B>(other: Producible<B>) => Operator<any, any>;
   
       multicast: <T = any>(subjectFactory: () => Subject<T>) => Operator<any, any>;
       publish: <T = any>() => Operator<any, any>;
       refCount: <T = any>() => Operator<any, any>;
   
       taggedError: (tag: string) => new (message: string) => TaggedError;
   
       with: {
           start: <T = any>(...values: T[]) => Operator<any, any>;
           end: <T = any>(...values: T[]) => Operator<any, any>;
       };
   
       switch: {
           map: <A, B>(project: (a: A, i: number) => Producible<B>) => Operator<any, any>;
           all: <T = any>() => Operator<any, any>;
       };
   
       exhaust: {
           map: <A, B>(project: (a: A, i: number) => Producible<B>) => Operator<any, any>;
           all: <T = any>() => Operator<any, any>;
       };
   
       window: {
           <T = any>(boundaries: Producible<unknown>): Operator<any, any>;
           count: <T = any>(n: number) => Operator<any, any>;
           time: <T = any>(ms: number, s?: Scheduler) => Operator<any, any>;
           when: <T = any>(closing: () => Producible<unknown>) => Operator<any, any>;
       };
   
       buffer: {
           <T = any>(boundaries: Producible<unknown>): Operator<any, any>;
           time: (ms: number, opts?: { priority?: Priority; scope?: string | Scope }) => any;
           when: <T = any>(closing: () => Producible<unknown>) => Operator<any, any>;
           toggle: <T = any>(openings: Producible<unknown>, closing: (v: unknown) => Producible<unknown>) => Operator<any, any>;
       };
   
       to: {
           emitter: <T = any>(k: string, sl?: any, ms?: any, rt?: any, ttl?: number, binary?: boolean) => Operator<any, any>;
           sauron: <T = any>(label: string, sl?: any, ms?: any, rt?: any, triggerRender?: boolean) => Operator<any, any>;
       };
   }
    type MERGE_FN = {
       <T = any>(...sources: Producible<T>[]): Producible<T>;
       map: <A, B>(project: (a: A, i: number) => Producible<B>, concurrency?: number) => Operator<A, B>;
   };
    type CONCAT_FN = {
       <T = any>(...sources: Producible<T>[]): Producible<T>;
       map: <A, B>(project: (a: A, i: number) => Producible<B>) => Operator<A, B>;
       all: <T = any>() => Operator<Producible<T>, T>;
   };
    type SWITCH_FN = {
       map: <A, B>(project: (a: A, i: number) => Producible<B>) => Operator<A, B>;
       all: <T = any>() => Operator<Producible<T>, T>;
   };
    type EXHAUST_FN = {
       map: <A, B>(project: (a: A, i: number) => Producible<B>) => Operator<A, B>;
       all: <T = any>() => Operator<Producible<T>, T>;
   };
    type FUSE_MAP = {
       <A = any, B = any>(
           fn: (a: A, i: number) => B
       ): Operator<A, B>;
   
       to: <A = any, B = any>(
           value: B
       ) => Operator<A, B>;
   };
    type FUSE_TAKE = {
       <T = any>(n: number): Operator<T, T>;
   
       while: <T = any>(
           pred: (v: T) => boolean
       ) => Operator<T, T>;
   };
    type FUSE_DISTINCT = {
       <T = any>(
           eq?: (a: T, b: T) => boolean
       ): Operator<T, T>;
   
       key: <T = any>(
           key: (v: T) => any
       ) => Operator<T, T>;
   
       untilChanged: <T = any>(
           eq?: (a: T, b: T) => boolean
       ) => Operator<T, T>;
   };
    type FUSE_WITH = {
       end: <T = any>(
           ...values: T[]
       ) => Operator<T, T>;
   };
    type FUSE_PRODUCER_FN = {
       (source: Producible<any>, ops: AnyOp[]): Producible<any>;
   
       fused: <A, B>(
           hook: () => (v: A) => any,
           plain: Operator<A, B>
       ) => Operator<A, B>;
   
       map: FUSE_MAP;
       take: FUSE_TAKE;
       distinct: FUSE_DISTINCT;
       with: FUSE_WITH;
   
       pipeFused: (
           source: Producible<any>,
           ...ops: AnyOp[]
       ) => Producible<any>;
   
       attachPipeFused: (
           ObservableClass: { prototype: any }
       ) => void;
   
       partition: <T = any>(
           source: Producible<T>,
           pred: (v: T) => boolean
       ) => [Producible<T>, Producible<T>];
   
       timeoutWith: <T = any>(
           ms: number,
           fallback: Producible<T>,
           sched: {
               schedule(
                   fn: () => void,
                   d: number
               ): { cancel(): void }
           }
       ) => Operator<T, T>;
   
       shareLatest: <T = any>(
           source: Producible<T>
       ) => Producible<T>;
   
       observeOn: <T = any>(
           sched: {
               schedule(
                   fn: () => void,
                   d: number
               ): { cancel(): void }
           },
           delayMs?: number
       ) => Operator<T, T>;
   
       subscribeOn: <T = any>(
           sched: {
               schedule(
                   fn: () => void,
                   d: number
               ): { cancel(): void }
           },
           delayMs?: number
       ) => Operator<T, T>;
   
       delayWhen: <T = any>(
           delayFn: (v: T) => Producible<any>
       ) => Operator<T, T>;
   
       retryWhen: <T = any>(
           notifFn: (errs: Producible<any>) => Producible<any>,
           maxAttempts?: number
       ) => Operator<T, T>;
   
       filter: <T = any>(
           pred: (v: T, i: number) => boolean
       ) => Operator<T, T>;
   
       tap: <T = any>(
           fn: (v: T) => void
       ) => Operator<T, T>;
   
       scan: <A = any, B = any>(
           fn: (acc: B, a: A) => B,
           seed: B
       ) => Operator<A, B>;
   
       pluck: <T, K extends keyof T>(
           key: K
       ) => Operator<T, T[K]>;
   
       count: <T = any>(
           pred?: (v: T) => boolean
       ) => Operator<T, number>;
   
       every: <T = any>(
           pred: (v: T) => boolean
       ) => Operator<T, boolean>;
   
       find: <T = any>(
           pred: (v: T) => boolean
       ) => Operator<T, T | undefined>;
   
       pairwise: <T = any>() => Operator<T, [T, T]>;
   
       skipWhile: <T = any>(
           pred: (v: T) => boolean
       ) => Operator<T, T>;
   };
    type CREATE_FN = {
       stream<T = any>(subscribe: (subscriber: Subscriber<T>) => Teardown): Producible<T>;
       of<T = any>(...values: T[]): Producible<T>;
       empty(): Producible<never>;
       never(): Producible<never>;
       error(e: unknown): Producible<never>;
       defer<T = any>(factory: (opts?: any) => Producible<T>, opts?: any): Producible<T>;
       timer(dueMs?: number, intervalMs?: number, s?: Scheduler): Producible<number>;
       interval(ms: number, s?: Scheduler): Producible<number>;
       from<T = any>(src: AsyncIterable<T> | Iterable<T> | Promise<T> | Producible<T>): Producible<T>;
       fromEmitter<T = any>(
           k: string,
           sl?: any,
           ms?: any,
           rt?: any,
           backpressure?: ChannelOptions | false
       ): Producible<T>;
       fromSauron<T = any>(
           label: string,
           sl?: any,
           ms?: any,
           rt?: any,
           emitCurrent?: boolean
       ): Producible<T>;
   };
    type MC_FN = {
       share: <T = any>() => Operator<T, T>;
       shareReplay: <T = any>(size?: number) => Operator<T, T>;
   };
    type BP_OP_FN = {
       bounded: <T = any>(n: number, strategy?: any) => Operator<T, T>;
       rt: <T = any>(opts: ChannelOptions) => Operator<T, T>;
       gateStream: <T = any>(source: Producible<T>, onGate: (paused: boolean) => void) => { gated: Producible<T>; gate: StreamGate };
   };
    type CHAIN_STATE_FN = {
       toSignal: <T = any>(source: Producible<T>, initial?: T, options?: ToSignalOptions) => SignalRef<T>;
       toSauron: <T = any>(label: string, options?: ToSauronOptions & { set?: (label: string, v: T, triggerRender: boolean) => void }) => Operator<T, T>;
   };
    type CHAIN_TO_FN = {
       promise: PROMISE_FN;
       DRS(key: string, opts?: any): ChainSelf;
       rt(k: string): ChainSelf;
   };
    type DRSDB_FN = {
       (): any;
       drsdb(): any;
       useDRSDB(): any;
       useDRSDBOptimistic(): any;
       useDRSDBCRDT(): any;
       drsdbStream(): any;
   };
    type RAFT_FN = {
       (): any;
       useDRSDBRaft(): any;
       useRxDBRaft(): any;
   };
    type RTDB_FN = {
       (): any;
       rtdb(): any;
       useRTDB(): any;
       rtdbStream(): any;
   };
    interface YJS_FN {
       (id: string, config?: DocConfig, k?: SU, sl?: SU, ms?: SU, rt?: SU): Promise<CollabDoc>;
       awareness(docId: string, k?: SU, sl?: SU, ms?: SU, rt?: SU): Promise<any>;
       map<T = any>(docId: string, field?: string, k?: SU, sl?: SU, ms?: SU, rt?: SU): Promise<MapResult<T>>;
       comments(docId: string, field?: string, k?: SU, sl?: SU, ms?: SU, rt?: SU): Promise<any>;
       presence(recordId: string, k?: SU, sl?: SU, ms?: SU, rt?: SU): Promise<any>;
       session(docId: string, k?: SU, sl?: SU, ms?: SU, rt?: SU): Promise<SessionResult>;
       text(docId: string, field?: string, k?: SU, sl?: SU, ms?: SU, rt?: SU): Promise<TextResult>;
       doc(docId: string, config?: DocConfig, k?: SU, sl?: SU, ms?: SU, rt?: SU): Promise<CollabDoc>;
   }
    interface DRS_FN {
       <T = any>(k: string, sl: string, ms: string, rt: string, initial?: T): any;
       db: {
           <T = any>(k: string, sl: string, ms: string, rt: string, initial: T,): any
           rt<T = any>(k: string, sl: string, ms: string, rt: string, initial: T,): any
       }
       liveStore<T = any>(k?: SU, sl?: SU, ms?: SU, rt?: SU, initial?: T): any
       crdt<T = any>(k?: SU, sl?: SU, ms?: SU, rt?: SU, initial?: T): any
       live<T = any>(k: string, sl: string, ms: string, rt: string, initial?: T): any
   }
    interface useDRS_FN {
       (initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): readonly [any, (next: any) => void];
   
       mesh<T = any>(key: string, initial?: T, reactor?: StateMeshReactor<T>, k?: SU, sl?: SU, ms?: SU, rt?: SU): StateMesh<T>;
   
       store(
           initialValue?: any | (() => any),
           key?: string | undefined,
           sl?: string | undefined,
           ms?: string | undefined,
           rt?: string | undefined,
       ): {
           value: any;
           subscribe(fn: (val: any) => void): () => void;
           destroy(): void;
           resolvedKey: string;
       };
   
       mailbox(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): readonly [any, (next: any) => void];
   
       liveStore(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU, nodeId?: any): any;
   
       crdt(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU, nodeId?: any): readonly [any, (next: any) => void];
   
       live(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): readonly [any, (next: any) => void];
   
       raft<TState = any>(initial?: TState | (() => TState), clusterId?: string | undefined, nodeId?: string | undefined, peerIds?: string[] | undefined, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): Promise<readonly [TState, (next: TState | ((prev: TState) => TState)) => Promise<void>, any]>;
   
       Observable<T>(initial?: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): {
           state: any;
           setState: (next: any | ((prev: any) => any), options?: { by?: string; reason?: string }) => void;
           metadata: {
               lastChangedBy: string | null;
               lastChangedAt: number | null;
               lastChangedKeys: (keyof any)[] | null;
               changeCount: number;
               history: Array<{
                   keys: (keyof any)[];
                   by: string;
                   at: number;
                   previousValue: Partial<any>;
                   newValue: Partial<any>;
               }>;
           };
           getHistory: () => Array<{
               keys: (keyof any)[];
               by: string;
               at: number;
               previousValue: Partial<any>;
               newValue: Partial<any>;
           }>;
           getLastChange: () => {
               by: string | null;
               at: number | null;
               keys: (keyof any)[] | null;
               count: number;
           };
           clearHistory: () => void;
       };
   
       db: {
           <T = any>(initial: T, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): readonly [T, (next: T | ((prev: T) => T)) => void] | undefined;
           optimistic: <T = any>(initial: T, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined) => {
               setSnapshotSource: (fn: () => T) => void;
               setReconciler: (fn: (guess: T) => T | Promise<T>) => any;
               apply: (guess: T) => void;
               confirm: () => T;
               fail: () => void;
               getState: () => T;
               isPending: () => boolean;
               pendingCount: () => number;
               on: (event: 'change', handler: (v: T, wasCorrected: boolean) => void) => () => void;
           } | undefined;
           crdt: <T = any>(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined) => {
               value: Record<string, T>;
               set: (key: string, v: T) => void;
               get: (key: string) => T | undefined;
           };
           rt: <T = any>(initial: T, db?: 'rdb' | 'kvdb' | 'tdb' | 'vdb' | 'gdb' | 'memory', k?: SU, sl?: SU, ms?: SU, rt?: SU) => readonly [T, (next: T | ((prev: T) => T)) => void] | undefined;
           raft: {
               <T = any>(initial: T, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): readonly [T, (next: T) => Promise<void>];
               rx: <T = any>(initial?: any, db?: 'rdb' | 'kvdb' | 'tdb' | 'vdb' | 'gdb' | 'memory', k?: SU, sl?: SU, ms?: SU, rt?: SU) => readonly [T, (next: T) => Promise<void>] | undefined;
           };
           yata: {
               <T = any>(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): {
                   value: T[];
                   insertAt: (i: number, v: T) => void;
                   deleteAt: (i: number) => void;
               };
               rx: <T = any>(initial?: T[], db?: 'rdb' | 'kvdb' | 'tdb' | 'vdb' | 'gdb' | 'memory', k?: SU, sl?: SU, ms?: SU, rt?: SU) => {
                   value: T[];
                   insertAt: (i: number, v: T) => Promise<void>;
                   deleteAt: (i: number) => Promise<void>;
               };
           };
       };
   }
    type DISTRIBUTED_FN = {
       (): any;
       harbormaster(): any;
       beacon(): any;
       vessel(): any;
       dock(): any;
       radar(): any;
       torpedo(): any;
       convoy(): any;
       sonar(): any;
       heartbeat(): any;
       watchdog(): any;
       flightCache(): any;
       singleFlight(): any;
       transaction(): any;
       autoFederate(): any;
       visualFlow(): any;
   };
    type EINSTEIN_FN = {
       (): any;
       fuseSignal(): any;
       streamLab(): any;
   };
    type EXE_FN = {
       (): any;
       worker(): any;
       enqueueJob(): any;
       cron(): any;
       fusebox(): any;
       tripwire(): any;
       fathom(): any;
       rigging(): any;
       circus(): any;
       nebula(): any;
       cyclone(): any;
       trident(): any;
       anchor(): any;
       pipeline(): any;
       tide(): any;
       mesh(): any;
       echo(): any;
       carousel(): any;
       synapse(): any;
       abortableFlight(): any;
       tokenBucket(): any;
       tokenBucket_simple(): any;
       _featureFlags(): any;
       _activeFeatures(): any;
       featureSwitch(): any;
       _isFeatureActive(): any;
       _DUMMY(): any;
       fullDummy(): any;
       resilience(): any;
       saga(): any;
       ecs(): any;
       commandBuffer(): any;
       reactor(): any;
       blackboard(): any;
       _sanitizeChannel(): any;
       snapshotIsolation(): any;
       smartBeacon(): any;
       lww_crdt(): any;
       useCRDT(): any;
       createCRDTChannel(): any;
       notifications(): any;
       useNotifications(): any;
       config(): any;
       useConfig(): any;
       useFeatureFlag(): any;
       lock(): any;
       mapReduce(): any;
       rateLimit(): any;
       appendOnlyLog(): any;
   };
    type LOGIC_GATES_FN = {
       (): any;
       barrier(): any;
       latch(): any;
       gateMaster(): any;
       gateMaster2(): any;
       floodGateWithLive(): any;
       plinko(): any;
       plinko3(): any;
       _circuitBreakers(): any;
       getCircuitBreaker(): any;
       circuitBreaker(): any;
       switchboard(): any;
       makeSwitchboardContext(): any;
       validateSwitchboardRoutes(): any;
       conditionVariable(): any;
   };
    interface CONSUMER_OBSERVABLE_FN {
   }
    interface ChainSelf {
       map(fn: (data: any) => any): this;
       filter(fn: (data: any) => boolean): this;
       reduce(fn: (acc: any, data: any) => any, initial: any): this;
       scan(fn: (acc: any, data: any) => any, initial: any): this;
       debounce(ms: number): this;
       throttle(ms: number): this;
       take(n: number): this;
       delay(ms: number): this;
       buffer: BUFFER_FN;
       distinct: DISTINCT_FN;
       log: LOG_FN;
       send: SEND__FN;
       publish: PUBLISH__FN;
       next: NEXT_FN;
       takeLast(n: number): this;
       skip(n: number): this;
       catchError(fn: (error: any) => any): this;
       retry(attempts: number): this;
       tap(fn: (data: any) => void): this;
       subscribe(handler: (data: any) => void): this;
       persist(key: string, opts?: any): this;
       to: CHAIN_TO_FN;
       create: CREATE_FN;
       mc: MC_FN;
       bp: BP_OP_FN;
       state: CHAIN_STATE_FN;
       w: WORKER_FN;
       producer: PRODUCIBLE_FN;
       consumer: CONSUMER_OBSERVABLE_FN
       fuse_producer: FUSE_PRODUCER_FN;
       s: SUBJECT__FN;
       c: CHANNEL__FN;
       subscriber: SUBSCRIBER_FN;
       subscription: SUBSCRIPTION_FN;
       scheduler: SCHEDULER_FN;
       runTeardown(t: Teardown): void;
       reportError(e: unknown): void;
   }
    interface ToSignalOptions {
       history?: number;
       onChange?: (prev: any, next: any) => void;
   }
    interface ToSauronOptions {
       triggerRender?: boolean;
   }
    interface SignalRef<T> {
       get(): T | undefined;
       peek(): T | undefined;
       set(v: T): void;
       onChange(fn: (v: T, prev: T | undefined) => void): () => void;
       history(): T[];
       unsubscribe(): void;
   }
    interface SignalSurface {
       rk?(key: any): string;
       read<T = any>(key: any): T | undefined;
       sub<T = any>(key: any, fn: (v: T) => void): () => void;
   }
    type SYNC_FN = {
       (k: string, sl: string, ms: string, rt: string, opts?: SyncStreamOptions): SyncStreamSendHandle;
       sub(k: string, sl: string, ms: string, rt: string): SyncStreamHandler;
       sink<T>(source: Producible<T>, k: string, sl: string, ms: string, rt: string, opts?: SyncStreamOptions): { unsubscribe: () => void; pendingCount: () => number; queued: () => number; flush: () => void };
       streamOver<T = any>(source: Producible<T>, k: string, sl: string, ms: string, rt: string): Producible<T>;
       overStream<T>(stream: Producible<T>, source: Producible<T>, k: string, sl: string, ms: string, rt: string, opts?: SyncStreamOptions): { unsubscribe: () => void; pendingCount: () => number; queued: () => number };
   }
    type SUB_FN = {
       (k: string, handler: (data: any) => void, sl?: string, ms?: string, rt?: string): () => void;
       any(handler: (data: any) => void, sl?: string, ms?: string, rt?: string): () => void;
       all(fn: (k: string | symbol, value: any) => void, sl?: string, ms?: string, rt?: string): () => void;
       un(k: string, handler: (data: any) => void, sl?: string, ms?: string, rt?: string): () => void;
       removeAll(event?: string, sl?: string, ms?: string, rt?: string): void;
       count(event: string, sl?: string, ms?: string, rt?: string): number;
       once(event: string, handler: (data: any) => void, sl?: string, ms?: string, rt?: string): () => void;
       names(sl?: string, ms?: string, rt?: string): string[];
   };
    type SEND_FN = {
       (data: any, k?: string, sl?: string, ms?: string, rt?: string): any;
       emit(event: string, p: any, sl?: string, ms?: string, rt?: string): void;
   }
    type PUBLISH_FN = {
       (data: any, k?: string, sl?: string, ms?: string, rt?: string): void;
       async(data: any, k?: string, sl?: string, ms?: string, rt?: string): Promise<void>;
   };
    interface ChannelOptions {
       highWaterMark: number;
       strategy?: any;
   }
    type SCHEDULER_FN = {
       (s: Scheduler): Scheduler;
       immediate: Scheduler;
       userBlocking: Scheduler;
       normal: Scheduler;
       background: Scheduler;
       idle: Scheduler;
       macrotask: Scheduler;
       microtask: Scheduler;
       schedule: typeof coreSchedule;
       scheduleChunked: typeof scheduleChunked;
       yieldToScheduler: typeof yieldToScheduler;
       withRequestScope: typeof withRequestScope;
       Priority: { order: typeof PRIORITY_ORDER };
   };
    type WSStatus = 'connecting' | 'open' | 'reconnecting' | 'closed'
    type WSHandler = (p: unknown, meta?: { seq?: number }) => void
    type WSOptions = {
       reconnect?: boolean
       initialDelay?: number
       maxDelay?: number
       backoffMultiplier?: number
       jitter?: boolean
       maxAttempts?: number
       heartbeatInterval?: number
       heartbeatTimeout?: number
       queueEnabled?: boolean
       maxQueueSize?: number
       maxQueueAge?: number
       resumeOnReconnect?: boolean
   }
    type WSMessage = {
       rt: string
       ms: string
       p: unknown
       id?: string
       ack?: boolean
       seq?: number
       error?: string
   }
    type QueuedMessage = { message: WSMessage; queuedAt: number }
    type ServerClient = {
       clientId: string
       channels: Set<string>
       send: (event: WSMessage) => void
       close: () => void
   }
    interface Command<T = any> { type: string;[k: string]: any; _idempotencyKey?: string }
    interface Query<T = any> { type: string;[k: string]: any }
    interface DomainEvent<T = any> { type: string; p: T; ts: number }
    type CommandHandler = (cmd: Command) => Promise<any>;
    type QueryHandler = (q: Query) => Promise<any>;
    interface CommandOpts {
       optimistic?: (cmd: Command, currentState?: any) => any;   // predicted next state
       rollback?: (cmd: Command, prevState: any) => void;         // undo the optimistic apply on failure
       idempotent?: boolean;
       offline?: boolean;                                          // queue instead of failing when offline
   }
    interface QueryOpts {
       ttlMs?: number;      // how long a cached result is considered fresh, default 0 (always revalidate)
       staleMs?: number;    // how long a stale result is still servable while revalidating, default ttlMs
   }
    interface UndoEntry {
       command: Command;
       prevState: any;
       rollback?: (cmd: Command, prevState: any) => void;
   }
    type Predictor<T = any> = (baseState: T) => T;
    interface PendingMutation {
       mutationId: string;
       entityKey: string;
       predict: Predictor;
       commandId?: string;
       origin: 'local' | 'remote';    // remote = came from another tab via BroadcastChannel
       createdAt: number;
   }
    interface OptimisticConfig {
       crossTabSync?: boolean;
       channelName?: string;
       defaultReconciler?: (predicted: any, actual: any) => any;
   }
    type OPTIMISTICEventMap = {
       'optimistic:applied': { entityKey: string; mutationId: string };
       'optimistic:confirmed': { entityKey: string; mutationId: string; actual: any };
       'optimistic:rolledback': { entityKey: string; mutationId: string; error?: unknown };
   };
    interface COMPRESSIONCompressionConfig {
       threshold?: number;           // bytes below which compression is skipped, default 256
       formatPriority?: CompressFormat[]; // probe order, default best-ratio-first
   }
    type Delta = any;
    interface DiffPatchConfig {
       arrayDiffThreshold?: number;   // default 500 — above this, fall back to cheap index diff
       textDiffThreshold?: number;    // default 60 chars — below this, whole-string replace is cheaper
       textDiffMaxLength?: number;    // default 20000 chars combined — above this, skip word-diff, whole-replace
   }
    interface SamplerConfig {
       enabled?: boolean;
       sampleRate?: number;                          // 0–1, fraction of calls to capture, default 0.05
       maxPerBucket?: number;                         // cap samples per shape bucket, default 200
       bucketBy?: (bytes: Uint8Array) => string;      // groups similar shapes, default: JSON `type`/keys signature
       redact?: (parsed: any) => any | null;          // return null to drop the sample entirely (fail-closed)
       flush: (batch: CorpusSample[]) => Promise<void>; // caller wires this to their own endpoint/storage
       flushIntervalMs?: number;                      // default 30000
       maxBatchSize?: number;                         // default 500, force-flush above this
   }
    interface CorpusSample {
       bucket: string;
       bytes: string;         // base64 — safe to batch/serialize
       capturedAt: number;
   }
    type YmirConflictStrategy = 'server-wins' | 'client-wins' | 'merge' | 'version'
    interface YmirOptions<T> {
       conflictStrategy?: YmirConflictStrategy
       mergeFn?: (local: T, server: T) => T
       versionField?: string
       prefetchOnFocus?: boolean
       prefetchThreshold?: number
       debounce?: number
       retry?: {
           baseDelay?: number
           maxDelay?: number
           maxAttempts?: number
           backoff?: 'exponential' | 'linear' | 'fixed'
       }
   }
    interface YmirWriteOptions<T> {
       fetcher: (value: T) => Promise<T>
       optimistic?: boolean
   }
    interface CherrioConfig {
       wasmSource?: string | Uint8Array;
       cacheSelectors?: boolean;
       maxSelectorCacheSize?: number;
   }
    interface ParseNode {
       tag: string;
       attrs: Record<string, string>;
       children: ParseNode[];
       text?: string;
       parent?: ParseNode;
   }
    interface Document {
       root: ParseNode;
       nodeCount: number;
   }
    interface CheerioAPI {
       (selector: string): CheerioSelection;
   }
    interface CheerioSelection {
       nodes: ParseNode[];
       text(): string;
       attr(name: string): string | undefined;
       find(selector: string): CheerioSelection;
       each(fn: (i: number, node: ParseNode) => void): CheerioSelection;
       filter(fn: (node: ParseNode) => boolean): CheerioSelection;
       first(): CheerioSelection;
       length: number;
   }
    type CompiledSelector = (root: ParseNode) => ParseNode[];
    type CheerioEmitter = { on: (e: string, h: (p: any) => void) => () => void; emit: (e: string, p: any) => void };
    type RaftRole = 'follower' | 'candidate' | 'leader';
    interface RaftSnapshot {
       lastIncludedIndex: number;
       lastIncludedTerm: number;
       state: any;
   }
    interface LogEntry { term: number; index: number; command: any; }
   
    interface RaftOptions {
       clusterId: string;
       nodeId: string;
       peerIds: string[];
   }
    interface NginMiddleware {
       beforeGet?(key: string): void | Promise<void>;
       afterGet?(key: string, value: unknown): void | Promise<void>;
       beforeSet?(key: string, value: unknown): void | Promise<void>;
       afterSet?(key: string, value: unknown): void | Promise<void>;
       beforeDelete?(key: string): void | Promise<void>;
       afterDelete?(key: string): void | Promise<void>;
   }
    type AtomicMutateFn = (current: any) => any;
    interface LockEntry {
       owner: string;
       expiresAt: number;
   }
    interface Snapshot {
       memory: Record<string, unknown>;
       persistent: Record<string, string | null>;
   }
    interface IndexConfig {
       keys: string[];
   }
    interface IndexFilter {
       [key: string]: unknown;
   }
    interface LockApi {
       acquire(key: string, ttlMs?: number): Promise<string | null>;
       release(key: string, owner: string): Promise<boolean>;
       renew(key: string, owner: string, ttlMs?: number): Promise<boolean>;
   }
    interface NginTableSchema {
       name: string;
       type: string;
       notnull: number;
       dflt_value: string | null;
       pk: number;
   }
    interface NginBatchEntry {
       key: string;
       value: unknown;
   }
    interface Ngin {
       get(key: string): Promise<any>;
       getMemory(key: string): Promise<any>;
       getMany(keys: string[]): Promise<any>;
       getManyMemory(keys: string[]): Promise<any>;
       getLocalStorage(key: string): Promise<any>;
   
       set(key: string, value: string | object): Promise<void>;
       setMemory(key: string, value: unknown): Promise<void>;
       setMany(entries: Record<string, unknown>): Promise<void>;
       setManyMemory(entries: Record<string, unknown>): Promise<void>;
       setLocalStorage(key: string, value: string | object): Promise<void>;
   
       delete(key: string): Promise<void>;
       deleteMemory(key: string): Promise<void>;
       deleteMany(keys: string[]): Promise<void>;
       deleteManyMemory(keys: string[]): Promise<void>;
   
       watch(key: string, handler: (value: any) => void): Promise<any>;
       watchMany(keys: string[], handler: (value: any) => void): Promise<any>;
       watchPattern(pattern: string, handler: (value: any) => void): Promise<any>;
       watchPrefix(prefix: string, handler: (value: any) => void): Promise<any>;
       watchAll(handler: (value: any) => void): Promise<any>;
   
       setIfChanged(key: string, value: any): Promise<boolean>;
   
       expire(key: string, ms: number): Promise<void>;
       expireAt(key: string, timestamp: number): Promise<void>;
       persist(key: string): Promise<void>;
       touch(key: string, ms?: number): Promise<void>;
   
       lock(key: string, ttlMs?: number): Promise<string | null>;
       unlock(key: string, owner: string): Promise<boolean>;
       renewLock(key: string, owner: string, ttlMs?: number): Promise<boolean>;
       lockApi: LockApi;
   
       sync(key: string, options?: { direction?: SyncDirection }): Promise<void>;
       getMemoryEntries(): { key: string; value: unknown }[];
   
       openFile(filePath: string): void;
       closeFile(): void;
       getTables(useAux?: boolean): string[];
       getSchema(table: string, useAux?: boolean): NginTableSchema[];
       queryTable(table: string, useAux?: boolean): Record<string, unknown>[];
       updateCell(table: string, pkCol: string, pkVal: unknown, col: string, value: unknown, useAux?: boolean): void;
       insertRow(table: string, cols: string[], values: unknown[], useAux?: boolean): void;
       deleteRow(table: string, pkCol: string, pkVal: unknown, useAux?: boolean): void;
       addColumn(table: string, colName: string, colType: string, useAux?: boolean): void;
       close(): void;
   
       transaction(fn: (tx: Ngin) => Promise<void> | void): Promise<void>;
       batch(entries: NginBatchEntry[]): Promise<void>;
   
       DRS<T extends Record<string, unknown>>(key: string, initial?: T): T;
       computed<T = any>(key: string, deps: string[], computeFn: (...values: any[]) => T): void;
       scope(prefix: string): Ngin;
   
       snapshot(): Promise<Snapshot>;
       restore(snapshot: Snapshot): Promise<void>;
   
       (prefix?: string): Promise<Record<string, unknown>>;
       import(data: Record<string, unknown>, strategy?: Strategy): Promise<void>;
   
       use(mw: NginMiddleware): void;
   
       index: {
           create(name: string, config: IndexConfig): Promise<void>;
           query(name: string, filter: IndexFilter): Promise<Record<string, unknown>[]>;
       };
   
       query(expr: QueryExpr): Promise<Record<string, unknown>[]>;
   
       atomic: {
           compareAndSwap<T = any>(key: string, expected: T | null, next: T): Promise<boolean>;
           mutate<T = any>(key: string, fn: AtomicMutateFn): Promise<T>;
           increment(key: string, by?: number): Promise<number>;
           append(key: string, value: any): Promise<any>;
       };
   }
    interface NginAdapter {
       get(key: string): Promise<string | null>;
       set(key: string, value: string): Promise<void>;
       delete(key: string): Promise<void>;
       clear(): Promise<void>;
       keys(): Promise<string[]>;
   }
    type BastionFlagType = 'boolean' | 'percentage' | 'variant';
    type BastionReason =
       | 'default'
       | 'enabled'
       | 'disabled'
       | 'killed'
       | 'rollout'
       | 'targeting'
       | 'schedule'
       | 'variant'
       | 'override'
       | 'missing'
       | 'fallback';
    type BastionSubject = {
       id: string;
       tenantId?: string;
       attributes?: Record<string, any>;
   };
    type BastionTargetRule = {
       attribute: string;
       operator:
       | 'eq'
       | 'neq'
       | 'in'
       | 'not_in'
       | 'contains'
       | 'starts_with'
       | 'ends_with'
       | 'gt'
       | 'gte'
       | 'lt'
       | 'lte';
       value: any;
   };
    type BastionVariant = {
       value: any;
       weight: number;
   };
    type BastionSchedule = {
       start?: number;
       end?: number;
   };
    type BastionOverride = {
       value?: boolean;
       variant?: string;
       expiresAt?: number;
   };
    type BastionFlag = {
       key: string;
       type: BastionFlagType;
       enabled: boolean;
       killed: boolean;
       rollout: number;
       defaultValue: any;
       variants?: Record<string, BastionVariant>;
       targeting?: BastionTargetRule[];
       schedules?: BastionSchedule;
       overrides?: Record<string, BastionOverride>;
       metadata?: Record<string, any>;
       revision: string;
       updatedAt: number;
       updatedBy?: string;
   };
    type BastionEvaluation = {
       key: string;
       enabled: boolean;
       value: any;
       variant?: string;
       reason: BastionReason;
       revision?: string;
   };
    type BastionAuditEntry = {
       key: string;
       operation: string;
       revision: string;
       timestamp: number;
       actor?: string;
       previous?: BastionFlag;
       next?: BastionFlag;
   };
    type BastionOptions = {
       persist?: boolean;
       broadcast?: boolean;
       audit?: boolean;
       defaultValue?: any;
   };
    type BastionCreateOptions = BastionOptions & {
       type?: BastionFlagType;
       rollout?: number;
       variants?: Record<string, BastionVariant>;
       targeting?: BastionTargetRule[];
       schedules?: BastionSchedule;
       metadata?: Record<string, any>;
   };
   // #endregion
      // #region ══ QUEUE ════════════════════════════════════════════════════════════════════
    type QueuedPush = { key: Key; p: Uint8Array };
    type QueuedEdit = { key: Key; transformFn: (bytes: Uint8Array) => Uint8Array };
    type QueuedDelete = { key: Key };
    type QueuedTransform = { key: Key; tierName: string };
    type TransformerQueued = { rt: ChannelKey; bytes: Uint8Array; seq: number };
    interface DemandSignal {
       requested: number;
       pending: number;
       request(n: number): void;
       cancel(): void;
       onDemandChange(cb: (signal: DemandSignal) => void): () => void;
   }
    interface BackpressureSignal {
       readonly paused: boolean;
       pause(): void;
       resume(): void;
       onPause(cb: () => void): () => void;
       onResume(cb: () => void): () => void;
   }
    interface RunOptions {
       clock?: Clock;
       priority?: Priority;
       scope?: string | Scope;
       signal?: AbortSignal;
       onError?: (e: unknown) => void;
   }
    interface Clock {
       now(): number;
       schedule(fn: () => void, delay: number, signal?: AbortSignal): Task;
       dispose(): void;
   }
    type VALUE_OBSERVABLE_FN = {
   };
    type RESOURCE_OBSERVABLE_FN = {
   };
    type PERSISTENCE_OBSERVABLE_FN = {
   };
    type DEMAND_OBSERVABLE_FN = {
   };
    type LIFECYCLE_OBSERVABLE_FN = {
   };
    type STATE_OBSERVABLE_FN = {
   };
    type TOPOLOGY_OBSERVABLE_FN = {
   };
    type EXECUTION_PRODUCER_FN = {
   };
    type Domain = 'UNIVERSAL' | 'LIFECYCLE' | 'FLOW_CONTROL' | 'OPERATOR' | 'TRANSPORT';
    type ExecutionEvent = {
       type: string;
       domain: Domain;
       t: number;
       id: string;          // execution correlation id (propagates through the pipeline)
       streamId: string;    // owning pipeline
       stage?: string;      // operator / stage name
       input?: any;
       output?: any;
       value?: any;
       error?: unknown;
       duration?: number;   // per-execution latency (ms, performance.now precision)
       status?: 'ok' | 'error' | 'dropped' | 'cancelled' | 'exhausted' | 'retrying' | 'handled' | 'unhandled' | 'flush'
       reason?: string;
       n?: number;
       queueSize?: number;
       capacity?: number;
       meta?: Record<string, any>;
       __intercepted?: boolean;
   };
    type ExecutionHandler = (event: ExecutionEvent) => void | false;
    type StageStats = { executions: number; dropped: number; errors: number; totalMs: number; maxMs: number };
   
   
    interface PRODUCER_FN {
       <T = any>(subscribe: (subscriber: Subscriber<T>) => Teardown): Producible<T>;
       inspect: () => void;
       map: {
           <A = any, B = any>(fn: (a: A, i: number) => B): Operator<A, B>;
           to: <A = any, B = any>(value: B) => Operator<A, B>;
       };
       take: {
           <T = any>(n: number): Operator<T, T>;
           while: <T = any>(pred: (v: T) => boolean) => any;
           until: <T = any>(notifier: Producible<unknown>) => any;
       };
       merge: {
           <T = any>(...sources: Producible<T>[]): Producible<T>;
           map: <A, B>(project: (a: A, i: number) => Producible<B>, concurrency?: number) => Operator<A, B>;
       };
       concat: {
           <T = any>(...sources: Producible<T>[]): Producible<T>;
           map: <A, B>(project: (a: A, i: number) => Producible<B>) => any
           all: <T = any>() => Operator<Producible<T>, T>;
       };
       window: {
           <T = any>(boundaries: Producible<unknown>): Operator<T, Producible<T>>;
           count: <T = any>(n: number) => Operator<T, Producible<T>>;
           time: <T = any>(ms: number, s?: Scheduler) => Operator<T, Producible<T>>;
           when: <T = any>(closing: () => Producible<unknown>) => Operator<T, Producible<T>>;
       };
       buffer: {
           <T = any>(boundaries: Producible<unknown>): Operator<T, T[]>;
           time: (ms: number, opts?: { priority?: Priority; scope?: string | Scope }) => any;
           when: <T = any>(closing: () => Producible<unknown>) => Operator<T, T[]>;
           toggle: <T = any>(openings: Producible<unknown>, closing: (v: unknown) => Producible<unknown>) => Operator<T, T[]>;
       };
       switch: {
           map: <A, B>(project: (a: A, i: number) => Producible<B>) => Operator<A, B>;
           all: <T = any>() => Operator<Producible<T>, T>;
       };
       exhaust: {
           map: <A, B>(project: (a: A, i: number) => Producible<B>) => Operator<A, B>;
           all: <T = any>() => Operator<Producible<T>, T>;
       };
       to: {
           emitter: <T = any>(k: string, sl?: any, ms?: any, rt?: any, ttl?: number, binary?: boolean) => Operator<T, T>;
           sauron: <T = any>(label: string, sl?: any, ms?: any, rt?: any, triggerRender?: boolean) => Operator<T, T>;
       };
       with: {
           start: <T = any>(...values: T[]) => Operator<T, T>;
           end: <T = any>(...values: T[]) => Operator<T, T>;
       };
       catch: {
           error: <T = any>(handler: (err: unknown, caught: Producible<T>) => Producible<T>) => Operator<T, T>;
           tag: <T = any>(tag: string, handler: (err: TaggedError) => Producible<T>) => Operator<T, T>;
       };
       listener: {
           add: (next: (v: any) => void) => any;
           remove: (s: Subscription) => void;
       };
       observe: <T = any>(next: (v: T) => void, source: Producible<T>) => Subscription;
       subscribe: <T = any>(next: (v: T) => void, source: Producible<T>) => Subscription;
       publish: <T = any>() => (source: Producible<T>) => Producible<T>;
       endWhen: <T = any>(signal: Producible<any>) => Operator<T, T>;
       startWith: <T = any>(...values: T[]) => Operator<T, T>;
       timeoutWith: <T = any>(ms: number, fallback: Producible<T>, sched: { schedule: (fn: () => void, d: number) => { cancel(): void } }, opts?: { priority?: Priority; scope?: string | Scope }) => Operator<T, T>;
       continueWith: <T = any>(...values: T[]) => Operator<T, T>;
       imitate: <T = any>(other: Producible<T>) => Producible<T>;
       transduce: <A = any, B = any>(transducer: (rf: (acc: B, x: A) => B) => (acc: B, x: A) => B, seed: B) => Operator<A, B>;
       during: <T = any>(t1: number, t2: number) => Operator<T, T>;
       since: <T = any>(t: number) => Operator<T, T>;
       until: <T = any>(signal: Producible<any>) => Operator<T, T>;
       chain: <A = any, B = any>(f: (a: A) => Producible<B>) => Operator<A, B>;
       flatten: <T = any>() => Operator<Producible<T>, T>;
       fold: <A = any, B = any>(fn: (acc: B, a: A) => B, seed: B) => Operator<A, B>;
       drop: <T = any>(n: number) => Operator<T, T>;
       reduce: <A = any, B = any>(fn: (acc: B, a: A) => B, seed: B) => Operator<A, B>;
       scan: <A = any, B = any>(fn: (acc: B, a: A) => B, seed: B) => Operator<A, B>;
       toArray: <T = any>() => Operator<T, T[]>;
       bufferCount: <T = any>(n: number) => Operator<T, T[]>;
       filter: <T = any>(pred: (v: T, i: number) => boolean) => Operator<T, T>;
       skip: <T = any>(n: number) => Operator<T, T>;
       first: <T = any>(pred?: (v: T) => boolean) => Operator<T, T>;
       last: <T = any>() => Operator<T, T>;
       distinctUntilChanged: <T = any>(eq?: (a: T, b: T) => boolean) => Operator<T, T>;
       tap: <T = any>(fn: (v: T) => void) => Operator<T, T>;
       finalize: <T = any>(fn: () => void) => Operator<T, T>;
       debounce: <T = any>(ms: number, s?: Scheduler, opts?: { priority?: Priority; scope?: string | Scope }) => Operator<T, T>;
       throttle: <T = any>(ms: number, s?: Scheduler, opts?: { priority?: Priority; scope?: string | Scope }) => Operator<T, T>;
       delay: <T = any>(ms: number, opts?: { priority?: Priority; scope?: string | Scope }) => Operator<T, T>;
       timeout: <T = any>(ms: number, s?: Scheduler, opts?: { priority?: Priority; scope?: string | Scope }) => Operator<T, T>;
       retry: <T = any>(count: number, delayMs?: number, s?: Scheduler) => Operator<T, T>;
       race: <T = any>(...sources: Producible<T>[]) => Producible<T>;
       combineLatest: <T extends readonly unknown[]>(sources: { [K in keyof T]: Producible<T[K]> }) => Producible<T>;
       zip: <T extends readonly unknown[]>(sources: { [K in keyof T]: Producible<T[K]> }) => Producible<T>;
       forkJoin: <T extends readonly unknown[]>(sources: { [K in keyof T]: Producible<T[K]> }) => Producible<T>;
       withLatestFrom: <A, B>(other: Producible<B>) => Operator<A, [A, B]>;
       multicast: <T = any>(subjectFactory: () => Subject<T>) => (source: Producible<T>) => Producible<T>;
       refCount: <T = any>() => (source: Producible<T>) => Producible<T>;
       audit: <T = any>(ms: number, s?: Scheduler) => Operator<T, T>;
       sample: <T = any>(notifier: Producible<unknown>) => Operator<T, T>;
       taggedError: (tag: string) => new (message: string) => TaggedError;
       remember: <T = any>() => Operator<T, T>;
       loop: (f: () => Producible<any>) => Promise<never>;
       compose: <A = any>(...ops: Operator<any, any>[]) => Operator<A, any>;
   }
    interface SubscribeOptions {
       clock?: Clock;
       priority?: Priority;
       scope?: string | Scope;
       signal?: AbortSignal;
   }
    type FuseContext = {
       next(v: any): void;
       error(e: any): void;
       complete(): void;
   };
    type FuseStep = (v: any, ctx: FuseContext) => any;
    type FuseComplete = (ctx: FuseContext) => void;
    type AnyOp = Operator<any, any> & {
       __fuse?: () => FuseStep;
       __fuseComplete?: () => FuseComplete;
   };
   
 type ManagedSource = {
    source: EventSource;
    url: string;
    channels: Map<string, Set<SSEHandler>>;
    attempts: number;
    retryTimer: ReturnType<typeof setTimeout> | null;
    status: 'connected' | 'disconnected' | 'reconnecting';
    ymirInstances: Map<string, YMIR<any>>;
};
 type BroadcasterClient = {
    id: string;
    send: (event: string, data: unknown) => void;
    channels: Set<string>;
};
 type FuseRoute = {
    status: 'closed' | 'open' | 'degraded';
    trippedAt: number;
    failures: number;
    overrideTarget?: string;
};
 type FuseBoxState = {
    routes: Record<string, FuseRoute>;
    lockdown: boolean;
};
 interface RequestOptions {
    timeout?: number;
    headers?: Record<string, string>;
    method?: string;
    signal?: AbortSignal;
    [key: string]: unknown;
}
 type Strategy = 'overwrite' | 'merge' | 'skip';
 type SyncDirection = 'memory->adapter' | 'adapter->memory' | 'both';
 type DeliveryStatus = 'ack' | 'nak';
 type QueryExpr =
    | { type: 'eq'; key: string; value: unknown }
    | { type: 'and'; exprs: QueryExpr[] }
    | { type: 'or'; exprs: QueryExpr[] };
 type FloodPayload = any;

 interface FloodGatesAdapter {
    adapter_id?: any
    id?: string;
    send(msg: FloodPayload): void;
    onMessage(handler: (msg: FloodPayload) => void): () => void;
    onConnect?(handler: () => void): void;
    onDisconnect?(handler: () => void): void;
}
 interface CSENginLink {
    get(key: string): Promise<any>;
    set(key: string, value: any): Promise<void>;
    delete(key: string): Promise<void>;
}
 interface CSESchema {
    validate(p: unknown): boolean;
    coerce?(p: unknown): unknown;
}
 interface ChannelPermissions {
    allow?: string[];
    deny?: string[];
    read?: string[];
    write?: string[];
}
 interface ChannelInfo {
    rt: string;
    handlers: number;
    adapters: string[];
    middleware: number;
    messageCount: number;
    tags: string[];
}
 interface AdapterMetrics {
    id: string;
    latencyMs: number;
    failureRate: number;
    throughputPerSec: number;
    healthy: boolean;
    disabled: boolean;
}
 interface BackpressureConfig {
    maxQueueSize?: number;
    slowConsumerThresholdMs?: number;
    throttleMs?: number;
}
 interface RouteRule {
    name: string;
    match: (msg: CSEMessage | CBORValue) => boolean;
    targetAdapters?: string[];
    targetChannels?: string[];
}
 interface Transform {
    outgoing?(msg: CSEMessage | CBORValue): CSEMessage | Promise<CSEMessage>;
    incoming?(msg: CSEMessage | CBORValue): CSEMessage | Promise<CSEMessage>;
}
 interface CompressionConfig {
    rt?: string;
    adapterId?: string;
    algorithm: string;
}
 interface DurableOptions {
    subscriberId: string;
    fromOffset?: number;
    fromTimestamp?: number;
    tags?: string[];
}
 interface ReplayOptions {
    rt: string;
    fromOffset?: number;
    toOffset?: number;
    fromTimestamp?: number;
    toTimestamp?: number;
    tags?: string[];
}
 interface GroupOptions {
    enabled?: boolean;
    middleware?: (msg: CSEMessage | CBORValue) => boolean | void;
}
 interface MessageMeta {
    id?: string;
    ttl?: number;
    priority?: CSEPriority;
    tags?: string[];
    timestamp?: number;
    streamId?: string;
    [key: string]: unknown;
}
 interface SendOptions {
    ttl?: number;
    priority?: CSEPriority;
    tags?: string[];
    metadata?: Record<string, unknown>;
    expectReply?: boolean;
}
 type CSEHandlerLegacy = (p: unknown) => unknown | Promise<unknown>;
 interface BatchItem {
    rt: string;
    p: Record<string, unknown>;
}
 interface CSEMiddleware {
    beforeSend?(msg: CSEMessage): boolean | void | Promise<boolean | void>;
    afterSend?(msg: CSEMessage, result: unknown): void | Promise<void>;
    beforeReceive?(msg: CSEMessage): boolean | void | Promise<boolean | void>;
    afterReceive?(msg: CSEMessage, result: unknown): void | Promise<void>;
    onError?(err: Error, msg?: CSEMessage): void | Promise<void>;
}
 interface ClusterConfig {
    nodeId: string;
    peers: string[];
}
 interface WebRTCAdapterOptions {
    signalingAdapter: CSEAdapter;
    peerId: string;
    iceServers?: RTCIceServer[];
}
 interface CSEScope {
    send(
        rt: string,
        ms: string,
        p: unknown,
        ttl?: number,
        binary?: boolean
    ): Promise<unknown>;

    sub(rt: string, ms: string, handler: CSEHandler): () => void;

    gar(
        rt: string,
        ms: string,
        p: unknown,
        ttl?: number,
        binary?: boolean
    ): Promise<unknown>;

    use(
        rt: string,
        fn: (msg: CSEMessage) => boolean | void
    ): void;

    scope(subprefix: string): CSEScope;

    multisub(
        rt: string,
        ms: string,
        handler: CSEHandler
    ): () => void;

    sendsub(
        rt: string,
        ms: string,
        p: unknown,
        ttl?: number,
        binary?: boolean
    ): Promise<unknown>;

    stream(
        rt: string,
        ms: string,
        p: any,
        onChunk: (chunk: any) => void,
        binary?: boolean
    ): Promise<void>;

    streamHandler(
        rt: string,
        ms: string,
        handler: (d: any) => any,
        binary?: boolean
    ): void;


    reply(
        replyChannel: string,
        ms: string,
        p: any
    ): Promise<unknown>;

    on(
        rt: string,
        ms: string,
        handler: CSEHandler
    ): () => void;

    once(
        rt: string,
        ms: string,
        handler: CSEHandler
    ): () => void;
}


 interface CoreAPI {
    init(ngin: CSENginLink): Promise<void>;
    registerAdapter(adapter: CSEAdapter): () => void;

    send(rt: string, p: unknown, options?: SendOptions): Promise<unknown>;
    gar(rt: string, p: unknown, options?: SendOptions): Promise<unknown>;
    reply(replyChannel: string, p: unknown, options?: SendOptions): Promise<unknown>;

    on(rt: string, handler: CSEHandler): () => void;
    sub(rt: string, handler: CSEHandler): () => void;
    once(rt: string, handler: CSEHandler): () => void;

    scope(prefix: string): CSEScope;
    DRS<T extends Record<string, unknown>>(rt: string, initial: T): T;
    request(rt: string, p: Record<string, unknown> & { timeout?: number }, options?: RequestOptions): Promise<unknown>;
    broadcast(rt: string, p: unknown, options?: SendOptions): Promise<void>;

    subWithHistory(rt: string, handler: CSEHandler, options?: { limit?: number }): () => void;
    batch(messages: BatchItem[]): Promise<unknown[]>;

    stream(
        rt: string,
        p: unknown,
        onChunk: (chunk: string, done: boolean, meta: MessageMeta) => void,
        options?: SendOptions
    ): Promise<void>;
    streamChunk(rt: string, streamId: string, chunk: string, meta?: MessageMeta): void;
    streamDone(rt: string, streamId: string, meta?: MessageMeta): void;
    cancelStream(rt: string, streamId: string): void;

    clear(): void;

    use(channelPattern: string, fn: (msg: CSEMessage) => boolean | void): void;
    useGlobal(mw: CSEMiddleware): void;

    createGroup(name: string, channels?: string[], options?: GroupOptions): void;
    deleteGroup(name: string): void;
    addChannelToGroup(name: string, rt: string): void;
    removeChannelFromGroup(name: string, rt: string): void;
    enableGroup(name: string): void;
    disableGroup(name: string): void;
    groupBroadcast(name: string, p: unknown, options?: SendOptions): Promise<void>;
    groupUse(name: string, fn: (msg: CSEMessage) => boolean | void): void;

    setDefaultPriority(priority: CSEPriority): void;
    getDefaultPriority(): CSEPriority;

    ack(messageId: string): void;
    nak(messageId: string, reason?: string): void;
    onDeliveryReceipt(handler: (info: { id: string; status: DeliveryStatus; reason?: string }) => void): () => void;
    listDeadLetters(rt?: string): Promise<CSEMessage[]>;
    requeueDeadLetter(id: string, options?: SendOptions): Promise<void>;

    subscribeDurable(rt: string, handler: CSEHandler, options: DurableOptions): () => void;
    setCheckpoint(rt: string, subscriberId: string, offset: number): Promise<void>;
    getCheckpoint(rt: string, subscriberId: string): Promise<number | null>;
    replay(options: ReplayOptions, handler: CSEHandler): Promise<void>;

    listChannels(): string[];
    getChannelInfo(rt: string): ChannelInfo | null;
    listHandlers(rt?: string): { rt: string; count: number }[];
    listAdapters(): string[];
    listMiddleware(rt?: string): number[];
    getMessageCount(rt: string): number;

    getAdapterMetrics(): AdapterMetrics[];
    disableAdapter(id: string): void;
    enableAdapter(id: string): void;
    setBackpressureConfig(config: BackpressureConfig): void;

    setChannelSchema(rt: string, schema: CSESchema): void;
    getChannelSchema(rt: string): CSESchema | null;

    setChannelPermissions(rt: string, perms: ChannelPermissions): void;
    getChannelPermissions(rt: string): ChannelPermissions | null;

    addRouteRule(rule: RouteRule): void;
    removeRouteRule(name: string): void;
    listRouteRules(): RouteRule[];

    addTransform(channelPattern: string, transform: Transform): void;
    removeTransform(channelPattern: string): void;

    configureEncryption(config: EncryptionConfig): void;
    configureCompression(config: CompressionConfig): void;

    subscribeByTag(tag: string, handler: CSEHandler): () => void;
    listTags(): string[];
    listChannelsByTag(tag: string): string[];

    enableHubMode(enabled: boolean): void;
    syncFromHub(options?: { since?: number }): Promise<void>;

    getTimeline(rt: string, options?: { limit?: number }): Promise<CSEMessage[]>;
    rewind(rt: string, toTimestamp: number): Promise<void>;
    diff(rt: string, fromTimestamp: number, toTimestamp: number): Promise<unknown>;

    setAdapterPriority(id: string, priority: number): void;
    addFallbackAdapter(primaryId: string, fallbackId: string): void;

    configureCluster(config: ClusterConfig): void;
    getClusterConfig(): ClusterConfig | null;
}
    type CircuitState = 'closed' | 'open' | 'half-open';
   
    interface CircuitBreakerOptions {
       enabled?: boolean;               // default true once `circuitBreaker` is provided
       failureThreshold?: number;       // consecutive failures to trip open, default 5
       cooldownMs?: number;             // base time circuit stays open, default 15000
       cooldownFactor?: number;         // exponential growth per repeat trip, default 2
       cooldownMaxMs?: number;          // ceiling on cooldown, default 300000 (5 min)
       halfOpenMaxAttempts?: number;    // trial requests before reopening, default 1
   }
    type LongPollState = 'idle' | 'connecting' | 'open' | 'backoff' | 'paused' | 'closed' | 'circuit-open';
   
    interface LongPollMetric {
       type: 'request' | 'success' | 'error' | 'timeout' | 'retry' | 'leaderChange' | 'circuitOpen' | 'circuitHalfOpen' | 'circuitClose';
       durationMs?: number;
       status?: number;
       attempt?: number;
       isLeader?: boolean;
       error?: unknown;
   
   }
   
   
   
    interface AdaptiveInterval {
       min?: number;         // ms between polls when data is flowing, default 0
       max?: number;         // ms ceiling when quiet, default 8000
       step?: number;        // growth per empty response, default 500
   }
   
    interface LongPollOptions<T, C = unknown> {
       url: string | (() => string);
       fetcher?: typeof fetch;                                 // inject for Node/tests
       buildRequest?: (cursor: C | undefined) => RequestInit;
       parseResponse?: (res: Response) => Promise<{ data: T | null; cursor?: C }>;
       getInitialCursor?: () => C | undefined;
       circuitBreaker?: CircuitBreakerOptions | false;
       backoff?: BackoffOptions;
       adaptiveInterval?: AdaptiveInterval;
       timeoutMs?: number;                                     // per-request timeout, default 30000
       inactivityMs?: number;                                  // watchdog, default 0 (off)
   
       retryable?: (status: number | null, error: unknown) => boolean;
   
       interceptors?: {
           beforeRequest?: (init: RequestInit) => RequestInit | Promise<RequestInit>;
           onResponse?: (res: Response) => void | Promise<void>;
       };
   
       crossTabLeaderElection?: boolean;                        // default false
       channelName?: string;                                    // BroadcastChannel name
       pauseOnHidden?: boolean;                                 // default true
       pauseOnOffline?: boolean;                                // default true
   
       onMetric?: (metric: LongPollMetric) => void;
   }
   
    type EventMap<T> = {
       data: T;
       error: unknown;
       stateChange: { from: LongPollState; to: LongPollState };
       open: void;
       close: void;
       retry: { attempt: number; delayMs: number };
       circuitChange: { from: CircuitState; to: CircuitState }
   };
    interface OPTIONAL_IMPORT_OPTIONS<T, F = any> {
    moduleName?: string;
    fallback?: F | (() => F);
    preferRequire?: boolean;
    module?: boolean;
    importPromise?: any;
    comp_name?: string;
    [key: string]: any;
}

interface EnvDetectionState {
    moduleLevel: string | null;
    platform: string | null;
    compilers: string[];   // full scan
    bundler: string | null;
    adapters: string[];    // full scan
    ready: boolean;
}

    type Handler<E> = (p: E) => void;
     // #endregion  
   // #endregion
   // #region ███ SWR ████████████████████████████████████████████████████████████████████
    interface SWRGlobalConfig {
       fetcher?: (key: string) => Promise<unknown>
       revalidateOnFocus?: boolean
       revalidateOnReconnect?: boolean
       revalidateIfStale?: boolean
       dedupingInterval?: number
       refreshInterval?: number
   }
   
    interface SWROptions<T> {
       fetcher?: (key: string) => Promise<T>
       revalidateOnFocus?: boolean
       revalidateOnReconnect?: boolean
       revalidateIfStale?: boolean
       dedupingInterval?: number
       refreshInterval?: number
       fallbackData?: T
       suspense?: boolean
       keepPreviousData?: boolean
       onSuccess?: (data: T) => void
       onError?: (error: Error) => void
   }
   
    interface SWRResponse<T> {
       data: T | undefined
       error: Error | undefined
       isLoading: boolean
       isValidating: boolean
       mutate: (data?: T | Promise<T> | ((current: T | undefined) => T | Promise<T>), revalidate?: boolean) => Promise<T | undefined>
   }
   
    type KeyLoader<T> = (index: number, previousPageData: T | null) => string | null | undefined | false
   
    interface SWRInfiniteOptions<T> {
       fetcher?: (key: string) => Promise<T>
       initialSize?: number
       revalidateFirstPage?: boolean
       revalidateAll?: boolean
       parallel?: boolean
       fallbackData?: T[]
       onSuccess?: (data: T[]) => void
       onError?: (error: Error) => void
   }
   
    interface SWRInfiniteResponse<T> {
       data: T[] | undefined
       error: Error | undefined
       isLoading: boolean
       isValidating: boolean
       size: number
       setSize: (size: number | ((s: number) => number)) => void
       mutate: (data?: T[]) => Promise<void>
   }
   
    interface SWRMutationOptions<T, A> {
       onSuccess?: (data: T, key: string, arg: A) => void
       onError?: (error: Error, key: string, arg: A) => void
       revalidate?: boolean
       populateCache?: boolean | ((result: T, current: T | undefined) => T)
       optimisticData?: T | ((current: T | undefined) => T)
       rollbackOnError?: boolean
       throwOnError?: boolean
   }
   
    interface SWRMutationResponse<T, A> {
       data: T | undefined
       error: Error | undefined
       isMutating: boolean
       trigger: (arg: A, options?: SWRMutationOptions<T, A>) => Promise<T | undefined>
       reset: () => void
   }
   
    type SWRSubscriptionNext<T> = (error: Error | null, data?: T) => void
    type SWRSubscribe<T> = (key: string, options: { next: SWRSubscriptionNext<T> }) => () => void
   
    interface SWRSubscriptionOptions<T> {
       fallbackData?: T
   }
   
    interface SWRSubscriptionResponse<T> {
       data: T | undefined
       error: Error | undefined
   }
   
   // #endregion
   // #region ███ YIMIR ██████████████████████████████████████████████████████████████████
    type MutateData<T> = T | Promise<T> | ((current: T | undefined) => T | Promise<T>)
   
    interface MutateOptions<T> {
       revalidate?: boolean
       fetcher?: (key: string) => Promise<T>
       populateCache?: boolean
   }
   
    interface PrefetchOptions<T> {
       fetcher?: (key: string) => Promise<T>
       dedupe?: boolean
   }
   
    type YmirServerClient = { controller: ReadableStreamDefaultController; encoder: TextEncoder };
    type YmirHandler = (p: unknown) => void;
   
   // #endregion
   // #region ███ SSE ████████████████████████████████████████████████████████████████████
    type UseSSEOptions = {
       baseDelay?: number
       maxDelay?: number
       maxAttempts?: number
   }
   
   
    type ServerResponse = {
       setHeader?: (key: string, value: string) => void;
       write?: (chunk: string) => boolean;
       on?: (event: string, cb: () => void) => void;
       flush?: () => void;
       end?: () => void;
   };
interface Scheduler {
    now(): number;
    schedule(fn: () => void, delay?: number): { cancel(): void };
}
 type stream_string = string
type maybe_s_string = string | undefined
 interface DUPLEX_FN {
    <TUp = any, TDown = any>(k: string, sl?: string, ms?: string, rt?: string, opts?: { windowSize?: number }, type?: string,): DuplexStream<TUp, TDown>;

    open<T = any>(
        opts: { highWaterMark: number },
        k: string,
        sl?: string,
        ms?: string,
        rt?: string,
    ): any;
}
 interface DUPLEX_SIGNALS_FN {
    (readConfig: { k: string; sl?: string; ms?: string; rt?: string },
        writeConfig: { k: string; sl?: string; ms?: string; rt?: string }
        ,): any;

    async<TUp = any, TDown = any>(
        k: string,
        sl?: SU,
        ms?: SU,
        rt?: SU,
        opts?: { windowSize?: number },
    ): any;
}
 type StreamLabStage<T> = {
    name: string
    handler: (data: T) => T | Promise<T>
    errorHandler?: (err: Error, data: T) => T
}
 interface StreamLabDefinition<T = any, TState = any, TPayload = any, TKey extends string = string> {
    routes?: Record<any, any>;
    switchboardOptions?: Partial<SwitchboardOptions<TPayload, TKey>>
    selectKey?: (p: TPayload) => TKey
    initialState?: TState
    tree?: PlinkoTree<TState, TPayload>
    plinkoOptions?: PlinkoOptions<TState, TPayload>
    pipelineStages?: StreamLabStage<T>[]
    meshOptions?: { peerId?: string; announceInterval?: number; peerTimeout?: number; maxPeers?: number }
    relayOptions?: { maxSubscribers?: number; bufferSize?: number; backpressureStrategy?: 'drop' | 'pause' | 'error' }
    broadcastOutput?: boolean
    broadcastStageOutput?: boolean
    routing: {
        selectKey: (p: T) => string;
        onUnmatched?: (p: T, key: string) => void;
    };
    mesh?: {
        enabled?: boolean;
        peerId?: string;
        announceInterval?: number;
        peerTimeout?: number;
        maxPeers?: number;
        fanout?: number;
    };
    sync?: {
        enabled?: boolean;
        windowSize?: number;
        binary?: boolean;
        onAck?: (seq: number) => void;
    };

    maxInflight?: number;
    metadata?: Record<string, any>;
}
 interface StreamLabHandle<T = any, TState = any, TPayload = any, TKey extends string = string> {
    process?(p: T): Promise<T>
    board?: SwitchboardHandle<TPayload, TKey> | null
    plinko?: PlinkoSession<TState, TPayload> | null
    pipeline?: {
        stage?(name: string, handler: (data: T) => T | Promise<T>): unknown
        onError?(stageName: string, handler: (err: Error, data: T) => T): unknown
        execute?(input: T): Promise<T>
        observe?(handler: (event: { type: string; stage?: string; data?: T; error?: string }) => void): unknown
    }
    mesh?: {
        getPeers?(): Array<{ id: string; lastSeen: number; metadata: Record<string, any>; latency: number }>
        getPeerCount?(): number
        sendTo?(targetPeerId: string, p: T): Promise<unknown>
        sendVeto?(targetPeerId: string, p: T): Promise<unknown>
        gossip?(p: T, fanout?: number): Promise<void>
        onMessage?(handler: (message: { from: string; p: T }) => void): unknown
        findNearest?(): { id: string; latency: number } | null
        destroy?(): void
    }
    relay?: {
        publish(chunk: any): Promise<void>
        subscribe(handler: (chunk: any) => void): {
            unsubscribe(): void
            pause(): void
            resume(): void
            getBufferSize(): number
        }
        end(): Promise<void>
    }
    sync?(chunks: any[], onAck?: (seq: number) => void, windowSize?: number, binary?: boolean): Promise<void>
    syncSub?(handler: (chunk: any, seq: number) => Promise<void> | void): void
    broadcast?(data: T): void
    publish?: (p: T) => Promise<StreamLabResult>;
    publishMany?: (payloads: T[]) => Promise<StreamLabResult[]>;
    subscribe?: (
        handler?: (result: StreamLabResult) => Promise<void> | void
    ) => () => void;
    getTopology?: () => any;
    getStats?: () => any;
    getPeers?: () => any[];
    getPeerCount?: () => number;
    registerRoute?: (
        key?: string,
        route?: StreamLabRoute<T>
    ) => void;
    unregisterRoute?: (key: string) => boolean;
    updateRoutes?: (
        routes?: Record<string, StreamLabRoute<T> | undefined>
    ) => void;
    injectStep?: (key: string, step: PlinkoStep2) => void;
    getSession?: (sessionId: string) => PlinkoContext2 | undefined;
    replay?: (sessionId: string) => Promise<PlinkoExecutionResult2>;
    pause?: () => void;
    resume?: () => void;
    destroy: () => void;
}
 type StreamLabStageContext<T = any> = {
    p: T;
    streamId: string;
    sequence: number;
    route?: string;
    sessionId?: string;
    metadata: Map<string, any>;
    bus: any;
};
 type StreamLabRoute<T = any> = {
    match?: (p: T) => boolean | Promise<boolean>;
    execute: Record<string, PlinkoStep2> | PlinkoTree2<T>;
    startStep?: string;
};
 type StreamLabResult = {
    success: boolean;
    streamId: string;
    sequence: number;
    route?: string;
    result?: any;
    error?: Error;
    duration: number;
};
 type SX__FN = {
    (data?: any, k?: string, sl?: string, ms?: string, rt?: string): any;
    no_payload(k?: string, sl?: string, ms?: string, rt?: string): any;

    create: () => void;
    read: () => void;
    write: () => void;
    subscribe: () => void;
    effect: () => void;
    computed: () => void;

    map: () => void;
    filter: () => void;
    sub: () => void;
    pipe: () => void;
    streamed: () => void;   // streamed value, no setter
    duplexed: () => void;   // getter + setter

    drs: () => void;
    useDRS: () => void;
    useEffectDRS: () => void;
    useMemoDRS: () => void;
    useReducerDRS: () => void;
    createContext: () => void;
    useContext: () => void;
    setHC: () => void;
    getHC: () => void;
    deleteHC: () => void;

    stream: () => void;
    relay: () => void;
    send: () => void;
};
 interface STREAMS_SX_FN {
    (p: any, onChunk: (chunk: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): Promise<void>;
    readable(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): ReadableStream<any>;
    writable(k?: SU, sl?: SU, ms?: SU, rt?: SU): WritableStream<any>;
    duplex(readConfig: {
        k: string;
        sl?: string | undefined;
        ms?: string | undefined;
        rt?: string | undefined;
    }, writeConfig: {
        k?: string | undefined;
        sl?: string | undefined;
        ms?: string | undefined;
        rt?: string | undefined;
    }): {
        sub: ReadableStream<any>;
        send: WritableStream<any>;
    };
    StreamRelay(k?: SU, sl?: SU, ms?: SU, rt?: SU, opts?: StreamRelayOptions): any;
    transform(readConfig: {
        k: string;
        sl?: string | undefined;
        ms?: string | undefined;
        rt?: string | undefined;
    }, writeConfig: {
        k?: string | undefined;
        sl?: string | undefined;
        ms?: string | undefined;
        rt?: string | undefined;
    }, transformer?: (chunk: any) => any | Promise<any>): {
        sub: TransformStream<any, any>;
        send: TransformStream<any, any>;
    };
    pipeline<T = any>(k?: SU, sl?: SU, ms?: SU, rt?: SU, stages?: HydraStage<T>[]): {
        unsubscribe: () => void;
    };
    route<T = any>(k?: SU, sl?: SU, ms?: SU, rt?: SU, selectKey?: (p: T) => string, outPrefix?: string, opts?: {
        defaultKey?: string;
        onUnmatched?: (p: T, key: string) => void;
    }): {
        unsubscribe: () => void;
        stats: () => Record<string, number>;
    };
    from: {
        emitter(k?: SU, sl?: SU, ms?: SU, rt?: SU): any;
        signal(sauron: SignalSurface, key: any): any;
        any(src: any): any
        busChannel<T = any>(k?: SU, sl?: SU, ms?: SU, rt?: SU): any
        relay<T = any>(k?: SU, sl?: SU, ms?: SU, rt?: SU): any;
    };
    to: {
        emitter(obs: any, k?: SU, sl?: SU, ms?: SU, rt?: SU): Teardown;
        busChannel<T = any>(k?: SU, sl?: SU, ms?: SU, rt?: SU): (source: any) => any;
        relay(k?: SU, sl?: SU, ms?: SU, rt?: SU, outs?: string[]): {
            unsubscribe: () => void;
        };
    };
    syncGuard(chunks: any[], k: string, options?: SyncIntegrityOptions): Promise<SyncIntegrityResult>;
    relayWithFlowControl(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, options?: RelayFlowOptions): any;
    useDRSWithConsensus(initialState: any, k?: SU, sl?: SU, ms?: SU, rt?: SU, options?: DRSConflictOptions): any;
    sync(chunks: any[], k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, onAck?: (seq: number) => void, windowSize?: number, binary?: boolean): Promise<void>;
    relay(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, options?: {
        maxSubscribers?: number;
        bufferSize?: number;
        backpressureStrategy?: 'drop' | 'pause' | 'error';
    }): any;
    openSync(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        windowSize?: number;
    }): any;
    priority(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    transactional(chunks: any[], k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): Promise<{
        committed: boolean;
        error?: string;
    }>;
    delta<T extends any>(computeDelta: (prev: T, next: T) => any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    presence(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    authority<T = any>(initial: T, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    heartbeat(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        idleThresholdMs?: number;
    }): any;
    compression(p: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        threshold?: number;
    }): Promise<void>;
    backpressure(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        windowSize?: number;
    }): any;
    stateful(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        key?: string;
    }): any;
    multicast(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        key?: string;
    }): any;
    partitioned(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        partitionCount?: number;
    }): any;
    batch(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        maxSize?: number;
        maxWaitMs?: number;
    }): any;
    filtered(predicate: (p: any) => boolean, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    deadLetter(p: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        maxRetries?: number;
        backoff?: BackoffOptions;
    }): Promise<{
        delivered: boolean;
    }>;
    idempotent(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    lateArrival(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    checkpoint(streamKey: string, opts?: {
        every?: number;
    }): any;
    rateLimited(opts: {
        ratePerSecond: number;
        burst?: number;
    }, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    combo(k: string, sl: string[], ms?: string | undefined, rt?: string | undefined, strategy?: ComboStrategy): any;
    transformative(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    fanout(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        key?: string;
    }): any;
    useDRSS<T extends Record<string, unknown> = any, P = any>(initial: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): any;
    useDRSSSync(initial: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): any;
}
 type SauronListener = (value: unknown) => void;
 interface DRSHookOptions {
    hydrate?: (key: string) => unknown;
}
 type AnySub = { next: (v: any) => void; error: (e: any) => void; complete: () => void };
//  type Operator<A = any, B = any> = (source: Producible<A>) => Producible<B>;
//  type Teardown = (() => void) | { unsubscribe(): void };
 type ExecEvent = { domain: string; type: string; streamId?: string; at: number; data?: any };
 type EventCore = { emit(ev: ExecEvent): void };
 type OpPair<T = any, A = any> = { __fuse?: () => (v: any) => any; op: Operator<T, A> };
 type SchedFn = (fn: () => void, opts?: { priority?: string; scope?: string; delay?: number; signal?: AbortSignal }) => Task;
 interface STREAM_FN {
    (p: any, onChunk: (chunk: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): Promise<void>;
    syncGuard(chunks: any[], k: string, options?: SyncIntegrityOptions): Promise<SyncIntegrityResult>;
    relayWithFlowControl(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, options?: RelayFlowOptions): any;
    useDRSWithConsensus(initialState: any, k?: SU, sl?: SU, ms?: SU, rt?: SU, options?: DRSConflictOptions): any;
    sync(chunks: any[], k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, onAck?: (seq: number) => void, windowSize?: number, binary?: boolean): Promise<void>;
    relay(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, options?: {
        maxSubscribers?: number;
        bufferSize?: number;
        backpressureStrategy?: 'drop' | 'pause' | 'error';
    }): any;
    openSync(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        windowSize?: number;
    }): any;
    priority(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    transactional(chunks: any[], k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): Promise<{
        committed: boolean;
        error?: string;
    }>;
    delta<T extends any>(computeDelta: (prev: T, next: T) => any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    presence(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    authority<T = any>(initial: T, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    heartbeat(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        idleThresholdMs?: number;
    }): any;
    compression(p: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        threshold?: number;
    }): Promise<void>;
    backpressure(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        windowSize?: number;
    }): any;
    stateful(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        key?: string;
    }): any;
    multicast(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        key?: string;
    }): any;
    partitioned(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        partitionCount?: number;
    }): any;
    batch(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        maxSize?: number;
        maxWaitMs?: number;
    }): any;
    filtered(predicate: (p: any) => boolean, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    deadLetter(p: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        maxRetries?: number;
        backoff?: BackoffOptions;
    }): Promise<{
        delivered: boolean;
    }>;
    idempotent(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    lateArrival(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    checkpoint(streamKey: string, opts?: {
        every?: number;
    }): any;
    rateLimited(opts: {
        ratePerSecond: number;
        burst?: number;
    }, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    combo(k: string, sl: string[], ms?: string | undefined, rt?: string | undefined, strategy?: ComboStrategy): any;
    transform(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    fanout(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        key?: string;
    }): any;
    useDRSS<T extends Record<string, unknown> = any, P = any>(initial: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): any;
    useDRSSSync(initial: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): any;
}
 interface STREAM_HANDLER_FN {
    (handler: (d: any) => any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): void;
    syncGuard(handler: (chunk: any, seq: number, streamId: string) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, options?: SyncSubGuardOptions): void;
    sync(handler: (chunk: any, seq: number) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): void;
    openSync(handler: (chunk: any, seq: number) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
    priority(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
    transactional(apply: (chunks: any[]) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
    delta<T>(applyPatch: (current: T, diff: any) => T, initial: T, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    presence(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, onUpdate?: (all: Record<string, any>) => void): any;
    authority<T>(resolve: (guess: T) => Promise<T> | T, k: string, sl: string, ms: string, rt: string): () => void;
    heartbeat(onDead: () => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        deadThresholdMs?: number;
    }): any;
    sendCompression(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, format?: CompressFormat): () => void;
    backpressure(handler: (p: any) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
    stateful(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        key?: string;
    }): any;
    multicast(receiverId: string, handler: (p: any, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        key?: string;
        startFrom?: 'beginning' | 'now';
    }): Promise<any>;
    partitioned(handler: (key: string, p: any, partition: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        partitions?: number[];
        partitionCount?: number;
    }): any;
    batch(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
    filtered(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, predicate?: (p: any) => boolean): () => void;
    deadLetter(handler: (entry: CSEMessage) => Promise<boolean> | boolean): any;
    idempotent(handler: (p: any) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        keyPrefix?: string;
        ttlMs?: number;
    }): () => void;
    lateArrival(handler: (p: any, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        strategy?: LateArrivalStrategy;
        toleranceMs?: number;
    }): () => void;
    checkpoint(streamKey: string, handler: (p: any, seq: number) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        every?: number;
    }): Promise<() => void>;
    rateLimited(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
    combo(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    transform<T = any, R = any>(fn: (p: T) => Promise<R> | R, onResult: (result: R, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        concurrency?: number;
    }): () => void;
    map<T = any, R = any>(fn: (item: T) => R, onResult: (r: R, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        concurrency?: number;
    }): any;
    filter<T = any>(predicate: (item: T) => boolean, onResult: (item: T, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
    reduce<T = any, R = any>(fn: (acc: R, item: T) => R, initial: R, onUpdate: (acc: R) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
    fanout(receiverId: string, handler: (p: any, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
        key?: string;
        startFrom?: 'beginning' | 'now';
    }): any;
    useDRSS<T extends Record<string, unknown> = any, P = any>(initial: any, handler: (chunk: any, state: any) => any | Promise<T>, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): any;
    useDRSSSync(initial: any, handler: (chunk: any, seq: number, state: any) => any | Promise<any>, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): any;
}
 type HadronKey = string | number | symbol;
 type HadronOperation = 'set' | 'delete' | 'consume';
 interface HadronEvent<T = unknown> {
    readonly id: string;
    readonly operation: HadronOperation;
    readonly key: HadronKey;
    readonly value?: T;
    readonly origin: string;
    readonly sequence: number;
    readonly at: number;
    readonly triggerRender: boolean;
    readonly meta?: Readonly<Record<string, unknown>>;
}
 type HadronTransform<TIn, TOut> = (
    event: HadronEvent<TIn>,
) => HadronEvent<TOut> | null | undefined | Promise<HadronEvent<TOut> | null | undefined>;
 interface HadronDuplex<TUp = unknown, TDown = unknown> {
    send(p: TUp): void;
    onData(handler: (p: TDown, sequence: number) => void): () => void;
    onError?(handler: (error: unknown) => void): () => void;
    close?(): void;
}
 interface HadronColliderOptions {
    /** The first rt.  CH_2/CH_3 default to the staff's scoped channels. */
    k: string;
    sl?: string;
    ms?: string;
    rt?: string;
    windowSize?: number;
    /** A stable node id makes echoed traffic safely idempotent. */
    origin?: string;
    /** Bounds the duplicate window without turning it into a history store. */
    duplicateWindow?: number;
}
 interface SwitchboardOptions<TPayload = any, TKey extends string = string> {
    selectKey: (p: TPayload) => TKey;
    onUnmatched?: (p: TPayload, key: TKey) => void;
}
 interface Permit {
    id: string;
    label?: string;
    acquiredAt: number;
    release(): void;
    renew(): void;
}
 interface SemaphoreConfig {
    limit: number;
    leaseMs?: number;
    distributed?: boolean;
    nodeId?: string;         // required if distributed: true
    raft?: RAFT;              // required if distributed: true
    hlc?: HYBRID_LOGICAL_CLOCK;
    pollIntervalMs?: number;  // distributed-mode capacity poll, default 75
}
 interface QueueEntry {
    hlcStamp: string;
    label?: string;
    resolve: (permit: Permit) => void;
    reject: (err: Error) => void;
    timeoutTimer?: any;
    createdAt: number;
}
 interface ActivePermit {
    id: string;
    label?: string;
    acquiredAt: number;
    leaseTimer: any;
}
 interface RemoteHolder {
    nodeId: string;
    label?: string;
    acquiredAt: number;
}
 type DevtoolsEvent = {
    type?: S | A
    r?: S | A
    s?: S
    k?: A
    m?: S | A;
    msgId?: S | A
    detail?: Record<string, unknown> | any
    // CSE MESSAGE VALUES
    id?: string | any;
    p?: unknown | any;
    ttl?: number | any;
    _ack?: boolean | any;
    _adapter?: CSEAdapter | any;
    priority?: CSEPriority | any;
    tags?: string[] | any;
    streamId?: string | any;
    sessionId?: any;
    token?: any;
    binary?: 'signal_save_value' | 'signal' | true | false | string;
    error?: any
    adapter_id?: any
    ts?: any
    full_channel?: any
}
 type DeltaFn<T> = (prev: T, next: T) => any; // computes a compact diff — caller-supplied, since diff shape depends on data shape
 type PatchFn<T> = (current: T, diff: any) => T; // applies a received diff to local state — must be the inverse of deltaFn
 type COMBINE__FN = {
    <T extends readonly unknown[]>(...sources: { [K in keyof T]: Producible<T[K]> }): Producible<T>;
    array: <T = any > (f: (...vs: any[]) => T, sources: Producible<any>[]) => Producible<T>;
};
 type MetricsSink = (metric: SignalMetric & { key: string }) => void
 interface ChannelOptions {
    highWaterMark: number;
    strategy?: any;
    ttl?: number
}
 interface SignalMetric {
    writeCount: number
    readCount: number
    subscriberCount: number
    lastWrite: number
    flushDuration: number
}
 interface SignalContract {
    name: string
    keys: string[]
    invariant: (snapshot: Record<string, any>) => boolean
    block: boolean
}
 type PlinkoContext<TState = any, TPayload = any> = {
    state: TState;
    p: TPayload;
    path: string[];
    metadata: Map<string, any>;
    reply: (data: unknown, targetSc?: string) => Promise<unknown>;
    abort: (reason?: string) => void;
};
 type PlinkoNode<TState = any, TPayload = any, TResult = any> = {
    matcher: (p: TPayload, ctx: PlinkoContext<TState, TPayload>) => boolean | Promise<boolean>;
    execute?: (p: TPayload, ctx: PlinkoContext<TState, TPayload>) => TResult | Promise<TResult>;
    branches?: Record<string, PlinkoNode<TState, TPayload, TResult>>;
    hooks?: {
        beforeEnter?: (p: TPayload, ctx: PlinkoContext<TState, TPayload>) => void | Promise<void>;
        afterExit?: (result: TResult, ctx: PlinkoContext<TState, TPayload>) => void | Promise<void>;
    };
};
 type PlinkoTree<TState = any, TPayload = any, TResult = any> = Record<string, PlinkoNode<TState, TPayload, TResult>>;
 interface PlinkoOptions<TState = any, TPayload = any> {
    onError?: (err: any, nodePath: string[], p: TPayload) => void;
    onTransition?: (fromPath: string[], toPath: string[], p: TPayload) => void;
    autoResetOnTerminal?: boolean;
}
    // #endregion   // #region ══ TOMB OF SECRETS ════════════════════════════════════════════════════════════════════
// #region ══ SHARDS - CELLS ════════════════════════════════════════════════════════════════════
  type SOUL_KEY = string | number | symbol;
  type OWNERSHIP = "bespoke" | "shared";
  type SOUL_SHARD_TYPE = object;
  type ROOT_SHARD = SOUL_SHARD<any> | null;
type SHARD_CLASS<S extends object> = new (...args: any[]) => S;
  interface CHANGE<W> {
    key: SOUL_KEY;
    previous: W;
    current: W;
}
  type LISTENER<W> = (change: CHANGE<W>) => void;
  type UNSUBSCRIBE = () => void;
interface SLOT {
    shard: SOUL_SHARD;
    owner: OWNERSHIP;
}
    // #endregion   

    // #region ══ TOMB OF SECRETS ════════════════════════════════════════════════════════════════════
     // #endregion  
 type AnyFunction = (...args: any[]) => any;
 type ChainInvocationMode = "direct" | "operator" | "factory" | "side_effect";
 type Chainify<T> = T extends AnyFunction ? (...args: Parameters<T>) => Chainify<ReturnType<T>> : T extends object ? { [K in keyof T]: Chainify<T[K]> } : T;
 interface ChainState {
    value: any;
    previous: any;
    graph: ChainInvocation[];
    version: number;
}
 interface chains_type {
    k?: string
    sl: string
    ms: string
    rt: string
    p?: any
    initial_value?: any
}
 interface ChainInvocation {
    mode?: ChainInvocationMode;
    fn?: Function | string;
    args?: any[];
    path?: any[];
    property?: any;
}
 interface StreamSheetState {
    value: any;
    previous: any;
    graph: ChainInvocation[];
    version: number;
    error?: any;
}
 type SSXUnsubscribe = () => void;
 type SSXMaybePromise<T> = T | Promise<T>;
 type SSXChannelConfig = {
    k?: string;
    sl?: string;
    ms?: string;
    rt?: string;
};
 type SSXStatus = | "idle" | "queued" | "running" | "streaming" | "ready" | "completed" | "cancelled" | "error" | "disposed";
 type SSXStreamOverflow = | "drop-oldest" | "drop-newest" | "error";
 type SSXNodeOptions = {
    /**
     * "replace" cancels the prior run when .run() is invoked again.
     * "queue" is reserved for future multi-run queue behavior.
     */
    mode?: "replace" | "queue";

    /**
     * Metadata only in the core implementation.
     * Add your DRS/CRDT projection adapter later.
     */
    persist?: boolean;

    /**
     * Used by stream adapters that need buffering.
     */
    stream?: {
        bufferSize?: number;
        overflow?: SSXStreamOverflow;
    };

    tags?: string[];
};
 type SSXCell<T = unknown> = {
    id: string;
    label: string;

    epoch: number;
    revision: number;

    status: SSXStatus;

    value?: T;
    previous?: T;
    error?: unknown;

    emissions: number;

    startedAt?: number;
    updatedAt?: number;
    completedAt?: number;

    tags?: string[];
};
 type SSXSnapshot<T = unknown> = {
    id: string;
    epoch: number;

    status: SSXStatus;

    input?: unknown;
    value?: T;
    error?: unknown;

    startedAt?: number;
    updatedAt?: number;
    completedAt?: number;

    cells: Record<string, SSXCell>;
};
 type SSXTeardown = () => void | Promise<void>;
 type SSXPlatformContext = {
    /**
     * Your existing platform/declarative context belongs here.
     * It remains intentionally open because your surface area is large.
     */
    [key: string]: any;
};
 type SSXContext = {
    readonly chainId: string;
    readonly nodeId: string;
    readonly nodeLabel: string;
    readonly epoch: number;

    readonly signal: AbortSignal;
    readonly input: unknown;

    /**
     * Live values written by named key.
     *
     * $.self.foo = value
     * $.self.foo
     * $.self.$read("foo")
     * $.self.$subscribe("foo", listener)
     */
    readonly self: Record<string, any> & {
        $read<T = unknown>(name: string): T | undefined;
        $peek<T = unknown>(name: string): T | undefined;
        $subscribe<T = unknown>(
            name: string,
            listener: (value: T, source?: string) => void,
        ): SSXUnsubscribe;
    };

    readonly cells: {
        get<T = unknown>(idOrLabel: string): SSXCell<T> | undefined;
        value<T = unknown>(idOrLabel: string): T | undefined;
        subscribe<T = unknown>(
            idOrLabel: string,
            listener: (cell: SSXCell<T>) => void,
        ): SSXUnsubscribe;
    };

    /**
     * Emits a live node value immediately.
     * This is how callback streams can update the chain in real time.
     */
    emit<T = unknown>(value: T): void;

    /**
     * Merges object fields into the current chain output.
     */
    patch(patch: Record<string, unknown>): void;

    /**
     * Registers a cleanup owned by this node execution epoch.
     * Cleanup runs on cancel, replacement, error, complete, or dispose.
     */
    teardown(cleanup: SSXTeardown): void;

    /**
     * Starts a nested chain under the current epoch.
     * Child cancellation is linked to parent cancellation.
     */
    run<T = unknown>(
        child: SSXChainHandle<T>,
        input?: unknown,
    ): Promise<T | undefined>;

    /**
     * Existing platform APIs. Build this with buildCtxStaff if desired.
     */
    readonly platform: SSXPlatformContext;

    /**
     * A narrow wrapper over your existing callback stream API.
     */
    readonly streams: {
        request(
            p: unknown,
            onChunk: (chunk: unknown) => void,
            config?: SSXChannelConfig,
        ): Promise<void>;
    };
};
 type SSXOutput<T = unknown> = | T | Promise<T> | AsyncIterable<T> | SSXChainHandle<T>;
 type SSXStep<I = unknown, O = unknown> = (value: I, ctx: SSXContext,) => SSXMaybePromise<SSXOutput<O>>;
 type SSXNode = {
    id: string;
    label: string;
    kind: "step" | "tap" | "stream" | "platform";
    invoke: SSXStep;
    options: Required<Pick<SSXNodeOptions, "mode" | "persist">> &
    Omit<SSXNodeOptions, "mode" | "persist">;
};
 type SSXOptions = SSXChannelConfig & {
    id?: string;
    name?: string;

    /**
     * Optional custom context builder.
     *
     * This is where you attach:
     * buildCtxStaff(refs, selfProxy, "chains")
     * runNodePipeline_chains(...)
     * DRS/CRDT APIs
     * stream/fuse/observable APIs
     * bus, gates, workers, cache, storage, etc.
     */
    platform?: (
        input: {
            chainId: string;
            nodeId: string;
            nodeLabel: string;
            epoch: number;
            self: Record<string, any>;
        },
    ) => SSXPlatformContext;
};
 type SSXSignalStore = {
    create<T>(
        key: any,
        initial?: T | (() => T),
        options?: any,
    ): string;

    write<T>(
        key: any,
        value: T | ((previous: T | undefined) => T),
        source?: string,
    ): void;

    read<T>(key: any): T | undefined;
    peek<T>(key: any): T | undefined;

    subscribe<T>(
        key: any,
        listener: (value: T, source?: string) => void,
    ): SSXUnsubscribe;

    batch(block: () => void): void;
    transaction?(block: () => void): void;
    delete(key: any): void;
};
 type SSXChainHandle<T = unknown> = {
    readonly id: string;
    readonly result: Promise<T | undefined>;

    run(input?: unknown): Promise<T | undefined>;

    value(): T | undefined;
    snapshot(): SSXSnapshot<T>;

    cell<TCell = unknown>(
        idOrLabel: string,
    ): SSXCell<TCell> | undefined;

    subscribe(
        listener: (snapshot: SSXSnapshot<T>) => void,
    ): SSXUnsubscribe;

    subscribeCell<TCell = unknown>(
        idOrLabel: string,
        listener: (cell: SSXCell<TCell>) => void,
    ): SSXUnsubscribe;

    cancel(reason?: unknown): void;
    dispose(): void;
};

// #endregion
//           TYPES FOR CHAINS
// #region ═════════════════════════════════════════════════════════════════════════════════════
 interface chains_type1 {
    k?: string
    sl: string
    ms: string
    rt: string
    p?: any
    initial_value?: any
}
 type ChainInvocationMode1 = 'direct' | 'operator' | 'factory' | 'side_effect';
 interface ChainInvocation1 {
    mode: ChainInvocationMode;
    fn: Function;
    path?: any[]
    args: any[];
}
 type AnyFunction1 = (...args: any[]) => any;
 type Chainify1<T> = T extends AnyFunction ? (...args: Parameters<T>) => Chainify<ReturnType<T>> : T extends object ? { [K in keyof T]: Chainify<T[K]> } : T;
 type Capabilities = {
    cookies?: {
        get?: (key: string) => any
        set?: (key: string, value: any) => any
    }
    iterate?: () => any
    map?: () => any
    crdt?: {
        or_set?: (fn: any) => any
    }
    duplex?: {
        async?: () => void
    }
    fuse?: {
        map?: <A, B>(fn: (value: A) => B) => any
    }
}


    // #endregion
    // #region ══ DEFER ════════════════════════════════════════════════════════════════════
    type QueueFunction = {
        <T>(taskOrTasks: (() => Promise<T>) | (() => Promise<T>)[], taskOptions?: { priority?: number; label?: string }): Promise<T | T[]>;
        start: () => void;
        stop: () => void;
        clear: () => void;
        flush: () => void;
        peek: () => QueueTask<any> | undefined;
        peekAll: () => QueueTask<any>[];
        getRunning: () => QueueTask<any>[];
        removeAt: (index: number) => void;
        moveUp: (index: number) => void;
        moveDown: (index: number) => void;
        moveToNext: (index: number) => void;
        moveToLast: (index: number) => void;
        setOptions: (opts: Partial<QueueOptions>) => void;
        readonly size: number;
        readonly isEmpty: boolean;
        readonly isRunning: boolean;
        readonly isPausedState: boolean;
        readonly pending: number;
        readonly active: number;
    };
    
    type QueueOptions = {
        concurrent?: number;
        retry?: number;
        timeout?: number;
        priority?: boolean;
        onError?: (error: Error, task: any) => void;
        onComplete?: (result: any) => void;
        onChange?: () => void;
    };
    
    type QueueTask<T> = {
        fn: () => Promise<T>;
        priority?: number;
        resolve: (value: T) => void;
        reject: (error: Error) => void;
        label?: string;
    };
    
    type DeferredKey = S;
    type DeferredState = 'pending' | 'running';

    type DeferredTask = {
        id: N;
        deps: DeferredKey[];
        fn: (...v: A[]) => A;
        state: DeferredState;
    };

    type DeferredEntry = {
        v: A;
        version: N;
    };

    type DeferredStats = {
        registered: N;
        executed: N;
        completed: N;
        failed: N;
        cancelled: N;
    };



    
    //                                    TYPES
    // #region ══════════════════════════════════════════════════════════════════════════════════════════════════════
    
    // #region PRIMITIVE TYPES
    
    const IncantationsConfig: IncantationsConfigCreator = (config) => config;
     type ObjectType = Record<string, IncantationsConfig<any, any, any, any, any, any, any, any, any, any>>;
     type SelfType = { self: any;[category: string]: any };
     type Factory = (ctx: SelfType) => ObjectType
    
    
     type AnySelfType = { self: any;[key: string]: any };
     type AnyObject = Record<string, any>;
     type AnyFactory = (ctx: AnySelfType) => AnyObject;
     type AnyType = AnyObject | AnyFactory;
    
    
     type incan_vars_obj = Record<string, any>;
     type incan_vars_ctx = { self: any;[category: string]: any };
     type incan_vars_vault_factory = (ctx: incan_vars_ctx) => incan_vars_obj | incan_vars_obj;
    
    
     type ArcheTypeCtx = { self: any;[category: string]: any };
    
     type Boundary = 'same-app' | 'same-node' | 'cross-node'
    
    
      type StubHit = { category: string; key: string; prop: string; location: any };
     const GRAPH_KEYS = ['types', 'enums', 'interfaces', 'generics'] as const;
    
      type GraphKey = typeof GRAPH_KEYS[number];
      type ExtractFactory<A1, A2> =
        A1 extends string
        ? Extract<A2, (...args: any[]) => any>
        : Extract<A1, (...args: any[]) => any>
     interface CloudState {
        get<T>(key: string | symbol): T | undefined;
        set<T>(key: string | symbol, value: T | ((prev: T | undefined) => T)): void;
        subscribe<T>(key: string | symbol, listener: (value: T) => void): () => void;
        clear(): void;
    }
      type ConcentrationGenericsCtx = { self: any;[category: string]: any };
      type CGFactory = (ctx: ConcentrationGenericsCtx) => Record<string, any>
      type types<C> = { [K in keyof ReturnType<Extract<C, (...args: any[]) => any>>]: ReturnType<Extract<C, (...args: any[]) => any>>[K] extends { types: infer T } ? T : never }
      type __location = { file: string; line: number; column: number; functionName: string }
      type KernelTypeParameter = {
        helpers: {
            generateTypeString: (typeDef: any, paramValues?: Record<string, string>) => string
            validateGenericUsage: (typeDef: any, providedParams: string[]) => boolean
        }
    }
      type arg1<C> = string | C
      type arg2<C> = C | KernelTypeParameter
      type concentrationTypeRef =
        | { kind: "Named"; name: string; args?: concentrationTypeRef[] }
        | { kind: "Union"; types: concentrationTypeRef[] }
        | { kind: "Function"; params: { name: string; type: concentrationTypeRef }[]; returnType: concentrationTypeRef }
        | { kind: "Object"; fields: Record<string, { type: concentrationTypeRef; optional?: boolean }> }
     type concentrationGeneric = {
        name: string
        typeParameters: concentrationTypeParameter[]
        signature: concentrationTypeRef // always a Function here
    }
     type SubstEnv = Record<string, concentrationTypeRef>
    
    
    
    
     interface CGInterface<C> {
        arg1: arg1<C>
        arg2?: C | KernelTypeParameter
        arg3?: KernelTypeParameter
    }
    type concentrationTypeFlags = | "Any" | "Unknown" | "Boolean" | "Number" | "String" | "Object" | "Function" | "TypeParameter" | "Union" | "Intersection"
    type concentrationTypeEnv = Record<string, concentrationTypeId>
    type concentrationTypeId = string
    type concentrationTypeParameter = {
        id: concentrationTypeId
        name: string
        constraint?: concentrationTypeId
        default?: concentrationTypeId
    }
    type concentrationSignature = {
        typeParameters?: concentrationTypeParameter[]
        parameters: { name: string; type: concentrationTypeId }[]
        returnType: concentrationTypeId
    }
    type concentrationType = {
        id: concentrationTypeId
        flags: concentrationTypeFlags[]
        name?: string
        signatures?: concentrationSignature[]
        aliasOf?: concentrationTypeId
    }
    
    
    
    // #endregion ============================================
    // #region FUNCTION TYPES
    // ============================================
     type vault_source = {
        variants?: Record<string, Record<string, any>>;
        base?: ClassInput;
        slots?: Record<string, ClassInput>;
        compoundVariants?: any[];
        defaultVariants?: Record<string, any>;
        animation?: any;
        aliases?: any;
    };
     type base_props = {
        className?: string;
        class?: string;
        children?: any;
        style?: any;
        [key: string]: any;
    };
    
    
     type ClassInput =
        | string
        | number
        | boolean
        | null
        | undefined
        | ClassInput[]
        | Record<string, boolean | null | undefined>;
     type AsConfig = Record<string, ClassInput>;
    
     type AnimationVariant = {
        enter?: ClassInput;
        exit?: ClassInput;
        hover?: ClassInput;
        focus?: ClassInput;
        active?: ClassInput;
    };
    
     type MotionVariant = {
        v?: Record<string, any>;
        animate?: Record<string, any>;
        exit?: Record<string, any>;
        transition?: Record<string, any>;
        whileHover?: Record<string, any>;
        whileFocus?: Record<string, any>;
        whileTap?: Record<string, any>;
    };
    
    
     type AsNode = Record<string, any> & { parent: string };
    
     type SlotRecord = Record<string, ClassInput>;
    
     type VariantSchema = Record<string, Record<string, ClassInput>>;
    
    
    
     type AnyVariantSchema =
        | VariantSchema
        | SlotVariantSchema;
    
     type AnimationPresetMap = Record<
        string,
        AnimationVariant | MotionVariant
    >;
    
     type ExposedVariants = Record<string, VariantGroup>;
    
    // #endregion ============================================
    // #region BASE PROPS
    // ============================================
    
     type BaseProps = {
        className?: string;
        class?: string;
        children?: any;
        style?: any;
        [key: string]: any;
    };
    
    // #endregion ============================================
    // #region VARIANT GROUP
    // ============================================
    
     type VariantGroup = Record<string, ClassInput> & {
        extend: (
            overrides: Record<string, ClassInput>
        ) => Record<string, ClassInput>;
    };
    
    // #endregion ============================================
    // #region COMPOUND VARIANTS
    // ============================================
    
     type CompoundVariant = {
        variants: Record<string, string>;
        className?: ClassInput;
        style?: A;
        class?: ClassInput;
    };
    
     type SlotVariantSchema1 = Record<
        string,
        Record<string, SlotRecord>
    >;
    
     type SlotVariantSchema = Record<string, Record<string, SlotRecord>>;
    
     type SlotCompoundVariant = {
        variants?: Record<string, string>;
        slots?: string[];
        class: ClassInput;
    };
    
    
    // #endregion ============================================
    // #region STATE MACHINE
    // ============================================
    
     interface StateMachineConfig1 {
        [ComponentVariantKey: string]: {
            v: string;
            transitions: Record<string, string[]>;
            guards?: Record<string, (props: any, prev: string, next: string) => boolean>;
            onEnter?: Record<string, (props: any, prev: string, next: string) => void>;
            onExit?: Record<string, (props: any, prev: string, next: string) => void>;
            onTransition?: (props: any, prev: string, next: string) => void;
        };
    }
     interface StateMachineConfig {
        v: string;
        transitions: Record<string, string[]>;
        guards?: Record<string, (props: any, prev: string, next: string) => boolean>;
        onEnter?: Record<string, (props: any, prev: string, next: string) => void>;
        onExit?: Record<string, (props: any, prev: string, next: string) => void>;
        onTransition?: (props: any, prev: string, next: string) => void;
    }
    
    // #endregion ============================================
    // #region MACHINE TYPES
    // ============================================
    
     type MachineState = {
        currentState: Record<string, string>;
    };
    
     type LogicMachine = {
        [logicalState: string]: {
            ON?: Record<string, string>;
            ASYNC_GUARD?: (props: any) => Promise<any> | boolean;
            actions?: string[];
        };
    };
    
     type MachineRunner = {
        states: Record<string, string>;
        send: (
            variantKey: string,
            event: string,
            currentProps: any
        ) => Record<string, string> | undefined;
    };
    
    // #endregion ============================================
    // #region VAULT TYPES
    // ============================================
    
     type VaultSource = {
        variants?: Record<string, Record<string, any>>;
        base?: ClassInput;
        slots?: Record<string, ClassInput>;
        compoundVariants?: any[];
        defaultVariants?: Record<string, any>;
        animation?: any;
        aliases?: any;
    };
    
     type VaultEntry = {
        source: VaultSource;
        variants?: { [variantKey: string]: { [entryKey: string]: string } };
    };
    
     type VaultConfig = {
        vault?: VaultEntry;
        [key: string]: IncantationsConfig | VaultEntry | undefined;
    };
    
    // #endregion ============================================
    // #region FREYR ENUMS
    // ============================================
    
     type FreyrMode = "light" | "dark" | "system" | string;
     type FreyrTheme = "default" | "ocean" | "forest" | "sunset" | string;
     type FreyrVersion = "v1" | "v2" | "v3" | string;
     type FreyrFonts = "sans" | "serif" | "mono" | string;
     type FreyrPresets = "minimal" | "modern" | "vintage" | string;
    
     type IncantationsFreyrContext = {
        theme: FreyrTheme;
        version: FreyrVersion;
        mode: FreyrMode;
    };
    
     type IncantationsFreyr = {
        mode?: FreyrMode;
        theme?: FreyrTheme;
        version?: FreyrVersion;
        fonts?: FreyrFonts;
        presets?: FreyrPresets;
    };
    
    // #endregion ============================================
    // #region INCANTATIONS LEVEL 3
    // ============================================
     type variant_group = Record<string, ClassInput> & {
        extend: (
            overrides: Record<string, ClassInput>
        ) => Record<string, ClassInput>;
    };
    
     type IncantationsLvl3 = {
        db: any;
        bus: any;
        form: any;
        rdb: any;
        loader: any;
        session_mgmt: any;
        signals: any;
        jobs: any;
        fetch: any;
        sauron: any;
        htmx: any;
        cloud: any;
        cron: any;
        action: any;
        auth: any;
        realtime: any;
        reflect: any;
    };
     type vault_entry = {
        source: vault_source;
        variants?: { [variantKey: string]: { [entryKey: string]: string } };
    };
    
    // #endregion ============================================
    // #region GENERIC INCANTATIONS CONFIG
    
     type IncantationsConfig<
        S extends string = never,
        V extends Record<string, Record<string, any>> = Record<string, Record<string, any>>,
        T = unknown,
        I = unknown,
        E = unknown,
        C = unknown,
        SP = unknown,
        SO = unknown,
        CL = unknown,
        G = unknown
    > = {
        // Identifiers
        __S__?: S;
        __V__?: V;
        __T__?: T;
        __I__?: I;
        __E__?: E;
        __C__?: C;
        __SP__?: SP;
        __SO__?: SO;
        __CL__?: CL;
        __G__?: G;
        // NEED TO WORK ON THESE
        timeMachine?: any
        useMachine?: any
        useTimeMachine?: any
        logicMachine?: any
        inlineStyles?: any
        theme?: any
        className?: any
        preset?: any
        __Incantations__?: any
        meta?: any
        staticMeta?: any
        machinesMachine?: any
        router?: any
    
    
        // Types
        enums?: E;
        types?: T;
        interfaces?: I;
        generics?: G;
    
        interface?: I;
        enum?: I;
    
        // Styles
        styles?: {
            base?: A;
            variants?: Record<string, Record<string, A>>;
            defaultVariants?: Record<string, string>;
        };
        slots?: Record<S, ClassInput>;
        // Freyr & Global
        global?: () => G;
        freyrClasses?: string;
        freyrIncantations?: A;
        __globalContent?: Record<string, any>;
        __isGlobalized__?: boolean;
        freyr?: IncantationsFreyr | ((props: any) => any);
        classNames?: any;
        customTheme?: any;
        customCSS?: any;
        // Variants
        variants?: V;
        compoundVariants?: S extends never ? CompoundVariant[] : SlotCompoundVariant[];
        defaultVariants?: { [K in keyof V]?: keyof V[K] };
        base?: ClassInput;
    
        // Animations
        animation?: S extends never
        ? AnimationVariant | AnimationPresetMap
        : Record<S, AnimationVariant> | undefined;
        transition?: S extends never
        ? AnimationVariant | AnimationPresetMap
        : Record<S, AnimationVariant> | undefined;
    
        // Extend & Sync
        extend?: string;
        cloud?: CL;
        sync?: string;
        master?: boolean;
    
        // Context
        context?: (props: any) => any;
        useContext?: any;
        createContext?: any;
        sauronContext?: any;
        reactContext?: any;
        useReactContext?: any;
        _compiledReactContext?: any;
    
        // State Machines
        stateMachine?: { [K in keyof V]?: StateMachineConfig; };
        __logicMachineRunner?: any;
        getLogicState?: () => Record<string, string>;
        __machineRunner?: MachineRunner | null;
        getMachineState?: () => Record<string, string>;
        variantMachine?: any;
    
    
    
        // As
        as?: AsConfig;
        asName?: string;
    
        // Singles
        aliases?: { [K in keyof V]?: Record<string, keyof V[K]> };
    
        // Constants & Specs
        constants?: C;
        specs?: SP;
        source?: SO;
    
        // Documentation
        docs?: {
            [K in keyof V]?: {
                description?: string;
                values?: { [J in keyof V[keyof V]]?: string };
            };
        } & { description?: string };
    
        // Dev Tools
        __location?: {
            file: string;
            line: number;
            column: number;
            functionName: string;
        };
        __definitionName?: string;
        __concentrationEnumGraph?: Record<string, TypeGraph>;
        __concentrationInterfaceGraph?: Record<string, TypeGraph>;
        __concentrationGenericGraph?: Record<string, TypeGraph>;
        __IncantationsTypeGraph?: Record<string, TypeGraph>;
    };
    // #endregion ============================================
    // #region TypeGraph  - Complete Type Introspection System
    
     type TypeFlags =
        | "Any"
        | "Unknown"
        | "Boolean"
        | "Number"
        | "String"
        | "Object"
        | "Array"
        | "Function"
        | "TypeParameter"
        | "Union"
        | "Intersection"
        | "Literal"
        | "Enum"
        | "Interface"
        | "Class"
        | "Generic"
        | "Record"
        | "Tuple"
        | "Optional"
        | "Nullable"
        | "Readonly";
    
     type TypeGraph = {
        // Core identification
        id?: string;
        name?: string;
        type: TypeFlags;
        kind?: "primitive" | "composite" | "reference" | "generic";
    
        // Value representation
        value?: any;
        defaultValue?: any;
    
        // Type structure
        properties?: Record<string, TypeGraph>;
        elements?: TypeGraph[];
        indexSignature?: TypeGraph;
    
        // Type parameters (generics)
        typeParameters?: TypeGraph[];
        typeArguments?: TypeGraph[];
        constraint?: TypeGraph;
    
        // Union/Intersection members
        unionMembers?: TypeGraph[];
        intersectionMembers?: TypeGraph[];
    
        // Function types
        parameters?: TypeGraph[];
        returnType?: TypeGraph;
        isAsync?: boolean;
    
        // Class/Interface
        extends?: TypeGraph[];
        implements?: TypeGraph[];
        constructors?: TypeGraph[];
        methods?: Record<string, TypeGraph>;
        accessors?: Record<string, TypeGraph>;
    
        // Enum
        enumMembers?: Record<string, string | number>;
        isStringEnum?: boolean;
        isNumericEnum?: boolean;
    
        // Record types
        keyType?: TypeGraph;
        valueType?: TypeGraph;
    
        // Tuple
        tupleElements?: TypeGraph[];
        isFixedLength?: boolean;
        restElement?: TypeGraph;
    
        // Modifiers
        isOptional?: boolean;
        isNullable?: boolean;
        isReadonly?: boolean;
        isAbstract?: boolean;
        isStatic?: boolean;
    
        // Generic constraints
        extendsConstraint?: TypeGraph;
        defaultType?: TypeGraph;
    
        // Metadata
        description?: string;
        tags?: Record<string, any>;
        source?: {
            file: string;
            line: number;
            column: number;
        };
    
        // Dependencies
        imports?: Record<string, string[]>;
        s?: string[];
        references?: TypeGraph[];
    
        // Runtime info
        runtimeType?: any;
        validator?: (value: any) => boolean;
        serializer?: (value: any) => any;
        deserializer?: (value: any) => any;
    
        // Graph relationships
        parent?: TypeGraph;
        children?: TypeGraph[];
        dependencies?: TypeGraph[];
    
        // Custom metadata
        metadata?: Record<string, any>;
    
        // Timestamps
        createdAt?: Date;
        updatedAt?: Date;
        version?: string;
    };
    
    // #endregion ============================================
    // #region TYPE GRAPH UTILITIES
    // ============================================
    
    // Helper to create primitive types
     function createPrimitiveGraph(
        type: "String" | "Number" | "Boolean" | "Any" | "Unknown" | "Object",
        options?: Partial<TypeGraph>
    ): TypeGraph {
        return {
            type,
            kind: "primitive",
            ...options
        };
    }
    
    // Helper to create object type
     function createObjectGraph(
        properties: Record<string, TypeGraph>,
        options?: Partial<TypeGraph>
    ): TypeGraph {
        return {
            type: "Object",
            kind: "composite",
            properties,
            ...options
        };
    }
    
    // Helper to create array type
     function createArrayGraph(
        elementType: TypeGraph,
        options?: Partial<TypeGraph>
    ): TypeGraph {
        return {
            type: "Array",
            kind: "composite",
            elements: [elementType],
            ...options
        };
    }
    
    // Helper to create union type
     function createUnionGraph(
        members: TypeGraph[],
        options?: Partial<TypeGraph>
    ): TypeGraph {
        return {
            type: "Union",
            kind: "composite",
            unionMembers: members,
            ...options
        };
    }
    
    // Helper to create function type
     function createFunctionGraph(
        parameters: TypeGraph[],
        returnType: TypeGraph,
        options?: Partial<TypeGraph>
    ): TypeGraph {
        return {
            type: "Function",
            kind: "composite",
            parameters,
            returnType,
            ...options
        };
    }
    
    // Helper to create generic type
     function createGenericGraph(
        name: string,
        typeParameters: TypeGraph[],
        constraint?: TypeGraph,
        options?: Partial<TypeGraph>
    ): TypeGraph {
        return {
            type: "Generic",
            kind: "generic",
            name,
            typeParameters,
            constraint,
            ...options
        };
    }
    
    // #endregion ============================================
    // #region TYPE GRAPH PREDICATES
    // ============================================
    
     type TypeGraphPredicates = {
        isPrimitive: (graph: TypeGraph) => boolean;
        isComposite: (graph: TypeGraph) => boolean;
        isGeneric: (graph: TypeGraph) => boolean;
        isUnion: (graph: TypeGraph) => boolean;
        isIntersection: (graph: TypeGraph) => boolean;
        isObject: (graph: TypeGraph) => boolean;
        isArray: (graph: TypeGraph) => boolean;
        isFunction: (graph: TypeGraph) => boolean;
        isEnum: (graph: TypeGraph) => boolean;
        isOptional: (graph: TypeGraph) => boolean;
        isNullable: (graph: TypeGraph) => boolean;
    };
    
    // #endregion ============================================
    // #region TYPE GRAPH TRANSFORMERS
    // ============================================
    
     type TypeGraphTransformers = {
        // Traverse graph
        traverse: (
            graph: TypeGraph,
            visitor: (node: TypeGraph) => void
        ) => void;
    
        // Find nodes
        findNodes: (
            graph: TypeGraph,
            predicate: (node: TypeGraph) => boolean
        ) => TypeGraph[];
    
        // Transform nodes
        mapNodes: (
            graph: TypeGraph,
            mapper: (node: TypeGraph) => TypeGraph
        ) => TypeGraph;
    
        // Collect types
        collectTypes: (graph: TypeGraph) => Set<TypeFlags>;
    
        // Resolve references
        resolveReferences: (
            graph: TypeGraph,
            context: Record<string, TypeGraph>
        ) => TypeGraph;
    
        // Validate
        validate: (
            graph: TypeGraph,
            value: any
        ) => boolean;
    };
    
    
    // #endregion ============================================
    // #region EXAMPLE USAGE
    // ============================================
    
    // Example: Build a type graph for a config
    const stringType = createPrimitiveGraph("String");
    const numberType = createPrimitiveGraph("Number");
    const booleanType = createPrimitiveGraph("Boolean");
    
    const variantSchemaGraph = createObjectGraph({
        size: createUnionGraph([
            createPrimitiveGraph("String", { value: "small" }),
            createPrimitiveGraph("String", { value: "large" })
        ]),
        color: createUnionGraph([
            createPrimitiveGraph("String", { value: "red" }),
            createPrimitiveGraph("String", { value: "blue" })
        ])
    });
    
    const configGraph: TypeGraph = {
        type: "Interface",
        kind: "composite",
        name: "IncantationsConfig",
        properties: {
            variants: variantSchemaGraph,
            defaultVariants: createObjectGraph({
                size: createPrimitiveGraph("String", { defaultValue: "small" })
            })
        },
        typeParameters: [
            {
                type: "TypeParameter",
                name: "S",
                constraint: createPrimitiveGraph("String")
            },
            {
                type: "TypeParameter",
                name: "V",
                constraint: createPrimitiveGraph("Object")
            }
        ]
    };
    // #endregion ============================================
    // #region IncantationsConfigCreator
     type IncantationsConfigCreator = <
        S extends string = never,
        V extends Record<string, Record<string, any>> = Record<string, Record<string, any>>,
        T = unknown,
        I = unknown,
        E = unknown,
        C = unknown,
        SP = unknown,
        SO = unknown,
        CL = unknown,
        G = unknown
    >(
        config: IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>
    ) => IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>;
    
    // #endregion ============================================
    // #region AllIncantationTypes
     type AllIncantationTypes = {
        ClassInput: ClassInput;
        AnimationVariant: AnimationVariant;
        MotionVariant: MotionVariant;
        AsConfig: AsConfig;
        AsNode: AsNode;
        SlotRecord: SlotRecord;
        VariantSchema: VariantSchema;
        SlotVariantSchema: SlotVariantSchema;
        AnyVariantSchema: AnyVariantSchema;
        AnimationPresetMap: AnimationPresetMap;
        ExposedVariants: ExposedVariants;
        BaseProps: BaseProps;
        VariantGroup: VariantGroup;
        CompoundVariant: CompoundVariant;
        SlotCompoundVariant: SlotCompoundVariant;
        StateMachineConfig: StateMachineConfig;
        MachineState: MachineState;
        LogicMachine: LogicMachine;
        MachineRunner: MachineRunner;
        VaultSource: VaultSource;
        VaultEntry: VaultEntry;
        VaultConfig: VaultConfig;
        IncantationsFreyrContext: IncantationsFreyrContext;
        IncantationsFreyr: IncantationsFreyr;
        IncantationsLvl3: IncantationsLvl3;
        TypeFlags: TypeFlags;
        IncantationsConfig: IncantationsConfig;
    };
    
    // #endregion ============================================
    
    // #endregion ============================================
    // #region INFER INCANTATIONS CONFIG
    // ============================================
    
     type InferIncantationsConfig = <
        Cfg extends {
            __S__?: any;
            __V__?: any;
            __T__?: any;
            __I__?: any;
            __E__?: any;
            __C__?: any;
            __SP__?: any;
            __SO__?: any;
            __CL__?: any;
            __G__?: any;
        }
    >(
        config: Cfg
    ) => {
        S: Cfg["__S__"];
        V: Cfg["__V__"];
        T: Cfg["__T__"];
        I: Cfg["__I__"];
        E: Cfg["__E__"];
        C: Cfg["__C__"];
        SP: Cfg["__SP__"];
        SO: Cfg["__SO__"];
        CL: Cfg["__CL__"];
        G: Cfg["__G__"];
        Config: Cfg;
    };
    
    // #endregion ============================================
    // #region VARIANT PROPS
    // ============================================
    
     type VariantProps = {
        [key: string]: any;
        animation?: string;
        preset?: string;
        class?: any;
        className?: any;
        __instanceId__?: string;
        freyr?: FreyrConfig | ((props: any) => any);
    };
    
     type FreyrConfig = {
        mode?: FreyrMode;
        theme?: FreyrTheme;
        version?: FreyrVersion;
        fonts?: FreyrFonts;
        presets?: FreyrPresets;
    };
    
    
    // #endregion ============================================
    // #region SLOTTED RESULT
    // ============================================
    
     type SlottedResult<S extends string = string> = {
        [K in S]?: string;
    } & {
        className?: string;
        class?: string;
        [key: string]: any;
    };
    // #endregion ============================================
    // #region NAMESPACE AUGMENT
    // ============================================
    
     type NamespaceAugment = any; // Define based on your implementation
    
    // #endregion ============================================
    // #region INCANTATIONS RESULT
    // ============================================
    
    // ============================================
    // INCANTATIONS RESULT - Complete Type 
    // (ALL properties from IncantationsConfig + React additions)
    // ============================================
    
    // ============================================
    // INCANTATIONS RESULT - Fixed with proper constraints
    // ============================================
    
     type IncantationsResult<
        S extends string = never,
        V extends Record<string, Record<string, any>> = Record<string, Record<string, any>>,
        T = unknown,
        I = unknown,
        E = unknown,
        C = unknown,
        SP = unknown,
        SO = unknown,
        CL = unknown,
        G = unknown
    > = {
        // ── THE MAIN FUNCTION ────────────────────────────────────────────────────
        (props?: VariantProps & T & {
            animation?: keyof AnimationVariant | string;
            preset?: string;
            class?: any;
            className?: any;
            __instanceId__?: string;
            freyr?: FreyrConfig | ((props: any) => any);
        }): string;
    
        // ── IDENTIFIERS ──────────────────────────────────────────────────────────
        __S__?: S;
        __V__?: V;
        __T__?: T;
        __I__?: I;
        __E__?: E;
        __C__?: C;
        __SP__?: SP;
        __SO__?: SO;
        __CL__?: CL;
        __G__?: G;
    
        // ── TYPES ──────────────────────────────────────────────────────────────
        enums?: E;
        types?: T;
        interfaces?: I;
        generics?: G;
    
        // ── STYLES ──────────────────────────────────────────────────────────────
        styles?: {
            base?: A;
            variants?: Record<string, Record<string, A>>;
            defaultVariants?: Record<string, string>;
        };
        slots?: Record<S, ClassInput>;
        base?: ClassInput;
    
        // ── VARIANTS ──────────────────────────────────────────────────────────────
        variants?: V;
        compoundVariants?: S extends never ? CompoundVariant[] : SlotCompoundVariant[];
        defaultVariants?: { [K in keyof V]?: keyof V[K] };
    
        // ── ANIMATIONS ──────────────────────────────────────────────────────────
        animation?: S extends never
        ? AnimationVariant | AnimationPresetMap
        : Record<S, AnimationVariant> | undefined;
        transition?: S extends never
        ? AnimationVariant | AnimationPresetMap
        : Record<S, AnimationVariant> | undefined;
    
        // ── EXTEND & SYNC ──────────────────────────────────────────────────────
        extend?: string;
        cloud?: CL;
        sync?: string;
        master?: boolean;
    
        // ── CONTEXT ──────────────────────────────────────────────────────────────
        context?: (props: any) => any;
        useContext?: any;
        createContext?: any;
        sauronContext?: any;
        reactContext?: any;
        _compiledReactContext?: any;
    
        // ── STATE MACHINES ────────────────────────────────────────────────────
        stateMachine?: {
            [K in keyof V]?: StateMachineConfig;
        };
        logicMachine?: LogicMachine;
        __logicMachineRunner?: any;
        getLogicState?: () => Record<string, string>;
        __machineRunner?: MachineRunner | null;
        getMachineState?: () => Record<string, string>;
        variantMachine?: any;
    
        // ── FREYR & GLOBAL ──────────────────────────────────────────────────────
        global?: () => G;
        freyrClasses?: string;
        freyrIncantations?: A;
        __globalContent?: Record<string, any>;
        __isGlobalized__?: boolean;
        freyr?: IncantationsFreyr | ((props: any) => any);
        classNames?: any;
        customTheme?: any;
        customCSS?: any;
    
        // ── AS ──────────────────────────────────────────────────────────────────
        as?: AsConfig;
        asName?: string;
    
        // ── SINGLES ──────────────────────────────────────────────────────────────
        aliases?: { [K in keyof V]?: Record<string, keyof V[K]> };
    
        // ── CONSTANTS & SPECS ──────────────────────────────────────────────────
        constants?: C;
        specs?: SP;
        source?: SO;
    
        // ── DOCUMENTATION ──────────────────────────────────────────────────────
        docs?: {
            [K in keyof V]?: {
                description?: string;
                values?: { [J in keyof V[keyof V]]?: string };
            };
        } & { description?: string };
    
        // ── DEV TOOLS ──────────────────────────────────────────────────────────
        __location?: {
            file: string;
            line: number;
            column: number;
            functionName: string;
        };
        __definitionName?: string;
        __concentrationEnumGraph?: Record<string, TypeGraph>;
        __concentrationInterfaceGraph?: Record<string, TypeGraph>;
        __concentrationGenericGraph?: Record<string, TypeGraph>;
        __IncantationsTypeGraph?: Record<string, TypeGraph>;
    
        // ── REACT CONTEXT (Added by wizard template) ──────────────────────────
        ReactContext: A;
        createReactContext: (props?: any) =>A;
        useReactContext: () => any;
    
        // ── SUB-COMPONENT UTILITIES ─────────────────────────────────────────────
        extendResult: (
            overrides: Partial<IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>>
        ) => IncantationsResult<S, V, T, I, E, C, SP, SO, CL, G>;
    };
    // #endregion ============================================
    // #region INCANTATIONS RESULT CREATOR
    // ============================================
    
     type IncantationsResultCreator = <
        S extends string = never,
        V extends AnyVariantSchema = any,
        T = unknown,
        I = unknown,
        C = unknown,
        SP = unknown,
        SO = unknown,
        CL = unknown,
        E = unknown,
        G = unknown
    >(
        config: ((
            props?: VariantProps & T & {
                animation?: keyof AnimationVariant | string;
                preset?: string;
                class?: any;
                className?: any;
                __instanceId__?: string;
                freyr?: FreyrConfig | ((props: any) => any);
            }
        ) => string) & {
            // ── CORE HOOKS & PROCESSING ENGINE ──────────────────────────────────────
            slots: (
                props?: VariantProps & {
                    preset?: string;
                    class?: Partial<Record<S, ClassInput>>;
                    className?: Partial<Record<S, ClassInput>>;
                    __instanceId__?: string;
                    freyr?: FreyrConfig | ((props: any) => any);
                }
            ) => SlottedResult<S>;
    
            // ── THE INLINE STYLES SYSTEM ───────────────────────────────────────────
            styles?: Record<string, any>;
            inlineStyles?: A;
            freyrClasses?: string;
            freyrIncantations?: A;
            classNames?: any;
            customTheme?: any;
            customCSS?: any;
    
            // ── BLUEPRINT ECHOES (CONFIG TO RESULT COPIES) ───────────────────────────
            types: T;
            interface: I;
            enum: E;
            constants: C;
            specs: SP;
            source: SO;
            cloud: CL;
            as: AsConfig;
            variants: ExposedVariants;
            compoundVariants?: any[];
            defaultVariants?: Record<string, any>;
            aliases?: Record<string, string>;
            docs?: string;
    
            // ── ADVANCED NESTED ENGINES ──────────────────────────────────────────────
            variantMachine?: Record<string, any>;
            transition?: {
                show?: Record<string, any>;
                hide?: Record<string, any>;
                [key: string]: any;
            };
    
            // ── SYSTEM MIGRATION & REACTION THREADS ──────────────────────────────────
            sync?: string;
            master?: boolean;
            context: (props: any, __sauron_id__?: string) => I;
            createContext?: any;
            sauronContext?: any;
            global: NamespaceAugment;
    
            // ── STATE ENGINE ACCESSORS (EXPOSED RUNTIMES) ────────────────────────────
            stateMachine?: Record<string, any>;
            logicMachine?: Record<string, any>;
            __machineRunner?: any;
            __logicMachineRunner?: any;
            getMachineState?: () => Record<string, any>;
            getLogicState?: () => Record<string, any>;
            useMachine?: (props?: any) => {
                state: Record<string, any>;
                setState: (key: string, value: any) => void;
            } & Record<string, (value: any) => void>;
    
            // ── GLOBALIZATION & COMPILER PROFILES ────────────────────────────────────
            __globalContent?: any;
            __isGlobalized__?: boolean;
            __location: string;
            __definitionName: string;
    
            // ── SUB-COMPONENT UTILITIES ─────────────────────────────────────────────
            extend: (
                overrides: Partial<IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>>
            ) => IncantationsResult<S, V, T, I, C, SP, SO, CL, E, G>;
        }
    ) => IncantationsResult<S, V, T, I, C, SP, SO, CL, E, G>;
    
    
    // #endregion ============================================
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     interface SyncStreamOptions665 {
        /** Max unacknowledged in-flight payloads before the sender backs off. */
        windowSize?: number;
        /** Retransmit timeout per in-flight seq (default 5s). Keeps a lost ack from wedging the window. */
        retransmitMs?: number;
    }
     type SBackpressureStrategy665 = "drop" | "pause" | "error";
     interface StreamRelayOptions665 {
        maxSubscribers?: number;
        bufferSize?: number;
        backpressureStrategy?: SBackpressureStrategy665;
    }
     interface PipelineStage665<T> {
        name: string;
        handler: (data: T) => T | Promise<T>;
        errorHandler?: (err: Error, data: T) => T | Promise<T>;
    }
     type PipelineEvent665<T> = | { type: "stage:enter"; stage: string; data: T } | { type: "stage:exit"; stage: string; data: T } | { type: "error"; stage: string; data?: T; error: string };
     interface MeshOptions665 {
        peerId?: string;
        announceInterval?: number; // ms
        peerTimeout?: number;      // ms — peer considered stale
        maxPeers?: number;
    }
     interface MeshPeer665<TMeta extends Record<string, unknown> = Record<string, unknown>> {
        id: string;
        metadata: TMeta;
        latency: number;
        lastSeen: number;
    }
     interface MeshMessage665<T> {
        from: string;
        p: T;
        timestamp: number;
    }
     interface MeshState665 {
        peerId: string;
        peers: Array<{ id: string; metadata: Record<string, unknown> }>;
        meshSize: number;
    }
     interface PlinkoContext665<TState, TPayload> {
        state: TState;
        p: TPayload;
        path: string[];
        metadata: Map<string, any>;
        reply: (data: unknown, targetSc?: string) => Promise<unknown>;
        abort: (reason?: string) => never;
        send?(rt: string, p: unknown): void;
    }
     interface PlinkoNode665<TState, TPayload> {
        matcher: (p: TPayload, ctx: PlinkoContext665<TState, TPayload>) => boolean | Promise<boolean>;
        execute?: (p: TPayload, ctx: PlinkoContext665<TState, TPayload>) => unknown | Promise<unknown>;
        branches?: Record<string, PlinkoNode665<TState, TPayload>>;
        hooks?: {
            beforeEnter?: (p: TPayload, ctx: PlinkoContext665<TState, TPayload>) => void | Promise<void>;
            afterExit?: (result: unknown, ctx: PlinkoContext665<TState, TPayload>) => void | Promise<void>;
        };
    }
     type PlinkoTree665<TState, TPayload> = Record<string, PlinkoNode665<TState, TPayload>>;
     interface PlinkoOptions665<TState = any, TPayload = any> {
        autoResetOnTerminal?: boolean;
        onTransition?: (from: string[], to: string[], p: TPayload) => void;
        onError?: (err: Error, path: string[], p: TPayload) => void;
    }
     interface PlinkoEvaluation665<TState, TPayload> {
        success: boolean;
        path: string[];
        result: unknown;
        terminal: boolean;
        state?: TState;
        metadata?: Map<string, any>;
    }
     interface PlinkoHandle665<TState, TPayload> {
        evaluate(p: TPayload, replyFn?: (data: unknown, targetSc?: string) => Promise<unknown>): Promise<PlinkoEvaluation665<TState, TPayload>>;
        getState(): TState;
        getPath(): string[];
        reset(): void;
    }
     interface SwitchboardContext665<TPayload> {
        p: TPayload;
        reply: (data: unknown) => Promise<unknown>;
        store: Map<string, any>;
    }
     interface SSwitchboardResult665 {
        success: boolean;
        matchedKey: string | null;
        unmatched: boolean;
        result?: unknown;
        error?: Error;
    }
     interface SwitchboardRoute665<TPayload> {
        (p: TPayload, ctx: SwitchboardContext665<TPayload>): unknown;
    }
     type SwitchboardRoutes665<TPayload, TKey extends string = string> = { [K in TKey]?: SwitchboardRoute665<TPayload> | "unmatched"; } & { default?: SwitchboardRoute665<TPayload> };
     interface SwitchboardOptions665<TPayload, TKey extends string = string> {
        rt?: string;
        subrt?: string;
        selectKey: (p: TPayload) => TKey;
        onUnmatched?: (p: TPayload, key: string) => void;
        onDispatch?: (route: string, p: TPayload, result: unknown) => void;
    }
     interface CRDTStateHook665<S> {
        (v: S): [S, (patch: unknown) => void];
    }
     interface StreamLabOptions665 {
        /** Route all bus traffic through the flood-gate transport fabric. */
        floodGates?: boolean;
        /** Transport provider for flood gates (memory by default in the VM). */
    }
     interface Outbound {
        seq: number;
        p: unknown;
        acked: boolean;
        sentAt: number;
        timer?: ReturnType<typeof setTimeout>;
    }
     interface SyncStreamHandler665 {
        onOrdered: (cb: (p: unknown, seq: number) => void) => void;
        onComplete: (cb: () => void) => void;
        close: () => void;
    }
     type SignalKey = any;
    
     type AlienSignal<T> = {
        (): T;
        (next: T): void;
        peek?: () => T;
    };
     type Change<T> = {
        key: SignalKey;
        previous: T;
        current: T;
        version: number;
        timestamp: number;
        source?: string;
    };
     type AtomContract<T> = {
        name: string;
        postcondition: (next: T, previous: T) => boolean;
        block: boolean;
    };
     type SyncJob = () => void;
     type AsyncEffectJob = {
        id: string;
        priority: number;
        run: () => void | Promise<void>;
        retry?: number;
        timeout?: number;
    };
     type Unsubscribe = () => void;
     type ConflictMeta = { at: number; node: string; userId?: string };
     type ConflictEnvelope<T = any> = { value: T; meta: ConflictMeta };
     type ConflictStrategy<T = any> = | 'lww' | 'merge' | { priority: string[] } | ((local: ConflictEnvelope<T> | undefined, remote: ConflictEnvelope<T>) => ConflictEnvelope<T>);
    
     interface SHADOW_FN {
        <T = any>(
            v: T | (() => T),
            key: string,
            sl?: string | undefined,
            ms?: string | undefined,
            rt?: string | undefined,
        ): {
            get: () => T;
            set: (value: T | ((prev: T) => T)) => void;
            subscribe: (fn: (value: T) => void) => () => void;
            destroy: () => void;
            exists: () => boolean;
        };
    
        use<T>(
            v: T | (() => T),
            key: string,
            sl?: string | undefined,
            ms?: string | undefined,
            rt?: string | undefined,
        ): readonly [T, (value: T | ((prev: T) => T)) => void];
    
        withTTL<T>(
            v?: T | (() => T),
            k?: string | undefined,
            sl?: string | undefined,
            ms?: string | undefined,
            rt?: string | undefined,
            ttlMs?: number,
        ): {
            get: () => T | null;
            set: (value: T | ((prev: T) => T)) => void;
            subscribe: (fn: (value: T | null) => void) => () => void;
            refresh: () => void;
            destroy: () => void;
            exists: () => boolean;
            getTimeRemaining: () => number;
        };
    
        batch<T extends Record<string, any>>(
            v: T,
            options?: { debounceMs?: number },
            key?: string | undefined,
            sl?: string | undefined,
            ms?: string | undefined,
            rt?: string | undefined,
        ): {
            get: () => T;
            set: (updates: Partial<T> | ((prev: T) => Partial<T>)) => void;
            subscribe: (fn: (value: T) => void) => () => void;
            flush: () => void;
        };
    }
     interface PORTAL_FN {
        (k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
        use(v?: any, k?: SU, sl?: string, ms?: string, rt?: string): any;
        crdt(v?: any, k?: SU, sl?: string, ms?: string, rt?: string, trigger_render?: boolean, nodeId?: any): any;
        umbrella(v: Record<string, any> | undefined, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, trigger_render?: boolean): any;
        effect(effect: () => void | (() => void), k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, deps?: any[]): void;
        context: {
            (v: Record<string, any>, k: string, sl: string, ms: string, rt: string, trigger_render: boolean): any;
        };
        state: {
            (v?: any, k?: SU, sl?: string, ms?: string, rt?: string): any;
            use(v?: any, k?: SU, sl?: string, ms?: string, rt?: string, trigger_render?: boolean): any;
        };
        store: {
            (v?: any | (() => any), key?: string | undefined, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
            use(v?: any | (() => any), key?: string | undefined, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, trigger_render?: boolean): any;
        };
    }
     type StateMeshReactor<T = any, A = any> = (state: T, action: A, snapshot: T) => T;
     type StateMeshUpdater<T> = T | ((current: T) => T);
     interface StateMesh<T = any, A = any> {
        state: T;
        snapshot(): T;
        set(next: StateMeshUpdater<T>): void;
        transition: <B = A>(action: B, reactor?: StateMeshReactor<T, B>) => void;
    
        commit(): void;
        rollback(): void;
    }
     type SamplingRate = {
        numerator: number;
        denominator: number;
    };
     type ProbabilisticSampling = {
        version: 1;
        algorithm: 'fnv1a64';
        seed: string;
        rate: SamplingRate;
        namespace: string;
    };
     type ProbabilisticOptions<T> = {
        // Exact probability as a fraction. { numerator: 1, denominator: 10 } means keep approximately 10%. Avoids float ambiguity across runtimes.
        rate: SamplingRate;
        // Shared deterministic seed. Same seed + namespace + key = same sampling decision.
        seed: string | number;
    
        // Stable identity of the logical item. Must remain unchanged across producer, consumer, retries, replay, reconnects, and process restarts. Prefer event ID / record ID / trace ID.
        key: (chunk: T, index: number) => string;
        // Separates unrelated sampled populations that happen to use the same seed. Keep this constant on both ends.
    
        namespace?: string;
    };
     type ProbabilisticSender = (
        p: any,
        onChunk: (chunk: any) => void,
        k: string,
        sl?: SU,
        ms?: SU,
        rt?: SU,
        chain?: 'chain' | 'rechain',
        binary?: boolean,
    ) => Promise<void>;
     type SamplingEnvelope<T> = {
        __probabilistic: ProbabilisticSampling;
        data: T;
    };
     type SamplingConfig = {
        version?: 1;
        rate: number; // 0..1
        seed: string | number;
        algorithm?: 'fnv1a64';
    };
    
     type StreamEncoding = 'json' | 'msgpack' | 'binary';
     type StreamRetryMode = | 'none' | 'at-least-once' | 'idempotent';
     type StreamContractOffer = {
        protocol: 'stream-contract';
        version: 1;
    
        schemas: readonly string[];
        encodings: readonly StreamEncoding[];
    
        limits: {
            maxChunkBytes: number;
            maxInFlightChunks: number;
            maxInFlightBytes?: number;
        };
    
        retry: {
            modes: readonly StreamRetryMode[];
            maxAttempts: number;
        };
    
        capabilities?: Record<string, boolean>;
    };
     type NegotiatedStreamContract = {
        protocol: 'stream-contract';
        version: 1;
    
        schema: string;
        encoding: StreamEncoding;
    
        limits: {
            maxChunkBytes: number;
            maxInFlightChunks: number;
            maxInFlightBytes?: number;
        };
    
        retry: {
            mode: StreamRetryMode;
            maxAttempts: number;
        };
    
        capabilities: Record<string, boolean>;
    };
     type NegotiationChunk =
        | {
            type: 'negotiate.accept';
            contract: NegotiatedStreamContract;
        }
        | {
            type: 'negotiate.reject';
            code: string;
            message: string;
        };
     type ConstellationFailureMode2 = 'continue' | 'fail-fast';
     type ConstellationMember2 = {
        id: string;
        p: any;
        k: string;
        sl?: SU;
        ms?: SU;
        rt?: SU;
        binary?: boolean;
    
        /**
         * Relative scheduling priority.
         * 1 = one turn, 2 = two turns, etc.
         */
        weight?: number;
    };
     type ConstellationChunk2 = {
        memberId: string;
        chunk: any;
        receivedAt: number;
    };
     type ConstellationMemberStatus2 = | 'running' | 'done' | 'error' | 'removed';
     type ConstellationMemberSnapshot2 = {
        id: string;
        status: ConstellationMemberStatus2;
        queuedChunks: number;
        error?: Error;
    };
     type ConstellationStrategy = | 'round-robin' | 'weighted' | 'least-busy' | 'first-alive';
     type ConstellationFailover = | 'next-member' | 'retry-same' | 'abort';
     type ConstellationOptions2 = {
        failure?: ConstellationFailureMode2;
        maxQueuedChunksPerMember?: number;
        onMemberStatus?: (
            member: ConstellationMember,
            status: ConstellationMemberStatus,
            error?: Error,
        ) => void;
    
        // ---- from constellation3 ----
        /** Selection strategy for picking the next ready member. Default: 'weighted'. */
        strategy?: ConstellationStrategy;
    
        /** What to do when a member's stream throws or rejects. Default: 'next-member'. */
        failover?: ConstellationFailover;
    
        /** Max retries before giving up (used by 'retry-same' and 'next-member'). Default: 2. */
        maxRetries?: number;
    
        /** How many consecutive failures before a member is marked unhealthy. Default: 3. */
        unhealthyAfterFailures?: number;
    
        /** Interval (ms) for the health/idle sweep. 0 disables. Default: 5_000. */
        healthCheckMs?: number;
    
        /** Evict idle members after this many ms of no use. 0 disables. Default: 0. */
        idleEvictMs?: number;
    
        /** Called when a member joins the constellation. */
        onMemberJoin?: (member: ConstellationMember) => void;
    
        /** Called when a member leaves (manual, idle, or error). */
        onMemberLeave?: (
            member: ConstellationMember,
            reason?: 'error' | 'manual' | 'idle',
        ) => void;
    
        /** Called when a failover occurs: `to` is null if no successor was available. */
        onFailover?: (
            from: ConstellationMember,
            to: ConstellationMember | null,
            error: unknown,
        ) => void;
    };
     type ConstellationHandle2 = {
        readonly done: Promise<void>;
    
        join(member: ConstellationMember2): void;
    
        /**
         * Stops forwarding output from this member.
         * This does not mutate or depend on your existing fn implementation.
         */
        remove(memberId: string): boolean;
    
        /**
         * Stops forwarding all future output and rejects `done`.
         */
        abort(reason?: unknown): void;
    
        members(): readonly ConstellationMemberSnapshot2[];
        setHealth(memberId: any, healthy: any): any
        on(event: string, handler: (e: Event) => void): any
        dispose(): any
    };
     type ConstellationFactory2 = (options?: ConstellationOptions2,) => (onChunk?: (event: ConstellationChunk2) => void,) => ConstellationHandle2;
     type ConstellationFactory = (options?: ConstellationOptions,) => (onChunk?: (event: ConstellationChunk) => void,) => ConstellationHandle
     type ConstellationOptions = {
        strategy?: 'round-robin' | 'weighted' | 'least-busy' | 'first-alive'
        failure?: 'continue' | 'fail-fast'
        maxQueuedChunksPerMember?: number
        maxRetries?: number
        onMemberStatus?: (
            member: ConstellationMember,
            status: ConstellationMemberStatus,
            error?: Error,
        ) => void
        onFailover?: (
            from: ConstellationMember,
            to: ConstellationMember | null,
            error: unknown,
        ) => void
    }
     type ConstellationMember = {
        id: string
        p: any
        k: string
        sl?: SU
        ms?: SU
        rt?: SU
        binary?: boolean
        weight?: number
    }
     type ConstellationMemberStatus = | 'running' | 'done' | 'error' | 'removed'
     type ConstellationChunk = {
        memberId: string
        chunk: any
        receivedAt: number
    }
     type ConstellationHandle = {
        done: Promise<void>
    
        join(member: ConstellationMember): void
    
        remove(memberId: string): boolean
    
        abort(reason?: unknown): void
    
        members(): Array<{
            id: string
            status: ConstellationMemberStatus
            queuedChunks: number
            error?: Error
        }>
    }
     type StreamAddress = {
        streamId: string;
        k: string;
        sl?: SU;
        ms?: SU;
        rt?: SU;
    };
     type LiminalState = 'waiting' | 'live' | 'closed';
     type LiminalChunk<T = unknown> = {
        type: 'liminal';
        direction: 'upstream->downstream' | 'downstream->upstream';
        data: T;
        upstreamStreamId: string;
        downstreamStreamId: string;
        observedAt: number;
    };
     type StreamChunk<T = unknown> = {
        type: 'chunk';
        data: T;
        streamId?: string;
        ts?: number;
    };
     type StreamDone = {
        type: 'done';
        streamId?: string;
        ts?: number;
    };
     type StreamError = {
        type: 'error';
        error: string | Error | unknown;
        streamId?: string;
        ts?: number;
    };
     type StreamEvent<T = unknown> =
        | StreamChunk<T>
        | StreamDone
        | StreamError;
     type rts = { sl?: any; ms?: any; rt?: any }
     type SIG_BUS_Boundary = 'same-app' | 'same-node' | 'cross-node'
     type SIG_BUS_Priority = 'high' | 'normal' | 'low';
     type SIG_BUS_Strategy = 'overwrite' | 'merge' | 'skip';
     type SIG_BUS_SyncDirection = 'memory->adapter' | 'adapter->memory' | 'both';
     type SIG_BUS_DeliveryStatus = 'ack' | 'nak';
     type SIG_BUS_AdapterSendPayload = | SIG_BUS_Message | Uint8Array | SIG_BUS_SecureEnvelope;
     type SIG_BUS_Handler = (p: any, ctx?: SIG_BUS_HandlerContext) => any | Promise<any>;
     type SIG_BUS_CBORValue = null | boolean | number | string | Uint8Array | SIG_BUS_CBORValue[] | { [k: string]: SIG_BUS_CBORValue }
     type SIG_BUS_QueryExpr = | { type: 'eq'; key: string; value: unknown } | { type: 'and'; exprs: SIG_BUS_QueryExpr[] } | { type: 'or'; exprs: SIG_BUS_QueryExpr[] };
     interface SIG_BUS_Adapter {
        id?: string;
        send(msg: SIG_BUS_AdapterSendPayload): void;
        onMessage(handler: (msg: SIG_BUS_AdapterSendPayload) => void): () => void;
        onConnect?(handler: () => void): void;
        onDisconnect?(handler: () => void): void;
    }
     interface SIG_BUS_SecureEnvelope {
        sessionId: string;
        token: string;
        p: SIG_BUS_Message | SIG_BUS_CBORValue;
    }
     interface SIG_BUS_Message {
        id: string;
        rt: string;
        ms?: string;
        sl?: string;
        k?: string;
        topic?: string;
        p: unknown;
        ttl?: number;
        ts?: number;
        _ack?: boolean;
        _adapter?: SIG_BUS_Adapter;
        priority?: any;
        tags?: string[];
        streamId?: string;
        sessionId?: any;
        token?: any;
        binary?: 'signal_save_value' | 'signal' | true | false | string;
        error?: any
        adapter_id?: any
        cross_cse_ngin_connect_adapter_id?: any
        cross_app_adapter_adapter_id?: any
        type?: string
        boundary?: SIG_BUS_Boundary
    }
     interface SIG_BUS_BackpressureConfig {
        maxQueueSize?: number;
        slowConsumerThresholdMs?: number;
        throttleMs?: number;
    }
     interface SIG_BUS_Schema {
        validate(p: unknown): boolean;
        coerce?(p: unknown): unknown;
    }
     interface SIG_BUS_rtPermissions {
        allow?: string[];
        deny?: string[];
        read?: string[];
        write?: string[];
    }
     interface SIG_BUS_rtInfo {
        rt: string;
        handlers: number;
        adapters: string[];
        middleware: number;
        messageCount: number;
        tags: string[];
    }
     interface SIG_BUS_AdapterMetrics {
        id: string;
        latencyMs: number;
        failureRate: number;
        throughputPerSec: number;
        healthy: boolean;
        disabled: boolean;
    }
     interface SIG_BUS_RouteRule {
        name: string;
        match: (msg: SIG_BUS_Message | SIG_BUS_CBORValue) => boolean;
        targetAdapters?: string[];
        targetrts?: string[];
    }
     interface SIG_BUS_Transform {
        outgoing?(msg: SIG_BUS_Message | SIG_BUS_CBORValue): SIG_BUS_Message | Promise<SIG_BUS_Message>;
        incoming?(msg: SIG_BUS_Message | SIG_BUS_CBORValue): SIG_BUS_Message | Promise<SIG_BUS_Message>;
    }
     interface SIG_BUS_EncryptionConfig {
        rt?: string;
        adapterId?: string;
        secret?: string;
        publicKey?: string;
        algorithm?: string;
    }
     interface SIG_BUS_DurableOptions {
        subscriberId: string;
        fromOffset?: number;
        fromTimestamp?: number;
        tags?: string[];
    }
     interface SIG_BUS_ReplayOptions {
        rt: string;
        fromOffset?: number;
        toOffset?: number;
        fromTimestamp?: number;
        toTimestamp?: number;
        tags?: string[];
    }
     interface SIG_BUS_GroupOptions {
        enabled?: boolean;
        middleware?: (msg: SIG_BUS_Message | SIG_BUS_CBORValue) => boolean | void;
    }
     interface SIG_BUS_SendOptions {
        ttl?: number;
        priority?: SIG_BUS_Priority;
        tags?: string[];
        metadata?: Record<string, unknown>;
        expectReply?: boolean;
    }
     interface SIG_BUS_BatchItem {
        rt: string;
        p: Record<string, unknown>;
    }
     interface SIG_BUS_HandlerContext {
        rt: string;
        adapter?: SIG_BUS_Adapter;
        meta: SIG_BUS_MessageMeta;
    }
     interface SIG_BUS_ClusterConfig {
        nodeId: string;
        peers: string[];
    }
     interface SIG_BUS_WebRTCAdapterOptions {
        signalingAdapter: SIG_BUS_Adapter;
        peerId: string;
        iceServers?: RTCIceServer[];
    }
     interface SIG_BUS_MessageMeta {
        id?: string;
        ttl?: number;
        priority?: SIG_BUS_Priority;
        tags?: string[];
        timestamp?: number;
        streamId?: string;
        [key: string]: unknown;
    }
     interface SIG_BUS_CompressionConfig {
        rt?: string;
        adapterId?: string;
        algorithm: string;
    }
     interface SIG_BUS_SEND_FN {
        (ppayload: unknown, k: string, sl?: string, ms?: string, rt?: string, ttl?: number, chain?: 'chain' | 'rechain', binary?: boolean): Promise<unknown>
        broadcast(p: unknown, k: string, sl?: string, ms?: string, rt?: string, ttl?: number, binary?: boolean): Promise<unknown>
        broadcastState(state: any, k: string, sl: string, ms: string, rt: string, chain?: 'chain' | 'rechain'): any
        bare_metal(p: unknown, k: string, sl?: string, ms?: string, rt?: string, boundary?: "same-app" | "same-node" | "cross-node"): Promise<unknown>
        emit(event: string, p: any, sl?: string, ms?: string, rt?: string): void
    }
     interface SIG_BUS_SUB_FN {
        (handler: any, k: string, sl?: string, ms?: string, rt?: string, boundary?: Boundary): any
        subscribe(handler: (d: unknown) => MaybePromise<void>, quad: string, trip: string, sub: string, ch: string,): any
    }
     interface SIG_BUS_BOUNDARY_FN {
        register(k: string, sl?: string, ms?: string, rt?: string, boundary?: Boundary): any
        probe<T = any>(p: unknown, k: string, sl?: string, ms?: string, rt?: string, boundary?: "same-app" | "same-node" | "cross-node"): any
    
    }
     interface SIG_BUS_CELL_FN {
        <T = any>(k: string, sl?: string, ms?: string, rt?: string, chain?: 'chain' | 'rechain', v?: T): any
        send<T = any>(p: unknown, k: string, sl?: string, ms?: string, rt?: string, chain?: 'chain' | 'rechain'): any
        cell<T = any>(k: string, sl?: string, ms?: string, rt?: string, type?: 'waitFor' | 'sub' | 'cell', chain?: 'chain' | 'rechain', v?: T): any
        crdt<T = any>(k: string, sl?: string, ms?: string, rt?: string, chain?: 'chain' | 'rechain', v?: T): any
    }
    
     type CELL_TYPE = 'waitFor' | 'sub' | 'cell' | 'none'
     type CHAIN_TYPE = 'chain' | 'rechain'
     type STORE_TYPE = 'tc' | 'rr' | 'auto'
     type INI_QD<T = any> = [v?: T, k?: string, sl?: string, ms?: string, rt?: string]
    // ...args: [...INI_QD<T>,]
    //  mailbox<T = any>(...args: [...INI_QD<T>, ]): any
     type QD_INI = [k: string, v?: any, sl?: string, ms?: string, rt?: string,]
    // ...args: [...QD_INI,]
    //  mailbox(...args: [...QD_INI, ]): any
     type QD = [k: string, sl?: string, ms?: string, rt?: string]
    // ...args: [...QD,]
    //  mailbox(...args: [...QD, ]): any
    
    
     interface SIG_BUS_DEPLUX_FN {
        (k: string, sl?: string, ms?: string, rt?: string, opts?: { windowSize?: number; livenessId?: string; }, type?: string): any;
        async<TUp = any, TDown = any>(...args: [...QD, opts?: { windowSize?: number }]): any;
        solo(readConfig: { k: string; sl?: string; ms?: string; rt?: string },
            writeConfig: { k?: string; sl?: string; ms?: string; rt?: string }
        ): { sub: ReadableStream; send: WritableStream }
        open(...args: [opts: any, ...QD,]): any
        sx(...args: [...QD, opts: any]): any
    }
     interface DUPLEX_HANDLER_FN {
        <TUp = any, TDown = any>(handlerFn: (data: TUp, stream: any) => void | Promise<void>, k: string, sl?: string, ms?: string, rt?: string, opts?: { windowSize?: number; }, type?: 'default' | 'sync' | 'stream-relay' | 'rate-limited' | 'fan-out' | 'priority' | 'transactional' | 'presence' | 'authority' | 'multicast' | 'partitioned' | 'batch' | 'filtered' | 'idempotent' | 'checkpoint' | 'transform'): any;
    
        async<TUp = any, TDown = any>(handlerFn: (data: TUp, stream: DuplexStream<TDown, TUp>) => void | Promise<void>, k: string, sl?: string, ms?: string, rt?: string, opts?: { windowSize?: number }): any;
    }
     interface DuplexStream<TSend = any, TRecv = any> {
        send: (p: TSend) => void;
        onData: (handler: (chunk: TRecv, seq: number) => void) => () => boolean;
        onError: (handler: (err: DuplexError) => void) => () => boolean;
        onRemoteClose: (handler: () => void) => () => boolean;
        closeUp?: () => void;
        closeDown?: () => void;
        close: () => void;
        isFullyClosed: () => boolean;
        isFatallyErrored: () => boolean;
    }
     interface DuplexError {
        dir: 'up' | 'down';
        message: string;
        fatal: boolean;
        retryable?: boolean;
        code?: string;
    }
     type LateArrivalStrategy = 'discard' | 'delay' | 'reorder';
     type CompressFormat = 'gzip' | 'deflate' | 'deflate-raw' | 'brotli' | 'zstd';
     interface HANDLER_FN {
        (handler: (d: any) => any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): any;
        syncGuard(handler: (chunk: any, seq: number, streamId: string) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, options?: SyncSubGuardOptions): void;
        sync(k: string, sl?: string, ms?: string, rt?: string): any;
        sync_2(handler: (chunk: any, seq: number) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): void;
        openSync(handler: (chunk: any, seq: number) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
        priority(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
        transactional(apply: (chunks: any[]) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
        delta<T>(applyPatch: (current: T, diff: any) => T, v: T, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
        presence(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, onUpdate?: (all: Record<string, any>) => void): any;
        authority<T>(resolve: (guess: T) => Promise<T> | T, k: string, sl: string, ms: string, rt: string): () => void;
        heartbeat(onDead: () => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { deadThresholdMs?: number }): any;
        backpressure(handler: (p: any) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
        stateful(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { key?: string }): any;
        multicast(receiverId: string, handler: (p: any, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { key?: string; startFrom?: 'beginning' | 'now' }): Promise<any>;
        partitioned(handler: (key: string, p: any, partition: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { partitions?: number[]; partitionCount?: number }): any;
        batch(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
        filtered(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, predicate?: (p: any) => boolean): () => void;
        deadLetter(handler: (entry: SIG_BUS_Message) => Promise<boolean> | boolean): any;
        idempotent(handler: (p: any) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { keyPrefix?: string; ttlMs?: number }): any;
        lateArrival(handler: (p: any, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { strategy?: LateArrivalStrategy; toleranceMs?: number }): () => void;
        checkpoint(streamKey: string, handler: (p: any, seq: number) => Promise<void> | void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { every?: number }): Promise<any>;
        rateLimited(handler: (p: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
        combo(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
        transform<T = any, R = any>(fn: (p: T) => Promise<R> | R, onResult: (result: R, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { concurrency?: number }): () => void;
        map<T = any, R = any>(fn: (item: T) => R, onResult: (r: R, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { concurrency?: number }): () => void;
        filter<T = any>(predicate: (item: T) => boolean, onResult: (item: T, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
        reduce<T = any, R = any>(fn: (acc: R, item: T) => R, v: R, onUpdate: (acc: R) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): () => void;
        fanout(receiverId: string, handler: (p: any, seq: number) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: { key?: string; startFrom?: 'beginning' | 'now' }): Promise<any>;
        useDRSS<T extends Record<string, unknown>>(v: any, handler: (chunk: any, state: any) => any | Promise<T>, k: string, sl?: string, ms?: string, rt?: string, binary?: boolean): any;
        useDRSSSync(v: any, handler: (chunk: any, seq: number, state: any) => any | Promise<any>, k: string, sl?: string, ms?: string, rt?: string, binary?: boolean): any;
    }
     interface SyncSubGuardOptions {
        sl?: string;
        ms?: string;
        rt?: string;
        maxBufferSize?: number;
        streamTTLMs?: number;
        maxStreams?: number;
        binary?: boolean;
        onStreamComplete?: (streamId: string, totalChunks: number) => void;
        onStreamError?: (streamId: string, error: string) => void;
    }
     interface FieldTouch {
        field: string;
        action: 'viewing' | 'editing';
        userId?: string;
        timestamp?: number;
        [key: string]: any;
    }
     interface DRSConflictOptions {
        k?: string;
        sl?: string;
        ms?: string;
        rt?: string;
        conflictStrategy?: 'lww' | 'version-vector' | 'custom' | string;
        versionKey?: string;
        debounceMs?: number;
        binary?: boolean;
        onConflict?: (local: any, remote: any) => any;
    }
     interface RelayFlowOptions extends StreamRelayOptions { }
     interface SyncIntegrityOptions {
        sl?: string;
        ms?: string;
        rt?: string;
        windowSize?: number;
        chunkRetries?: number;
        retryBackoffMs?: number;
        timeoutMs?: number;
        binary?: boolean;
        priority?: any;
        ttl?: number;
        onProgress?: (sent: number, acked: number, total: number) => void;
        onChunkFailed?: (seq: number, retries: number) => void;
    }
     interface SyncIntegrityResult {
        success: boolean;
        delivered: number;
        acknowledged: number;
        failed: number[];
        durationMs: number;
    }
     type ComboStrategy = 'arrival' | 'round-robin' | 'timestamp';
    
     interface HydraStage<T> {
        name: string;
        handler: (data: T) => T;
    }
     type BackpressureRelayStrategy = 'drop-oldest' | 'drop-newest' | 'block' | 'drop' | 'latest' | 'error' | "pause";
     interface StreamRelayOptions {
        maxSubscribers?: number;
        bufferSize?: number;
        backpressureStrategy?: BackpressureRelayStrategy
        deliveryGuarantee?: 'at-most-once' | 'at-least-once';
        subscriberTimeoutMs?: number;
        onSubscriberDrop?: (id: string, reason: string) => void;
    }
     interface SyncStreamOptions {
        windowSize?: number;
        retransmitMs?: number;
    }
     interface SyncStreamSendHandle {
        push(p: unknown): void;
        pendingCount(): number;
        close(): void;
    }
     interface SyncStreamHandler {
        onOrdered(cb: (p: unknown, seq: number) => void): void;
        onComplete(cb: () => void): void;
        close(): void;
    }
     interface Outbound {
        seq: number;
        p: unknown;
        acked: boolean;
        sentAt: number;
        timer?: ReturnType<typeof setTimeout>;
    }
     interface SIG_BUS_useEffect_FN {
        (effect: () => void | (() => void), deps: any[], k: string, sl: string, ms: string, rt: string): any;
        auto(effect: (scope: ReturnType<any>) => void, deps: any[], k: string, sl: string, ms: string, rt: string): any;
        layout(effect: any, deps: any, k: string, sl: string, ms: string, rt: string): any
    }
     interface SIG_BUS_STREAM_FN {
        (p: any, onChunk: (chunk: any) => void, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, chain?: 'chain' | 'rechain', binary?: boolean): Promise<void>;
        chunk(streamId: string, chunk: string, k: string, sl?: string, ms?: string, rt?: string): void
        done(streamId: string, chunk: string, k: string, sl?: string, ms?: string, rt?: string): void
        cancel(streamId: string, chunk: string, k: string, sl?: string, ms?: string, rt?: string): void
        liminal<T = unknown>(upstream: StreamAddress, downstream: StreamAddress, onChunk: (event: LiminalChunk<T>) => void,): { id: string; done: Promise<void>; close: () => void; }
        constellation(
            options?: ConstellationOptions,
        ): (
            onChunk?: (event: ConstellationChunk) => void,
        ) => ConstellationHandle
        constellation2(
            options?: ConstellationOptions2,
        ): (
            onChunk: (event: ConstellationChunk2) => void,
        ) => ConstellationHandle2
        negotiate(offer: StreamContractOffer, k: string, sl?: string, ms?: string, rt?: string, timeoutMs?: number,): Promise<NegotiatedStreamContract>
        probabilistic<T>(send: ProbabilisticSender, options: ProbabilisticOptions<T>,): ProbabilisticSender
        readable(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): ReadableStream<any>;
        writable(k?: SU, sl?: string, ms?: string, rt?: string): WritableStream<any>;
        StreamRelay(k?: SU, sl?: string, ms?: string, rt?: string, opts?: StreamRelayOptions): any;
        transform(readConfig: {
            k: string;
            sl?: string | undefined;
            ms?: string | undefined;
            rt?: string | undefined;
        }, writeConfig: {
            k?: string | undefined;
            sl?: string | undefined;
            ms?: string | undefined;
            rt?: string | undefined;
        }, transformer?: (chunk: any) => any | Promise<any>): {
            sub: TransformStream<any, any>;
            send: TransformStream<any, any>;
        };
        pipeline<T = any>(k?: SU, sl?: string, ms?: string, rt?: string, stages?: HydraStage<T>[]): {
            unsubscribe: () => void;
        };
        route<T = any>(k?: SU, sl?: string, ms?: string, rt?: string, selectKey?: (p: T) => string, outPrefix?: string, opts?: {
            defaultKey?: string;
            onUnmatched?: (p: T, key: string) => void;
        }): {
            unsubscribe: () => void;
            stats: () => Record<string, number>;
        };
        syncGuard(chunks: any[], k: string, options?: SyncIntegrityOptions): Promise<SyncIntegrityResult>;
        relayWithFlowControl(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, options?: RelayFlowOptions): any;
        useDRSWithConsensus(vState: any, k?: SU, sl?: string, ms?: string, rt?: string, options?: DRSConflictOptions): any;
    
        sync_2(chunks: any[], k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, onAck?: (seq: number) => void, windowSize?: number, binary?: boolean): Promise<void>;
        sync(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: SyncStreamOptions): any;
    
        relay(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, options?: {
            maxSubscribers?: number;
            bufferSize?: number;
            backpressureStrategy?: 'drop' | 'pause' | 'error';
        }): any;
        openSync(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
            windowSize?: number;
        }): any;
        priority(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
        transactional(chunks: any[], k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): Promise<{
            committed: boolean;
            error?: string;
        }>;
        delta<T extends any>(computeDelta: (prev: T, next: T) => any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
        presence(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
        authority<T = any>(v: T, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
        heartbeat(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
            idleThresholdMs?: number;
        }): any;
        backpressure(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
            windowSize?: number;
        }): any;
        stateful(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
            key?: string;
        }): any;
        multicast(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
            key?: string;
        }): any;
        partitioned(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
            partitionCount?: number;
        }): any;
        batch(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
            maxSize?: number;
            maxWaitMs?: number;
        }): any;
        filtered(predicate: (p: any) => boolean, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
        deadLetter(p: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
            maxRetries?: number;
            backoff?: any;
        }): Promise<{
            delivered: boolean;
        }>;
        idempotent(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
        lateArrival(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
        checkpoint(streamKey: string, opts?: {
            every?: number;
        }): any;
        rateLimited(opts: {
            ratePerSecond: number;
            burst?: number;
        }, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
        combo(k: string, sl: string[], ms?: string | undefined, rt?: string | undefined, strategy?: ComboStrategy): any;
        transformative(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined): any;
        fanout(k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, opts?: {
            key?: string;
        }): any;
        useDRSS<T extends Record<string, unknown> = any, P = any>(v: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): any;
        useDRSSSync(v: any, k: string, sl?: string | undefined, ms?: string | undefined, rt?: string | undefined, binary?: boolean): any;
    }
     interface SIG_BUS_HANDLER_FN { }
    
    
    
    
    
    
     interface SIG_BUS_CELL_DRS_FN {
        (...args: [...QD_INI, type?: CELL_TYPE, chain?: CHAIN_TYPE]): any
        crdt<T = any>(...args: [...INI_QD<T>]): any
        cell(...args: [...QD_INI, type?: CELL_TYPE, chain?: CHAIN_TYPE]): any
        rifts: {
            <T = any>(module?: any, named_?: any, store?: STORE_TYPE, wait?: number, chain?: CHAIN_TYPE): any
            mailbox<T = any>(...args: [...INI_QD<T>, STORE_TYPE]): any
        }
        crdtb<T = any>(...args: [...INI_QD<T>, nodeId?: string]): any
        topology(k: string, sl?: string, ms?: string, rt?: string, chain?: 'chain' | 'rechain', selfId?: string, opts?: { probeTimeoutMs?: number }): any
        map<K, V>(k: string, v: Map<K, V>, sl?: string, ms?: string, rt?: string, type?: CELL_TYPE, chain?: CHAIN_TYPE): any
        set<T = any>(k: string, v: Iterable<T>, sl?: string, ms?: string, rt?: string, type?: CELL_TYPE, chain?: CHAIN_TYPE): any
        array<T = any>(k: string, v: T[], sl?: string, ms?: string, rt?: string, type?: CELL_TYPE, chain?: CHAIN_TYPE): any
        obj<T extends Record<PropertyKey, any>>(k: string, v?: T, sl?: string, ms?: string, rt?: string, type?: CELL_TYPE, chain?: CHAIN_TYPE): any
        string(k: string, v: string, sl?: string, ms?: string, rt?: string, type?: CELL_TYPE, chain?: CHAIN_TYPE): any
        num(k: string, v: number, sl?: string, ms?: string, rt?: string, type?: CELL_TYPE, chain?: CHAIN_TYPE): any
        boolean(k: string, v: boolean, sl?: string, ms?: string, rt?: string, type?: CELL_TYPE, chain?: CHAIN_TYPE): any
        stream(...args: [...INI_QD, opts?: any]): any
        duplex(...args: [...INI_QD, chain?: CHAIN_TYPE, opts?: any,]): any
        time_travel(...args: [...INI_QD,]): any
        gated(predicate: (topo: any, ...ctx: any[]) => boolean, value: any, deps: any[], k: any, sl?: string, ms?: string, rt?: string): any
        transaction(...args: [...QD_INI,]): any
        signal<T = any>(v?: T | (() => T), k?: string, sl?: string, ms?: string, rt?: string, chain?: CHAIN_TYPE): any
        graph(...args: [...QD_INI,]): any
        distributed(...args: [...QD_INI,]): any
        synchronization(...args: [...QD_INI,]): any
        replication(...args: [...QD_INI,]): any
        resilience(...args: [...QD_INI,]): any
        temporal(...args: [...QD_INI,]): any
        mesh<T = any>(v?: T, reactor?: StateMeshReactor<T>, k?: string, sl?: string, ms?: string, rt?: string,): StateMesh<T>
        store(...args: [...INI_QD,]): any
        mailbox(...args: [...INI_QD,]): any
        mailbox2(...args: [...INI_QD,]): any
        stateStore(...args: [...INI_QD,]): any
        liveStore(...args: [...INI_QD, nodeId?: string]): any
        live(...args: [...INI_QD,]): any
        observable(...args: [...INI_QD,]): any
        ref(...args: [...INI_QD,]): any
        umbrella(v?: Record<string, any>, k?: string, sl?: string, ms?: string, rt?: string): any
        context(v?: Record<string, any>, k?: string, sl?: string, ms?: string, rt?: string): any
    }
     type SIG_BUS_SS_FN = {
        // ── callable: creates a signal handle ────────────────────────────────────────────────────
        <T = any>(v?: any, key?: string, sl?: string, ms?: string, rt?: string, chain?: 'chain' | 'rechain', options?: SignalOptions<T>): any;
        update(node: SignalNode | ComputedNode | EffectScopeNode): boolean
        notify(effect: EffectNode): any
    
    
    
    
    
    
    
    
        _bindComponentToSignal(rk: string, sl?: string, ms?: string, rt?: string): void;
        _hashTuple(tuple: unknown[]): string
        _serializeTuple(tuple: any[]): string
        create<T = any>(key: string, v?: any, sl?: string, ms?: string, rt?: string, options?: SignalOptions<T>): string;
        read<T>(key: string, sl?: string, ms?: string, rt?: string,): any
        write<T>(key: string, sl?: string, ms?: string, rt?: string,): any
        normalizeKey(rawKey: string): any
        runTeardown(t: Teardown): void
        reportError(e: unknown): void
        untrackFn<T>(fn: () => T): T
        untrack<T>(fn: () => T): T
        
        setEffectErrorHandler(fn: EffectErrorHandler | null): void
        getActiveSub(): ReactiveNode | undefined
        setActiveSub(sub?: ReactiveNode): any
        getBatchDepth(): number
        startBatch(): any
        endBatch(): any
        isSignal(fn: () => void): boolean
        isComputed(fn: () => void): boolean
        isEffect(fn: () => void): boolean
        isEffectScope(fn: () => void): boolean
        signal<T>(v?: T): { (): T | undefined; (value: T | undefined): void; }
        computed<T>(getter: (previousValue?: T) => T): () => T
        effect(fn: () => void | (() => void), onError?: EffectErrorHandler): (that: EffectNode) => void
        effectScope(fn: () => void, onError?: EffectErrorHandler): (that: EffectScopeNode) => void
        trigger(fn: () => void): any
        updateComputed(c: ComputedNode): boolean
        updateSignal(s: SignalNode): boolean
        run(e: EffectNode): void
        flushSS(): void
        runCleanup(e: EffectNode): void
        disposeAllDepsInReverse(sub: ReactiveNode): void
        purgeDeps(sub: ReactiveNode): any
    
        // ── ergonomic helpers ────────────────────────────────────────────────────────────────────
        sysEffect(fn: () => void | (() => void)): () => void;
    
        // ── internals exposed on the namespace ───────────────────────────────────────────────────
        _validateSchema(rk: string, value: any, sl?: string, ms?: string, rt?: string): any;
        _hashTuple(tuple: unknown[]): string;
        _recordCausal(rk: string, value: any, source: string, sl?: string, ms?: string, rt?: string, cause?: string): void;
        _resolveConflict(rk: string, prev: any, next: any, sl?: string, ms?: string, rt?: string): any;
        _writeResolved(rk: string, value: any, source: string, sl?: string, ms?: string, rt?: string, cause?: string): void;
    
        // ── key + schema ─────────────────────────────────────────────────────────────────────────
        resolveKey(key: any, sl?: string, ms?: string, rt?: string): string;
        registerSchema<T = any>(key: any, schema: SignalSchema<T>, sl?: string, ms?: string, rt?: string): void;
    
        // ── signal CRUD ──────────────────────────────────────────────────────────────────────────
        write<T = any>(key: any, value: T | ((prev: T | undefined) => T), sl?: string, ms?: string, rt?: string, source?: string): void;
        read<T = any>(key: any, sl?: string, ms?: string, rt?: string): T | undefined;
        peek<T = any>(key: any, sl?: string, ms?: string, rt?: string): T | undefined;
        subscribe<T>(key: string, listener: (value: T, previous: T) => void, sl?: string, ms?: string, rt?: string,): Unsubscribe
        has(key: any, sl?: string, ms?: string, rt?: string): boolean;
        delete(key: any, sl?: string, ms?: string, rt?: string): void;
    
        // ── signal state modifiers ───────────────────────────────────────────────────────────────
        freeze(key: any, sl?: string, ms?: string, rt?: string): void;
        seal(key: any, sl?: string, ms?: string, rt?: string): void;
        reset(key: any, sl?: string, ms?: string, rt?: string): void;
        hydrate<T = any>(key: any, value: T, sl?: string, ms?: string, rt?: string): void;
    
        clone(srcKey: any, destKey: any, src: rts, dest: rts,): void;
    
        // ── persistence ──────────────────────────────────────────────────────────────────────────
        persist<T = any>(key: any, value: T, sl?: string, ms?: string, rt?: string, options?: { serialize?: (v: T) => string }): Promise<void>;
        unpersist(key: any, sl?: string, ms?: string, rt?: string): Promise<void>;
    
        // ── messaging ────────────────────────────────────────────────────────────────────────────
        sub<T = any>(k: string, handler: any, sl?: string, ms?: string, rt?: string): () => void;
        send(p: any, fromKey: any, toKey: any, ms?: string, rt?: string): void;
    
        // ── derived ──────────────────────────────────────────────────────────────────────────────
        derive<T = any>(
            key: any,
            deps: any[],
            compute: (...values: any[]) => T, sl?: string, ms?: string, rt?: string,
            options?: { eager?: boolean; onError?: (err: Error) => void }
        ): string;
        invalidateDerived(key: any): void;
    
        // ── async ────────────────────────────────────────────────────────────────────────────────
        createAsync<T = any>(
            key: any,
            fetcher: (signal: AbortSignal) => Promise<T>, sl?: string, ms?: string, rt?: string,
            options?: { fallback?: T }
        ): AsyncSignalHandles;
        invalidateAsync(key: any, sl?: string, ms?: string, rt?: string): void;
        mutateAsync<T = any>(key: any, optimistic: T, sl?: string, ms?: string, rt?: string): void;
        abortAsync(key: any, sl?: string, ms?: string, rt?: string): void;
        prefetchAsync<T = any>(key: any, fetcher: () => Promise<T>, sl?: string, ms?: string, rt?: string): void;
        readAsync<T = any>(key: any, sl?: string, ms?: string, rt?: string): T;
    
        // ── batch / tx ───────────────────────────────────────────────────────────────────────────
        batch(fn: () => void): void;
        tx(fn: () => void): void;
        transaction(block: () => void): void;
    
        // ── history / time travel ────────────────────────────────────────────────────────────────
        enableHistory(key: any, sl?: string, ms?: string, rt?: string, options?: { max: number }): void;
        undo(key: any, sl?: string, ms?: string, rt?: string): void;
        redo(key: any, sl?: string, ms?: string, rt?: string): void;
        signalTimeline(key: any, sl?: string, ms?: string, rt?: string): SignalTimelineEntry[];
        snapshot(): Record<string, any>;
        restore(snapshot: Record<string, any>): void;
        diffSnapshots(a: Record<string, any>, b: Record<string, any>): Record<string, { from: any; to: any }>;
        applyPatch(patch: Record<string, { from: any; to: any }>): void;
        replay(key: any, sl?: string, ms?: string, rt?: string, options?: { speed?: number }): Promise<void>;
    
        // ── causal / conflict / contracts ────────────────────────────────────────────────────────
        getCausalChain(key: any, sl?: string, ms?: string, rt?: string): CausalEntry[];
        conflictPolicy<T = any>(key: any, policy: ConflictPolicy<T>): void;
        declareContract(
            name: string,
            key: any,
            postcondition: (next: any, prev: any) => boolean, sl?: string, ms?: string, rt?: string,
            options?: { block?: boolean }
        ): void;
        removeContract(name: string): void;
    
        // ── scopes ───────────────────────────────────────────────────────────────────────────────
        createScope(id: string): SignalScopeHandle;
    
        // ── effects ──────────────────────────────────────────────────────────────────────────────
    
        effectOnce(
            keys: any[],
            predicate: (...v: any[]) => boolean,
            fn: (...v: any[]) => void
        ): () => void;
    
        // ── operators ────────────────────────────────────────────────────────────────────────────
        map<A = any, B = any>(srcKey: any, destKey: any, fn: (v: A) => B, src: rts, dest: rts): () => void;
        filter<T = any>(srcKey: any, destKey: any, pred: (v: T) => boolean, src: rts, dest: rts): () => void;
        debounce(sourceKey: any, delay: number, src: rts, dest: rts): [string, () => void];
        throttle(srcKey: any, destKey: any, ms: number, src: rts, dest: rts): () => void;
        merge(srcKeys: any[], destKey: any, src: rts, dest: rts): () => void;
        zip(srcKeys: any[], destKey: any, src: rts, dest: rts): () => void;
        combine(srcKeys: any[], destKey: any, src: rts, dest: rts): () => void;
        scan<T = any, A = any>(srcKey: any, destKey: any, reducer: (a: A, v: T) => A, seed: A, src: rts, dest: rts): () => void;
        switch(srcKey: any, destKey: any, src: rts, dest: rts): () => void;
        buffer(srcKey: any, destKey: any, count: number, src: rts, dest: rts): () => void;
        window(srcKey: any, destKey: any, ms: number, src: rts, dest: rts): () => void;
        distinct<T = any>(srcKey: any, destKey: any, equals?: (a: T, b: T) => boolean, src?: rts, dest?: rts,): any;
        audit(srcKey: any, destKey: any, ms: number, src: rts, dest: rts): () => void;
        sample(srcKey: any, triggerKey: any, destKey: any, src: rts, dest: rts): () => void;
        gate(srcKey: any, gateKey: any, destKey: any, src: rts, dest: rts): () => void;
    };
     interface AsyncSignalHandles {
        dataKey: string;
        loadingKey: string;
        errorKey: string;
    }
     interface SignalScopeHandle {
        add(key: any): void;
        suspend(): void;
        resume(): void;
        dispose(): void;
        snapshot(): Record<string, any>;
        restore(snapshot: Record<string, any>): void;
        fork(): SignalScopeHandle;
        merge(forked: SignalScopeHandle): void;
    }
     type Teardown =
        | void
        | null
        | (() => void)
        | { unsubscribe(): void }
        | { [Symbol.dispose](): void }
        | Teardown[];
     interface Link {
        version: number;
        dep: ReactiveNode;
        sub: ReactiveNode;
        prevSub: Link | undefined;
        nextSub: Link | undefined;
        prevDep: Link | undefined;
        nextDep: Link | undefined;
        bus?: any
        value?: any
        label?: string
    }
     interface Stack<T> {
        value: T;
        prev: Stack<T> | undefined;
    }
     const enum ReactiveFlags {
        None = 0,
        Mutable = 1,
        Watching = 2,
        RecursedCheck = 4,
        Recursed = 8,
        Dirty = 16,
        Pending = 32,
    }
     interface EffectScopeNode extends ReactiveNode {
        onError?: EffectErrorHandler;
        children?: Set<ReactiveNode>;
    }
     type EffectErrorHandler = (err: unknown, node: ReactiveNode) => void;
     interface ReactiveNode {
        deps?: Link;
        depsTail?: Link;
        subs?: Link;
        subsTail?: Link;
        flags: ReactiveFlags;
    }
     interface AsyncNode<T = any> extends ReactiveNode {
        fetcher: (signal: AbortSignal) => Promise<T>;
        value: T | undefined;
        error: unknown;
        pending: boolean;
        controller: AbortController | null;
        version: number;
        onError?: EffectErrorHandler;
    }
     interface EffectNode extends ReactiveNode {
        fn(): (() => void) | void;
        cleanup: (() => void) | void;
        onError?: EffectErrorHandler;
    }
     interface ComputedNode<T = any> extends ReactiveNode {
        value: T | undefined;
        getter: (previousValue?: T) => T;
    }
     interface SignalNode<T = any> extends ReactiveNode {
        currentValue: T;
        pendingValue: T;
    }
     interface SignalScope {
        id: string
        keys: Set<string>
        effects: Set<any>
        suspended: boolean
        pendingFlush: Map<string, any>
    }
     type SignalListener = { (value: any, source?: string): void }
     interface SignalLifecycle<T = any> {
        onCreate?: () => void;
        onWrite?: (value: T, prev: T | undefined) => void;
        onRead?: (value: T) => void;
        onDelete?: () => void;
        onFreeze?: () => void;
        onExpire?: () => void;
        onError?: (err: Error) => void;
    }
     interface SignalEffect {
        keys: string[];
        fn: (...values: any[]) => (() => void) | void | Promise<(() => void) | void>;
        cleanup: (() => void) | null;
        controller: AbortController | null;
    }
     interface AsyncSignalState<T> {
        fetcher: () => Promise<T> | void;
        controller: AbortController | null;
        retryCount: number;
        staleValue?: T;
    }
     type ConflictPolicy2<T = any> = | ConflictPolicyName | ((current: T, incoming: T, meta: { key: string; timestamp: number }) => T)
    // interface ConflictPolicy<T = any> { resolve?: (prev: T | undefined, next: T) => T | undefined; }
     interface ConflictPolicy<T = any> { resolve?: (prev: T | undefined, next: T) => T | undefined; }
     interface SignalOptions<T = any> {
        schema?: SignalSchema<T>;
        conflict?: ConflictPolicy<T>;
        history?: { max: number };
        lifecycle?: SignalLifecycle<T>;
        persist?: boolean;
        ttl?: number;
        broadcast?: boolean;
        trigger_render?: boolean;
        conflictStrategy?: any
    }
     interface SysEntry {
        read: () => any;
        write: (v: any) => void;
        node: any;
        isComputed: boolean;
    }
     interface Metrics {
        readCount: number;
        writeCount: number;
        subscriberCount: number;
        lastWrite: number | null;
        flushDuration: number;
    }
     interface SignalHandle<T = any> {
        value: T;
        peek(): T;
    }
     interface ComputedHandle<T = any> {
        value: T;
        peek(): T;
    }
     interface SignalSchema<T = any> {
        validate: (v: any) => boolean;
        coerce?: (v: any) => T;
    }
     interface SignalLifecycle<T = any> {
        onCreate?: () => void;
        onWrite?: (value: T, prev: T | undefined) => void;
        onRead?: (value: T) => void;
        onDelete?: () => void;
        onFreeze?: () => void;
        onExpire?: () => void;
        onError?: (err: Error) => void;
    }
     interface SignalEffect {
        keys: string[];
        fn: (...values: any[]) => (() => void) | void | Promise<(() => void) | void>;
        cleanup: (() => void) | null;
        controller: AbortController | null;
    }
     interface AsyncSignalState<T = any> {
        fetcher: () => Promise<T> | void;
        controller: AbortController | null;
        retryCount: number;
        staleValue?: T;
    }
     interface SignalOptions<T = any> {
        schema?: SignalSchema<T>;
        conflict?: ConflictPolicy<T>;
        history?: { max: number };
        lifecycle?: SignalLifecycle<T>;
        persist?: boolean;
        ttl?: number;
        broadcast?: boolean;
    }
     interface SignalTimelineEntry {
        value: any;
        timestamp: number;
        source?: string;
    }
     type ConflictPolicyName = 'last-write-wins' | 'first-write-wins' | 'merge' | 'reject-on-conflict' | 'queue'
     interface CausalEntry {
        key: string
        value: any
        timestamp: number
        source?: 'write' | 'effect' | 'derived' | 'staff' | 'ngin' | string
        cause?: string
    }
     interface DOMBinding {
        node: Node
        update: (node: Node, value: any) => void
        active?: boolean
    }
     interface CallbackHookState extends HookState {
        callback: (...args: any[]) => any
        deps: any[]
    }
    
     function chain<T = any>(value: MaybePromise<T>) { return Promise.resolve(value); }
    
    // #endregion
    // #region MATBE GENERIC
    
    // #region MaybeScope
     interface ScopeOptions {
        sl?: any
        ms?: any
        rt?: any
        k?: any
    }
     type MS1 = symbol;
    
    
     interface maybe_ch_payload {
    
        v?: any
        rt?: SU
        ms?: SU
        sl?: SU
        k?: SU
    }
     interface maybe_rt {
        sl?: SU
        ms?: SU
        rt?: SU
    }
     interface SauronRegistry extends SauronState {
      name: string
      destroy(): void
    }
     interface SAURON_REGISTRY_STORAGE {
      get<T>(key: string, opts?: ScopeOptions): T | undefined
      set<T>(key: string, value: T | ((prev: T | undefined) => T), opts?: { triggerRender?: boolean } & ScopeOptions): void
      delete(key: string, opts?: ScopeOptions): boolean
      getByPrefix<T>(prefix: string, opts?: ScopeOptions): { key: string; value: T }[]
      getAll<T = any>(opts?: ScopeOptions): Record<string, T>
      subscribe<T>(key: string, listener: (value: T) => void, opts?: ScopeOptions): () => void
      subscribeAll(listener: (key: string, value: any) => void, opts?: ScopeOptions): () => void
      batch(key: string, fn: () => void, opts?: ScopeOptions): void
      clear(opts?: ScopeOptions): void
    
      name: string
      destroy(): void
    }
    
    // #endregion
    // #endregion
    
    
     type GateContext<TPayload = unknown> = {
        p: TPayload;
        store: Map<string, unknown>;
        reply: (data: unknown, targetrt?: string) => Promise<unknown>;
    };
     type GateMatcher<TPayload = unknown> = (p: TPayload, ctx: GateContext<TPayload>) => MaybePromise<boolean>;
     type GateHandler<TPayload = unknown, TResult = unknown> = (p: TPayload, ctx: GateContext<TPayload>) => MaybePromise<TResult>;
     type GateDefinition<TPayload = unknown, TResult = unknown> = {
        /**
         * Higher values are checked first in sequential mode.
         * In concurrent mode priority only provides deterministic ordering metadata.
         */
        priority?: number;
    
        matcher: GateMatcher<TPayload>;
        handler?: GateHandler<TPayload, TResult>;
    };
     type GateMap<TPayload = unknown> = Record<string, GateMatcher<TPayload> | GateDefinition<TPayload>>;
     type GateRunResult<TResult = unknown> = {
        name: string;
        matched: boolean;
        success: boolean;
        result?: TResult;
        error?: unknown;
    };
     type GateMasterOptions = {
        /**
         * true: match all gates and run all matches in parallel
         * false: match and run one gate at a time, in priority order
         */
        concurrency?: boolean;
    
        /**
         * In sequential mode, stop after the first successful matching handler.
         * Defaults to false because Gate Master is intended to fan out to all matches.
         */
        stopAfterFirstMatch?: boolean;
    
        /**
         * If true, a failed matcher/handler stops sequential processing.
         * Defaults to false, so other independent gates keep running.
         */
        failFast?: boolean;
    
        onError?: (
            error: unknown,
            gateName: string,
            phase: "match" | "execute",
            p: unknown
        ) => void;
    };
     type Awaitable<T> = T | Promise<T>;
     type NodeId = string;
     type RunId = string;
     type PlinkoOutcome = | "success" | "failure" | "skipped" | "cancelled";
     type PlinkoRunStatus = | "idle" | "running" | "succeeded" | "failed" | "cancelled";
     type SerializedError = {
        name: string;
        message: string;
        stack?: string;
        cause?: SerializedError;
    };
     type PlinkoRetryPolicy = {
        maxAttempts?: number;
        delayMs?: number;
        maxDelayMs?: number;
        backoff?: "fixed" | "linear" | "exponential";
        jitter?: "none" | "full";
        retryIf?: (error: unknown, attempt: number) => boolean;
    };
     type PlinkoNodeContext<TInput, TResults extends Record<string, unknown> = Record<string, unknown>,> = {
        readonly runId: RunId;
        readonly nodeId: NodeId;
        readonly attempt: number;
        readonly input: TInput;
        readonly results: Readonly<TResults>;
        readonly variables: ReadonlyMap<string, unknown>;
        readonly signal: AbortSignal;
    
        emit(name: string, p?: unknown): void;
    };
     type ActionNode<TInput, TResults extends Record<string, unknown> = Record<string, unknown>, TOutput = unknown,> = {
        kind?: "action";
        label?: string;
    
        when?: (
            ctx: PlinkoNodeContext<TInput, TResults>,
        ) => Awaitable<boolean>;
    
        run: (
            ctx: PlinkoNodeContext<TInput, TResults>,
        ) => Awaitable<TOutput>;
    
        timeoutMs?: number;
        retry?: PlinkoRetryPolicy;
        on?: Partial<Record<PlinkoOutcome, NodeId>>;
    };
     type PlinkoDefinition<TInput> = {
        id: string;
        version?: string;
        start: NodeId;
        nodes: Record<NodeId, ActionNode<TInput>>;
    };
     type CompiledGraph<TInput> = Readonly<{
        id: string;
        version?: string;
        start: NodeId;
        nodes: Readonly<Record<NodeId, ActionNode<TInput>>>;
    }>;
     type PlinkoEvent =
        | {
            type: "run.started";
            runId: RunId;
            graphId: string;
            graphVersion?: string;
            input: unknown;
            at: number;
        }
        | {
            type: "node.selected";
            runId: RunId;
            nodeId: NodeId;
            at: number;
        }
        | {
            type: "node.started";
            runId: RunId;
            nodeId: NodeId;
            attempt: number;
            at: number;
        }
        | {
            type: "node.skipped";
            runId: RunId;
            nodeId: NodeId;
            reason: string;
            at: number;
        }
        | {
            type: "node.succeeded";
            runId: RunId;
            nodeId: NodeId;
            attempt: number;
            result: unknown;
            durationMs: number;
            at: number;
        }
        | {
            type: "node.failed";
            runId: RunId;
            nodeId: NodeId;
            attempt: number;
            error: SerializedError;
            durationMs: number;
            willRetry: boolean;
            at: number;
        }
        | {
            type: "node.retrying";
            runId: RunId;
            nodeId: NodeId;
            attempt: number;
            delayMs: number;
            at: number;
        }
        | {
            type: "node.cancelled";
            runId: RunId;
            nodeId: NodeId;
            attempt: number;
            reason?: unknown;
            at: number;
        }
        | {
            type: "transition.taken";
            runId: RunId;
            from: NodeId;
            outcome: PlinkoOutcome;
            to?: NodeId;
            at: number;
        }
        | {
            type: "run.event";
            runId: RunId;
            nodeId: NodeId;
            name: string;
            p?: unknown;
            at: number;
        }
        | {
            type: "run.completed";
            runId: RunId;
            status: Extract<
                PlinkoRunStatus,
                "succeeded" | "failed" | "cancelled"
            >;
            result: Record<string, unknown>;
            error?: SerializedError;
            at: number;
        };
     type PlinkoEnvelope = {
        __plinko: 1;
        graphId: string;
        graphVersion?: string;
        runId: RunId;
        event: PlinkoEvent;
        snapshot: PlinkoRunSnapshot;
    };
     type PlinkoRunSnapshot = Readonly<{
        id: RunId;
        graphId: string;
        graphVersion?: string;
        status: PlinkoRunStatus;
        currentNodeId?: NodeId;
        input: unknown;
        results: Readonly<Record<string, unknown>>;
        events: readonly PlinkoEvent[];
        startedAt?: number;
        endedAt?: number;
        error?: SerializedError;
    }>;
     type MutablePlinkoRunSnapshot = {
        id: RunId;
        graphId: string;
        graphVersion?: string;
        status: PlinkoRunStatus;
        currentNodeId?: NodeId;
        input: unknown;
        results: Record<string, unknown>;
        events: PlinkoEvent[];
        startedAt?: number;
        endedAt?: number;
        error?: SerializedError;
    };
     type PlinkoAttemptEvent<TOutput> =
        | {
            type: "started";
            attempt: number;
        }
        | {
            type: "succeeded";
            attempt: number;
            result: TOutput;
            durationMs: number;
        }
        | {
            type: "failed";
            attempt: number;
            error: SerializedError;
            durationMs: number;
            willRetry: boolean;
        }
        | {
            type: "retrying";
            attempt: number;
            delayMs: number;
        }
        | {
            type: "cancelled";
            attempt: number;
            reason?: unknown;
        };
     type PlinkoNodeExecution<TOutput> = {
        outcome: PlinkoOutcome;
        result?: TOutput;
        error?: SerializedError;
        attempt: number;
    };
     type PlinkoStartOptions = {
        runId?: RunId;
        k?: string;
        sl?: SU;
        ms?: SU;
        rt?: SU;
        ttl?: number;
        maxTransitions?: number;
    };
     type PlinkoRunHandle = Readonly<{
        id: RunId;
        done: Promise<PlinkoRunSnapshot>;
    
        cancel(reason?: unknown): void;
    }>;
     type PlinkoDefinitionHandle<TInput> = Readonly<{
        graph: CompiledGraph<TInput>;
    
        start(
            input: TInput,
            options?: PlinkoStartOptions,
        ): PlinkoRunHandle;
    }>;
     type SIG_BUS_PLINKO_FN = {
        <TInput>(
            definition: PlinkoDefinition<TInput>,
        ): PlinkoDefinitionHandle<TInput>;
    
        define<TInput>(
            definition: PlinkoDefinition<TInput>,
        ): PlinkoDefinitionHandle<TInput>;
    
        compile<TInput>(
            definition: PlinkoDefinition<TInput>,
        ): CompiledGraph<TInput>;
    };
     class PlinkoDefinitionError extends Error {
        constructor(
            message: string,
            readonly errors: readonly string[],
            readonly warnings: readonly string[] = [],
        ) {
            super(message);
            this.name = "PlinkoDefinitionError";
        }
    }
     class PlinkoTimeoutError extends Error {
        constructor(
            readonly nodeId: NodeId,
            readonly timeoutMs: number,
        ) {
            super(
                `Plinko node "${nodeId}" timed out after ${timeoutMs}ms.`,
            );
            this.name = "PlinkoTimeoutError";
        }
    }
     class PlinkoTransitionLimitError extends Error {
        constructor(
            readonly graphId: string,
            readonly runId: RunId,
            readonly limit: number,
        ) {
            super(
                `Plinko graph "${graphId}" run "${runId}" exceeded maxTransitions (${limit}).`,
            );
            this.name = "PlinkoTransitionLimitError";
        }
    }
     type StartOptions = {
        eventSink?: EventSink;
        maxTransitions?: number;
        runId?: RunId;
    
        /**
         * Used for non-durable diagnostics/telemetry. If omitted, telemetry append
         * failures are ignored. Event-sink failures are never ignored.
         */
        onTelemetryError?: (error: unknown, event: PlinkoEvent) => void;
    };
     type RunSnapshot = Readonly<{
        id: RunId;
        graphId: string;
        graphVersion?: string;
        status: RunStatus;
        currentNodeId?: NodeId;
        input: unknown;
        results: Readonly<Record<string, unknown>>;
        events: readonly PlinkoEvent[];
        startedAt?: number;
        endedAt?: number;
        error?: SerializedError;
    }>;
     type MutableRunSnapshot = {
        id: RunId;
        graphId: string;
        graphVersion?: string;
        status: RunStatus;
        currentNodeId?: NodeId;
        input: unknown;
        results: Record<string, unknown>;
        events: PlinkoEvent[];
        startedAt?: number;
        endedAt?: number;
        error?: SerializedError;
    };
     type ReadonlyValue<T> = T extends object ? Readonly<T> : T;
     type Outcome = | "success" | "failure" | "skipped" | "cancelled";
     type RunStatus = | "idle" | "running" | "succeeded" | "failed" | "cancelled";
     type RetryPolicy = {
        maxAttempts?: number;
        delayMs?: number;
        maxDelayMs?: number;
        backoff?: "fixed" | "linear" | "exponential";
        jitter?: "none" | "full";
        retryIf?: (error: unknown, attempt: number) => boolean;
    };
     type NodeContext<TInput, TResults extends Record<string, unknown> = Record<string, unknown>,> = {
        readonly runId: RunId;
        readonly nodeId: NodeId;
        readonly attempt: number;
        readonly input: TInput;
        readonly results: Readonly<TResults>;
        readonly variables: ReadonlyMap<string, unknown>;
        readonly signal: AbortSignal;
        emit(name: string, p?: unknown): void;
    };
     type AttemptEvent<TOutput> =
        | {
            type: "started";
            attempt: number;
        }
        | {
            type: "succeeded";
            attempt: number;
            result: TOutput;
            durationMs: number;
        }
        | {
            type: "failed";
            attempt: number;
            error: SerializedError;
            durationMs: number;
            willRetry: boolean;
        }
        | {
            type: "retrying";
            attempt: number;
            delayMs: number;
        }
        | {
            type: "cancelled";
            attempt: number;
            reason?: unknown;
        };
     type NodeExecution<TOutput = unknown> = {
        outcome: Outcome;
        result?: TOutput;
        error?: SerializedError;
        attempt: number;
    };
     type EventSink = {
        append(event: PlinkoEvent): void | Promise<void>;
    };
     type RunHandle = {
        id: RunId;
        done: Promise<RunSnapshot>;
    
        getSnapshot(): RunSnapshot;
        subscribe(listener: () => void): () => void;
        cancel(reason?: unknown): void;
    };
     interface HandlerContext {
        rt: string;
        adapter?: SIG_BUS_Adapter;
        meta: SIG_BUS_MessageMeta;
    }
     interface SwitchboardResult {
        success: boolean;
        matchedKey: string | null;
        result?: any;
        error?: Error;
        unmatched?: boolean;
    }
     type SwitchboardRoute2<TPayload = any> = (p: TPayload, ctx?: any) => Promise<any> | any;
     type SwitchboardRoutes<TPayload = any, TKey extends string = string> = | { [K in TKey | 'default']?: SwitchboardRoute2<TPayload> } | Map<string, SwitchboardRoute2<TPayload>>;
     interface SwitchboardHandle<TPayload = any, TKey extends string = string> {
        unregister: () => void; // same as your prior unregister()
        registerRoute: (rawKey: string, route: SwitchboardRoute2<TPayload>) => void;
        unregisterRoute: (rawKey: string) => boolean;
        updateRoutes: (routes: Partial<Record<string, SwitchboardRoute2<TPayload>>>) => void;
        getRoutes: () => Record<string, SwitchboardRoute2<TPayload> | undefined>;
        changes: () => AsyncIterable<{ type: 'add' | 'remove' | 'update'; key: string }>;
    }
     interface SwitchboardOptions2<TPayload = any, TKey extends string = string> {
        selectKey: (p: TPayload) => TKey;
        onUnmatched?: (p: TPayload, key: string | null) => void;
    }
     type PlinkoConditionType2 = | 'onSuccess' | 'onFailure' | 'always' | 'envVariable' | 'configValue' | 'fileExists' | 'fileNotExists' | 'itemSuccess' | 'itemFailure' | 'custom' | 'and' | 'or' | 'not' | 'timeBased' | 'rateLimit' | 'random' | 'dependencies';
     type ExecutionMode2 = 'sequential' | 'parallel' | 'firstMatch' | 'allMatch' | 'race';
     type BackoffStrategy2 = 'exponential' | 'linear' | 'fixed' | 'none';
     interface RetryConfig2 {
        max: number;
        backoff: BackoffStrategy2;
        delay?: number;
        maxDelay?: number;
        retryOn?: string[]; // Error types to retry on
    }
     interface PlinkoCondition2 {
        type: PlinkoConditionType2;
        // Environment/Config
        envKey?: string;
        configKey?: string;
        operator?: 'equals' | 'contains' | 'startsWith' | 'endsWith' | 'regex' | 'gt' | 'gte' | 'lt' | 'lte';
        value?: any;
        // File operations
        filePath?: string;
        // Item tracking
        itemLabel?: string;
        // Custom expressions
        expression?: string;
        // Logic operators
        conditions?: PlinkoCondition2[];
        // Time based
        window?: number; // Time window in ms
        limit?: number; // Rate limit count
        // Execution targets
        executeChain?: string | string[] | PlinkoStep2[];
        exe?: PlinkoStep2[];
        // Branching
        onSuccess?: string | PlinkoStep2[];
        onFailure?: string | PlinkoStep2[];
        // Priority (higher runs first)
        priority?: number;
        // Optional label
        label?: string;
        // Timeout for this condition's execution
        timeout?: number;
    }
     interface PlinkoStep2 {
        id?: string;
        label?: string;
        path?: string;
        type: 'chain' | 'parallel' | 'conditionalTree' | 'function' | 'retry' | 'timeout' | 'circuitBreaker';
        args?: any[];
        // Execution
        execute?: (context: PlinkoContext2) => any | Promise<any>;
        // Chain execution (sequential steps)
        steps?: PlinkoStep2[];
        // Conditional tree args
        conditions?: PlinkoCondition2[];
        // Retry configuration
        retry?: RetryConfig2;
        // Timeout in ms
        timeout?: number;
        // Circuit breaker
        circuitBreaker?: {
            failureThreshold: number;
            resetTimeout: number;
            halfOpenMaxCalls: number;
        };
        // Condition to run this step
        condition?: (context: PlinkoContext2) => boolean | Promise<boolean>;
        // Priority
        priority?: number;
        // Dependencies
        dependsOn?: string[];
        // On complete hook
        onComplete?: (result: any, context: PlinkoContext2) => any | Promise<any>;
        onError?: (error: Error, context: PlinkoContext2) => any | Promise<any>;
        // Environment
        environment?: string | string[];
        metadata?: Record<string, any>;
    }
     interface PlinkoContext22 {
        // Original p
        p: any;
        // Shared state
        state: Map<string, any>;
        // Results from each step
        results: Map<string, any>;
        // Execution history
        history: string[];
        // Variables (mutable)
        variables: Map<string, any>;
        // Step results with timestamps
        stepResults: Map<string, StepResult2>;
        // Session ID
        sessionId: string;
        // Start time
        startTime: number;
        // Parent context (for nested executions)
        parent?: PlinkoContext2;
        // Bus reference
        bus: any;
        // Metadata
        metadata: Map<string, any>;
    }
     interface PlinkoContext2 {
        p: any;
        state: Map<any, any>;
        results: Map<any, any>;
        history: string[];
        variables: Map<any, any>;
        stepResults: Map<any, any>;
        sessionId: string;
        startTime: number;
        bus: any;
        metadata: Map<any, any>;
    }
     interface StepResult2 {
        success: boolean;
        result?: any;
        error?: Error;
        duration: number;
        startTime: number;
        endTime: number;
        metadata?: Record<string, any>;
    }
     interface PlinkoTree2<T = any> {
        [key: string]: PlinkoStep2 | PlinkoTree2<T> | ((context: PlinkoContext2) => any);
    }
     interface PlinkoExecutionResult2 {
        sessionId: string;
        success: boolean;
        results: Map<string, StepResult2>;
        history: string[];
        duration: number;
        error?: Error;
        metadata: Record<string, any>;
    }
     type GateMatcher1<T = any> = (p: T) => boolean | Promise<boolean>;
     type GateHandler1<T = any, R = any> = (
        p: T,
        context: {
            reply: (data: any, subrt?: string) => Promise<unknown>;
            store: Map<string, any>;
            bus: any;
        }
    ) => R | Promise<R>;
     interface GateDefinition1<T = any, R = any> {
        priority?: number;
        matcher: GateMatcher1<T>;
        execute: GateHandler1<T, R>;
        persistent?: boolean;
        blocking?: boolean;
    }
     type GateInput1<T = any> =
        | GateMatcher1<T>
        | GateDefinition1<T>;
     type GateMap1<T = any> = Record<string, GateInput1<T>>;
     interface GateExecutionResult1 {
        gateId: string;
        fired: boolean;
        result?: any;
        error?: Error;
        duration: number;
    }
     interface ResolvedGate1<T = any> extends GateDefinition1<T> {
        id: string;
    }
     interface RelayHandle {
        publish: (chunk: any) => Promise<void>;
        subscribe: (handler: (chunk: any) => void) => {
            unsubscribe: () => void;
            pause: () => void;
            resume: () => void;
            getBufferSize: () => number;
        };
        end: () => Promise<void>;
        stats?(): { subscribers: number; ended: boolean };
    }
     interface RelaySubscription {
        unsubscribe(): void;
        pause(): void;
        resume(): void;
        getBufferSize(): number;
    }
     interface RelayOptions {
        maxSubscribers?: number;
        bufferSize?: number;
        backpressureStrategy?: 'drop' | 'pause' | 'error';
    }
     interface OffsetCheckpoint {
        epoch: string;
        offset: number;
    }
     interface RelaySub {
        id: string;
        buffer: WireEnvelope[];
        paused: boolean;
        closed: boolean;
        notify: (() => void) | null;
        pump: Promise<void>;
    }
     interface OffsetStore {
        get(sid: string): Promise<OffsetCheckpoint | undefined>;
        set(sid: string, cp: OffsetCheckpoint): Promise<void>;
        delete(sid: string): Promise<void>;
    }
     interface SyncSubOptions {
        name?: string;
        epoch?: string;          // resume a run from its checkpoint
        maxSkew?: number;
        bufferTtlMs?: number;
        nackDelayMs?: number;
        nackBatch?: number;
        graceMs?: number;
        offsetStore?: OffsetStore;
        checkpointEveryMs?: number;
        onDlq?: (env: WireEnvelope, reason: string) => MaybePromise<void>;
        onComplete?: (err?: Error) => void;
        signal?: AbortSignal;
    }
     interface SyncHandle {
        close(): void;
        whenComplete(): Promise<void>;
        state(): { epoch: string | null; expected: number; buffered: number };
    }
     interface SyncSendOptions {
        name?: string;
        epoch?: string;          // reuse to resume a prior interrupted run
        trace?: string;
        windowSize?: number;
        timeoutMs?: number;
        maxRetries?: number;
        backoffBaseMs?: number;
        onProgress?: (acked: number, total: number) => void;
        onDlq?: (env: WireEnvelope, reason: string) => MaybePromise<void>;
        signal?: AbortSignal;
    }
     interface StreamLabMetrics {
        dataSent: number;
        dataAcked: number;
        dataRetransmitted: number;
        nackSent: number;
        nackReceived: number;
        overflow: number;
        dlq: number;
        dropped: number;
        errors: number;
        streamsActive: number;
        streamsCompleted: number;
        relaySent: number;
    }
     type WireKind = 'data' | 'ack' | 'nack' | 'done' | 'abort' | 'dlq';
     interface WireEnvelope<T = unknown> {
        v: number
        kind: WireKind;
        sid: string;        // deterministic logical stream id
        epoch: string;      // run id — reusing an epoch resumes that run
        seq: number;
        total: number;
        data?: T;
        enc?: 'json' | 'base64';
        trace: string;
        retryOf?: number;
        reason?: string;
    }
     interface SauronState {
        get<T>(key: string | symbol, opts?: ScopeOptions): T | undefined
        set<T>(key: string | symbol, value: T | ((prev: T | undefined) => T), opts?: { triggerRender?: boolean } & ScopeOptions): void
        delete(key: string | symbol, opts?: ScopeOptions): boolean
        getByPrefix<T>(prefix: string, opts?: ScopeOptions): { key: string; value: T }[]
        getAll<T = any>(opts?: ScopeOptions): Record<string | symbol, T>
        subscribe<T>(key: string | symbol, listener: (value: T) => void, opts?: ScopeOptions): () => void
        subscribeAll(listener: (key: string | symbol, value: any) => void, opts?: ScopeOptions): () => void
        clear(opts?: ScopeOptions): void
        waitFor<T = any>(key: string | symbol, opts: ScopeOptions): Promise<T>
        batch?(key: any, fn: () => void): void
    }
     interface HookState {
        value: any
        deps?: any[]
        cleanup?: () => void
        ref?: any
        domRefs?: Map<string, Node>
        bindings?: Set<DOMBinding>
    }
     interface ComponentInstance {
        id: string
        hooks: Map<string, HookState>
        unmount: Set<() => void>
        render?: () => void
        parent?: ComponentInstance | null
        contextProviders?: Map<string, { value: any; subscribe: (fn: () => void) => () => void }>
    }
     interface OptimisticHookState extends HookState {
        previousValue: any
        isPending: boolean
    }
     interface SauronContext<T> {
        id: string;
        DefaultValue?: T;
        Provider?: any;
        sl?: string
        ms?: string
        rt?: string
    }
     interface RuntimeAdapter {
        getComponentInstance: () => { instance: ComponentInstance, forceUpdate: () => void }
        onHookSubscribe: (key: string, forceUpdate: () => void) => void
    }
    
    
    // #region PRIMITIVE TYPES
    
    const IncantationsConfig: IncantationsConfigCreator = (config) => config;
     type ObjectType = Record<string, IncantationsConfig<any, any, any, any, any, any, any, any, any, any>>;
     type SelfType = { self: any;[category: string]: any };
     type Factory = (ctx: SelfType) => ObjectType
    
    
     type AnySelfType = { self: any;[key: string]: any };
     type AnyObject = Record<string, any>;
     type AnyFactory = (ctx: AnySelfType) => AnyObject;
     type AnyType = AnyObject | AnyFactory;
    
    
     type AO = Record<string, any>;
     type AS = { self: any;[key: string]: any };
     type AF = (ctx: AS) => AnyObject;
     type AOAF = AnyObject | AnyFactory;
    
    
     type incan_vars_obj = Record<string, any>;
     type incan_vars_ctx = { self: any;[category: string]: any };
     type incan_vars_vault_factory = (ctx: incan_vars_ctx) => incan_vars_obj | incan_vars_obj;
    
    
     type ArcheTypeCtx = { self: any;[category: string]: any };
    
    
    
    // #endregion ============================================
    // #region FUNCTION TYPES
    // ============================================
     type vault_source = {
      variants?: Record<string, Record<string, any>>;
      base?: ClassInput;
      slots?: Record<string, ClassInput>;
      compoundVariants?: any[];
      defaultVariants?: Record<string, any>;
      animation?: any;
      aliases?: any;
    };
     type base_props = {
      className?: string;
      class?: string;
      children?: any;
      style?: any;
      [key: string]: any;
    };
    
    
     type ClassInput =
      | string
      | number
      | boolean
      | null
      | undefined
      | ClassInput[]
      | Record<string, boolean | null | undefined>;
     type AsConfig = Record<string, ClassInput>;
    
     type AnimationVariant = {
      enter?: ClassInput;
      exit?: ClassInput;
      hover?: ClassInput;
      focus?: ClassInput;
      active?: ClassInput;
    };
    
     type MotionVariant = {
      initial?: Record<string, any>;
      animate?: Record<string, any>;
      exit?: Record<string, any>;
      transition?: Record<string, any>;
      whileHover?: Record<string, any>;
      whileFocus?: Record<string, any>;
      whileTap?: Record<string, any>;
    };
    
    
     type AsNode = Record<string, any> & { parent: string };
    
     type SlotRecord = Record<string, ClassInput>;
    
     type VariantSchema = Record<string, Record<string, ClassInput>>;
    
    
    
     type AnyVariantSchema =
      | VariantSchema
      | SlotVariantSchema;
    
     type AnimationPresetMap = Record<
      string,
      AnimationVariant | MotionVariant
    >;
    
     type ExposedVariants = Record<string, VariantGroup>;
    
    // #endregion ============================================
    // #region BASE PROPS
    // ============================================
    
     type BaseProps = {
      className?: string;
      class?: string;
      children?: any;
      style?: any;
      [key: string]: any;
    };
    
    // #endregion ============================================
    // #region VARIANT GROUP
    // ============================================
    
     type VariantGroup = Record<string, ClassInput> & {
      extend: (
        overrides: Record<string, ClassInput>
      ) => Record<string, ClassInput>;
    };
    
    // #endregion ============================================
    // #region COMPOUND VARIANTS
    // ============================================
    
     type CompoundVariant = {
      variants: Record<string, string>;
      className?: ClassInput;
      style?: A;
      class?: ClassInput;
    };
    
     type SlotVariantSchema1 = Record<
      string,
      Record<string, SlotRecord>
    >;
    
     type SlotVariantSchema = Record<string, Record<string, SlotRecord>>;
    
     type SlotCompoundVariant = {
      variants?: Record<string, string>;
      slots?: string[];
      class: ClassInput;
    };
    
    
    // #endregion ============================================
    // #region STATE MACHINE
    // ============================================
    
     interface StateMachineConfig1 {
      [ComponentVariantKey: string]: {
        initial: string;
        transitions: Record<string, string[]>;
        guards?: Record<string, (props: any, prev: string, next: string) => boolean>;
        onEnter?: Record<string, (props: any, prev: string, next: string) => void>;
        onExit?: Record<string, (props: any, prev: string, next: string) => void>;
        onTransition?: (props: any, prev: string, next: string) => void;
      };
    }
     interface StateMachineConfig {
      initial: string;
      transitions: Record<string, string[]>;
      guards?: Record<string, (props: any, prev: string, next: string) => boolean>;
      onEnter?: Record<string, (props: any, prev: string, next: string) => void>;
      onExit?: Record<string, (props: any, prev: string, next: string) => void>;
      onTransition?: (props: any, prev: string, next: string) => void;
    }
    
    // #endregion ============================================
    // #region MACHINE TYPES
    // ============================================
    
     type MachineState = {
      currentState: Record<string, string>;
    };
    
     type LogicMachine = {
      [logicalState: string]: {
        ON?: Record<string, string>;
        ASYNC_GUARD?: (props: any) => Promise<any> | boolean;
        actions?: string[];
      };
    };
    
     type MachineRunner = {
      states: Record<string, string>;
      send: (
        variantKey: string,
        event: string,
        currentProps: any
      ) => Record<string, string> | undefined;
    };
    
    // #endregion ============================================
    // #region VAULT TYPES
    // ============================================
    
     type VaultSource = {
      variants?: Record<string, Record<string, any>>;
      base?: ClassInput;
      slots?: Record<string, ClassInput>;
      compoundVariants?: any[];
      defaultVariants?: Record<string, any>;
      animation?: any;
      aliases?: any;
    };
    
     type VaultEntry = {
      source: VaultSource;
      variants?: { [variantKey: string]: { [entryKey: string]: string } };
    };
    
     type VaultConfig = {
      vault?: VaultEntry;
      [key: string]: IncantationsConfig | VaultEntry | undefined;
    };
    
    // #endregion ============================================
    // #region FREYR ENUMS
    // ============================================
    
     type FreyrMode = "light" | "dark" | "system" | string;
     type FreyrTheme = "default" | "ocean" | "forest" | "sunset" | string;
     type FreyrVersion = "v1" | "v2" | "v3" | string;
     type FreyrFonts = "sans" | "serif" | "mono" | string;
     type FreyrPresets = "minimal" | "modern" | "vintage" | string;
    
     type IncantationsFreyrContext = {
      theme: FreyrTheme;
      version: FreyrVersion;
      mode: FreyrMode;
    };
    
     type IncantationsFreyr = {
      mode?: FreyrMode;
      theme?: FreyrTheme;
      version?: FreyrVersion;
      fonts?: FreyrFonts;
      presets?: FreyrPresets;
    };
    
    // #endregion ============================================
    // #region INCANTATIONS LEVEL 3
    // ============================================
     type variant_group = Record<string, ClassInput> & {
      extend: (
        overrides: Record<string, ClassInput>
      ) => Record<string, ClassInput>;
    };
    
     type IncantationsLvl3 = {
      db: any;
      bus: any;
      form: any;
      rdb: any;
      loader: any;
      session_mgmt: any;
      signals: any;
      jobs: any;
      fetch: any;
      sauron: any;
      htmx: any;
      cloud: any;
      cron: any;
      action: any;
      auth: any;
      realtime: any;
      reflect: any;
    };
     type vault_entry = {
      source: vault_source;
      variants?: { [variantKey: string]: { [entryKey: string]: string } };
    };
    
    // #endregion ============================================
    // #region GENERIC INCANTATIONS CONFIG
    
     type IncantationsConfig<
      S extends string = never,
      V extends Record<string, Record<string, any>> = Record<string, Record<string, any>>,
      T = unknown,
      I = unknown,
      E = unknown,
      C = unknown,
      SP = unknown,
      SO = unknown,
      CL = unknown,
      G = unknown
    > = {
      // Identifiers
      __S__?: S;
      __V__?: V;
      __T__?: T;
      __I__?: I;
      __E__?: E;
      __C__?: C;
      __SP__?: SP;
      __SO__?: SO;
      __CL__?: CL;
      __G__?: G;
      // NEED TO WORK ON THESE
      timeMachine?: any
      useMachine?: any
      useTimeMachine?: any
      logicMachine?: any
      inlineStyles?: any
      theme?: any
      className?: any
      preset?: any
      __Incantations__?: any
      meta?: any
      staticMeta?: any
      machinesMachine?: any
      router?: any
    
    
      // Types
      enums?: E;
      types?: T;
      interfaces?: I;
      generics?: G;
    
      interface?: I;
      enum?: I;
    
      // Styles
      styles?: {
        base?: A;
        variants?: Record<string, Record<string, A>>;
        defaultVariants?: Record<string, string>;
      };
      slots?: Record<S, ClassInput>;
      // Freyr & Global
      global?: () => G;
      freyrClasses?: string;
      freyrIncantations?: A;
      __globalContent?: Record<string, any>;
      __isGlobalized__?: boolean;
      freyr?: IncantationsFreyr | ((props: any) => any);
      classNames?: ClassInput;
      customTheme?: ClassInput;
      customCSS?: any;
      // Variants
      variants?: V;
      compoundVariants?: S extends never ? CompoundVariant[] : SlotCompoundVariant[];
      defaultVariants?: { [K in keyof V]?: keyof V[K] };
      base?: ClassInput;
    
      // Animations
      animation?: S extends never
      ? AnimationVariant | AnimationPresetMap
      : Record<S, AnimationVariant> | undefined;
      transition?: S extends never
      ? AnimationVariant | AnimationPresetMap
      : Record<S, AnimationVariant> | undefined;
    
      // Extend & Sync
      extend?: string;
      cloud?: CL;
      sync?: string;
      master?: boolean;
    
      // Context
      context?: (props: any) => any;
      useContext?: any;
      createContext?: any;
      sauronContext?: any;
      reactContext?: any;
      useReactContext?: any;
      _compiledReactContext?: any;
    
      // State Machines
      stateMachine?: { [K in keyof V]?: StateMachineConfig; };
      __logicMachineRunner?: any;
      getLogicState?: () => Record<string, string>;
      __machineRunner?: MachineRunner | null;
      getMachineState?: () => Record<string, string>;
      variantMachine?: any;
    
    
    
      // As
      as?: AsConfig;
      asName?: string;
    
      // Singles
      aliases?: { [K in keyof V]?: Record<string, keyof V[K]> };
    
      // Constants & Specs
      constants?: C;
      specs?: SP;
      source?: SO;
    
      // Documentation
      docs?: {
        [K in keyof V]?: {
          description?: string;
          values?: { [J in keyof V[keyof V]]?: string };
        };
      } & { description?: string };
    
      // Dev Tools
      __location?: {
        file: string;
        line: number;
        column: number;
        functionName: string;
      };
      __definitionName?: string;
      __concentrationEnumGraph?: Record<string, TypeGraph>;
      __concentrationInterfaceGraph?: Record<string, TypeGraph>;
      __concentrationGenericGraph?: Record<string, TypeGraph>;
      __IncantationsTypeGraph?: Record<string, TypeGraph>;
    };
    // #endregion ============================================
    // #region TypeGraph  - Complete Type Introspection System
    
     type TypeFlags =
      | "Any"
      | "Unknown"
      | "Boolean"
      | "Number"
      | "String"
      | "Object"
      | "Array"
      | "Function"
      | "TypeParameter"
      | "Union"
      | "Intersection"
      | "Literal"
      | "Enum"
      | "Interface"
      | "Class"
      | "Generic"
      | "Record"
      | "Tuple"
      | "Optional"
      | "Nullable"
      | "Readonly";
    
     type TypeGraph = {
      // Core identification
      id?: string;
      name?: string;
      type: TypeFlags;
      kind?: "primitive" | "composite" | "reference" | "generic";
    
      // Value representation
      value?: any;
      defaultValue?: any;
    
      // Type structure
      properties?: Record<string, TypeGraph>;
      elements?: TypeGraph[];
      indexSignature?: TypeGraph;
    
      // Type parameters (generics)
      typeParameters?: TypeGraph[];
      typeArguments?: TypeGraph[];
      constraint?: TypeGraph;
    
      // Union/Intersection members
      unionMembers?: TypeGraph[];
      intersectionMembers?: TypeGraph[];
    
      // Function types
      parameters?: TypeGraph[];
      returnType?: TypeGraph;
      isAsync?: boolean;
    
      // Class/Interface
      extends?: TypeGraph[];
      implements?: TypeGraph[];
      constructors?: TypeGraph[];
      methods?: Record<string, TypeGraph>;
      accessors?: Record<string, TypeGraph>;
    
      // Enum
      enumMembers?: Record<string, string | number>;
      isStringEnum?: boolean;
      isNumericEnum?: boolean;
    
      // Record types
      keyType?: TypeGraph;
      valueType?: TypeGraph;
    
      // Tuple
      tupleElements?: TypeGraph[];
      isFixedLength?: boolean;
      restElement?: TypeGraph;
    
      // Modifiers
      isOptional?: boolean;
      isNullable?: boolean;
      isReadonly?: boolean;
      isAbstract?: boolean;
      isStatic?: boolean;
    
      // Generic constraints
      extendsConstraint?: TypeGraph;
      defaultType?: TypeGraph;
    
      // Metadata
      description?: string;
      tags?: Record<string, any>;
      source?: {
        file: string;
        line: number;
        column: number;
      };
    
      // Dependencies
      imports?: Record<string, string[]>;
      s?: string[];
      references?: TypeGraph[];
    
      // Runtime info
      runtimeType?: any;
      validator?: (value: any) => boolean;
      serializer?: (value: any) => any;
      deserializer?: (value: any) => any;
    
      // Graph relationships
      parent?: TypeGraph;
      children?: TypeGraph[];
      dependencies?: TypeGraph[];
    
      // Custom metadata
      metadata?: Record<string, any>;
    
      // Timestamps
      createdAt?: Date;
      updatedAt?: Date;
      version?: string;
    };
    
    // #endregion ============================================
    // #region TYPE GRAPH UTILITIES
    // ============================================
    
    // Helper to create primitive types
     function createPrimitiveGraph(
      type: "String" | "Number" | "Boolean" | "Any" | "Unknown" | "Object",
      options?: Partial<TypeGraph>
    ): TypeGraph {
      return {
        type,
        kind: "primitive",
        ...options
      };
    }
    
    // Helper to create object type
     function createObjectGraph(
      properties: Record<string, TypeGraph>,
      options?: Partial<TypeGraph>
    ): TypeGraph {
      return {
        type: "Object",
        kind: "composite",
        properties,
        ...options
      };
    }
    
    // Helper to create array type
     function createArrayGraph(
      elementType: TypeGraph,
      options?: Partial<TypeGraph>
    ): TypeGraph {
      return {
        type: "Array",
        kind: "composite",
        elements: [elementType],
        ...options
      };
    }
    
    // Helper to create union type
     function createUnionGraph(
      members: TypeGraph[],
      options?: Partial<TypeGraph>
    ): TypeGraph {
      return {
        type: "Union",
        kind: "composite",
        unionMembers: members,
        ...options
      };
    }
    
    // Helper to create function type
     function createFunctionGraph(
      parameters: TypeGraph[],
      returnType: TypeGraph,
      options?: Partial<TypeGraph>
    ): TypeGraph {
      return {
        type: "Function",
        kind: "composite",
        parameters,
        returnType,
        ...options
      };
    }
    
    // Helper to create generic type
     function createGenericGraph(
      name: string,
      typeParameters: TypeGraph[],
      constraint?: TypeGraph,
      options?: Partial<TypeGraph>
    ): TypeGraph {
      return {
        type: "Generic",
        kind: "generic",
        name,
        typeParameters,
        constraint,
        ...options
      };
    }
    
    // #endregion ============================================
    // #region TYPE GRAPH PREDICATES
    // ============================================
    
     type TypeGraphPredicates = {
      isPrimitive: (graph: TypeGraph) => boolean;
      isComposite: (graph: TypeGraph) => boolean;
      isGeneric: (graph: TypeGraph) => boolean;
      isUnion: (graph: TypeGraph) => boolean;
      isIntersection: (graph: TypeGraph) => boolean;
      isObject: (graph: TypeGraph) => boolean;
      isArray: (graph: TypeGraph) => boolean;
      isFunction: (graph: TypeGraph) => boolean;
      isEnum: (graph: TypeGraph) => boolean;
      isOptional: (graph: TypeGraph) => boolean;
      isNullable: (graph: TypeGraph) => boolean;
    };
    
    // #endregion ============================================
    // #region TYPE GRAPH TRANSFORMERS
    // ============================================
    
     type TypeGraphTransformers = {
      // Traverse graph
      traverse: (
        graph: TypeGraph,
        visitor: (node: TypeGraph) => void
      ) => void;
    
      // Find nodes
      findNodes: (
        graph: TypeGraph,
        predicate: (node: TypeGraph) => boolean
      ) => TypeGraph[];
    
      // Transform nodes
      mapNodes: (
        graph: TypeGraph,
        mapper: (node: TypeGraph) => TypeGraph
      ) => TypeGraph;
    
      // Collect types
      collectTypes: (graph: TypeGraph) => Set<TypeFlags>;
    
      // Resolve references
      resolveReferences: (
        graph: TypeGraph,
        context: Record<string, TypeGraph>
      ) => TypeGraph;
    
      // Validate
      validate: (
        graph: TypeGraph,
        value: any
      ) => boolean;
    };
    
    
    // #endregion ============================================
    // #region EXAMPLE USAGE
    // ============================================
    
    // Example: Build a type graph for a config
    const stringType = createPrimitiveGraph("String");
    const numberType = createPrimitiveGraph("Number");
    const booleanType = createPrimitiveGraph("Boolean");
    
    const variantSchemaGraph = createObjectGraph({
      size: createUnionGraph([
        createPrimitiveGraph("String", { value: "small" }),
        createPrimitiveGraph("String", { value: "large" })
      ]),
      color: createUnionGraph([
        createPrimitiveGraph("String", { value: "red" }),
        createPrimitiveGraph("String", { value: "blue" })
      ])
    });
    
    const configGraph: TypeGraph = {
      type: "Interface",
      kind: "composite",
      name: "IncantationsConfig",
      properties: {
        variants: variantSchemaGraph,
        defaultVariants: createObjectGraph({
          size: createPrimitiveGraph("String", { defaultValue: "small" })
        })
      },
      typeParameters: [
        {
          type: "TypeParameter",
          name: "S",
          constraint: createPrimitiveGraph("String")
        },
        {
          type: "TypeParameter",
          name: "V",
          constraint: createPrimitiveGraph("Object")
        }
      ]
    };
    // #endregion ============================================
    // #region IncantationsConfigCreator
     type IncantationsConfigCreator = <
      S extends string = never,
      V extends Record<string, Record<string, any>> = Record<string, Record<string, any>>,
      T = unknown,
      I = unknown,
      E = unknown,
      C = unknown,
      SP = unknown,
      SO = unknown,
      CL = unknown,
      G = unknown
    >(
      config: IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>
    ) => IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>;
    
    // #endregion ============================================
    // #region AllIncantationTypes
     type AllIncantationTypes = {
      ClassInput: ClassInput;
      AnimationVariant: AnimationVariant;
      MotionVariant: MotionVariant;
      AsConfig: AsConfig;
      AsNode: AsNode;
      SlotRecord: SlotRecord;
      VariantSchema: VariantSchema;
      SlotVariantSchema: SlotVariantSchema;
      AnyVariantSchema: AnyVariantSchema;
      AnimationPresetMap: AnimationPresetMap;
      ExposedVariants: ExposedVariants;
      BaseProps: BaseProps;
      VariantGroup: VariantGroup;
      CompoundVariant: CompoundVariant;
      SlotCompoundVariant: SlotCompoundVariant;
      StateMachineConfig: StateMachineConfig;
      MachineState: MachineState;
      LogicMachine: LogicMachine;
      MachineRunner: MachineRunner;
      VaultSource: VaultSource;
      VaultEntry: VaultEntry;
      VaultConfig: VaultConfig;
      IncantationsFreyrContext: IncantationsFreyrContext;
      IncantationsFreyr: IncantationsFreyr;
      IncantationsLvl3: IncantationsLvl3;
      TypeFlags: TypeFlags;
      IncantationsConfig: IncantationsConfig;
    };
    
    // #endregion ============================================
    
    // #endregion ============================================
    // #region INFER INCANTATIONS CONFIG
    // ============================================
    
     type InferIncantationsConfig = <
      Cfg extends {
        __S__?: any;
        __V__?: any;
        __T__?: any;
        __I__?: any;
        __E__?: any;
        __C__?: any;
        __SP__?: any;
        __SO__?: any;
        __CL__?: any;
        __G__?: any;
      }
    >(
      config: Cfg
    ) => {
      S: Cfg["__S__"];
      V: Cfg["__V__"];
      T: Cfg["__T__"];
      I: Cfg["__I__"];
      E: Cfg["__E__"];
      C: Cfg["__C__"];
      SP: Cfg["__SP__"];
      SO: Cfg["__SO__"];
      CL: Cfg["__CL__"];
      G: Cfg["__G__"];
      Config: Cfg;
    };
    
    // #endregion ============================================
    // #region VARIANT PROPS
    // ============================================
    
     type VariantProps = {
      [key: string]: any;
      animation?: string;
      preset?: string;
      class?: any;
      className?: any;
      __instanceId__?: string;
      freyr?: FreyrConfig | ((props: any) => any);
    };
    
     type FreyrConfig = {
      mode?: FreyrMode;
      theme?: FreyrTheme;
      version?: FreyrVersion;
      fonts?: FreyrFonts;
      presets?: FreyrPresets;
    };
    
    
    // #endregion ============================================
    // #region SLOTTED RESULT
    // ============================================
    
     type SlottedResult<S extends string = string> = {
      [K in S]?: string;
    } & {
      className?: string;
      class?: string;
      [key: string]: any;
    };
    // #endregion ============================================
    // #region NAMESPACE AUGMENT
    // ============================================
    
     type NamespaceAugment = any; // Define based on your implementation
    
    // #endregion ============================================
    // #region INCANTATIONS RESULT
    // ============================================
    
    // ============================================
    // INCANTATIONS RESULT - Complete Type 
    // (ALL properties from IncantationsConfig + React additions)
    // ============================================
    
    // ============================================
    // INCANTATIONS RESULT - Fixed with proper constraints
    // ============================================
    
     type IncantationsResult<
      S extends string = never,
      V extends Record<string, Record<string, any>> = Record<string, Record<string, any>>,
      T = unknown,
      I = unknown,
      E = unknown,
      C = unknown,
      SP = unknown,
      SO = unknown,
      CL = unknown,
      G = unknown
    > = {
      // ── THE MAIN FUNCTION ────────────────────────────────────────────────────
      (props?: VariantProps & T & {
        animation?: keyof AnimationVariant | string;
        preset?: string;
        class?: any;
        className?: any;
        __instanceId__?: string;
        freyr?: FreyrConfig | ((props: any) => any);
      }): string;
    
      // ── IDENTIFIERS ──────────────────────────────────────────────────────────
      __S__?: S;
      __V__?: V;
      __T__?: T;
      __I__?: I;
      __E__?: E;
      __C__?: C;
      __SP__?: SP;
      __SO__?: SO;
      __CL__?: CL;
      __G__?: G;
    
      // ── TYPES ──────────────────────────────────────────────────────────────
      enums?: E;
      types?: T;
      interfaces?: I;
      generics?: G;
    
      // ── STYLES ──────────────────────────────────────────────────────────────
      styles?: {
        base?: A;
        variants?: Record<string, Record<string, A>>;
        defaultVariants?: Record<string, string>;
      };
      slots?: Record<S, ClassInput>;
      base?: ClassInput;
    
      // ── VARIANTS ──────────────────────────────────────────────────────────────
      variants?: V;
      compoundVariants?: S extends never ? CompoundVariant[] : SlotCompoundVariant[];
      defaultVariants?: { [K in keyof V]?: keyof V[K] };
    
      // ── ANIMATIONS ──────────────────────────────────────────────────────────
      animation?: S extends never
      ? AnimationVariant | AnimationPresetMap
      : Record<S, AnimationVariant> | undefined;
      transition?: S extends never
      ? AnimationVariant | AnimationPresetMap
      : Record<S, AnimationVariant> | undefined;
    
      // ── EXTEND & SYNC ──────────────────────────────────────────────────────
      extend?: string;
      cloud?: CL;
      sync?: string;
      master?: boolean;
    
      // ── CONTEXT ──────────────────────────────────────────────────────────────
      context?: (props: any) => any;
      useContext?: any;
      createContext?: any;
      sauronContext?: any;
      reactContext?: any;
      _compiledReactContext?: any;
    
      // ── STATE MACHINES ────────────────────────────────────────────────────
      stateMachine?: {
        [K in keyof V]?: StateMachineConfig;
      };
      logicMachine?: LogicMachine;
      __logicMachineRunner?: any;
      getLogicState?: () => Record<string, string>;
      __machineRunner?: MachineRunner | null;
      getMachineState?: () => Record<string, string>;
      variantMachine?: any;
    
      // ── FREYR & GLOBAL ──────────────────────────────────────────────────────
      global?: () => G;
      freyrClasses?: string;
      freyrIncantations?: A;
      __globalContent?: Record<string, any>;
      __isGlobalized__?: boolean;
      freyr?: IncantationsFreyr | ((props: any) => any);
      classNames?: any;
      customTheme?: any;
      customCSS?: any;
    
      // ── AS ──────────────────────────────────────────────────────────────────
      as?: AsConfig;
      asName?: string;
    
      // ── SINGLES ──────────────────────────────────────────────────────────────
      aliases?: { [K in keyof V]?: Record<string, keyof V[K]> };
    
      // ── CONSTANTS & SPECS ──────────────────────────────────────────────────
      constants?: C;
      specs?: SP;
      source?: SO;
    
      // ── DOCUMENTATION ──────────────────────────────────────────────────────
      docs?: {
        [K in keyof V]?: {
          description?: string;
          values?: { [J in keyof V[keyof V]]?: string };
        };
      } & { description?: string };
    
      // ── DEV TOOLS ──────────────────────────────────────────────────────────
      __location?: {
        file: string;
        line: number;
        column: number;
        functionName: string;
      };
      __definitionName?: string;
      __concentrationEnumGraph?: Record<string, TypeGraph>;
      __concentrationInterfaceGraph?: Record<string, TypeGraph>;
      __concentrationGenericGraph?: Record<string, TypeGraph>;
      __IncantationsTypeGraph?: Record<string, TypeGraph>;
    
      // ── REACT CONTEXT (Added by wizard template) ──────────────────────────
      ReactContext: A;
      createReactContext: (props?: any) =>A;
      useReactContext: () => any;
    
      // ── SUB-COMPONENT UTILITIES ─────────────────────────────────────────────
      extendResult: (
        overrides: Partial<IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>>
      ) => IncantationsResult<S, V, T, I, E, C, SP, SO, CL, G>;
    };
    // #endregion ============================================
    // #region INCANTATIONS RESULT CREATOR
    // ============================================
    
     type IncantationsResultCreator = <
      S extends string = never,
      V extends AnyVariantSchema = any,
      T = unknown,
      I = unknown,
      C = unknown,
      SP = unknown,
      SO = unknown,
      CL = unknown,
      E = unknown,
      G = unknown
    >(
      config: ((
        props?: VariantProps & T & {
          animation?: keyof AnimationVariant | string;
          preset?: string;
          class?: any;
          className?: any;
          __instanceId__?: string;
          freyr?: FreyrConfig | ((props: any) => any);
        }
      ) => string) & {
        // ── CORE HOOKS & PROCESSING ENGINE ──────────────────────────────────────
        slots: (
          props?: VariantProps & {
            preset?: string;
            class?: Partial<Record<S, ClassInput>>;
            className?: Partial<Record<S, ClassInput>>;
            __instanceId__?: string;
            freyr?: FreyrConfig | ((props: any) => any);
          }
        ) => SlottedResult<S>;
    
        // ── THE INLINE STYLES SYSTEM ───────────────────────────────────────────
        styles?: Record<string, any>;
        inlineStyles?: A;
        freyrClasses?: string;
        freyrIncantations?: A;
        classNames?: any;
        customTheme?: any;
        customCSS?: any;
    
        // ── BLUEPRINT ECHOES (CONFIG TO RESULT COPIES) ───────────────────────────
        types: T;
        interface: I;
        enum: E;
        constants: C;
        specs: SP;
        source: SO;
        cloud: CL;
        as: AsConfig;
        variants: ExposedVariants;
        compoundVariants?: any[];
        defaultVariants?: Record<string, any>;
        aliases?: Record<string, string>;
        docs?: string;
    
        // ── ADVANCED NESTED ENGINES ──────────────────────────────────────────────
        variantMachine?: Record<string, any>;
        transition?: {
          show?: Record<string, any>;
          hide?: Record<string, any>;
          [key: string]: any;
        };
    
        // ── SYSTEM MIGRATION & REACTION THREADS ──────────────────────────────────
        sync?: string;
        master?: boolean;
        context: (props: any, __sauron_id__?: string) => I;
        createContext?: any;
        sauronContext?: any;
        global: NamespaceAugment;
    
        // ── STATE ENGINE ACCESSORS (EXPOSED RUNTIMES) ────────────────────────────
        stateMachine?: Record<string, any>;
        logicMachine?: Record<string, any>;
        __machineRunner?: any;
        __logicMachineRunner?: any;
        getMachineState?: () => Record<string, any>;
        getLogicState?: () => Record<string, any>;
        useMachine?: (props?: any) => {
          state: Record<string, any>;
          setState: (key: string, value: any) => void;
        } & Record<string, (value: any) => void>;
    
        // ── GLOBALIZATION & COMPILER PROFILES ────────────────────────────────────
        __globalContent?: any;
        __isGlobalized__?: boolean;
        __location: string;
        __definitionName: string;
    
        // ── SUB-COMPONENT UTILITIES ─────────────────────────────────────────────
        extend: (
          overrides: Partial<IncantationsConfig<S, V, T, I, E, C, SP, SO, CL, G>>
        ) => IncantationsResult<S, V, T, I, C, SP, SO, CL, E, G>;
      }
    ) => IncantationsResult<S, V, T, I, C, SP, SO, CL, E, G>;
    
    
    // #endregion ============================================
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    // #endregion
}

