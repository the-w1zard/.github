
<div align="left" style="position: relative;">
<img src="./icons/gandalf.png" align="right" width="30%" style="margin: -20px 0 0 20px;">

<h1>CRDT & Sync Primitives: <span style="font-size:18px;" >The Wizard's Arsenal</span></h1>

<p align="left"><em>The most opinionated platform... ever.</em></p>
<p align="left"><em>Trust me... I'm a fucking wizard... 🧙</em></p>
<p align="left">VSCode ext:</p>
<p align="left">
<img src="https://img.shields.io/badge/THEMES- 251-95ED27?style=flat">
<img src="https://img.shields.io/badge/SIDEBARS- 160+-95ED27?style=flat">
<img src="https://img.shields.io/badge/PRODUCT ICONS- 651-95ED27?style=flat">
<img src="https://img.shields.io/badge/FILE ICONS- 454-95ED27?style=flat">
<img src="https://img.shields.io/badge/VSCode Extentions- 82+-95ED27?style=flat">
<img src="https://img.shields.io/badge/FEATURES- SHIT TONNE-95ED27?style=flat">
</p>
<p align="left">Small but powerful repos worth checking out:</p>
<p align="left">

<a href="https://github.com/the-w1zard/app_store"><img src="https://img.shields.io/badge/Store / Maelstrom-000000.svg?style=flat&logo=JetBrains&logoColor=white" alt="JetBrains"></a>
<a href="https://github.com/the-w1zard/dx"><img src="https://img.shields.io/badge/UX /DX-34A853.svg?style=flat&logo=Android&logoColor=white" alt="Android"></a>
<a href="https://github.com/the-w1zard/temporal_shift"><img src="https://img.shields.io/badge/Temporal Shift-77AA99.svg?style=flat&logo=Org&logoColor=white" alt="Org"></a>
<a href="https://github.com/the-w1zard/the_cloud"><img src="https://img.shields.io/badge/The Cloud-02303A.svg?style=flat&logo=Gradle&logoColor=white" alt="Gradle"></a>
<a href="https://github.com/the-w1zard/signals"><img src="https://img.shields.io/badge/Signals-02303A.svg?style=flat&logo=Gradle&logoColor=white" alt="Gradle"></a>
<img src="https://img.shields.io/badge/Sometimes, my genius... It generates gravity.-4285F4.svg?style=flat&logo=🧙&logoColor=white" alt="Google">
<a href="https://github.com/the-w1zard"><img src="https://img.shields.io/badge/Coming Soon: The Wizard Platform-7F52FF.svg?style=flat&logo=Kotlin&logoColor=white" alt="Kotlin"></a>
<a href="https://github.com/the-w1zard"><img src="https://img.shields.io/badge/Coming Soon: Hadron Particle Disruptor-%23ED8B00.svg?style=flat&logo=openjdk&logoColor=white" alt="java"></a>
</p>
<p align="left">The goal? To remove all friction, from everything.</p>

</div>
<br clear="right">

## Table of Contents

### 🔗 [THE_WIZARD]

- I. [TLDR](#-tldr)
- II. [HYBRID_LOGICAL_CLOCK](#hybrid_logical_clock)
- III. [LWW_REGISTER](#lww_register)
- IV. [OR_SET](#or_set)
- V. [DRSHeartbeatManager](#drsheartbeatmanager)
- VI. [YMIR](#ymir)
- VII. [AW_SET](#-deferred-tasks)
- VII. [CASUAL CURSOR](#-module-resolution)
- VII. [DELTA STORE](#-apparations-and-safe-fallbacks)
- VII. [G_SET](#-usage-quick-reference-sheet)
- VII. [VERSION VECTOR](#-usage-quick-reference-sheet)
- VII. [CIRCUIT BREAKER](#-usage-quick-reference-sheet)
- VII. [CQRS](#-usage-quick-reference-sheet)
- VII. [DIFFPATCH](#-usage-quick-reference-sheet)
- VII. [HYBRID LOGICAL CLOCK](#-usage-quick-reference-sheet)
- VII. [HYBRID LOGICAL CLOCK CRDT](#-usage-quick-reference-sheet)
- VII. [LWW](#-usage-quick-reference-sheet)
- VII. [LWW_ELEMENTAL](#-usage-quick-reference-sheet)
- VII. [MV](#-usage-quick-reference-sheet)
- VII. [OPTIMISTIC](#-usage-quick-reference-sheet)
- VII. [OR](#-usage-quick-reference-sheet)
- VII. [PN](#-usage-quick-reference-sheet)
- VII. [YIMIR](#-usage-quick-reference-sheet)
- VII. [SEMAPHORE](#-usage-quick-reference-sheet)
- VII. [TOMBSTONE COMPACTOR](#-usage-quick-reference-sheet)
- VII. [REVERSE HEARTBEAT MGR](#-usage-quick-reference-sheet)

---
<span  style="font-family: monospace"> 


> [!NOTE] TLDR
>
> 

</span>


COMHRENSIVE README INCLUDING
- FIRST TIME USAGE, WHERE THE USER USES THE MOS BASIC VERSION OF IT AND IS ABLE TO SUCCESFULLY USE IT IN UNDER 5 MINS
- IN DEPTH OVERVIEW
- THEN IN DEPTH USAGE LIKE TALKABOUT WHAT USE CASES IT SFOR
- IN DEPTH COVERAGE OF ALL UUSER USAGES

Understood — getting a single one actually finished. `AW_SET`, done, no gaps, no hedges, no mid-doc corrections. This is it.

# AW_SET

### Binary Add-Wins Set CRDT

---

## Quick Start

```ts
import { AW_SET } from "./aw_set";

const tags = new AW_SET("device-1");

tags.add("urgent");
tags.add("needs-review");

tags.has("urgent");          // true
tags.values();                 // ["urgent", "needs-review"]

tags.remove("needs-review");
tags.has("needs-review");    // false
```

One device, no sync — that's the whole API: `add`, `remove`, `has`, `values`.

Two devices that need to agree on the same set:

```ts
// device A
const deviceA = new AW_SET("device-a");
deviceA.add("urgent");

const bytes = deviceA.generateDelta();

// device B
const deviceB = new AW_SET("device-b");
deviceB.mergeDelta(bytes, "device-a");   // second arg: who you're syncing with

deviceB.has("urgent"); // true
```

---

## Constructor

```ts
new AW_SET(localNodeId: string, initialCapacity: number = 1024)
```

- `localNodeId` — identifies this device/tab/process. Must be distinct from other nodes you'll sync with.
- `initialCapacity` — preallocated slot count. Grows automatically; only matters for avoiding reallocation under heavy churn.

---

## Core API

```ts
.add(element: string): void
.remove(element: string): void
.has(element: string): boolean
.values(): string[]
```

Conflict rule: if an add and a remove happen on different devices without either knowing about the other, **the add wins** once they sync.

```ts
const a = new AW_SET("node-a");
const b = new AW_SET("node-b");

a.add("bug");
b.mergeDelta(a.generateDelta(), "node-a");

b.remove("bug");    // b removes it
a.add("bug");         // a re-adds it, unaware of b's remove

a.mergeDelta(b.generateDelta(), "node-b");
b.mergeDelta(a.generateDelta(), "node-a");

a.has("bug"); // true
b.has("bug"); // true
```

---

## Syncing

```ts
.version: number
.generateDelta(sinceVersion?: number): Uint8Array
.mergeDelta(deltaBytes: Uint8Array, senderNodeId: string): void
```

`generateDelta()` with no argument sends full current state — use this for a first sync with a new peer. After that, track the version you last sent and pass it in to send only what changed:

```ts
let lastSynced = 0;

function sync() {
  const delta = set.generateDelta(lastSynced);
  lastSynced = set.version;
  transport.send(delta);
}
```

`mergeDelta()` requires `senderNodeId` — the id of the peer you're syncing with. This is required, not optional, because it's how the set tracks which peers have acknowledged which removals (needed for `compact()`, below). Safe to call repeatedly with the same bytes — re-merging an already-applied delta is a no-op.

---

## Removing old tombstones: `.compact()`

```ts
.compact(): number   // returns rows dropped
```

Removed items aren't deleted immediately — they're kept as tombstones so a peer who hasn't synced yet still resolves conflicts correctly when they catch up. `compact()` drops tombstones once it's confirmed safe to do so.

"Safe" means: every peer you've directly synced with (via `mergeDelta`) has, per the digest they sent you, already acknowledged that specific removal. It will not compact a removal if any synced peer hasn't shown awareness of it, and it will not compact anything related to a peer you've never synced with at all — in that case `compact()` returns `0`.

```ts
const a = new AW_SET("node-a");
const b = new AW_SET("node-b");

a.add("bug");
b.mergeDelta(a.generateDelta(), "node-a");

b.remove("bug");
a.mergeDelta(b.generateDelta(), "node-b"); // a now has b's digest, confirming the removal

a.compact(); // drops the tombstone — b's digest proves it's acknowledged
```

If `b` never sends anything back to `a`, `a.compact()` returns `0` — no digest from `b` means nothing involving `b`'s actions is provably safe to drop.

---

## Hash collisions

Element names and node ids are hashed internally. If two different strings were ever merged as if they were the same element because of a hash collision, that would be silent data corruption. This class checks for that on every local use and every merge — if a real collision is ever detected, it throws immediately instead of merging:

```
Error: AW_SET: hash collision for element identity — "foo" and "<other string>" both hash to <value>.
```
